from pathlib import Path
import json,hashlib,datetime,runpy,copy,sys,subprocess
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch16-2026-11-08/';f=root/folder
read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()
pre=read(p/'preflight.json');matrix=read(f/'decision-matrix.json');g=runpy.run_path(str(p/'GLOBAL16-RULES.py'));rules=runpy.run_path(str(p/'BATCH16-RULES.py'));bank=read(p/'runtime-before.json')['bank'];reference=g['load_reference']((p/'reference-bank.json').read_bytes())
args=[bank,matrix,read(f/'exact-comparisons.json'),read(f/'blind-solutions.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidates.json'),{d['questionId']:(f/'reports'/(d['questionId']+'.md')).read_text(encoding='utf8') for d in matrix['decisions']},{f'2026-10-27.{i}':read(root/f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}]
def rejects(call):
    try:call()
    except AssertionError:return True
    return False
rules['check'](*args);g['check_bank'](bank,reference)
outside=copy.deepcopy(args);outside[0][1]['text']['en']='adulterated bank';assert outside[0][1]['id']=='tl-002' and outside[0][1]!=bank[1]
assert rules['check'](*outside)['result']=='PASS' and rejects(lambda:g['check_bank'](outside[0],reference)) and rejects(lambda:g['check_bank'](outside[0],outside[0]))
inside=copy.deepcopy(args);next(q for q in inside[0] if q['id']=='tl-084')['text']['en']='adulterated bank';assert rejects(lambda:rules['check'](*inside))
route={'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'intactControlsPassed':True,'tl002MutationInjectedIntoActualArgument':True,'tl002ScopedControlPassed':True,'tl002GlobalRejected':True,'tl084ScopedRejected':True,'poisonedReferenceRejected':True,'layerContract':'Scope2 evidence / immutable full90 object equality; out-of-scope edits intentionally delegated globally'}
(p/'layer-routing-result.json').write_text(json.dumps(route,indent=2)+'\n')

sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
source=[]
for src in read(f/'sources.json')['sources']:
 b=(Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0')/src['fileName']).read_bytes();assert sha(b)==src['sha256'];pdf=pymupdf.open(stream=b,filetype='pdf');assert len(pdf)==src['pageCount'];checks=[]
 for d in matrix['decisions']:
  for section,pages in d['references'].items():
   numbers=pages[src['language']];texts=''.join(pdf[n-1].get_text() for n in numbers);headerPage=next((n for n in numbers if section in pdf[n-1].get_text()),None)
   if headerPage is None:
    # A citation may legitimately point to a continuation page, as EN2.2.1 on page29.
    previous=min(numbers)-1;assert previous>=1 and section in pdf[previous-1].get_text();headerPage=previous
   checks.append({'questionId':d['questionId'],'section':section,'physicalPages':numbers,'sectionFound':True,'headerPhysicalPage':headerPage,'continuationPageCitation':headerPage not in numbers})
  assert d['learningObjective'] in ''.join(pdf[n-1].get_text() for n in d['LOPages'][src['language']])
 source.append({'language':src['language'],'edition':src['edition'],'sha256':sha(b),'pageCount':len(pdf),'sectionAndLOChecks':checks})
(p/'source-verification-result.json').write_text(json.dumps({'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':source,'webStatus':'EN and PT official endpoints accessible this execution; local official copies hashed; remote raw-byte equality not asserted','fullPDFsOrPageTextsExported':False},ensure_ascii=False,indent=2)+'\n')
mathCases=[{'p95ms':v,'limitMS':300,'users':200,'expected':ok,'actual':v<=300} for v,ok in [(299.999,True),(300,True),(300.001,False)]];assert all(x['actual']==x['expected'] for x in mathCases)
sample=[250]*95+[450]*5;nearestRank95=sorted(sample)[94];assert nearestRank95<=300 and max(sample)>300
mathResult={'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':4,'inclusiveLimitCases':mathCases,'percentileCounterexample':{'method':'Illustrative nearest-rank only; not a mandated estimator for the question','sampleCount':100,'lowCount':95,'lowMS':250,'tailCount':5,'tailMS':450,'p95MS':nearestRank95,'maxMS':max(sample),'p95LimitSatisfied':True,'allResponsesLimitSatisfied':False},'scope':'Synthetic mathematical interpretation only; no real load test or user data; question leaves estimator/sampling unspecified'}
(p/'math-interpretation-result.json').write_text(json.dumps(mathResult,indent=2)+'\n')
# Confirm every established first8 fixture in both earlier multiple-choice groups remains present.
import zipfile
with zipfile.ZipFile(Path('C:/Users/gabri/Downloads')/pre['priorPackageName']) as z:previousScore=json.loads(z.read('evidence/checks/multiple-answer-scoring.log'))
score=json.loads((p/'multiple-answer-scoring.log').read_text());assert score['syntheticCases']==36 and len(score['questionChecks'])==4 and all(len(q['syntheticSelections'])==9 for q in score['questionChecks'])
for oldq in previousScore['questionChecks']:
 q=next(q for q in score['questionChecks'] if q['questionId']==oldq['questionId']);assert q['syntheticSelections'][:8]==oldq['syntheticSelections']
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
for n in ['blind-projection.json','blind-solutions.json']:assert (f/n).read_bytes()==(p/n).read_bytes()
for x in f.rglob('*.json'):read(x)
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
inventory=read(f/'file-inventory.json');inventory.update(afterGitStatus=git('status','--untracked-files=all'),existingFilesChanged=[],recordedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),newDocumentPaths=sorted(x.relative_to(root).as_posix() for x in f.rglob('*') if x.is_file()),frozenBlindSHA256={n:sha((p/n).read_bytes()) for n in ['blind-projection.json','blind-solutions.json']})
(f/'file-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
metas={n:read(p/(n+'-result.json')) for n in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']};assert all(v['exitCode']==0 for v in metas.values())
text="""# Lote 16 — verificação técnica e limites

Preflight e soluções cegas em 2026-11-07 UTC; dossiê e verificações posteriores em 2026-11-08 UTC. Não se retrodatam horários nem se apresentam logs históricos como execuções novas. O dossiê identifica a data real de criação.

## Baseline e preservação

Preflight PASS: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10. ZIP do Lote 15 autenticado por SHA-256 387a3e01f6c6b87bd3ad5229477fe7286f6a2c955bf4a82e114d0d980b4df68e, CRC, 517 hashes, 518 membros e verificador portátil em extração limpa. As 244 referências do repositório coincidiram com os bytes atuais. Inventário inicial: 409 ficheiros rastreados/não ignorados, 195 não rastreados e 206 documentos académicos anteriores.

Integridade nova: 90 objetos completos iguais à referência fixa autenticada, incluindo 364 alternativas, 64 objetivos, IDs, gabaritos, versões e explicações. Nove arquivos .1–.9 byte-idênticos ao HEAD e ao inventário inicial. Todos os 409 ficheiros anteriores preservados, incluindo guards e evidências de falhas/recuperações; nenhuma revisão .11. Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED novo.

## Resultados novos

| Gate | Resultado |
| --- | --- |
| BATCH16 completo | PASS: duas questões, dez alternativas, duas respostas por item, 96 blocos literais e comparações lado a lado |
| Negativos encaminhados | PASS: 26 rejeitados, 25 específicos e um global; inclui chave, parcial/excedente, cardinalidade, tradução, versão/revisão, explicação, histórico, fontes, aprovação falsa e relatório ausente |
| GLOBAL16 | PASS: igualdade dos 90 objetos completos com referência fixa do ZIP anterior |
| Negativos globais | PASS: 96 rejeitados, incluindo 90 mutações individuais de enunciado e chave, versão, explicação, ID ausente/duplicado e referência igualmente adulterada |
| Encaminhamento | PASS: tl-084 rejeitada pelo específico; tl-002 fora do lote aceita pelo controlo de âmbito específico e rejeitada pela proteção global; nenhuma mutação aplicada ao banco real |
| Vitest direcionado | PASS: 85 testes em seis ficheiros, sem skips |
| Seleção múltipla | PASS: 36 casos, nove em cada tl-001, tl-083, tl-084 e tl-085; os 16 casos anteriores preservados, 16 equivalentes acrescentados e quatro combinações corretas/incorretas adicionais |
| Matemática do requisito | PASS: três casos de fronteira inclusiva e um contraexemplo sintético que distingue p95 de máximo individual; não é teste de carga real |
| Fontes e JSON | PASS: cópias locais oficiais, hashes, páginas e LO/K; continuidade de secção EN2.2.1 citada no corpo da página 29, com cabeçalho na página 28 verificado |
| Formato | PASS: Prettier nos dez ficheiros novos aplicáveis; dois JSON cegos congelados, validados sem reformatar |
| git diff --check | PASS; os documentos não rastreados recebem guard, JSON e formato próprios porque este comando não os cobre |

Os seis ficheiros reexecutados são academic-audit, bank-history, backup, syllabus-coverage, quality-maintenance e blueprint. Comandos, horários UTC, exit codes e logs completos estão em evidence/checks. Nenhum teste ou controlo foi removido ou enfraquecido. Não houve falha crítica neste lote.

## Conferência dos metadados

O rótulo layerContract inicialmente herdado dizia Scope8, embora a lista e os objetos realmente verificados já fossem os dois itens deste lote. Foi corrigido para Scope2, sem alterar guard, testes, dados ou expectativas, e os controlos foram reexecutados. O registo original permanece em evidence/checks/metadata-label-adjustment.json. Não se apresenta a etiqueta anterior como descrição válida do âmbito nem como falha do banco.

## Limitações

Não se repetiram TypeScript, ESLint, build nem E2E completos: não há alteração de banco, implementação, pontuação ou persistência. O carregamento runtime é comparação de dados, não typecheck completo. Não se executou guard académico legado como se fosse deste lote. Não houve acesso a dados reais, perfis ou LocalStorage: os testes usam apenas cópias em memória ou staging temporário.

Fontes EN v4.0.1 e PT v4.0 tradução 1.0 não são textualmente idênticas. Ambos os endpoints oficiais ficaram acessíveis; páginas e hashes referem-se às cópias oficiais locais, sem alegar igualdade remota de bytes. Nenhuma fonte contém uma definição detalhada de estimador do percentil: o raciocínio matemático do requisito está separado das regras do syllabus. O exemplo nearest-rank é apenas ilustração, não imposição ao banco. Não se executou carga real de 200 utilizadores nem se inventou método, duração ou limiar adicional.

Dois pareceres ACCEPT_AS_IS; nenhuma correção obrigatória ou proposta editorial justificada. Coincidência de chave não foi prova única; as dez alternativas, explicações, traduções e interpretações concorrentes estão analisadas. Revisão por IA não é aprovação académica humana. Fase 10H aberta, pendente de reconciliação global e revisão humana independente, não iniciadas automaticamente.

## Exportação condicionada

Só após os gates, comparar diretamente todos os 518 membros anteriores, preservar manifesto e metadados históricos e produzir novo manifesto. Os testes de pacote, CRC, extração limpa e hashes têm registo próprio no export-result.json externo e no pacote. Não se antecipam resultados desses passos neste documento.

## Metadados novos

```json
"""+json.dumps({'specific':read(p/'batch16-specific-execution.json'),'integrity':read(p/'integrity-execution.json'),'commands':metas,'layerRouting':route,'mathematicalChecks':mathResult},ensure_ascii=False,indent=2)+'\n```\n'
(f/'verification.md').write_text(text,encoding='utf8')
(p/'verification-helpers-execution.json').write_text(json.dumps({'command':[sys.executable,str(p/'record-verification.py')],'startedAt':startedAt,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'checks':['layer routing','official source identity/pages','4 mathematical cases','preserved earlier16 scoring fixtures','JSON','file preservation']},indent=2)+'\n')
print(json.dumps({'result':'PASS','sourceCount':len(source),'mathChecks':4,'scoringChecks':36,'earlier16CasesPreserved':True,'existing409Preserved':True,'layerRouting':route},indent=2))
