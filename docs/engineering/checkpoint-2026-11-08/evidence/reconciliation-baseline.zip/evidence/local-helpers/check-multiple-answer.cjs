// Synthetic selections only; no storage, profiles or student data.
const fs=require('node:fs'),root=process.argv[2],local=require('node:module').createRequire(root+'/package.json'),ts=local('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,esModuleInterop:true,target:ts.ScriptTarget.ES2022}}).outputText,f);
const bank=local('./src/data/questions.ts').questions,{isCorrect}=local('./src/domain/engine.ts'),checks=[];
for(const [id,key] of [['tl-001',['o1','o4']],['tl-083',['o2','o4']],['tl-084',['o1','o4']],['tl-085',['o2','o5']]]){
 const q=bank.find(q=>q.id===id),[a,b]=key;
 if(q.required!==2||JSON.stringify(q.correct)!==JSON.stringify(key))throw new Error('Published multi-select contract differs: '+id);
 const wrong={'tl-001':'o2','tl-083':'o5','tl-084':'o2','tl-085':'o1'}[id];
 const cases=[{selection:[],expected:false},{selection:[a],expected:false},{selection:[b],expected:false},{selection:[a,b],expected:true},{selection:[b,a],expected:true},{selection:[a,b,wrong],expected:false},{selection:[wrong],expected:false},{selection:[a,a,b],expected:false},{selection:[a,wrong],expected:false}];
 for(const c of cases){c.actual=isCorrect(q,c.selection);if(c.actual!==c.expected)throw new Error('Exact-set scoring mismatch: '+id+' '+JSON.stringify(c));}
 checks.push({questionId:id,required:q.required,publishedKey:q.correct,optionCount:q.options.length,syntheticSelections:cases});
}
process.stdout.write(JSON.stringify({result:'PASS',questionChecks:checks,syntheticCases:36,storageAccessed:false},null,2));
