# TestLearn — Fase 10H, Lote 15

Âmbito exclusivo: tl-069, tl-070, tl-075, tl-079, tl-080, tl-081, tl-082 e tl-083. São oito questões e 33 alternativas: tl-083 já tem cinco alternativas e exige DUAS respostas no banco e no ZIP autenticado, em vez da premissa de quatro alternativas por item no pedido. Todas foram revistas; não houve ampliação para outra questão nem alteração do banco. Os sete itens restantes têm quatro alternativas e uma resposta.

Oito pareceres ACCEPT_AS_IS por IA, não aprovação SME humana. A triagem NONE não foi usada como evidência. Soluções, fundamentos individuais, horário e hash foram congelados antes da revelação de chaves e explicações. Nenhuma correção obrigatória ou proposta editorial justificada; sugestões não são aplicadas automaticamente. Os blocos literais originais PT/EN ficam separados da análise e têm comparação antes/depois idêntica.

Baseline: develop; HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049; revisão 2026-10-27.10; 90 questões, 364 alternativas e 64 objetivos. ZIP do Lote 14 autenticado: 47ad385f5cd7f7fe2761ff6bae56312779c71825c753d3f0bb04a46997894c04, 471 membros e 470 hashes. Inventário inicial: 391 ficheiros rastreados/não ignorados, 177 não rastreados e 188 documentos académicos anteriores. Todos são preservados, incluindo falhas e recuperações anteriores.

Fontes EN v4.0.1 e PT v4.0 tradução 1.0 consultadas por secção e página física nas cópias oficiais locais, com hashes em sources.json. EN web acessível; PT web teve timeout nesta execução. Não se inventa novo download PT nem igualdade textual ou remota dos bytes. Não foi necessário glossário separado.

Resultados conceptuais: BDD não executa frases arbitrárias sem suporte; famílias de técnicas dependem da derivação e não da automação; baselines apoiam reprodução sem garantir todo contexto externo; cobertura de ramos não equivale a requisitos cobertos; fim de suporte é risco futuro; competências são condição na whole team approach; quadrantes classificam perspetiva e propósito, não estimativas; tipos de revisão não herdam automaticamente restrições de inspeção.

Duas camadas: BATCH15-RULES valida oito objetos, as 33 alternativas e os 328 blocos literais, respeitando a cardinalidade fixa autenticada de cada item. GLOBAL15-RULES compara 90 objetos completos com referência imutável extraída do ZIP anterior, nunca gerada do candidato. tl-002 adulterada vai para a proteção global; tl-069 é também protegida pelo guard específico. Não se enfraquecem asserções para obter PASS.

Sem alterações ao banco, históricos, código, testes do projeto, persistência, versões ou pontuação. tl-001 mantém o conjunto exato o1/o4 e tl-083 o conjunto o2/o4, com required=2 em ambos. Sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Integridade técnica não é verdade académica nem aceite do proprietário.

Logs novos e históricos separados em verification.md e evidence/checks do pacote. Exportar só após gates passarem, com continuidade direta dos 471 membros anteriores. Esta exportação é dossiê de evidência, não repositório executável completo. Fase 10H aberta; parar após Lote 15 e aguardar auditoria. Sem Lote 16, commit, push, merge, PR ou deploy.


# tl-069 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.3 / K1; versão 2; revisão 2026-10-27.10; SHA-256 canónico `5ceb5524a517d84ee85d867b65e8a77343dc9f263c251630ae0cfe0c0044bf88`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

O BDD usa descrições compreensíveis de comportamento esperado em linguagem natural partilhada, ligadas a exemplos executáveis. O ciclo de testes de componentes, implementação e refatoração é TDD; revisão de código e exploração são outras práticas. A justificação geral publicada já rejeita geração automática infalível sem código de suporte.

Raciocínio guardado antes da revelação:

BDD expressa comportamento esperado em linguagem natural compreensível e partilhada, com exemplos ligados a testes executáveis. Não se confunde com ciclo de testes de componentes primeiro, revisão de código ou exploração da funcionalidade já implementada.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 2.1.3: EN páginas [26]; PT páginas [28].

- LO FL-2.1.3/K1: EN página 24; PT página 26.

EN página 26 diz que os testes devem depois ser traduzidos automaticamente para testes executáveis; PT página 28 usa uma formulação descritiva mais categórica. Ambas descrevem a ligação à execução, não um mecanismo infalível para toda frase natural. A ressalva publicada é compatível e impede a extrapolação.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Shared natural-language examples/exemplos de linguagem natural partilhada mantém comunicação e entendimento comum. Become executable/se tornam executáveis não diz que qualquer frase seja convertida infalivelmente. Test first/escrever primeiro em o1 distingue a ênfase em componentes; timed session/sessão com duração definida mantém o caráter exploratório do outro distrator.

| EN literal                       | PT literal                               |
| -------------------------------- | ---------------------------------------- |
| shared natural-language examples | exemplos de linguagem natural partilhada |
| become executable tests          | se tornam testes executáveis             |
| supporting code                  | código de suporte                        |

## Contraevidência e outras respostas defensáveis

BDD, ATDD e TDD podem coexistir e sobrepor-se; o item pergunta a descrição característica no syllabus, não exclusividade de técnicas. Linguagem natural arbitrária não se executa sozinha: são necessários acordo semântico e mecanismos de execução. A opção correta descreve essa ligação sem alegar conversão sem trabalho ou sem defeitos.

## LO, nível K, explicações e dificuldade

K1: recordar a descrição de BDD entre exemplos de abordagens test-first. A comparação com TDD e exploração é direta e não exige derivar casos de teste. As quatro justificações e a explicação geral são coerentes e explicitam o limite da automatização, permitindo ao estudante não inferir magia na geração de testes.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa pretende que exemplos do comportamento esperado orientem o desenvolvimento. Que descrição caracteriza o desenvolvimento orientado para comportamento (BDD) no syllabus?
```

Proposto atual — sem alteração

```text
Uma equipa pretende que exemplos do comportamento esperado orientem o desenvolvimento. Que descrição caracteriza o desenvolvimento orientado para comportamento (BDD) no syllabus?
```

### Enunciado EN

Original

```text
A team wants examples of expected behaviour to drive development. Which description characterises behaviour-driven development (BDD) in the syllabus?
```

Proposto atual — sem alteração

```text
A team wants examples of expected behaviour to drive development. Which description characterises behaviour-driven development (BDD) in the syllabus?
```

### o1 — alternativa PT

Original

```text
Os programadores escrevem primeiro testes de componentes e depois implementam e refatoram o código correspondente.
```

Proposto atual — sem alteração

```text
Os programadores escrevem primeiro testes de componentes e depois implementam e refatoram o código correspondente.
```

### o1 — explicação PT

Original

```text
Isto descreve o ciclo habitual de TDD, em vez da ênfase característica do BDD numa linguagem partilhada.
```

Proposto atual — sem alteração

```text
Isto descreve o ciclo habitual de TDD, em vez da ênfase característica do BDD numa linguagem partilhada.
```

### o1 — alternativa EN

Original

```text
Developers write component tests first, then implement and refactor the corresponding code.
```

Proposto atual — sem alteração

```text
Developers write component tests first, then implement and refactor the corresponding code.
```

### o1 — explicação EN

Original

```text
This describes the usual TDD cycle rather than the characteristic shared-language emphasis of BDD.
```

Proposto atual — sem alteração

```text
This describes the usual TDD cycle rather than the characteristic shared-language emphasis of BDD.
```

### o2 — alternativa PT

Original

```text
Os revisores examinam o código-fonte com uma checklist antes da entrada no pipeline de compilação.
```

Proposto atual — sem alteração

```text
Os revisores examinam o código-fonte com uma checklist antes da entrada no pipeline de compilação.
```

### o2 — explicação PT

Original

```text
Isto descreve uma prática de revisão estática, não exemplos de comportamento a orientar a implementação.
```

Proposto atual — sem alteração

```text
Isto descreve uma prática de revisão estática, não exemplos de comportamento a orientar a implementação.
```

### o2 — alternativa EN

Original

```text
Reviewers examine the source code against a checklist before it enters the build pipeline.
```

Proposto atual — sem alteração

```text
Reviewers examine the source code against a checklist before it enters the build pipeline.
```

### o2 — explicação EN

Original

```text
This describes a static review practice, not behaviour examples directing implementation.
```

Proposto atual — sem alteração

```text
This describes a static review practice, not behaviour examples directing implementation.
```

### o3 — alternativa PT

Original

```text
A equipa expressa o comportamento em exemplos de linguagem natural partilhada que se tornam testes executáveis.
```

Proposto atual — sem alteração

```text
A equipa expressa o comportamento em exemplos de linguagem natural partilhada que se tornam testes executáveis.
```

### o3 — explicação PT

Original

```text
O BDD expressa o comportamento pretendido em exemplos compreensíveis, habitualmente Given/When/Then, ligados à execução.
```

Proposto atual — sem alteração

```text
O BDD expressa o comportamento pretendido em exemplos compreensíveis, habitualmente Given/When/Then, ligados à execução.
```

### o3 — alternativa EN

Original

```text
The team expresses behaviour in shared natural-language examples that become executable tests.
```

Proposto atual — sem alteração

```text
The team expresses behaviour in shared natural-language examples that become executable tests.
```

### o3 — explicação EN

Original

```text
BDD expresses desired behaviour in understandable examples, commonly Given/When/Then, linked to execution.
```

Proposto atual — sem alteração

```text
BDD expresses desired behaviour in understandable examples, commonly Given/When/Then, linked to execution.
```

### o4 — alternativa PT

Original

```text
Os testadores concebem e avaliam testes enquanto exploram a funcionalidade implementada numa sessão com duração definida.
```

Proposto atual — sem alteração

```text
Os testadores concebem e avaliam testes enquanto exploram a funcionalidade implementada numa sessão com duração definida.
```

### o4 — explicação PT

Original

```text
Isto descreve teste exploratório, não a abordagem de especificação do comportamento antes da implementação.
```

Proposto atual — sem alteração

```text
Isto descreve teste exploratório, não a abordagem de especificação do comportamento antes da implementação.
```

### o4 — alternativa EN

Original

```text
Testers design and evaluate tests while exploring the implemented feature in a timed session.
```

Proposto atual — sem alteração

```text
Testers design and evaluate tests while exploring the implemented feature in a timed session.
```

### o4 — explicação EN

Original

```text
This describes exploratory testing, not the test-first behavioural specification approach.
```

Proposto atual — sem alteração

```text
This describes exploratory testing, not the test-first behavioural specification approach.
```

### Explicação geral PT

Original

```text
O BDD destaca descrições partilhadas do comportamento traduzidas em exemplos executáveis. Isto não impede sobreposição com ATDD nem implica que qualquer exemplo em linguagem natural seja automaticamente executável sem código de suporte.
```

Proposto atual — sem alteração

```text
O BDD destaca descrições partilhadas do comportamento traduzidas em exemplos executáveis. Isto não impede sobreposição com ATDD nem implica que qualquer exemplo em linguagem natural seja automaticamente executável sem código de suporte.
```

### Explicação geral EN

Original

```text
BDD highlights shared descriptions of behaviour translated into executable examples. This does not prohibit overlap with ATDD or imply that every natural-language example is automatically executable without supporting code.
```

Proposto atual — sem alteração

```text
BDD highlights shared descriptions of behaviour translated into executable examples. This does not prohibit overlap with ATDD or imply that every natural-language example is automatically executable without supporting code.
```

## Avaliação de todas as alternativas

### o1 — distrator

A sequência de testes de componentes primeiro, implementação e refatoração corresponde a TDD; não define a ênfase do BDD em linguagem partilhada.

Writing component tests before implementation and refactoring characterises TDD. It can coexist with BDD, but alone does not identify the shared behaviour-example approach asked for.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

A revisão estática por checklist pode complementar o trabalho, mas não é a definição de exemplos comportamentais a orientar o desenvolvimento.

Reviewing source code against a checklist is a static review activity. It may improve quality but is not the defining behaviour-driven development description.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — correta

Correta: comportamento partilhado em linguagem natural ligado à execução caracteriza BDD; a explicação geral preserva a necessidade de código de suporte.

Shared natural-language examples express intended behaviour and connect to executable tests. This characterises BDD; it does not imply infallible generation without implementation, bindings or team agreement.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Conceber e avaliar durante exploração com duração definida caracteriza teste exploratório, não a especificação comportamental test-first pedida.

Designing and evaluating tests during timed exploration characterises exploratory testing. That can complement development but is not the test-first BDD description sought.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o3'] | 380c1227f399c856a86b11bd06f830cec6f75025a82adae69b10aabd9a986f81 |
| 2026-10-27.7 | True     | 1      | ['o3'] | 380c1227f399c856a86b11bd06f830cec6f75025a82adae69b10aabd9a986f81 |
| 2026-10-27.8 | True     | 2      | ['o3'] | 5ceb5524a517d84ee85d867b65e8a77343dc9f263c251630ae0cfe0c0044bf88 |
| 2026-10-27.9 | True     | 2      | ['o3'] | 5ceb5524a517d84ee85d867b65e8a77343dc9f263c251630ae0cfe0c0044bf88 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-070 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-4.1.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

A classificação depende da fonte de derivação: regras especificadas sem código para Ana, ramos internos para Bruno e padrões conhecidos de incidentes para Carla. A ordem correta é caixa-preta, caixa-branca e baseada na experiência. Execução manual ou automatizada não substitui estas famílias conceptuais.

Raciocínio guardado antes da revelação:

Ana usa regras de negócio sem estrutura interna, Bruno usa ramos do fluxo de controlo e Carla usa experiência de incidentes. A ordem é caixa-preta, caixa-branca e baseada na experiência; automatizar execução não altera a origem conceptual dos testes.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 4.1: EN páginas [39]; PT páginas [42].

- LO FL-4.1.1/K2: EN página 38; PT página 41.

EN secção 4.1 na página 39 e PT na página 42 distinguem comportamento especificado, estrutura interna e experiência. A ordem terminológica das alternativas foi comparada literalmente, sem depender da ordem de apresentação embaralhada. Ambas as edições sustentam a mesma classificação neste cenário.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Respectively/respetivamente preserva a ordem Ana, Bruno e Carla e a ordem das três categorias em todas as opções. Without reading code/sem ler código, control-flow branches/ramos do fluxo de controlo e past booking incidents/incidentes anteriores preservam as fontes de derivação. Não há troca de nomes, negação ou condição entre idiomas.

| EN literal            | PT literal                 |
| --------------------- | -------------------------- |
| without reading code  | sem ler código             |
| control-flow branches | ramos do fluxo de controlo |
| respectively          | respetivamente             |

## Contraevidência e outras respostas defensáveis

Um testador pode combinar fontes ou conhecer o domínio, mas o cenário delimita explicitamente a base usada por cada pessoa. Possuir experiência não converte qualquer teste de requisitos em técnica baseada na experiência. Automatizar a execução não transforma regras externas em análise estrutural.

## LO, nível K, explicações e dificuldade

K2: distinguir famílias a partir de três exemplos de derivação, sem efetuar cálculo de cobertura ou desenhar testes K3. As opções são permutações plausíveis e cada justificação indica precisamente quais posições estão trocadas. A explicação geral distingue derivação de execução, eliminando uma confusão frequente.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Num serviço de reservas, Ana deriva testes de regras de cancelamento sem ler código. Bruno deriva testes dos ramos do fluxo de controlo do serviço. Carla concebe testes usando padrões de incidentes anteriores de reservas. Que classificação corresponde, respetivamente, a Ana, Bruno e Carla?
```

Proposto atual — sem alteração

```text
Num serviço de reservas, Ana deriva testes de regras de cancelamento sem ler código. Bruno deriva testes dos ramos do fluxo de controlo do serviço. Carla concebe testes usando padrões de incidentes anteriores de reservas. Que classificação corresponde, respetivamente, a Ana, Bruno e Carla?
```

### Enunciado EN

Original

```text
For a booking service, Ana derives tests from cancellation rules without reading code. Bruno derives tests from the service's control-flow branches. Carla designs tests using patterns from past booking incidents. Which classification matches Ana, Bruno and Carla, respectively?
```

Proposto atual — sem alteração

```text
For a booking service, Ana derives tests from cancellation rules without reading code. Bruno derives tests from the service's control-flow branches. Carla designs tests using patterns from past booking incidents. Which classification matches Ana, Bruno and Carla, respectively?
```

### o1 — alternativa PT

Original

```text
Caixa-preta; baseada na experiência; caixa-branca.
```

Proposto atual — sem alteração

```text
Caixa-preta; baseada na experiência; caixa-branca.
```

### o1 — explicação PT

Original

```text
Bruno usa estrutura interna; Carla usa experiência de incidentes anteriores, pelo que as últimas duas classificações estão trocadas.
```

Proposto atual — sem alteração

```text
Bruno usa estrutura interna; Carla usa experiência de incidentes anteriores, pelo que as últimas duas classificações estão trocadas.
```

### o1 — alternativa EN

Original

```text
Black-box; experience-based; white-box.
```

Proposto atual — sem alteração

```text
Black-box; experience-based; white-box.
```

### o1 — explicação EN

Original

```text
Bruno uses internal structure; Carla uses prior incident experience, so the last two classifications are reversed.
```

Proposto atual — sem alteração

```text
Bruno uses internal structure; Carla uses prior incident experience, so the last two classifications are reversed.
```

### o2 — alternativa PT

Original

```text
Caixa-branca; caixa-preta; baseada na experiência.
```

Proposto atual — sem alteração

```text
Caixa-branca; caixa-preta; baseada na experiência.
```

### o2 — explicação PT

Original

```text
As duas primeiras classificações estão trocadas: as regras especificam comportamento e os ramos descrevem estrutura.
```

Proposto atual — sem alteração

```text
As duas primeiras classificações estão trocadas: as regras especificam comportamento e os ramos descrevem estrutura.
```

### o2 — alternativa EN

Original

```text
White-box; black-box; experience-based.
```

Proposto atual — sem alteração

```text
White-box; black-box; experience-based.
```

### o2 — explicação EN

Original

```text
The first two classifications are reversed: rules specify behaviour while control-flow branches describe structure.
```

Proposto atual — sem alteração

```text
The first two classifications are reversed: rules specify behaviour while control-flow branches describe structure.
```

### o3 — alternativa PT

Original

```text
Baseada na experiência; caixa-branca; caixa-preta.
```

Proposto atual — sem alteração

```text
Baseada na experiência; caixa-branca; caixa-preta.
```

### o3 — explicação PT

Original

```text
Ana usa regras especificadas em vez de experiência pessoal, enquanto Carla usa padrões de incidentes em vez de uma especificação.
```

Proposto atual — sem alteração

```text
Ana usa regras especificadas em vez de experiência pessoal, enquanto Carla usa padrões de incidentes em vez de uma especificação.
```

### o3 — alternativa EN

Original

```text
Experience-based; white-box; black-box.
```

Proposto atual — sem alteração

```text
Experience-based; white-box; black-box.
```

### o3 — explicação EN

Original

```text
Ana uses specified rules rather than personal experience, while Carla uses incident patterns rather than a specification.
```

Proposto atual — sem alteração

```text
Ana uses specified rules rather than personal experience, while Carla uses incident patterns rather than a specification.
```

### o4 — alternativa PT

Original

```text
Caixa-preta; caixa-branca; baseada na experiência.
```

Proposto atual — sem alteração

```text
Caixa-preta; caixa-branca; baseada na experiência.
```

### o4 — explicação PT

Original

```text
As fontes da derivação são, respetivamente, comportamento especificado, estrutura interna e experiência do testador.
```

Proposto atual — sem alteração

```text
As fontes da derivação são, respetivamente, comportamento especificado, estrutura interna e experiência do testador.
```

### o4 — alternativa EN

Original

```text
Black-box; white-box; experience-based.
```

Proposto atual — sem alteração

```text
Black-box; white-box; experience-based.
```

### o4 — explicação EN

Original

```text
The sources of test derivation are specified behaviour, internal structure and tester experience, respectively.
```

Proposto atual — sem alteração

```text
The sources of test derivation are specified behaviour, internal structure and tester experience, respectively.
```

### Explicação geral PT

Original

```text
A classificação depende da base usada para derivar testes, não de a execução ser manual ou automatizada.
```

Proposto atual — sem alteração

```text
A classificação depende da base usada para derivar testes, não de a execução ser manual ou automatizada.
```

### Explicação geral EN

Original

```text
Classification depends on the basis used to derive tests, not on whether execution is manual or automated.
```

Proposto atual — sem alteração

```text
Classification depends on the basis used to derive tests, not on whether execution is manual or automated.
```

## Avaliação de todas as alternativas

### o1 — distrator

Ana está bem classificada, mas Bruno usa estrutura e Carla incidentes anteriores; as duas últimas classificações estão trocadas, como a explicação indica.

Ana is correctly classified as black-box, but Bruno uses internal structure rather than past experience, and Carla uses incident experience rather than a structural model. The final two classifications are reversed.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

As duas primeiras categorias estão trocadas: regras externas são caixa-preta e ramos internos são caixa-branca; só a terceira permanece correta.

Ana derives tests from external cancellation rules, not internal structure; Bruno explicitly uses internal branches, not black-box specifications. The third classification alone is correct.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

A classificação estrutural de Bruno está correta, mas Ana não deriva de incidentes e Carla não deriva apenas de uma especificação; as pontas estão trocadas.

Bruno is structural, but Ana uses specified cancellation behaviour rather than past incidents, and Carla uses incident patterns rather than only a specification. The first and third classifications are incorrect.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — correta

Correta: a sequência caixa-preta, caixa-branca e experiência corresponde exatamente a Ana, Bruno e Carla e à origem de cada conjunto de testes.

Ana uses specification-based black-box derivation, Bruno uses structure-based white-box derivation and Carla uses experience-based derivation. The stated respective order matches all three.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o4'] | 568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8 |
| 2026-10-27.7 | True     | 1      | ['o4'] | 568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8 |
| 2026-10-27.8 | True     | 1      | ['o4'] | 568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8 |
| 2026-10-27.9 | True     | 1      | ['o4'] | 568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-075 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.4.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

Uma baseline regista versões e relações de itens relevantes, incluindo compilação r208, esquema v12, dados D6, scripts e ambiente. Recuperar esse conjunto permite comparar a observação original com significado. Repetir o mesmo script, ou o seu nome, não basta para controlar as outras variáveis alteradas.

Raciocínio guardado antes da revelação:

Reproduzir a referência registada requer identificar versões relacionadas de compilação, esquema, dados, script e configuração. Repetir o nome ou conteúdo do script não controla o ambiente; recuperar essa baseline apoia comparação, sem garantir reproduzir qualquer condição externa.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 5.4: EN páginas [56]; PT páginas [62].

- LO FL-5.4.1/K2: EN página 47; PT página 52.

EN secção 5.4 na página 56 e PT na página 62 referem itens complexos, versões, relações e regresso à baseline anterior. PT usa linha de base e a questão usa base de referência: ambas designam baseline no contexto. Nenhuma das fontes fornece garantia de controlar toda dependência externa não registada.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Best supports/melhor apoia mantém apoio sem garantia. Build/compilação refere a versão do artefacto, schema/esquema e seed data set/conjunto de dados mantêm r208, v12 e D6. Pass/aprovação significa resultado do teste neste contexto, não aceite humano académico. Recover the recorded baseline/recuperar a base de referência registada abrange relações e versões.

| EN literal             | PT literal                   |
| ---------------------- | ---------------------------- |
| application build r208 | compilação r208 da aplicação |
| schema v12             | esquema v12                  |
| seed data set D6       | conjunto de dados D6         |

## Contraevidência e outras respostas defensáveis

Restaurar a baseline apoia reprodução, mas uma falha intermitente pode ainda depender de temporização, serviços externos ou concorrência não controlados. O enunciado diz melhor apoia, não garante. Regenerar dados só seria equivalente se a equivalência fosse demonstrada; o distrator não estabelece isso nem repõe o esquema.

## LO, nível K, explicações e dificuldade

K2: resumir como controlo de versões e relações permite reconstituir configurações e comparar resultados. Não se pede efetuar rollback ou reconstruir um ambiente real. As explicações distinguem identidade por nome, restauração parcial, atualização indiscriminada e controlo do conjunto, sem invalidar uma falha antiga apenas por um novo PASS.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Foi observada uma falha com a compilação r208 da aplicação, o esquema v12 e o conjunto de dados D6. Uma nova execução do mesmo script passa, mas o ambiente foi reconstruído. Que ação melhor apoia a reprodução e comparação do resultado original?
```

Proposto atual — sem alteração

```text
Foi observada uma falha com a compilação r208 da aplicação, o esquema v12 e o conjunto de dados D6. Uma nova execução do mesmo script passa, mas o ambiente foi reconstruído. Que ação melhor apoia a reprodução e comparação do resultado original?
```

### Enunciado EN

Original

```text
A failure was observed with application build r208, schema v12 and seed data set D6. A rerun with the same test script now passes, but the environment has been rebuilt. Which action best supports reproducing and comparing the original result?
```

Proposto atual — sem alteração

```text
A failure was observed with application build r208, schema v12 and seed data set D6. A rerun with the same test script now passes, but the environment has been rebuilt. Which action best supports reproducing and comparing the original result?
```

### o1 — alternativa PT

Original

```text
Comparar os nomes dos scripts e aceitar a aprovação se coincidirem com o registo anterior.
```

Proposto atual — sem alteração

```text
Comparar os nomes dos scripts e aceitar a aprovação se coincidirem com o registo anterior.
```

### o1 — explicação PT

Original

```text
Os nomes não identificam as versões da aplicação, esquema, dados e ambiente que podem afetar o resultado.
```

Proposto atual — sem alteração

```text
Os nomes não identificam as versões da aplicação, esquema, dados e ambiente que podem afetar o resultado.
```

### o1 — alternativa EN

Original

```text
Compare the script names and accept the pass if they match the earlier test log.
```

Proposto atual — sem alteração

```text
Compare the script names and accept the pass if they match the earlier test log.
```

### o1 — explicação EN

Original

```text
Names do not identify versions of the application, schema, data and environment that may affect the result.
```

Proposto atual — sem alteração

```text
Names do not identify versions of the application, schema, data and environment that may affect the result.
```

### o2 — alternativa PT

Original

```text
Restaurar a compilação da aplicação mantendo o esquema atual e os dados iniciais regenerados.
```

Proposto atual — sem alteração

```text
Restaurar a compilação da aplicação mantendo o esquema atual e os dados iniciais regenerados.
```

### o2 — explicação PT

Original

```text
Restaurar um item deixa outros itens de configuração relevantes diferentes da base de referência original.
```

Proposto atual — sem alteração

```text
Restaurar um item deixa outros itens de configuração relevantes diferentes da base de referência original.
```

### o2 — alternativa EN

Original

```text
Restore the application build while keeping the current schema and regenerated seed data.
```

Proposto atual — sem alteração

```text
Restore the application build while keeping the current schema and regenerated seed data.
```

### o2 — explicação EN

Original

```text
Restoring one item leaves other relevant configuration items different from the original baseline.
```

Proposto atual — sem alteração

```text
Restoring one item leaves other relevant configuration items different from the original baseline.
```

### o3 — alternativa PT

Original

```text
Recuperar a base de referência registada da compilação, esquema, dados, scripts e configuração do ambiente para repetir o teste.
```

Proposto atual — sem alteração

```text
Recuperar a base de referência registada da compilação, esquema, dados, scripts e configuração do ambiente para repetir o teste.
```

### o3 — explicação PT

Original

```text
A gestão de configurações identifica itens relacionados e versionados para reproduzir uma base anterior e comparar resultados com significado.
```

Proposto atual — sem alteração

```text
A gestão de configurações identifica itens relacionados e versionados para reproduzir uma base anterior e comparar resultados com significado.
```

### o3 — alternativa EN

Original

```text
Recover the recorded baseline of build, schema, data, scripts and environment configuration for the rerun.
```

Proposto atual — sem alteração

```text
Recover the recorded baseline of build, schema, data, scripts and environment configuration for the rerun.
```

### o3 — explicação EN

Original

```text
CM identifies related versioned items so an earlier baseline can be reproduced and results compared meaningfully.
```

Proposto atual — sem alteração

```text
CM identifies related versioned items so an earlier baseline can be reproduced and results compared meaningfully.
```

### o4 — alternativa PT

Original

```text
Usar as versões mais recentes de cada item e anexar o registo da falha antiga à nova aprovação.
```

Proposto atual — sem alteração

```text
Usar as versões mais recentes de cada item e anexar o registo da falha antiga à nova aprovação.
```

### o4 — explicação PT

Original

```text
Isto documenta duas observações, mas não estabelece configurações equivalentes nem reproduz a base anterior.
```

Proposto atual — sem alteração

```text
Isto documenta duas observações, mas não estabelece configurações equivalentes nem reproduz a base anterior.
```

### o4 — alternativa EN

Original

```text
Use the newest versions of each item and attach the old failure log to the new pass.
```

Proposto atual — sem alteração

```text
Use the newest versions of each item and attach the old failure log to the new pass.
```

### o4 — explicação EN

Original

```text
This documents two observations but does not establish equivalent configurations or reproduce the old baseline.
```

Proposto atual — sem alteração

```text
This documents two observations but does not establish equivalent configurations or reproduce the old baseline.
```

### Explicação geral PT

Original

```text
Um resultado de teste está ligado a uma base de referência de configuração, não apenas ao nome de um script. São necessárias as relações e versões dos itens relevantes para o reproduzir.
```

Proposto atual — sem alteração

```text
Um resultado de teste está ligado a uma base de referência de configuração, não apenas ao nome de um script. São necessárias as relações e versões dos itens relevantes para o reproduzir.
```

### Explicação geral EN

Original

```text
A test result is tied to a configuration baseline, not just a script name. Relationships and versions of relevant items are needed to reproduce it.
```

Proposto atual — sem alteração

```text
A test result is tied to a configuration baseline, not just a script name. Relationships and versions of relevant items are needed to reproduce it.
```

## Avaliação de todas as alternativas

### o1 — distrator

Nomes coincidentes não identificam versões da aplicação, dados e ambiente; aceitar o novo PASS por esse critério não reproduz a configuração anterior.

Matching script names does not establish identical script versions or application, database and environment state. A passing result under changed configuration cannot by itself invalidate the earlier failure.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

Restaurar só a aplicação deixa esquema e dados diferentes ou sem equivalência demonstrada; a explicação identifica corretamente essa restauração parcial.

Restoring only the application build leaves the schema and seed data uncontrolled relative to the observed failing configuration. Reproduction requires the relevant baseline items to remain consistent together.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — correta

Correta: recuperar a baseline relacionada de compilação, esquema, dados, scripts e ambiente apoia reprodução; não promete controlar toda condição externa.

Recovering the recorded build, schema, seed data, scripts and environment baseline controls the identified configuration variables and best supports comparison. It supports reproduction without guaranteeing every external timing or service condition.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Usar itens mais novos e anexar o log antigo documenta duas observações, mas não estabelece equivalência de configurações nem correção demonstrada da falha.

Newest independent versions need not reproduce the original baseline. Attaching an old failure log to a new pass does not make the configurations comparable or establish that the original issue was fixed.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o3'] | e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723 |
| 2026-10-27.7 | True     | 1      | ['o3'] | e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723 |
| 2026-10-27.8 | True     | 1      | ['o3'] | e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723 |
| 2026-10-27.9 | True     | 1      | ['o3'] | e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-079 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-6.1.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

A necessidade em falta é evidência dos ramos internos efetivamente exercitados. Associar execução a ramos instrumentados mede cobertura estrutural e ajuda a orientar novos testes. Requisitos ligados, contagem de asserções e complexidade estática têm utilidade, mas as capacidades descritas não respondem à mesma pergunta.

Raciocínio guardado antes da revelação:

A evidência pedida é dos ramos internos realmente exercitados, e não apenas de requisitos associados ou asserções aprovadas. Medição de cobertura ligada a ramos instrumentados fornece diretamente a informação estrutural necessária para orientar testes adicionais.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 6.1: EN páginas [59]; PT páginas [65].
- Secção 4.3.2: EN páginas [43]; PT páginas [46, 47].

- LO FL-6.1.1/K2: EN página 58; PT página 64.

EN secção 6.1, página 59, e PT página 65 incluem execução e medição de cobertura. A definição de cobertura de ramos em EN página 43 e PT páginas 46–47 sustenta a evidência pedida. A nomenclatura dos grupos é ampla em ambas; selecionar uma capacidade não cria exclusividade universal de ferramentas.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Internal branches/ramos internos e instrumented branches/ramos instrumentados mantêm o objeto estrutural. Most directly/mais diretamente distingue utilidade geral de fornecimento da evidência pedida. Passed assertions/asserções aprovadas e requirements linked/requisitos ligados continuam resultados e rastreabilidade, sem se tornarem cobertura de ramos.

| EN literal            | PT literal           |
| --------------------- | -------------------- |
| internal branches     | ramos internos       |
| passed assertions     | asserções aprovadas  |
| instrumented branches | ramos instrumentados |

## Contraevidência e outras respostas defensáveis

Uma ferramenta comercial pode reunir análise estática, execução, gestão e cobertura no mesmo produto. O item pede a capacidade mais direta, não uma categoria de marca mutuamente exclusiva. Análise estrutural pode identificar ramos existentes, mas os relatórios estáticos descritos não demonstram quais foram percorridos pelos testes executados.

## LO, nível K, explicações e dificuldade

K2: explicar que capacidade de ferramenta suporta uma necessidade concreta, distinguindo evidência estrutural, resultados e rastreabilidade. Não exige instrumentar código ou calcular cobertura. As justificações qualificam os resultados efetivamente descritos, evitando concluir que ferramentas multifunção nunca possam incluir outras capacidades.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa já regista resultados de aprovação/falha e ligações aos requisitos. Precisa agora de evidência dos ramos internos exercitados pelos testes para orientar a conceção de testes adicionais. Que capacidade de ferramenta fornece mais diretamente a evidência em falta?
```

Proposto atual — sem alteração

```text
Uma equipa já regista resultados de aprovação/falha e ligações aos requisitos. Precisa agora de evidência dos ramos internos exercitados pelos testes para orientar a conceção de testes adicionais. Que capacidade de ferramenta fornece mais diretamente a evidência em falta?
```

### Enunciado EN

Original

```text
A team already records pass/fail results and requirements links. It now needs evidence of which internal branches were exercised by its tests to guide additional test design. Which tool capability most directly supplies the missing evidence?
```

Proposto atual — sem alteração

```text
A team already records pass/fail results and requirements links. It now needs evidence of which internal branches were exercised by its tests to guide additional test design. Which tool capability most directly supplies the missing evidence?
```

### o1 — alternativa PT

Original

```text
Análise estática que reporta complexidade e violações de regras de código.
```

Proposto atual — sem alteração

```text
Análise estática que reporta complexidade e violações de regras de código.
```

### o1 — explicação PT

Original

```text
Estas medidas podem orientar testes, mas não estabelecem os ramos efetivamente percorridos pelos testes executados.
```

Proposto atual — sem alteração

```text
Estas medidas podem orientar testes, mas não estabelecem os ramos efetivamente percorridos pelos testes executados.
```

### o1 — alternativa EN

Original

```text
Static analysis reporting complexity and coding-rule violations.
```

Proposto atual — sem alteração

```text
Static analysis reporting complexity and coding-rule violations.
```

### o1 — explicação EN

Original

```text
These measurements can guide testing but do not establish which branches the executed tests actually traversed.
```

Proposto atual — sem alteração

```text
These measurements can guide testing but do not establish which branches the executed tests actually traversed.
```

### o2 — alternativa PT

Original

```text
Gestão de testes que reporta requisitos ligados aos casos executados.
```

Proposto atual — sem alteração

```text
Gestão de testes que reporta requisitos ligados aos casos executados.
```

### o2 — explicação PT

Original

```text
A rastreabilidade de requisitos já está disponível e não é cobertura de ramos em execução.
```

Proposto atual — sem alteração

```text
A rastreabilidade de requisitos já está disponível e não é cobertura de ramos em execução.
```

### o2 — alternativa EN

Original

```text
Test management reporting requirements linked to executed cases.
```

Proposto atual — sem alteração

```text
Test management reporting requirements linked to executed cases.
```

### o2 — explicação EN

Original

```text
Requirements traceability is already available and is not runtime branch coverage.
```

Proposto atual — sem alteração

```text
Requirements traceability is already available and is not runtime branch coverage.
```

### o3 — alternativa PT

Original

```text
Execução de testes que reporta o número de asserções aprovadas.
```

Proposto atual — sem alteração

```text
Execução de testes que reporta o número de asserções aprovadas.
```

### o3 — explicação PT

Original

```text
Contagens de asserções não identificam os ramos internos exercitados ou ainda sem cobertura.
```

Proposto atual — sem alteração

```text
Contagens de asserções não identificam os ramos internos exercitados ou ainda sem cobertura.
```

### o3 — alternativa EN

Original

```text
Test execution reporting the number of passed assertions.
```

Proposto atual — sem alteração

```text
Test execution reporting the number of passed assertions.
```

### o3 — explicação EN

Original

```text
Assertion counts do not identify the internal branches exercised or remaining uncovered.
```

Proposto atual — sem alteração

```text
Assertion counts do not identify the internal branches exercised or remaining uncovered.
```

### o4 — alternativa PT

Original

```text
Medição de cobertura que associa os testes executados aos ramos instrumentados.
```

Proposto atual — sem alteração

```text
Medição de cobertura que associa os testes executados aos ramos instrumentados.
```

### o4 — explicação PT

Original

```text
Ferramentas de execução e cobertura podem medir cobertura estrutural, revelando ramos para testes adicionais.
```

Proposto atual — sem alteração

```text
Ferramentas de execução e cobertura podem medir cobertura estrutural, revelando ramos para testes adicionais.
```

### o4 — alternativa EN

Original

```text
Coverage measurement associating executed tests with instrumented branches.
```

Proposto atual — sem alteração

```text
Coverage measurement associating executed tests with instrumented branches.
```

### o4 — explicação EN

Original

```text
Execution and coverage tools can measure structural coverage, revealing branches for additional tests.
```

Proposto atual — sem alteração

```text
Execution and coverage tools can measure structural coverage, revealing branches for additional tests.
```

### Explicação geral PT

Original

```text
Seleciona-se a capacidade que fornece a evidência estrutural de execução em falta. As outras categorias continuam úteis, mas os resultados listados respondem a perguntas diferentes.
```

Proposto atual — sem alteração

```text
Seleciona-se a capacidade que fornece a evidência estrutural de execução em falta. As outras categorias continuam úteis, mas os resultados listados respondem a perguntas diferentes.
```

### Explicação geral EN

Original

```text
Select the capability that supplies the missing structural execution evidence. Other tool categories remain useful but their listed outputs answer different questions.
```

Proposto atual — sem alteração

```text
Select the capability that supplies the missing structural execution evidence. Other tool categories remain useful but their listed outputs answer different questions.
```

## Avaliação de todas as alternativas

### o1 — distrator

Complexidade e regras estáticas podem orientar testes, mas não medem por si os ramos realmente percorridos pelas execuções descritas.

Static complexity and coding-rule violations describe code properties without showing which internal branches the executed tests traversed. The capability as described lacks the requested execution coverage evidence.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

Ligar requisitos a casos executados já fornece rastreabilidade, mas não a evidência estrutural de ramos internos em falta no cenário.

Requirements linked to executed cases provide traceability and requirements coverage information, not a direct measurement of exercised internal control-flow branches.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

O número de asserções aprovadas indica resultados, sem identificar ramos exercitados ou ainda não cobertos; a explicação separa corretamente essas medidas.

A count of passed assertions reports test outcomes. It cannot identify which structural branches were exercised and which remain uncovered without an additional coverage capability.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — correta

Correta: associar testes executados a ramos instrumentados fornece diretamente cobertura estrutural para orientar testes adicionais, sem garantir correção completa.

Associating executed tests with instrumented branches directly measures the structural coverage requested. That evidence can guide new test design without proving all behaviour is correct.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o4'] | 3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29 |
| 2026-10-27.7 | True     | 1      | ['o4'] | 3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29 |
| 2026-10-27.8 | True     | 1      | ['o4'] | 3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29 |
| 2026-10-27.9 | True     | 1      | ['o4'] | 3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-080 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-6.2.1 / K1; versão 1; revisão 2026-10-27.10; SHA-256 canónico `a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

O fim de suporte anunciado para o próximo ano evidencia dependência do fornecedor e compatibilidade continuada da plataforma. É um risco à continuidade futura de uma suite que pode continuar a funcionar hoje; não invalida automaticamente resultados atuais nem prova falta de estatísticas ou comparação manual excessiva.

Raciocínio guardado antes da revelação:

O anúncio de fim de suporte do executor proprietário evidencia dependência do fornecedor e compatibilidade futura. Não demonstra que os testes já falhem hoje, nem que haja uma dificuldade atual de repetição humana, estatísticas ou comparação manual.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 6.2: EN páginas [59, 60]; PT páginas [65, 66].

- LO FL-6.2.1/K1: EN página 58; PT página 64.

EN secção 6.2 inicia na página 59 e lista riscos na página 60; PT inicia na página 65 e continua na página 66. Ambas referem suporte do fornecedor e incompatibilidade com plataforma. As formulações diferem na edição, mas nenhuma obriga a concluir falha imediata a partir de um anúncio futuro.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Will end next year/terminará no próximo ano preserva anúncio e horizonte futuro. Proprietary runner/executor proprietário mantém dependência tecnológica. Continuing platform compatibility/continuidade da compatibilidade distingue manter viabilidade de uma falha presente. Os outros distratores descrevem esforço manual, consistência e estatísticas, não este risco.

| EN literal                       | PT literal                        |
| -------------------------------- | --------------------------------- |
| proprietary runner               | executor proprietário             |
| end next year                    | terminará no próximo ano          |
| current test results are invalid | resultados atuais sejam inválidos |

## Contraevidência e outras respostas defensáveis

O fim de suporte pode levar a migração, custos ou problemas futuros, mas não prova uma falha imediata de execução. O enunciado não fornece data de avaria ou proibição atual. Proprietário não significa necessariamente inadequado; o risco identificado é a dependência e a continuidade do suporte, não uma condenação de toda ferramenta proprietária.

## LO, nível K, explicações e dificuldade

K1: recordar o risco de dependência do fornecedor e compatibilidade listado na secção 6.2. A explicação geral delimita explicitamente que o anúncio não torna inválidos os resultados atuais. As quatro opções contrastam benefícios potenciais e outra limitação de reporte sem introduzir requisitos de análise financeira ou migração técnica.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma suite de testes automatizados depende de um executor proprietário. O fornecedor anuncia que o suporte da plataforma terminará no próximo ano. Que risco reconhecido da automação de testes ilustra esta situação?
```

Proposto atual — sem alteração

```text
Uma suite de testes automatizados depende de um executor proprietário. O fornecedor anuncia que o suporte da plataforma terminará no próximo ano. Que risco reconhecido da automação de testes ilustra esta situação?
```

### Enunciado EN

Original

```text
An automated test suite depends on a proprietary runner. Its vendor announces that platform support will end next year. Which recognised test automation risk does this illustrate?
```

Proposto atual — sem alteração

```text
An automated test suite depends on a proprietary runner. Its vendor announces that platform support will end next year. Which recognised test automation risk does this illustrate?
```

### o1 — alternativa PT

Original

```text
Repetição inconsistente de dados de teste idênticos por pessoas.
```

Proposto atual — sem alteração

```text
Repetição inconsistente de dados de teste idênticos por pessoas.
```

### o1 — explicação PT

Original

```text
Isto é um problema de consistência humana que a automação pode ajudar a reduzir, não a dependência do fornecedor descrita.
```

Proposto atual — sem alteração

```text
Isto é um problema de consistência humana que a automação pode ajudar a reduzir, não a dependência do fornecedor descrita.
```

### o1 — alternativa EN

Original

```text
Inconsistent repetition of identical test data by people.
```

Proposto atual — sem alteração

```text
Inconsistent repetition of identical test data by people.
```

### o1 — explicação EN

Original

```text
This is a human consistency issue that automation can help reduce, not the vendor dependency described.
```

Proposto atual — sem alteração

```text
This is a human consistency issue that automation can help reduce, not the vendor dependency described.
```

### o2 — alternativa PT

Original

```text
Dependência de um fornecedor de ferramentas e da continuidade da compatibilidade com a plataforma.
```

Proposto atual — sem alteração

```text
Dependência de um fornecedor de ferramentas e da continuidade da compatibilidade com a plataforma.
```

### o2 — explicação PT

Original

```text
O suporte do fornecedor e a compatibilidade podem ameaçar a continuidade de uma suite automatizada que funciona.
```

Proposto atual — sem alteração

```text
O suporte do fornecedor e a compatibilidade podem ameaçar a continuidade de uma suite automatizada que funciona.
```

### o2 — alternativa EN

Original

```text
Dependency on a tool vendor and continuing platform compatibility.
```

Proposto atual — sem alteração

```text
Dependency on a tool vendor and continuing platform compatibility.
```

### o2 — explicação EN

Original

```text
Vendor support and compatibility can threaten continued use of an otherwise working automated suite.
```

Proposto atual — sem alteração

```text
Vendor support and compatibility can threaten continued use of an otherwise working automated suite.
```

### o3 — alternativa PT

Original

```text
Acesso limitado a estatísticas de execução para relatórios de gestão.
```

Proposto atual — sem alteração

```text
Acesso limitado a estatísticas de execução para relatórios de gestão.
```

### o3 — explicação PT

Original

```text
A capacidade de reporte não é o problema descrito; a alteração anunciada diz respeito à continuidade do suporte.
```

Proposto atual — sem alteração

```text
A capacidade de reporte não é o problema descrito; a alteração anunciada diz respeito à continuidade do suporte.
```

### o3 — alternativa EN

Original

```text
Limited access to execution statistics for management reporting.
```

Proposto atual — sem alteração

```text
Limited access to execution statistics for management reporting.
```

### o3 — explicação EN

Original

```text
Reporting capability is not the problem described; the announced change concerns continued support.
```

Proposto atual — sem alteração

```text
Reporting capability is not the problem described; the announced change concerns continued support.
```

### o4 — alternativa PT

Original

```text
Esforço excessivo na comparação manual de resultados esperados e obtidos.
```

Proposto atual — sem alteração

```text
Esforço excessivo na comparação manual de resultados esperados e obtidos.
```

### o4 — explicação PT

Original

```text
Reduzir esse esforço repetitivo é uma vantagem potencial da automação, não este risco de suporte do fornecedor.
```

Proposto atual — sem alteração

```text
Reduzir esse esforço repetitivo é uma vantagem potencial da automação, não este risco de suporte do fornecedor.
```

### o4 — alternativa EN

Original

```text
Excessive effort spent manually comparing expected and actual outputs.
```

Proposto atual — sem alteração

```text
Excessive effort spent manually comparing expected and actual outputs.
```

### o4 — explicação EN

Original

```text
Reducing such repetitive effort is a potential automation benefit, not this vendor-support risk.
```

Proposto atual — sem alteração

```text
Reducing such repetitive effort is a potential automation benefit, not this vendor-support risk.
```

### Explicação geral PT

Original

```text
A automação introduz dependências continuadas, além de vantagens. O anúncio do fim de suporte é evidência para analisar riscos de fornecedor e compatibilidade; por si só não significa que os resultados atuais sejam inválidos.
```

Proposto atual — sem alteração

```text
A automação introduz dependências continuadas, além de vantagens. O anúncio do fim de suporte é evidência para analisar riscos de fornecedor e compatibilidade; por si só não significa que os resultados atuais sejam inválidos.
```

### Explicação geral EN

Original

```text
Automation introduces ongoing dependencies as well as benefits. A support-ending announcement is evidence for analysing vendor and compatibility risk; it does not by itself mean the current test results are invalid.
```

Proposto atual — sem alteração

```text
Automation introduces ongoing dependencies as well as benefits. A support-ending announcement is evidence for analysing vendor and compatibility risk; it does not by itself mean the current test results are invalid.
```

## Avaliação de todas as alternativas

### o1 — distrator

Inconsistência de repetição humana é um problema que automação pode reduzir; não corresponde à dependência de suporte anunciada no cenário.

Inconsistent manual repetition is a human execution concern that automation can reduce. No such inconsistency is reported, and it does not explain the announced end of vendor platform support.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — correta

Correta: fornecedor e compatibilidade futura ameaçam continuidade, mas não significam que os testes já tenham falhado ou que os resultados atuais sejam inválidos.

Dependence on a proprietary runner exposes vendor and platform-compatibility risk when support is scheduled to end. The risk is future-facing and is not evidence that the current tests fail immediately.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

O cenário não diz que faltam estatísticas ou relatórios; o evento anunciado refere continuidade de suporte e compatibilidade da ferramenta.

Limited execution statistics may be a separate tooling limitation, but the scenario provides no evidence of missing reports. It specifically identifies a vendor support and compatibility dependency.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Comparação manual excessiva é esforço que automação pode reduzir, não a consequência específica do anúncio de fim de suporte do executor.

Manual comparison effort is not the risk demonstrated by the vendor announcement. Automation may reduce that effort, but this does not remove dependence on a supported runner platform.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o2'] | a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b |
| 2026-10-27.7 | True     | 1      | ['o2'] | a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b |
| 2026-10-27.8 | True     | 1      | ['o2'] | a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b |
| 2026-10-27.9 | True     | 1      | ['o2'] | a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-081 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.5.2 / K1; versão 1; revisão 2026-10-27.10; SHA-256 canónico `7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

O programador recebeu conhecimento e é explicitamente qualificado para a tarefa. A partilha de competências permite continuidade da verificação e colaboração com negócio, mantendo responsabilidade conjunta pela qualidade. Isso não elimina a especialização nem implica que qualquer pessoa sem preparação possa executar qualquer tarefa.

Raciocínio guardado antes da revelação:

A competência foi ensinada e o programador é explicitamente qualificado, permitindo partilhar tarefas e responsabilidade pela qualidade com comunicação ao negócio. Isto não dispensa especialização nem exige que qualquer membro sem preparação execute qualquer tarefa.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 1.5.2: EN páginas [22]; PT páginas [24].

- LO FL-1.5.2/K1: EN página 14; PT página 15.

EN secção 1.5.2 na página 22 e PT na página 24 condicionam execução das tarefas a conhecimentos e competências e descrevem transferência de conhecimento. Ambas ressalvam contextos que requerem independência. Não há fundamento para remover especialização ou interpretar o termo inglês como defeito académico.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Qualified developer/programador qualificado e necessary skills/competências necessárias preservam a condição de capacidade. Cross-skilled members/membros com competências partilhadas é entendido com a formação explícita no enunciado, não como uniformidade de especialidades. Can/podem mantém possibilidade; shared responsibility/responsabilidade conjunta não transfere toda responsabilidade a uma só função.

| EN literal                        | PT literal                               |
| --------------------------------- | ---------------------------------------- |
| qualified developer               | programador qualificado                  |
| necessary skills                  | competências necessárias                 |
| shared responsibility for quality | responsabilidade conjunta pela qualidade |

## Contraevidência e outras respostas defensáveis

Independência pode trazer benefícios noutro contexto, mas não houve revisor externo neste cenário. Automação e baselines também são úteis, porém não são os mecanismos descritos. A condição de competências adequadas é essencial; contextos críticos podem exigir independência, como a própria explicação geral reconhece.

## LO, nível K, explicações e dificuldade

K1: recordar a vantagem de colaboração e transferência de conhecimento na whole team approach, aplicada a uma verificação concreta simples. O empréstimo terminológico existe também na tradução oficial PT. As explicações separam independência, automação e configuração sem negar os seus benefícios próprios, e mantêm a qualificação necessária.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um testador ensina um programador a executar e avaliar uma verificação de aceitação. Quando o testador está indisponível, esse programador qualificado executa a verificação e discute o resultado com o representante do negócio. Que vantagem da whole team approach é ilustrada?
```

Proposto atual — sem alteração

```text
Um testador ensina um programador a executar e avaliar uma verificação de aceitação. Quando o testador está indisponível, esse programador qualificado executa a verificação e discute o resultado com o representante do negócio. Que vantagem da whole team approach é ilustrada?
```

### Enunciado EN

Original

```text
A tester teaches a developer to execute and assess an acceptance check. When the tester is unavailable, that qualified developer performs the check and discusses the result with the business representative. Which advantage of the whole team approach is illustrated?
```

Proposto atual — sem alteração

```text
A tester teaches a developer to execute and assess an acceptance check. When the tester is unavailable, that qualified developer performs the check and discusses the result with the business representative. Which advantage of the whole team approach is illustrated?
```

### o1 — alternativa PT

Original

```text
Um revisor externo pode questionar pressupostos sem partilhar a perspetiva do autor.
```

Proposto atual — sem alteração

```text
Um revisor externo pode questionar pressupostos sem partilhar a perspetiva do autor.
```

### o1 — explicação PT

Original

```text
Esta é uma vantagem potencial do teste independente; não ocorre revisão externa neste cenário.
```

Proposto atual — sem alteração

```text
Esta é uma vantagem potencial do teste independente; não ocorre revisão externa neste cenário.
```

### o1 — alternativa EN

Original

```text
An external reviewer can challenge assumptions without sharing the author's perspective.
```

Proposto atual — sem alteração

```text
An external reviewer can challenge assumptions without sharing the author's perspective.
```

### o1 — explicação EN

Original

```text
This is a potential benefit of independent testing; no external review takes place in this scenario.
```

Proposto atual — sem alteração

```text
This is a potential benefit of independent testing; no external review takes place in this scenario.
```

### o2 — alternativa PT

Original

```text
Uma suite automatizada pode repetir verificações de forma consistente, reduzindo o esforço de execução manual.
```

Proposto atual — sem alteração

```text
Uma suite automatizada pode repetir verificações de forma consistente, reduzindo o esforço de execução manual.
```

### o2 — explicação PT

Original

```text
Esta é uma vantagem da automação; o cenário descreve um membro formado da equipa a executar a tarefa.
```

Proposto atual — sem alteração

```text
Esta é uma vantagem da automação; o cenário descreve um membro formado da equipa a executar a tarefa.
```

### o2 — alternativa EN

Original

```text
An automated suite can repeat checks consistently while reducing manual execution effort.
```

Proposto atual — sem alteração

```text
An automated suite can repeat checks consistently while reducing manual execution effort.
```

### o2 — explicação EN

Original

```text
This is an automation benefit; the scenario describes a trained team member performing the task.
```

Proposto atual — sem alteração

```text
This is an automation benefit; the scenario describes a trained team member performing the task.
```

### o3 — alternativa PT

Original

```text
Membros com competências partilhadas podem executar tarefas de teste e manter responsabilidade conjunta pela qualidade.
```

Proposto atual — sem alteração

```text
Membros com competências partilhadas podem executar tarefas de teste e manter responsabilidade conjunta pela qualidade.
```

### o3 — explicação PT

Original

```text
Qualquer membro com as competências necessárias pode executar a tarefa; transferir conhecimento de testes permite essa flexibilidade.
```

Proposto atual — sem alteração

```text
Qualquer membro com as competências necessárias pode executar a tarefa; transferir conhecimento de testes permite essa flexibilidade.
```

### o3 — alternativa EN

Original

```text
Cross-skilled members can perform testing tasks and maintain shared responsibility for quality.
```

Proposto atual — sem alteração

```text
Cross-skilled members can perform testing tasks and maintain shared responsibility for quality.
```

### o3 — explicação EN

Original

```text
Any team member with the necessary skills can perform the task; transferring testing knowledge enables that flexibility.
```

Proposto atual — sem alteração

```text
Any team member with the necessary skills can perform the task; transferring testing knowledge enables that flexibility.
```

### o4 — alternativa PT

Original

```text
Uma base de referência versionada pode tornar as configurações de teste reproduzíveis quando mudam os membros da equipa.
```

Proposto atual — sem alteração

```text
Uma base de referência versionada pode tornar as configurações de teste reproduzíveis quando mudam os membros da equipa.
```

### o4 — explicação PT

Original

```text
Isto é apoio da gestão de configurações, não a vantagem de partilha de conhecimento demonstrada aqui.
```

Proposto atual — sem alteração

```text
Isto é apoio da gestão de configurações, não a vantagem de partilha de conhecimento demonstrada aqui.
```

### o4 — alternativa EN

Original

```text
A versioned baseline can make test configurations reproducible when team members change.
```

Proposto atual — sem alteração

```text
A versioned baseline can make test configurations reproducible when team members change.
```

### o4 — explicação EN

Original

```text
This is configuration management support, not the knowledge-sharing benefit demonstrated here.
```

Proposto atual — sem alteração

```text
This is configuration management support, not the knowledge-sharing benefit demonstrated here.
```

### Explicação geral PT

Original

```text
A vantagem é a colaboração e transferência de conhecimento entre pessoas com competências adequadas. Não implica que sejam desnecessárias competências especializadas ou independência dependente do contexto.
```

Proposto atual — sem alteração

```text
A vantagem é a colaboração e transferência de conhecimento entre pessoas com competências adequadas. Não implica que sejam desnecessárias competências especializadas ou independência dependente do contexto.
```

### Explicação geral EN

Original

```text
The benefit is collaboration and transfer of knowledge among people with suitable skills. It does not imply that specialist skills or context-dependent independence are unnecessary.
```

Proposto atual — sem alteração

```text
The benefit is collaboration and transfer of knowledge among people with suitable skills. It does not imply that specialist skills or context-dependent independence are unnecessary.
```

## Avaliação de todas as alternativas

### o1 — distrator

Uma perspetiva externa pode questionar pressupostos, mas não aparece neste cenário; a explicação corretamente distingue independência de partilha de competências.

Independent review may challenge assumptions, but no external reviewer appears in this scenario. The described benefit is cross-skilled collaboration inside the team rather than independent perspective.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

Repetição automatizada pode reduzir esforço, mas o cenário descreve uma pessoa formada a executar uma tarefa e comunicar com o negócio.

Consistent automated repetition can reduce manual effort, but the scenario describes a qualified person learning and performing a check with business communication, not an automation benefit.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — correta

Correta: membros com conhecimentos adequados podem executar tarefas e partilhar qualidade; formação e qualificação são condições explícitas, não intercambialidade irrestrita.

A qualified cross-skilled team member can perform a testing task and discuss its meaning with business representatives while quality remains a shared responsibility. Qualification is an explicit condition, not an assumption of universal interchangeability.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Baselines versionadas apoiam reprodução de configurações, mas não são o mecanismo de colaboração e formação transversal descrito neste caso.

Versioned configuration baselines support reproduction, but the scenario concerns teaching skills and sharing quality responsibility. No baseline reconstruction or configuration change is described.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o3'] | 7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43 |
| 2026-10-27.7 | True     | 1      | ['o3'] | 7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43 |
| 2026-10-27.8 | True     | 1      | ['o3'] | 7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43 |
| 2026-10-27.9 | True     | 1      | ['o3'] | 7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-082 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.1.7 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af`.

Resposta pré-gabarito: `['o1']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o1']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 4 alternativas; selecionar 1.

## Resolução independente e fundamento

Pedidos concorrentes ao serviço integrado investigam esgotamento de recursos e degradação de desempenho, ou seja, qualidades técnicas do produto. Nos dois eixos do modelo isto é orientação tecnológica e avaliação crítica do produto, Q4. O objetivo é determinante, não a profissão dos executantes ou apenas o momento após implementação.

Raciocínio guardado antes da revelação:

Pedidos concorrentes no serviço integrado procuram esgotamento de recursos e degradação de desempenho do produto existente. O foco técnico que avalia criticamente o produto corresponde a Q4; não é estimativa de esforço nem apenas apoio unitário à construção.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 5.1.7: EN páginas [51]; PT páginas [56, 57].

- LO FL-5.1.7/K2: EN página 47; PT página 52.

EN página 51 contém todos os quadrantes; PT começa a secção na página 56 e apresenta Q3/Q4 na página 57. Critique é explicado como medir comportamento face às expectativas. A hipótese de estimativas não descreve o texto real; nenhum objetivo ou terminologia precisa de mudança por essa hipótese.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Critique/avaliam criticamente preserva comparação do comportamento com expectativas, não censura pessoal. Integrated service/serviço integrado não é necessariamente integração de componentes isolada de Q1. Concurrent requests/pedidos concorrentes mantém simultaneidade de carga sem inventar número de pedidos ou limiar. Resource exhaustion/esgotamento de recursos mantém a preocupação técnica.

| EN literal           | PT literal                     |
| -------------------- | ------------------------------ |
| concurrent requests  | pedidos concorrentes           |
| integrated service   | serviço integrado              |
| critique the product | avaliam criticamente o produto |

## Contraevidência e outras respostas defensáveis

Desempenho pode afetar valor de negócio e testes de integração podem apoiar desenvolvimento; isso não elimina a perspetiva técnica e finalidade de crítica dadas. Os quadrantes não formam uma cronologia rígida. Não se pede estimativa: estimar esforço pertence a outro LO; a questão efetivamente mede FL-5.1.7 e seus eixos.

## LO, nível K, explicações e dificuldade

K2: explicar a classificação em dois eixos e relacionar testes não funcionais com Q4. Não se executa cálculo de estimativa ou carga K3. As quatro justificações distinguem apoio da equipa de crítica do produto e perspetiva técnica de negócio; a explicação geral impede usar apenas ator ou momento como critério.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Após implementar um incremento de um serviço, os engenheiros executam pedidos concorrentes contra o serviço integrado para investigar esgotamento de recursos e degradação do tempo de resposta antes da entrega. Que quadrante melhor representa estes testes?
```

Proposto atual — sem alteração

```text
Após implementar um incremento de um serviço, os engenheiros executam pedidos concorrentes contra o serviço integrado para investigar esgotamento de recursos e degradação do tempo de resposta antes da entrega. Que quadrante melhor representa estes testes?
```

### Enunciado EN

Original

```text
After implementing a service increment, engineers run concurrent requests against the integrated service to investigate resource exhaustion and response-time degradation before release. Which quadrant best represents this testing?
```

Proposto atual — sem alteração

```text
After implementing a service increment, engineers run concurrent requests against the integrated service to investigate resource exhaustion and response-time degradation before release. Which quadrant best represents this testing?
```

### o1 — alternativa PT

Original

```text
Q4: testes orientados para a tecnologia que avaliam criticamente o produto.
```

Proposto atual — sem alteração

```text
Q4: testes orientados para a tecnologia que avaliam criticamente o produto.
```

### o1 — explicação PT

Original

```text
A investigação não funcional de desempenho e fiabilidade enquadra-se no quadrante tecnológico de avaliação crítica do produto.
```

Proposto atual — sem alteração

```text
A investigação não funcional de desempenho e fiabilidade enquadra-se no quadrante tecnológico de avaliação crítica do produto.
```

### o1 — alternativa EN

Original

```text
Q4: technology-facing tests that critique the product.
```

Proposto atual — sem alteração

```text
Q4: technology-facing tests that critique the product.
```

### o1 — explicação EN

Original

```text
Non-functional performance and reliability investigation fits the technology-facing, product-critique quadrant.
```

Proposto atual — sem alteração

```text
Non-functional performance and reliability investigation fits the technology-facing, product-critique quadrant.
```

### o2 — alternativa PT

Original

```text
Q1: testes orientados para a tecnologia que apoiam a equipa.
```

Proposto atual — sem alteração

```text
Q1: testes orientados para a tecnologia que apoiam a equipa.
```

### o2 — explicação PT

Original

```text
Q1 inclui testes de componentes e integração de componentes que apoiam o desenvolvimento; o objetivo indicado aqui é avaliar criticamente o produto.
```

Proposto atual — sem alteração

```text
Q1 inclui testes de componentes e integração de componentes que apoiam o desenvolvimento; o objetivo indicado aqui é avaliar criticamente o produto.
```

### o2 — alternativa EN

Original

```text
Q1: technology-facing tests that support the team.
```

Proposto atual — sem alteração

```text
Q1: technology-facing tests that support the team.
```

### o2 — explicação EN

Original

```text
Q1 includes component and component-integration tests supporting development; the stated purpose here is product critique.
```

Proposto atual — sem alteração

```text
Q1 includes component and component-integration tests supporting development; the stated purpose here is product critique.
```

### o3 — alternativa PT

Original

```text
Q2: testes orientados para o negócio que apoiam a equipa.
```

Proposto atual — sem alteração

```text
Q2: testes orientados para o negócio que apoiam a equipa.
```

### o3 — explicação PT

Original

```text
Q2 orienta o desenvolvimento através de exemplos de negócio e critérios de aceitação, ao contrário da investigação técnica indicada.
```

Proposto atual — sem alteração

```text
Q2 orienta o desenvolvimento através de exemplos de negócio e critérios de aceitação, ao contrário da investigação técnica indicada.
```

### o3 — alternativa EN

Original

```text
Q2: business-facing tests that support the team.
```

Proposto atual — sem alteração

```text
Q2: business-facing tests that support the team.
```

### o3 — explicação EN

Original

```text
Q2 guides development through business examples and acceptance criteria, unlike the stated technical investigation.
```

Proposto atual — sem alteração

```text
Q2 guides development through business examples and acceptance criteria, unlike the stated technical investigation.
```

### o4 — alternativa PT

Original

```text
Q3: testes orientados para o negócio que avaliam criticamente o produto.
```

Proposto atual — sem alteração

```text
Q3: testes orientados para o negócio que avaliam criticamente o produto.
```

### o4 — explicação PT

Original

```text
Q3 inclui exploração orientada para utilizadores e usabilidade; este cenário diz respeito explicitamente a recursos técnicos e tempos de resposta.
```

Proposto atual — sem alteração

```text
Q3 inclui exploração orientada para utilizadores e usabilidade; este cenário diz respeito explicitamente a recursos técnicos e tempos de resposta.
```

### o4 — alternativa EN

Original

```text
Q3: business-facing tests that critique the product.
```

Proposto atual — sem alteração

```text
Q3: business-facing tests that critique the product.
```

### o4 — explicação EN

Original

```text
Q3 includes user-oriented exploration and usability; this scenario explicitly concerns technical resource and response behaviour.
```

Proposto atual — sem alteração

```text
Q3 includes user-oriented exploration and usability; this scenario explicitly concerns technical resource and response behaviour.
```

### Explicação geral PT

Original

```text
Classifica-se pela perspetiva e pelo objetivo, não pelo facto de os testes serem executados por engenheiros ou após a implementação. Q4 avalia criticamente qualidades técnicas do produto.
```

Proposto atual — sem alteração

```text
Classifica-se pela perspetiva e pelo objetivo, não pelo facto de os testes serem executados por engenheiros ou após a implementação. Q4 avalia criticamente qualidades técnicas do produto.
```

### Explicação geral EN

Original

```text
Classify by perspective and purpose, not by the fact that engineers execute tests or that execution happens after implementation. Q4 critiques technical qualities of the product.
```

Proposto atual — sem alteração

```text
Classify by perspective and purpose, not by the fact that engineers execute tests or that execution happens after implementation. Q4 critiques technical qualities of the product.
```

## Avaliação de todas as alternativas

### o1 — correta

Correta: investigar concorrência, recursos e tempo de resposta do produto enquadra-se em Q4, orientação técnica com avaliação crítica de qualidades não funcionais.

Q4 is technology-facing and critiques the product, including performance and other non-functional concerns. Concurrent integrated-service tests investigating resource exhaustion and response-time degradation match that purpose.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

Q1 apoia construção por testes técnicos de componentes e integração; o propósito aqui é avaliar limites do produto integrado, não apenas apoiar codificação.

Q1 technology-facing tests support development, commonly at component or component-integration level. The scenario instead critiques an integrated increment for resource and performance limits before release.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

Q2 usa exemplos e critérios orientados para o negócio para apoiar desenvolvimento; não é o objetivo técnico de investigação de recursos descrito.

Q2 business-facing tests support the team, such as acceptance examples guiding implementation. The stated internal resource and response-time investigation is technical product critique, not this purpose.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Q3 também critica o produto, mas pela perspetiva de utilizadores e negócio; a questão especifica investigação técnica de carga, recursos e tempos.

Q3 business-facing tests critique the product from user or business perspectives. Product critique alone is insufficient: the specified concurrent technical resource investigation distinguishes Q4 here.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o1'] | 6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af |
| 2026-10-27.7 | True     | 1      | ['o1'] | 6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af |
| 2026-10-27.8 | True     | 1      | ['o1'] | 6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af |
| 2026-10-27.9 | True     | 1      | ['o1'] | 6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


# tl-083 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-3.2.4 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `f31d575236f2c92922a162f519a70646956cff3d2057c8a2628276d9b5af521d`.

Resposta pré-gabarito: `['o2', 'o4']`; registada em `2026-11-07T23:30:39.344922+00:00`. Chave consultada depois: `['o2', 'o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 5 alternativas; selecionar 2.

## Resolução independente e fundamento

O conjunto correto é o2 e o4, entre cinco alternativas: walkthrough conduzido pelo autor para aprendizagem e revisão técnica por pares qualificados sob moderação para consenso. A inspeção tem restrições de autor e processo completo que não se transferem automaticamente a toda revisão técnica. Nenhuma seleção parcial satisfaz o pedido DUAS/TWO.

Raciocínio guardado antes da revelação:

São pedidas duas afirmações entre cinco opções. A primeira etapa conduzida pelo autor para partilhar entendimento corresponde a walkthrough; a segunda com pares qualificados, moderação e consenso corresponde a revisão técnica. Inspeção não permite autor como líder/redator e o seu processo completo não é obrigatório para toda revisão técnica.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 3.2.4: EN páginas [36, 37]; PT páginas [39, 40].

- LO FL-3.2.4/K2: EN página 32; PT página 35.

A secção 3.2.4 cobre EN páginas 36–37 e PT páginas 39–40: walkthrough pelo autor, revisão técnica por qualificados com moderador e inspeção com processo completo e restrições de autor. O banco autenticado já contém cinco opções e required=2; a diferença com a premissa de quatro no pedido é estrutural documentada, não alteração de conteúdo.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; endpoint PT teve timeout. Referências e páginas conferidas nas cópias oficiais locais identificadas, sem alegar download PT novo. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Select TWO/Selecione DUAS preserva exatamente duas respostas; ambas as versões têm cinco alternativas. Author-led/conduzido pelo autor e moderated/moderada preservam condução e papéis. Can/pode em o2 e must/tem de em o5 são decisivos: possibilidade de aprendizagem não é obrigação de transformar revisão técnica em inspeção. Scribe/redator coincide com a terminologia PT dos papéis.

| EN literal                           | PT literal                                |
| ------------------------------------ | ----------------------------------------- |
| Select TWO                           | Selecione DUAS                            |
| author-led walkthrough               | walkthrough conduzido pelo autor          |
| must use the full inspection process | tem de seguir todo o processo de inspeção |

## Contraevidência e outras respostas defensáveis

Walkthroughs podem também procurar consenso e revisões técnicas podem educar participantes; só o objetivo não distingue todos os tipos. Aqui liderança, qualificação e moderação completam o contexto. Uma revisão técnica pode escolher mais formalidade, mas o5 impõe obrigatoriedade universal de processo e métricas de inspeção. A ordem de duas etapas é premissa deste plano, não regra para todos os projetos.

## LO, nível K, explicações e dificuldade

K2: comparar tipos por liderança, participantes e objetivos em duas situações. A quinta alternativa permite testar a confusão entre consenso e formalidade de inspeção; não se pode omiti-la para forçar quatro opções. O conjunto o2/o4 é único entre as afirmações e as explicações publicadas sustentam todas as cinco, sem reclamar aprovação humana.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa planeia duas revisões de uma conceção de migração. Primeiro, o autor orientará os participantes pelo documento para criar uma compreensão partilhada. Depois, pares tecnicamente qualificados procurarão consenso sobre escolhas de interfaces numa reunião moderada. Selecione DUAS afirmações coerentes com os tipos de revisão CTFL.
```

Proposto atual — sem alteração

```text
Uma equipa planeia duas revisões de uma conceção de migração. Primeiro, o autor orientará os participantes pelo documento para criar uma compreensão partilhada. Depois, pares tecnicamente qualificados procurarão consenso sobre escolhas de interfaces numa reunião moderada. Selecione DUAS afirmações coerentes com os tipos de revisão CTFL.
```

### Enunciado EN

Original

```text
A team plans two reviews of a migration design. First, the author will lead participants through the document to build shared understanding. Next, technically qualified peers will seek agreement on interface choices in a moderated meeting. Select TWO statements consistent with the CTFL review types.
```

Proposto atual — sem alteração

```text
A team plans two reviews of a migration design. First, the author will lead participants through the document to build shared understanding. Next, technically qualified peers will seek agreement on interface choices in a moderated meeting. Select TWO statements consistent with the CTFL review types.
```

### o1 — alternativa PT

Original

```text
Uma inspeção adequa-se à primeira etapa porque o autor pode atuar como líder de revisão e redator.
```

Proposto atual — sem alteração

```text
Uma inspeção adequa-se à primeira etapa porque o autor pode atuar como líder de revisão e redator.
```

### o1 — explicação PT

Original

```text
Numa inspeção, o autor não pode atuar como líder de revisão nem redator. Esta atribuição contraria os papéis definidos.
```

Proposto atual — sem alteração

```text
Numa inspeção, o autor não pode atuar como líder de revisão nem redator. Esta atribuição contraria os papéis definidos.
```

### o1 — alternativa EN

Original

```text
An inspection fits the first step because its author can act as both review leader and scribe.
```

Proposto atual — sem alteração

```text
An inspection fits the first step because its author can act as both review leader and scribe.
```

### o1 — explicação EN

Original

```text
In an inspection the author cannot act as review leader or scribe. This assignment contradicts the defined roles.
```

Proposto atual — sem alteração

```text
In an inspection the author cannot act as review leader or scribe. This assignment contradicts the defined roles.
```

### o2 — alternativa PT

Original

```text
Um walkthrough conduzido pelo autor pode apoiar a aprendizagem partilhada pretendida na primeira etapa.
```

Proposto atual — sem alteração

```text
Um walkthrough conduzido pelo autor pode apoiar a aprendizagem partilhada pretendida na primeira etapa.
```

### o2 — explicação PT

Original

```text
Os walkthroughs são conduzidos pelo autor e podem formar os participantes e criar compreensão do produto de trabalho.
```

Proposto atual — sem alteração

```text
Os walkthroughs são conduzidos pelo autor e podem formar os participantes e criar compreensão do produto de trabalho.
```

### o2 — alternativa EN

Original

```text
An author-led walkthrough can support the shared-learning purpose of the first step.
```

Proposto atual — sem alteração

```text
An author-led walkthrough can support the shared-learning purpose of the first step.
```

### o2 — explicação EN

Original

```text
Walkthroughs are led by the author and can educate participants and build understanding of the work product.
```

Proposto atual — sem alteração

```text
Walkthroughs are led by the author and can educate participants and build understanding of the work product.
```

### o3 — alternativa PT

Original

```text
A segunda etapa moderada é um walkthrough porque é conduzida por um moderador, em vez do autor.
```

Proposto atual — sem alteração

```text
A segunda etapa moderada é um walkthrough porque é conduzida por um moderador, em vez do autor.
```

### o3 — explicação PT

Original

```text
A condução pelo autor caracteriza um walkthrough. Revisores tecnicamente qualificados que procuram consenso com um moderador caracterizam uma revisão técnica.
```

Proposto atual — sem alteração

```text
A condução pelo autor caracteriza um walkthrough. Revisores tecnicamente qualificados que procuram consenso com um moderador caracterizam uma revisão técnica.
```

### o3 — alternativa EN

Original

```text
The moderated second step is a walkthrough because a moderator, rather than the author, leads it.
```

Proposto atual — sem alteração

```text
The moderated second step is a walkthrough because a moderator, rather than the author, leads it.
```

### o3 — explicação EN

Original

```text
Author leadership characterizes a walkthrough. Technically qualified reviewers seeking consensus under a moderator characterize a technical review.
```

Proposto atual — sem alteração

```text
Author leadership characterizes a walkthrough. Technically qualified reviewers seeking consensus under a moderator characterize a technical review.
```

### o4 — alternativa PT

Original

```text
Uma revisão técnica adequa-se à segunda etapa, com revisores qualificados, moderação e um objetivo de consenso.
```

Proposto atual — sem alteração

```text
Uma revisão técnica adequa-se à segunda etapa, com revisores qualificados, moderação e um objetivo de consenso.
```

### o4 — explicação PT

Original

```text
Uma revisão técnica é conduzida por um moderador e realizada por revisores tecnicamente qualificados; obter consenso é um dos seus objetivos.
```

Proposto atual — sem alteração

```text
Uma revisão técnica é conduzida por um moderador e realizada por revisores tecnicamente qualificados; obter consenso é um dos seus objetivos.
```

### o4 — alternativa EN

Original

```text
A technical review fits the second step with qualified reviewers, moderation and a consensus objective.
```

Proposto atual — sem alteração

```text
A technical review fits the second step with qualified reviewers, moderation and a consensus objective.
```

### o4 — explicação EN

Original

```text
A technical review is led by a moderator and performed by technically qualified reviewers; gaining consensus is one of its objectives.
```

Proposto atual — sem alteração

```text
A technical review is led by a moderator and performed by technically qualified reviewers; gaining consensus is one of its objectives.
```

### o5 — alternativa PT

Original

```text
Para procurar consenso na segunda etapa, uma revisão técnica tem de seguir todo o processo de inspeção e recolher as suas métricas de melhoria.
```

Proposto atual — sem alteração

```text
Para procurar consenso na segunda etapa, uma revisão técnica tem de seguir todo o processo de inspeção e recolher as suas métricas de melhoria.
```

### o5 — explicação PT

Original

```text
Uma revisão técnica pode procurar consenso sem se tornar uma inspeção. O processo genérico completo e as métricas de melhoria exigidas caracterizam a inspeção, não todas as revisões técnicas.
```

Proposto atual — sem alteração

```text
Uma revisão técnica pode procurar consenso sem se tornar uma inspeção. O processo genérico completo e as métricas de melhoria exigidas caracterizam a inspeção, não todas as revisões técnicas.
```

### o5 — alternativa EN

Original

```text
To pursue consensus in the second step, a technical review must use the full inspection process and collect its improvement metrics.
```

Proposto atual — sem alteração

```text
To pursue consensus in the second step, a technical review must use the full inspection process and collect its improvement metrics.
```

### o5 — explicação EN

Original

```text
A technical review can seek consensus without becoming an inspection. The full generic process and required improvement metrics characterize inspection, not every technical review.
```

Proposto atual — sem alteração

```text
A technical review can seek consensus without becoming an inspection. The full generic process and required improvement metrics characterize inspection, not every technical review.
```

### Explicação geral PT

Original

```text
A primeira finalidade corresponde a um walkthrough conduzido pelo autor; a segunda corresponde a uma revisão técnica moderada, com pares qualificados a procurar consenso. As restrições de papéis e formalidade da inspeção não devem ser transferidas para outros tipos.
```

Proposto atual — sem alteração

```text
A primeira finalidade corresponde a um walkthrough conduzido pelo autor; a segunda corresponde a uma revisão técnica moderada, com pares qualificados a procurar consenso. As restrições de papéis e formalidade da inspeção não devem ser transferidas para outros tipos.
```

### Explicação geral EN

Original

```text
The first purpose matches an author-led walkthrough; the second matches a moderated technical review for qualified peers seeking consensus. Inspection role restrictions and formality must not be transferred to other types.
```

Proposto atual — sem alteração

```text
The first purpose matches an author-led walkthrough; the second matches a moderated technical review for qualified peers seeking consensus. Inspection role restrictions and formality must not be transferred to other types.
```

## Avaliação de todas as alternativas

### o1 — distrator

Incorreta: numa inspeção o autor não pode atuar como líder ou redator; a justificação do distrator contraria as restrições explicitadas na fonte.

In an inspection the author cannot act as review leader or scribe, so the justification is false. The first author-led learning step instead fits a walkthrough rather than the proposed inspection role arrangement.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — correta

Correta: um walkthrough conduzido pelo autor pode educar participantes e construir entendimento; pode não exclui outros objetivos também legítimos.

An author-led walkthrough can educate participants and build shared understanding. The option says can support, which fits the first stage without claiming this is its only possible objective.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

Incorreta: moderação por alguém distinto do autor não define walkthrough; a combinação de pares qualificados e consenso corresponde à revisão técnica aqui.

A walkthrough is led by the author, so classifying the moderated second stage as a walkthrough because it is led by someone else reverses the defining distinction. The stated peers and consensus fit a technical review.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — correta

Correta: revisão técnica com qualificação, moderador e consenso corresponde à segunda etapa; deve ser selecionada em conjunto com o2.

A technical review uses technically qualified reviewers, is led by a moderator and aims at consensus or technical decisions. All three features align with the second stage described.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o5 — distrator

Incorreta: procurar consenso não obriga toda revisão técnica a usar o processo completo e métricas de inspeção; pode escolher formalidade, mas tem de é excessivo.

A technical review need not use the full inspection process and its improvement metrics simply to pursue consensus. Those additional formality requirements characterise inspections, not every technical review.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave        | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —            | —                                                                |
| 2026-10-27.2 | False    | —      | —            | —                                                                |
| 2026-10-27.3 | False    | —      | —            | —                                                                |
| 2026-10-27.4 | False    | —      | —            | —                                                                |
| 2026-10-27.5 | False    | —      | —            | —                                                                |
| 2026-10-27.6 | False    | —      | —            | —                                                                |
| 2026-10-27.7 | False    | —      | —            | —                                                                |
| 2026-10-27.8 | False    | —      | —            | —                                                                |
| 2026-10-27.9 | True     | 1      | ['o2', 'o4'] | f31d575236f2c92922a162f519a70646956cff3d2057c8a2628276d9b5af521d |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 15; aguardar auditoria antes de Lote 16.


