"""Batch9 read-only evidence checks; does not prove semantic or academic truth.
Blind AI solutions are validated as prior evidence, not inferred by these checks.
"""
import hashlib,json,copy
IDS=['tl-024', 'tl-030', 'tl-032', 'tl-033', 'tl-040', 'tl-044', 'tl-055', 'tl-056']
EXPECTED={'tl-024': ('FL-4.5.2', 'K2', 3, ['o1'], 'fa851be96d01839d044a574c67f8ee6c2fba4ba65ba7f7a0723c920cdd5d1a2a'), 'tl-030': ('FL-5.1.6', 'K1', 3, ['o1'], 'b9f41f5222ac38fb497ddec1bfc228d17b8b41639b512dca149593ee82f160de'), 'tl-032': ('FL-5.1.3', 'K2', 3, ['o1'], '7f60217b3313eae469e74621d7576b74d6a2c7d565a401eb20f2f9d5d87a7c86'), 'tl-033': ('FL-5.2.2', 'K2', 3, ['o1'], '1dc16a58ba1ddf343dad01afe41b833ff1e0c141d0331f646367f592541c2815'), 'tl-040': ('FL-6.2.1', 'K1', 3, ['o1'], '54c59daacf5d024cf447db42fd143f2d2f20e4f4bc918f8ab3861502da66e2ca'), 'tl-044': ('FL-5.1.7', 'K2', 1, ['o4'], '8c0dbfcb05cce795cb2c9bc36175e347ebf375914e441e903aca16f02fa2a701'), 'tl-055': ('FL-3.1.2', 'K2', 1, ['o1'], '93eafb9f218b78b98e81fb520c5ebf355f546be186aa451da65a0b5e1825c043'), 'tl-056': ('FL-3.2.1', 'K1', 1, ['o3'], '5bd11c686943a22717afee509b42357df3dc59c93fa170bb7b9f81cc946f9ae9')}
canonical=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
alltext=lambda q,l:'\n'.join([q['text'][l],q['explanation'][l],*[o[f][l] for o in q['options'] for f in ['text','explanation']]])
def check(bank,matrix,comparisons,blind,projection,sources,optionalAll):
 assert matrix['scope']=='Phase 10H Batch 9 only' and matrix['humanApprovedCount']==matrix['ownerAcceptedCount']==matrix['contentChanges']==0
 assert [r['questionId'] for r in matrix['decisions']]==IDS and len(comparisons)==len(blind['solutions'])==len(projection)==8 and len(optionalAll)==4
 result=[]
 for row,c,p in zip(matrix['decisions'],comparisons,projection):
  ident=row['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,key,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],q['correct'],canonical(q))==(lo,k,v,key,h)
  assert row['learningObjective']==lo and row['cognitiveLevel']==k and row['questionVersion']==v
  assert row['decision']=='ACCEPT_AS_IS' and row['ownerDecision'] is None and row['humanApproval']==q['humanApproval']=='PENDING'
  assert row['confirmedProblems']==[] and row['contentChanged'] is False and row['priorLOWLabelNotUsedAsDecision'] is True
  assert row['requiredAnswers']==q['required']==len(key) and row['existingKey']==row['proposedKey']==row['independentSolution']['answer']==key
  assert row['independentSolution']==next(s for s in blind['solutions'] if s['questionId']==ident)
  assert row['beforeCanonicalSHA256']==row['afterCanonicalSHA256']==h and row['contentRevisionBefore']==row['contentRevisionAfter']=='2026-10-27.10'
  assert c['questionId']==ident and c['original']==c['proposed']==q and c['changed'] is False
  assert p['id']==ident and p['text']==q['text'] and p['lo']==lo and p['level']==k and not set(p)&{'correct','explanation'}
  assert p['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  a=row['analysis'];assert set(a['options'])=={o['id'] for o in q['options']} and len(a['options'])==4
  assert [o for o,d in a['options'].items() if d['supportsAnswer']]==key
  for d in a['options'].values():assert isinstance(d['supportsAnswer'],bool) and d['concept'] and all(len(d[l])>20 for l in ['pt','en'])
  for f in ['reason','translation','contrary','teaching','risks']:assert all(len(a[f][l])>40 for l in ['pt','en'])
  for en,pt,status in a['criticalPairs']:assert en in alltext(q,'en') and pt in alltext(q,'pt') and status
  for refs in [row['references'],*row['references']['supporting']]:
   for lang in ['EN','PT']:assert set(refs[lang])<=set(next(s for s in sources['sources'] if s['language']==lang)['pagesConsulted'])
  optional=row['optionalEditorialCandidate']
  if ident not in ['tl-024','tl-030','tl-040','tl-044']:
   assert optional is None
  else:
   assert optional==next(o for o in optionalAll if o['questionId']==ident) and optional['applied'] is False and optional['requiresExplicitOwnerAuthorization'] is True
   assert optional['kind']=='OPTIONAL_EDITORIAL_NOT_CONFIRMED_DEFECT' and optional['original']==q and optional['originalCanonicalSHA256']==h
   assert optional['answerKeyImpact']==optional['ID_LO_K_optionIdentityImpact']=='NONE' and optional['futureVersionIfAuthorized']==v+1
   assert len(optional['testsIfAuthorized'])==4 and optional['candidateCanonicalSHA256']==canonical(optional['candidate'])
   expected=copy.deepcopy(q);path=optional['path']
   assert path==({'tl-030':['options','o2','text'],'tl-044':['options','o2','explanation']}.get(ident,['explanation']))
   target=expected['explanation'] if path[0]=='explanation' else next(o for o in expected['options'] if o['id']=='o2')[path[-1]]
   assert optional['originalText']==target and set(optional['candidateText'])=={'pt','en'} and any(optional['candidateText'][l]!=target[l] for l in ['pt','en'])
   target.update(optional['candidateText']);assert expected==optional['candidate'] and expected!=q
  result.append({'questionId':ident,'LO':lo,'K':k,'version':v,'canonicalSHA256':h,'independentKey':key,'storedKeyMatchesBlind':True,'requiredAnswers':len(key),'alternativesReviewed':4,'criticalPairsAnchored':len(a['criticalPairs']),'optionalCandidate':optional is not None,'semanticTruthAutomaticallyProven':False})
 return {'result':'PASS','scope':'Batch9 identity, cardinality, review completeness, critical term anchors, counterevidence, optional-only deltas and approval boundaries','questions':result,'newOwnerAcceptances':0,'newHumanApprovals':0}
def negative_checks(bank,matrix,comparisons,blind,projection,sources,optionalAll):
 check(bank,matrix,comparisons,blind,projection,sources,optionalAll)
 mutations=[
 ('wrong answer key',lambda d:d['decisions'][0].update(proposedKey=['o4'])),
 ('wrong cardinality',lambda d:d['decisions'][0].update(requiredAnswers=2)),
 ('invented human approval',lambda d:d['decisions'][0].update(humanApproval='HUMAN_APPROVED')),
 ('invented owner acceptance',lambda d:d['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),
 ('unreviewed distractor',lambda d:d['decisions'][1]['analysis']['options'].pop('o4')),
 ('extra supported answer',lambda d:d['decisions'][1]['analysis']['options']['o4'].update(supportsAnswer=True)),
 ('missing contrary evidence',lambda d:d['decisions'][1]['analysis']['contrary'].update(pt='')),
 ('unauthorized optional application',lambda d:d['decisions'][0]['optionalEditorialCandidate'].update(applied=True)),
 ('invented source page',lambda d:d['decisions'][1]['references'].update(EN=[999])),
 ('LOW reused as decision',lambda d:d['decisions'][1].update(priorLOWLabelNotUsedAsDecision=False)),
 ('modality anchor invented',lambda d:d['decisions'][3]['analysis']['criticalPairs'][1].__setitem__(0,'will certainly affect'))]
 rejected=[]
 for name,mutate in mutations:
  d=copy.deepcopy(matrix);mutate(d)
  try:check(bank,d,comparisons,blind,projection,sources,optionalAll)
  except AssertionError:rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 p=copy.deepcopy(projection);p[0]['correct']=['o1','o4']
 try:check(bank,matrix,comparisons,blind,p,sources,optionalAll)
 except AssertionError:rejected.append('key leaked into blind projection')
 else:raise AssertionError('Blind leakage accepted')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'semanticTruthAutomaticallyProven':False}
