"""Fresh RED/GREEN replay, in-memory synthetic mutations only."""
from pathlib import Path
import json,copy,runpy,datetime,hashlib,sys,subprocess
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');out=p/'recovery-evidence';read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'))
def args_for(batch):
 f=root/('docs/academic/phase10h-batch'+str(batch)+'-2026-11-06');bank=read(p/'runtime-before.json')['bank']
 if batch==10:return [bank,read(f/'decision-matrix.json'),read(f/'exact-comparisons.json'),read(f/'blind-solution.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidate.json'),(f/'tl-062.md').read_text(encoding='utf8')]
 m=read(f/'decision-matrix.json');return [bank,m,read(f/'exact-comparisons.json'),read(f/'blind-solutions.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidates.json'),{d['questionId']:(f/'reports'/(d['questionId']+'.md')).read_text(encoding='utf8') for d in m['decisions']},{'2026-10-27.'+str(i):read(root/('src/data/archive/questions-2026-10-27.'+str(i)+'.json')) for i in range(1,10)}]
args=args_for(12);original=runpy.run_path(str(out/'original/BATCH12-RULES.py'));started=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:original['negative_checks'](*args)
except AssertionError as e:assert str(e)=='False positive: unauthorized bank edit';red=str(e)
else:raise AssertionError('Original RED was not reproduced')
g=runpy.run_path(str(p/'GLOBAL12-RULES.py'));ref=g['load_reference']((p/'reference-bank.json').read_bytes());fixed=runpy.run_path(str(p/'BATCH12-RULES.py'))
assert fixed['check'](*args)['result']=='PASS' and g['check_bank'](args[0],ref)['result']=='PASS'
mutated=copy.deepcopy(args);assert mutated[0][1]['id']=='tl-002';mutated[0][1]['text']['en']='adulterated bank'
assert fixed['check'](*mutated)['result']=='PASS','Scoped contract must not become a second full-bank validator'
try:g['check_bank'](mutated[0],ref)
except AssertionError as e:assert 'Unauthorized bank edit' in str(e);globalRejection=str(e)
else:raise AssertionError('Same tl-002 mutation was not rejected globally')
scoped=copy.deepcopy(args);next(q for q in scoped[0] if q['id']=='tl-016')['text']['en']='adulterated bank'
try:fixed['check'](*scoped)
except AssertionError:scopedRejected=True
else:raise AssertionError('tl-016 edit not rejected')
neg=fixed['negative_checks'](*args,global_check=g['check_bank'],reference_bank=ref);globalNeg=g['negative_checks'](ref)
comparison=[]
for batch in [10,11]:
 rules=runpy.run_path(str(p.parent/('phase10h-batch'+str(batch)+'-20261106')/('BATCH'+str(batch)+'-RULES.py')));a=args_for(batch);assert rules['check'](*a)['result']=='PASS';a=copy.deepcopy(a);a[0][1]['text']['en']='adulterated bank'
 try:rules['check'](*a)
 except AssertionError:rejected=True
 else:rejected=False
 assert rejected==(batch==11);comparison.append({'batch':batch,'mutatedQuestion':'tl-002','inScopedReview':batch==11,'scopedRejected':rejected,'globalEqualityWouldReject':a[0]!=ref})
result={'result':'PASS','startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':[sys.executable,str(p/'replay-recovery.py')],'exitCode':0,'RED':{'originalError':red,'originalCommandExitCode':read(out/'red-result.json')['exitCode'],'originalGuardSHA256':hashlib.sha256((out/'original/BATCH12-RULES.py').read_bytes()).hexdigest()},'GREEN':{'sameTl002Mutation':'adulterated bank','globalRejected':True,'rejectionMessage':globalRejection,'intactBankControlPassed':True,'scopedTl016MutationRejected':scopedRejected,'scopedContractRetained':True,'originalNegativeCaseRetained':neg['originalTl002CasePreserved']},'combinedNegativeChecks':neg,'globalNegativeChecks':globalNeg,'priorBatchComparison':comparison,'noActualQuestionBankWrite':True,'academicReviewRepeated':False}
(out/'red-green-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# Capture the unchanged public command as the fresh GREEN counterpart of red.log.
cmd=[sys.executable,str(p/'verify.py'),'batch12-specific'];beg=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
(out/'green.log').write_text(r.stdout+r.stderr,encoding='utf8');(out/'green-result.json').write_text(json.dumps({'command':cmd,'startedAt':beg,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['globalNegativeChecks','combinedNegativeChecks']},ensure_ascii=False,indent=2));print('Negative checks:16combined +96global PASS.')
