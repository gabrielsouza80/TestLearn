from pathlib import Path
import json,sys
p=Path(__file__).parent;r=lambda f:json.loads(Path(f).read_text(encoding='utf-8-sig'))
q=next(q for q in r(p/'runtime-before.json')['bank'] if q['id']=='tl-062');print(json.dumps(q,ensure_ascii=False,indent=2))
m=r('C:/TestLearn/tmp/develop-workspace/docs/academic/phase10h-2026-11-04/review-matrix.json')
def find(x):
 if isinstance(x,dict):
  if x.get('id',x.get('questionId'))=='tl-062':print('PRIOR MATRIX',json.dumps(x,ensure_ascii=False,indent=2))
  for v in x.values():find(v)
 elif isinstance(x,list):
  for v in x:find(v)
find(m)
for s in r(p/'source-pages.json'):
 for page in s['pages']:
  if s['language']=='EN' and page['physicalPage'] in [47,48]:print(s['language'],page['physicalPage'],page['text'])
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
base=Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0')
for lang,name in [('EN','ISTQB_CTFL_Syllabus_v4.0.1.pdf'),('PT','ISTQB_CTFL_Syllabus-v4.0-PT_v1.0 (1).pdf')]:
 d=pymupdf.open(base/name)
 for i,page in enumerate(d):
  t=page.get_text()
  if i>13 and (('1.5.2.' in t and ('Whole Team Approach' in t or 'Abordagem' in t)) or ('1.4.5.' in t and i<25)):
   print('SUPPORTING',lang,i+1,t)
