"""Read-only portable Batch7 verification; Python3.9+ standard library.
Inspect this file and BATCH7-RULES.py. This is evidence validation, not human academic approval.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Run without Python -O; assertions must remain enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,re,runpy
root=Path(__file__).resolve().parent
read=lambda n:json.loads((root/n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
folder='docs/academic/phase10h-batch7-2026-11-06'
m=read('MANIFEST.json');expected={e['relativePath'] for e in m['files']};actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert len(expected)==len(m['files']) and actual==expected|{'MANIFEST.json'}
for e in m['files']:
 n=e['relativePath'];p=root/n;pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts and '\\' not in n
 assert p.resolve().is_relative_to(root) and not p.is_symlink();b=p.read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256'],n
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json');inv=read('GIT-CHANGE-INVENTORY.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049'
assert pre['priorPackageSHA256']=='031e64554c3dfe2065a75272df78e37f4180461069356159e19efcc2ca80fb94' and pre['priorManifestHashCount']==100 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical']
assert len(pre['existingFilesSHA256'])==proof['existingFilesByteIdentical']==260 and len(pre['existingUncommittedDocuments'])==proof['priorUncommittedDocumentsPreserved']==46
assert proof['uniqueIDsAndKeysPreserved']==90 and proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
assert len(proof['priorBatchDocumentsSHA256'])==57
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha((root/n).read_bytes())==h==pre['existingFilesSHA256'][n]
assert inv['existingFilesChanged']==[] and len(inv['newBatch7Files'])==9 and len(inv['preservedPendingDocuments'])==46
for e in inv['newBatch7Files']:
 b=(root/e['relativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
for e in m['files']:
 if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
required={'src/data/syllabus-questions.ts','src/data/variability-questions.ts','src/domain/blueprint.ts','tests/unit/academic-audit.test.ts','tests/unit/blueprint.test.ts','tests/unit/quality-maintenance.test.ts','tests/unit/variability.test.ts'}
assert set(proof['requiredComparisonFilesSHA256'])==required and proof['comparisonFilesMatchBatch5ZIP'] is True
for n in required:assert n in expected and sha((root/n).read_bytes())==proof['requiredComparisonFilesSHA256'][n]==pre['existingFilesSHA256'][n]
bank=read('review-data/current-bank.json');old=read('src/data/archive/questions-2026-10-27.9.json');pres=read('BANK-PRESERVATION.json')
assert len(bank)==len({q['id'] for q in bank})==90 and pres['contentRevision']=='2026-10-27.10'
assert [q['id'] for q in bank]==[q['id'] for q in old] and all(a['correct']==b['correct'] for a,b in zip(old,bank))
assert [a['id'] for a,b in zip(old,bank) if a!=b]==['tl-011','tl-090']
assert len(pres['questions'])==90
for r,q in zip(pres['questions'],bank):assert r['id']==q['id'] and r['beforeCanonicalSHA256']==r['afterCanonicalSHA256']==canonical(q) and r['beforeKey']==r['afterKey']==q['correct'] and r['beforeVersion']==r['afterVersion']==q['version']
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha((root/n).read_bytes())==h==pre['existingFilesSHA256'][n]
data=read(folder+'/decision-matrix.json');comparisons=read(folder+'/exact-comparisons.json');blind=read(folder+'/blind-solutions.json');projection=read(folder+'/blind-projection.json');sources=read(folder+'/sources.json')
assert blind==read('evidence/blind-solutions.json') and projection==read('evidence/blind-projection.json')
assert blind['projectionSHA256']==sha((root/'evidence/blind-projection.json').read_bytes())
rules=runpy.run_path(str(root/'BATCH7-RULES.py'));args=[bank,data,comparisons,blind,projection,sources];specific=rules['check'](*args);neg=rules['negative_checks'](*args)
logged=read('evidence/checks/batch7-specific-result.json');assert logged['result']=='PASS' and logged['exitCode']==0 and logged['questions']==specific['questions'] and logged['negativeChecks']==neg and neg['negativeCasesRejected']==9
blocks=[];pairCount=0
for row,c in zip(data['decisions'],comparisons):
 ident=row['questionId'];q=next(q for q in bank if q['id']==ident);assert q==next(q for q in old if q['id']==ident)
 for h in row['history']:
  aq=next((v for v in read('src/data/archive/questions-'+h['contentRevision']+'.json') if v['id']==ident),None);assert h['present']==(aq is not None)
  if aq is not None:assert (h['version'],h['key'],h['canonicalSHA256'])==(aq['version'],aq['correct'],canonical(aq))
 item=[]
 for lang in ['pt','en']:item.extend([q['text'][lang]]*2)
 for o in q['options']:
  for lang in ['pt','en']:
   for f in ['text','explanation']:item.extend([o[f][lang]]*2)
 for lang in ['pt','en']:item.extend([q['explanation'][lang]]*2)
 assert len(item)==40
 for lang in ['pt','en']:item.extend([q['text'][lang],row['optionalEditorialCandidate']['text'][lang]])
 report=(root/folder/'reports'/(ident+'.md')).read_text(encoding='utf8')
 assert re.findall(r'```text\n([\s\S]*?)\n```',report)==item and len(item)==44
 pairs=row['analysis']['criticalPairs'];first={p[0] for p in pairs};parsed=[]
 for line in report.splitlines():
  if line.startswith('|'):
   cells=[c.strip() for c in line.split('|')[1:-1]]
   if len(cells)==4 and cells[0] in first:parsed.append(cells)
 assert parsed==pairs;pairCount+=len(pairs);blocks.extend(item)
assert len(blocks)==88 and pairCount==13
assert re.findall(r'```text\n([\s\S]*?)\n```',(root/'ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==blocks
for n in ['legacy-academic-context','targeted-vitest','format-check','diff-check']:assert read('evidence/checks/'+n+'-result.json')['exitCode']==0
assert 'NOT Batch7-specific' in read('evidence/checks/legacy-academic-context-result.json')['scopeNote']
assert read('docs/academic/phase10h-batch3-2026-11-06/record.json')['ownerDecision'] is None
for n in [4,5,6]:
 d=read('docs/academic/phase10h-batch'+str(n)+'-2026-11-06/decision-matrix.json');assert d['ownerAcceptedCount']==d['humanApprovedCount']==0
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(expected),'individualReports':2,'actualComparisonTextBlocks':80,'optionalComparisonTextBlocks':8,'criticalConceptPairs':pairCount,'alternativesReviewed':8,'historicalBanksVerified':9,'IDsAndKeysPreserved':90,'priorBatchDocumentsVerified':57,'extraComparisonFilesIncluded':7,'negativeCasesRejected':9,'newOwnerAcceptances':0,'newHumanApprovals':0,'linguisticTruthAutomaticallyProven':False},indent=2))
