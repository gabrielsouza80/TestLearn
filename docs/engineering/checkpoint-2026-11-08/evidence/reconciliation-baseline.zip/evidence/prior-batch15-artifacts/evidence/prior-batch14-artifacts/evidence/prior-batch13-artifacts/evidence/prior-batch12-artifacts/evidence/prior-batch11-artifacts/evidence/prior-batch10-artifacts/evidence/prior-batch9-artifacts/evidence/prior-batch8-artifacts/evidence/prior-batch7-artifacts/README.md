# TestLearn — Phase10H Batch7 academic and linguistic review evidence

Start with [ACADEMIC-REVIEW-SUMMARY.md](ACADEMIC-REVIEW-SUMMARY.md), [docs/academic/phase10h-batch7-2026-11-06/README.md](docs/academic/phase10h-batch7-2026-11-06/README.md), the two detailed bilingual reports, decision-matrix.json and verification.md.

## Identity and decision boundaries

Branch develop, HEAD `3fd0a85d95ecb79539515833ee3cbe7869c58049`, content revision2026-10-27.10. tl-022FL-4.4.1/K2independent/published keyo1; tl-041FL-1.5.2/K1keyo2. Both AI recommendations ACCEPT_AS_IS. No confirmed mandatory correction. Optional clarity candidates have complete original/candidate PT/EN, unchanged EN/key/options/explanations, explicit LOWlexical risk, rationale, future version/history/persistence effects and proposed tests if authorized. No candidate is applied or represented as a required correction.

No question, code, test, key, version, revision or persistence change. No.11created. All260existing files,46pending documents and57prior Batch1–6documents remain byte-identical; all57prior documents are included. Prior owner records retain exact scope; Batch3–6technical continuity/review does not become OWNER_ACCEPTED. Zero new owner/human approvals. Phase10H remainsOPEN; Batch8not started. No staging/commit/push/merge/PR/release/deploy or real student-data access.

## Academic findings and sources

tl-022: personal knowledge/o seu conhecimento preserve whose knowledge guides selection; prior failures in similar products directly support error guessing. The leap-day Portuguese wording can be clearer but does not change the selection basis. Dates can occur in BVA/exploratory work without making either the best explanation of the stated basis. tl-041: equipa de desenvolvimento can be cross-functional; a programmers-only reading is a residual lexical risk, not a restriction stated in the question. All alternatives and rationales support one answer. PSTQB retains Whole Team Approach; the optional Portuguese gloss is reviewer wording, not an official term.

EN4.0.1§4.4.1pp.43–44,§4.4.2p.44,§4.2.2p.40,§1.5.2p.22; LOpp.38/14. PT4.0/v1.0§4.4.1pp.47–48,§4.4.2p.48,§4.2.2pp.43–44,§1.5.2p.24; LOpp.41/15. Official URLs/local-byte hashes and physical pages counting cover are in sources.json. Local PDFs freshly read; ENweb open succeeded; PTweb fetch timed out. No fresh remote-byte equality or PTcoverage of allENerrata is claimed. Full copyrighted sources are not bundled. AI review is not independent human SME certification or psychometric evidence.

## Fresh tests and preservation

60/60Vitest tests in4files, no reported failure/skip. Batch7-specific checks validate evidence consistency for exactlytl-022/tl-041: pinned full-object hashes/versions/LO/K, recorded blind solutions,8option assessments,13literal critical-concept anchors, optional wording separation and approval boundaries. Nine corrupted records/projections are rejected. These are mechanical checks, **not automated proof of linguistic truth**.

The legacy guard using--phase10h-batch2was freshly run as historical context only. Its historical statuses are not rewritten or presented as Batch7approval. Logs/argv/timestamps/exit codes distinguish each check. Full TypeScript/lint/build/E2E were not repeated for documentation-only additions. One initial PDF-helper pagination assumption and one source-path lookup failed and were corrected without repository changes; both are disclosed in helper-failures.json.

All90IDs/keys/versions/explanations and immutable.1–.9banks are preserved; current.10matches preflight. Seven requested comparison files are included and their hashes match the Batch5ZIP:src/data/syllabus-questions.ts,src/data/variability-questions.ts,src/domain/blueprint.ts,tests/unit/academic-audit.test.ts,tests/unit/blueprint.test.ts,tests/unit/quality-maintenance.test.ts,tests/unit/variability.test.ts. Actual definitions in questions.ts/blueprint-questions.ts and review metadata JSON are included as relevant source context.

## Portable verification

Extract into a new empty directory. Inspect VERIFY-PACKAGE.py and BATCH7-RULES.py; run `python VERIFY-PACKAGE.py` with Python3.9+ standard library, without-O. Both files are read-only; bytecode writes disabled, no network/subprocesses. The verifier checks all payload sizes/hashes,57prior documents,7required comparison files,9archives,90IDs/keys/per-object hashes,2current questions,80literal actual comparisons,8optional text comparisons,13critical concept pairs,9negative cases and zero new approval claims. It does not independently solve natural-language meaning or confer human approval.

MANIFEST.json hashes every other file with relative path,size,SHA-256,provenance. It excludes itself to avoid recursive hashing; the wholeZIP SHA supplied externally covers it. Hashes are consistency checks, not authenticity signatures. GIT-CHANGE-INVENTORY.json distinguishes9new documents from46preexisting pending documents. A deliberately changed copied payload must fail before restoration; clean extracted verification must pass.

The package is **self-contained review evidence, not a complete executable repository**. Python portable verification needs only the extracted package. Original TypeScript/Vitest commands require the full checkout and pinned dependencies; source/test copies are context, not full module closure. evidence/local-verification-script.py requires the original workspace; do not confuse it with the portable verifier. No credentials,tokens,.env,.git,node_modules,dist,test-results,browser profiles,private backups,real student data orLocalStorage exports are included.
