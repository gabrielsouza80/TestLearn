"""Inspect before running. Python3.9+ standard library, read-only, no network/subprocess.
Hashes establish consistency, not authenticity, semantic truth or human approval.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Python -O is forbidden: integrity assertions must be enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,runpy,re,datetime
root=Path(__file__).resolve().parent
def safe(n):
 assert isinstance(n,str) and n and '\\' not in n and ':' not in n and '\x00' not in n
 pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and pp.as_posix()==n
 p=root/n;assert p.resolve().is_relative_to(root) and not any(a.is_symlink() for a in [p,*p.parents] if a.is_relative_to(root))
 return p
def read(n):return json.loads(safe(n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
m=read('MANIFEST.json');files=m['files'];names=[e['relativePath'] for e in files]
assert len(names)==len(set(names))==len({n.casefold() for n in names})
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};assert actual==set(names)|{'MANIFEST.json'}
for e in files:
 b=safe(e['relativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256'] and e['provenance'],e['relativePath']
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json');inv=read('GIT-CHANGE-INVENTORY.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049' and pre['contentRevision']=='2026-10-27.10'
assert pre['priorPackageName']=='TestLearn-Phase10H-Batch11-Academic-Review-20261106.zip' and pre['priorPackageSHA256']=='57db2636f49d56402944f71f8b87d14b0235cc25cd2d47d5b01951b3730c6188'
assert pre['priorManifestHashCount']==298 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical'] and proof['existingFilesByteIdentical']==len(pre['existingFilesSHA256'])==332 and proof['priorUncommittedDocumentsPreserved']==len(pre['existingUncommittedDocuments'])==118
assert len(proof['priorBatchDocumentsSHA256'])==129 and proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
assert inv['existingFilesChanged']==[] and len(inv['newFiles'])==20 and len(inv['preservedPendingDocuments'])==118
for e in inv['newFiles']:
 b=safe(e['relativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
for e in files:
 if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
continuity=read('EXPORT-CONTINUITY.json');oldManifest=read(continuity['priorManifestPath']);old={e['relativePath']:e for e in oldManifest['files']}
assert continuity['previousPackageSHA256']==pre['priorPackageSHA256'] and continuity['previousFileCount']==len(continuity['files'])==299
assert len({e['previousRelativePath'] for e in continuity['files']})==299 and {e['previousRelativePath'] for e in continuity['files']}==set(old)|{'MANIFEST.json'}
assert sum(e['kind']=='preserved_repository_reference' for e in continuity['files'])==167 and continuity['omittedFiles']==[]
for e in continuity['files']:
 b=safe(e['currentRelativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
 if e['previousRelativePath']!='MANIFEST.json':assert (len(b),sha(b))==(old[e['previousRelativePath']]['sizeBytes'],old[e['previousRelativePath']]['sha256'])
bank=read('review-data/current-bank.json');pres=read('BANK-PRESERVATION.json')
assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64 and pres['contentRevision']=='2026-10-27.10'
assert len(pres['questions'])==90
for a,q in zip(pres['questions'],bank):assert a['id']==q['id'] and a['beforeCanonicalSHA256']==a['afterCanonicalSHA256']==canonical(q) and a['beforeKey']==a['afterKey']==q['correct'] and a['beforeVersion']==a['afterVersion']==q['version']
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
archive=read('src/data/archive/questions-2026-10-27.9.json');assert [q['id'] for q in archive]==[q['id'] for q in bank] and all(a['correct']==q['correct'] for a,q in zip(archive,bank))
assert [q['id'] for a,q in zip(archive,bank) if a!=q]==['tl-011','tl-090']
q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
folder='docs/academic/phase10h-batch12-2026-11-06/'
matrix=read(folder+'decision-matrix.json');comparisons=read(folder+'exact-comparisons.json');blind=read(folder+'blind-solutions.json');projections=read(folder+'blind-projection.json');options=read(folder+'alternative-assessments.json');sources=read(folder+'sources.json');optional=read(folder+'optional-candidates.json')
assert blind==read('evidence/blind-solutions.json') and projections==read('evidence/blind-projection.json') and blind['projectionSHA256']==sha(safe('evidence/blind-projection.json').read_bytes())
reveal=read('evidence/key-reveal.json');assert len(reveal['questions'])==8
for s,k in zip(blind['solutions'],reveal['questions']):assert s['questionId']==k['questionId'] and s['answer']==k['key']==k['independentAnswer'] and datetime.datetime.fromisoformat(s['recordedAt'])<datetime.datetime.fromisoformat(reveal['at'])
reports={d['questionId']:safe(folder+'reports/'+d['questionId']+'.md').read_text(encoding='utf8') for d in matrix['decisions']}
archives={'2026-10-27.'+str(i):read('src/data/archive/questions-2026-10-27.'+str(i)+'.json') for i in range(1,10)}
g=runpy.run_path(str(safe('GLOBAL12-RULES.py')));reference=g['load_reference'](safe('reference-bank.json').read_bytes());globalResult=g['check_bank'](bank,reference);globalNegative=g['negative_checks'](reference)
rules=runpy.run_path(str(safe('BATCH12-RULES.py')));args=[bank,matrix,comparisons,blind,projections,options,sources,optional,reports,archives];specific=rules['check'](*args);negative=rules['negative_checks'](*args,global_check=g['check_bank'],reference_bank=reference)
logged=read('evidence/checks/batch12-specific-result.json');assert {k:logged[k] for k in specific}==specific and logged['negativeChecks']==negative and logged['globalBankCheck']==globalResult and logged['globalNegativeChecks']==globalNegative and logged['exitCode']==0
allBlocks=[]
for d in matrix['decisions']:allBlocks.extend(re.findall(r'```text\n([\s\S]*?)\n```',reports[d['questionId']]))
assert len(allBlocks)==320 and re.findall(r'```text\n([\s\S]*?)\n```',safe('ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==allBlocks
for n in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']:
 a=read('evidence/checks/'+n+'-result.json');assert a['exitCode']==0 and a['startedAt'] and a['completedAt']
scoring=json.loads(safe('evidence/checks/multiple-answer-scoring.log').read_text());assert len(scoring['syntheticSelections'])==8 and all(c['expected']==c['actual'] for c in scoring['syntheticSelections']) and not scoring['storageAccessed']
resume=read('evidence/recovery/resume-snapshot.json');assert len(resume['filesSHA256'])==350 and len(resume['batch12ExistingFilesSHA256'])==18
for n,h in resume['batch12ExistingFilesSHA256'].items():assert sha(safe(n).read_bytes())==h
assert sha(safe('evidence/recovery/original/STOP-FAILURE.json').read_bytes())==resume['STOP_FAILURE_SHA256']
assert read('evidence/recovery/original/STOP-FAILURE.json')['exitCode']==1
red=read('evidence/recovery/red-result.json');green=read('evidence/recovery/green-result.json');assert red['exitCode']==1 and green['exitCode']==0
assert 'False positive: unauthorized bank edit' in safe('evidence/recovery/red.log').read_text()
oldRules=runpy.run_path(str(safe('evidence/recovery/original/BATCH12-RULES.py')))
try:oldRules['negative_checks'](*args)
except AssertionError as e:assert str(e)=='False positive: unauthorized bank edit'
else:raise AssertionError('Original RED must remain reproducible')
replay=read('evidence/recovery/red-green-result.json');assert replay['result']=='PASS' and replay['GREEN']['sameTl002Mutation']=='adulterated bank' and all(replay['GREEN'][k] for k in ['globalRejected','intactBankControlPassed','scopedTl016MutationRejected','scopedContractRetained','originalNegativeCaseRetained'])
assert replay['combinedNegativeChecks']==negative and replay['globalNegativeChecks']==globalNegative and read('evidence/recovery/diagnosis.json')['hypothesisB']=='CONFIRMED'
helperDiff=read('evidence/recovery/helper-diff.json');assert helperDiff['originalCaseLiteralPreserved'] and helperDiff['bankOrApplicationChanges']==[]
assert "('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank'))" in safe('BATCH12-RULES.py').read_text()
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(files),'previousPackageFilesAccountedFor':299,'priorAcademicDocumentsVerified':129,'preRecoveryAcademicDocumentsByteIdentical':18,'questionsPreserved':90,'alternativesPreserved':364,'learningObjectivesPreserved':64,'historicalArchivesVerified':9,'batch12ReviewedQuestions':8,'batch12AlternativesVerified':32,'actualComparisonBlocks':320,'combinedNegativeCasesRejected':negative['negativeCasesRejected'],'globalNegativeCasesRejected':globalNegative['negativeCasesRejected'],'originalREDReproduced':True,'sameTl002ScenarioGREEN':True,'syntheticScoringChecks':8,'ownerAcceptedAdded':0,'humanApprovedAdded':0,'semanticTruthAutomaticallyProven':False},indent=2))
