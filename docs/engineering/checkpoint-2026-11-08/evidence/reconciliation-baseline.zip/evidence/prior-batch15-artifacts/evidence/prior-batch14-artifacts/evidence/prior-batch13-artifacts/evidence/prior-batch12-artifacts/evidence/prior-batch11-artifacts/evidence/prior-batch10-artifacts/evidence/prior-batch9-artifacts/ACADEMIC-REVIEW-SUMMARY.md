# TestLearn — Fase10H Lote9 / Batch9

**8ACCEPT_AS_ISporAI; nenhum defeito académico obrigatório demonstrado; banco inalterado.**

| ID                          | LO/K        | Independente/publicada | Parecer      |
| --------------------------- | ----------- | ---------------------- | ------------ |
| [tl-024](reports/tl-024.md) | FL-4.5.2/K2 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-030](reports/tl-030.md) | FL-5.1.6/K1 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-032](reports/tl-032.md) | FL-5.1.3/K2 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-033](reports/tl-033.md) | FL-5.2.2/K2 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-040](reports/tl-040.md) | FL-6.2.1/K1 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-044](reports/tl-044.md) | FL-5.1.7/K2 | ['o4']/['o4']          | ACCEPT_AS_IS |
| [tl-055](reports/tl-055.md) | FL-3.1.2/K2 | ['o1']/['o1']          | ACCEPT_AS_IS |
| [tl-056](reports/tl-056.md) | FL-3.2.1/K1 | ['o3']/['o3']          | ACCEPT_AS_IS |

Quatro candidatos opcionais não aplicados: explicação geral detl-024, alinhamentoPTde o2detl-030(ENinalterado), explicação geral detl-040e justificação de o2detl-044. Nenhuma correção obrigatória ou redesign dos outros itens. Cada relatório contém contraevidência, limites de interpretação e textos integraisPT/EN. A matriz alternativa-assessments.jsoncobre exatamente32opções.

develop,HEAD3fd0a85d95ecb79539515833ee3cbe7869c58049; banco2026-10-27.10. Preflight:285ficheiros/71pendentes e82documentos anteriores preservados. ZIP8validado:176membros/175payload hashes. Continuidade integral será demonstrada com mapa origem→destino, sem duplicar referências iguais.

RevisãoAI não equivale aHUMAN_APPROVEDouOWNER_ACCEPTED. Não se atribuíram novos aceites. Nenhum banco,ID,gabarito,versão,contrato de persistência ou documento anterior foi alterado. Fase10Haberta; Lote10não iniciado. Sem staging/commit/push/merge/PR/deploy/produção/dados reais.

Fontes e páginas verificadas emsources.json; PTwebtimeoutdocumentado, fonte oficial local consultada. Checks automáticos só comprovam integridade/consistência, não verdade académica. Resultados novos emverification.md; auditoria externa é o próximo passo.


# tl-024 — ACCEPT_AS_IS

LO`FL-4.5.2`; K2; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`fa851be96d01839d044a574c67f8ee6c2fba4ba65ba7f7a0723c920cdd5d1a2a` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

The request explicitly requires initial context, trigger and observable expected outcome. Given an empty basket supplies context; when opened supplies the event; showing zero supplies the result. The zero rule ino3is valid rule-oriented acceptance wording but lacks an explicit action, so does not best satisfy this specific request. o2is a sum rule rather than the requested scenario; o4names a trigger and internal service call but not starting empty context or an observable expected total. Unique offered matcho1; no universal requirement that all acceptance criteria useGiven/When/Then.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter4, §4.5.2; EN4.0.1pp.[38, 45, 46]; PT4.0/v1.0pp.[41, 49, 50]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** o1 explicita cesto vazio como contexto, abertura como ação/evento e apresentação de total zero como resultado observável. o2/o3 podem ser critérios válidos orientados a regras, mas não fornecem os três elementos explícitos pedidos. A unicidade depende desse requisito, não de tornar Given/When/Then obrigatório para qualquer critério.

**EN:** o1gives empty basket context, opening event and visible zero total. o2/o3can be valid rule-oriented criteria but lack the requested explicit three-part scenario. Uniqueness depends on that requirement, not universal mandatory Given/When/Then wording.

## Comparação PT/EN / PT/EN comparison

**PT:** Starting context/contexto inicial e triggering action/ação desencadeadora não foram trocados. When opened/quando é aberto refere o cesto em ambas as versões; não substitui o estado inicial vazio. Show a zero total/apresenta total zero é o mesmo resultado. O sujeito implícito de apresentar é o sistema/interface.

**EN:** Context and triggering action retain distinct roles. When opened refers to the basket in both languages, not its initial empty state. Showing zero is the same expected outcome; the implicit display actor is the system/interface.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** o3 tem contexto e resultado e é uma regra legítima; falta a ação explícita, pelo que não é a melhor resposta ao pedido completo. Alguns cestos reais podem ter taxas, mas o exemplo define total zero e não pede uma regra universal de comércio. O4 inclui ação interna de implementação sem resultado esperado definido.

**EN:** o3has context/outcome and is a legitimate rule, but lacks the explicit action required here. Real baskets may have fees, but this stipulated example is not a universal commerce rule. o4supplies an internal implementation action without the required observable result.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-4.5.2/K2 distingue formatos de critérios; dificuldade baixa/média com o3 próximo. As justificações são corretas, embora uma expansão possa evitar que o aluno considere regras inerentemente inválidas. Não é derivação completa de uma suiteK3.

**EN:** FL-4.5.2/K2distinguishes acceptance-criterion formats; low/moderate difficulty with a close rule-oriented distractor. Rationales are correct, with optional teaching clarification that rules are not inherently invalid.

## Riscos de interpretação / Interpretation risks

**PT:** LOW: extrapolar a preferência deste exemplo para uma obrigação universal de sintaxe ou presumir cobertura completa da user story. Nenhuma dessas conclusões é exigida.

**EN:** LOWrisk of universalizing this requested format or inferring complete story coverage; neither is required.

## Conceitos críticos / Critical concepts

| ENliteral         | PTliteral           | Avaliação / Assessment |
| ----------------- | ------------------- | ---------------------- |
| starting context  | contexto inicial    | EQUIVALENT_CONTEXT     |
| triggering action | ação desencadeadora | EQUIVALENT_TRIGGER     |
| when opened       | quando é aberto     | EQUIVALENT_EVENT       |
| zero total        | total zero          | EQUIVALENT_RESULT      |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: contém os três elementos, com total zero observável.

**EN:** Correct: all three elements are explicit with observable zero total.

### o2 — distrator/distractor

**PT:** Regra de soma válida noutro pedido; não explicita evento e contexto concreto.

**EN:** A potentially valid sum rule in another request, not the explicit concrete event/context requested.

### o3 — distrator/distractor

**PT:** Regra válida com cesto vazio e total zero; falta o evento explícito.

**EN:** A valid empty-basket/zero-total rule, lacking the explicit trigger.

### o4 — distrator/distractor

**PT:** Chamada ao serviço não fornece o contexto inicial nem o total esperado observável.

**EN:** A service call supplies neither initial state nor observable expected total.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Uma equipa precisa de um exemplo de aceitação que explicite o contexto inicial, a ação desencadeadora e o resultado esperado observável. Que critério melhor satisfaz essa necessidade?
```

### pt statement RETAINED_UNCHANGED

```text
Uma equipa precisa de um exemplo de aceitação que explicite o contexto inicial, a ação desencadeadora e o resultado esperado observável. Que critério melhor satisfaz essa necessidade?
```

### en statement ORIGINAL

```text
A team needs an acceptance example that explicitly states the starting context, triggering action and observable expected result. Which criterion best meets that need?
```

### en statement RETAINED_UNCHANGED

```text
A team needs an acceptance example that explicitly states the starting context, triggering action and observable expected result. Which criterion best meets that need?
```

### o1 pt text ORIGINAL

```text
Dado um cesto vazio, quando é aberto, então apresenta total zero
```

### o1 pt text RETAINED_UNCHANGED

```text
Dado um cesto vazio, quando é aberto, então apresenta total zero
```

### o1 pt explanation ORIGINAL

```text
O critério descreve contexto, evento e resultado observável concretos.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
O critério descreve contexto, evento e resultado observável concretos.
```

### o1 en text ORIGINAL

```text
Given an empty basket, when opened, then show a zero total
```

### o1 en text RETAINED_UNCHANGED

```text
Given an empty basket, when opened, then show a zero total
```

### o1 en explanation ORIGINAL

```text
The criterion describes a concrete context, event and observable outcome.
```

### o1 en explanation RETAINED_UNCHANGED

```text
The criterion describes a concrete context, event and observable outcome.
```

### o2 pt text ORIGINAL

```text
O total do cesto deve ser igual à soma dos preços dos seus artigos.
```

### o2 pt text RETAINED_UNCHANGED

```text
O total do cesto deve ser igual à soma dos preços dos seus artigos.
```

### o2 pt explanation ORIGINAL

```text
Este é um critério orientado para regras, não um cenário Dado/Quando/Então.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Este é um critério orientado para regras, não um cenário Dado/Quando/Então.
```

### o2 en text ORIGINAL

```text
The basket total must equal the sum of its item prices.
```

### o2 en text RETAINED_UNCHANGED

```text
The basket total must equal the sum of its item prices.
```

### o2 en explanation ORIGINAL

```text
This is a rule-oriented criterion, not a Given/When/Then scenario.
```

### o2 en explanation RETAINED_UNCHANGED

```text
This is a rule-oriented criterion, not a Given/When/Then scenario.
```

### o3 pt text ORIGINAL

```text
Um cesto sem artigos deve ter um total igual a zero.
```

### o3 pt text RETAINED_UNCHANGED

```text
Um cesto sem artigos deve ter um total igual a zero.
```

### o3 pt explanation ORIGINAL

```text
Isto apresenta uma regra sem a estrutura explícita de contexto, evento e resultado.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Isto apresenta uma regra sem a estrutura explícita de contexto, evento e resultado.
```

### o3 en text ORIGINAL

```text
A basket with no items must have a total of zero.
```

### o3 en text RETAINED_UNCHANGED

```text
A basket with no items must have a total of zero.
```

### o3 en explanation ORIGINAL

```text
This states a rule without the explicit context/event/outcome structure.
```

### o3 en explanation RETAINED_UNCHANGED

```text
This states a rule without the explicit context/event/outcome structure.
```

### o4 pt text ORIGINAL

```text
Quando o cesto é aberto, calcular o total através de uma chamada ao serviço de preços
```

### o4 pt text RETAINED_UNCHANGED

```text
Quando o cesto é aberto, calcular o total através de uma chamada ao serviço de preços
```

### o4 pt explanation ORIGINAL

```text
Isto descreve uma ação de implementação, mas omite o estado inicial do cesto e o total esperado observável. Não é um exemplo de aceitação completo no formato solicitado.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Isto descreve uma ação de implementação, mas omite o estado inicial do cesto e o total esperado observável. Não é um exemplo de aceitação completo no formato solicitado.
```

### o4 en text ORIGINAL

```text
When the basket opens, calculate its total by calling the pricing service
```

### o4 en text RETAINED_UNCHANGED

```text
When the basket opens, calculate its total by calling the pricing service
```

### o4 en explanation ORIGINAL

```text
This describes an implementation action, but omits the starting basket state and the observable expected total. It is not a complete acceptance example of the requested form.
```

### o4 en explanation RETAINED_UNCHANGED

```text
This describes an implementation action, but omits the starting basket state and the observable expected total. It is not a complete acceptance example of the requested form.
```

### pt general explanation ORIGINAL

```text
O critério descreve contexto, evento e resultado observável concretos.
```

### pt general explanation RETAINED_UNCHANGED

```text
O critério descreve contexto, evento e resultado observável concretos.
```

### en general explanation ORIGINAL

```text
The criterion describes a concrete context, event and observable outcome.
```

### en general explanation RETAINED_UNCHANGED

```text
The criterion describes a concrete context, event and observable outcome.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
O critério descreve contexto, evento e resultado observável concretos.
```

### pt affected field OPTIONAL_CANDIDATE

```text
O exemplo pedido liga explicitamente o contexto de cesto vazio, a ação de abrir e o total zero observável. Os critérios orientados a regras também são formatos de aceitação válidos, mas o2 e o3 não exprimem todos os três elementos pedidos. Este exemplo isolado não implica cobertura completa da user story.
```

### en affected field ORIGINAL

```text
The criterion describes a concrete context, event and observable outcome.
```

### en affected field OPTIONAL_CANDIDATE

```text
The requested example explicitly links an empty-basket context, opening action and observable zero total. Rule-oriented criteria are also valid acceptance formats, but o2 and o3 do not express all three requested elements. This single example does not imply complete story coverage.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão3→4 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-030 — ACCEPT_AS_IS

LO`FL-5.1.6`; K1; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`b9f41f5222ac38fb497ddec1bfc228d17b8b41639b512dca149593ee82f160de` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

A conventional test pyramid generally favours many small/isolated low-level tests and fewer large end-to-end tests. Generally preserves contextual variation, not a universal quota. o2inverts the pyramid; o3equal counts lack the pyramidal distribution; o4is integration-heavy rather than the conventional pyramid. Low-level describes granularity/scope, not low quality; small/large are not promised numeric sizes.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter5, §5.1.6; EN4.0.1pp.[47, 50, 51]; PT4.0/v1.0pp.[52, 56]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** A pirâmide geralmente favorece base larga de testes pequenos/isolados e menos testes grandes de ponta a ponta. o1 descreve a distribuição. o2 inverte-a, o3 iguala contagens e o4 concentra testes no meio. O modelo não fixa percentagens ou camadas universais.

**EN:** A pyramid generally favours many small/isolated tests below and fewer large end-to-end tests above. o1matches; o2inverts, o3equalizes counts and o4concentrates the middle. No universal percentages or layer count are fixed.

## Comparação PT/EN / PT/EN comparison

**PT:** Generally/geralmente preserva a qualificação. Low-level/baixo nível indica âmbito/granularidade, não baixa qualidade; small/large não é um limiar numérico. Há diferença lexical real em o2: isolated low-level tests vira testes pequenos e isolados, omitindo baixo nível e acrescentando pequenos. Não são sinónimos literais, mas ambas as opções mantêm a inversão muitosE2E/poucos testes da base.

**EN:** Generally remains qualified; low-level is scope/granularity, not low quality, and size is not a numeric threshold. o2has a real lexical difference: low-level becomes small in Portuguese. These are not literal synonyms, but both offered forms retain the inverse end-to-end-heavy distribution.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Uma estratégia contextual pode preferir muitos testes de integração ouE2E; isso não muda o que uma pirâmide geralmente representa. Níveis e nomes de camadas variam. A diferença PTde o2 não o torna a pirâmide correta nem afeta o1, já equivalente integralmente.

**EN:** Context-specific strategies may favour integration/E2Etests, without changing what a conventional pyramid generally depicts. Layers/names vary. o2’s PTscope difference does not make its inverted distribution correct or affect the fully equivalento1.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-5.1.6/K1 recorda o modelo; dificuldade baixa apropriada. Pequeno não significa necessariamente baixo nível em todos os contextos, embora se correlacionem na descrição convencional. Não usar o modelo para excluirE2E necessários.

**EN:** FL-5.1.6/K1recalls the model; appropriate low difficulty. Small and low-level are correlated in the conventional model, not universally interchangeable. NecessaryE2Etests are not excluded.

## Riscos de interpretação / Interpretation risks

**PT:** LOW: sinonímia imprecisa no distrator o2 e leitura de baixo nível como qualidade. O resultado da questão continua inequívoco; alinhamento lexical é opcional.

**EN:** LOWlexical risk ino2and low-level/quality confusion; the answer remains unambiguous, with optional lexical alignment.

## Conceitos críticos / Critical concepts

| ENliteral                      | PTliteral                        | Avaliação / Assessment                    |
| ------------------------------ | -------------------------------- | ----------------------------------------- |
| generally encouraged           | geralmente incentivada           | EQUIVALENT_QUALIFIER                      |
| small low-level tests          | testes pequenos de baixo nível   | EQUIVALENT_GRANULARITY                    |
| large end-to-end tests         | testes grandes de ponta a ponta  | EQUIVALENT_SCOPE                          |
| fewer isolated low-level tests | menos testes pequenos e isolados | NONLITERAL_SCOPE_DIFFERENCE_NO_KEY_CHANGE |
| Equal numbers                  | Um número igual                  | EQUIVALENT_COUNT                          |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: muitos testes pequenos de baixo nível, menosE2Egrandes, com qualificação geral.

**EN:** Correct: generally many small low-level tests and fewer largeE2Etests.

### o2 — distrator/distractor

**PT:** Inverte a proporção em ambas as línguas; PTtem substituição lexical descrita, sem tornar a opção correta.

**EN:** Inverted in both languages; acknowledged PTlexical substitution does not make it correct.

### o3 — distrator/distractor

**PT:** Contagens iguais não representam a proporção piramidal, ainda que possam ocorrer num projeto específico.

**EN:** Equal counts do not depict the pyramid, even if a particular project has them.

### o4 — distrator/distractor

**PT:** Concentração de integração descreve outra distribuição, não a pirâmide geral pedida.

**EN:** Integration concentration describes another distribution, not the requested general pyramid.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Que distribuição é geralmente incentivada pela pirâmide de testes?
```

### pt statement RETAINED_UNCHANGED

```text
Que distribuição é geralmente incentivada pela pirâmide de testes?
```

### en statement ORIGINAL

```text
Which distribution is generally encouraged by a test pyramid?
```

### en statement RETAINED_UNCHANGED

```text
Which distribution is generally encouraged by a test pyramid?
```

### o1 pt text ORIGINAL

```text
Muitos testes pequenos de baixo nível, menos testes grandes de ponta a ponta
```

### o1 pt text RETAINED_UNCHANGED

```text
Muitos testes pequenos de baixo nível, menos testes grandes de ponta a ponta
```

### o1 pt explanation ORIGINAL

```text
Os testes menores dão frequentemente feedback rápido e localizado.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Os testes menores dão frequentemente feedback rápido e localizado.
```

### o1 en text ORIGINAL

```text
Many small low-level tests, fewer large end-to-end tests
```

### o1 en text RETAINED_UNCHANGED

```text
Many small low-level tests, fewer large end-to-end tests
```

### o1 en explanation ORIGINAL

```text
Smaller tests often give fast, focused feedback.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Smaller tests often give fast, focused feedback.
```

### o2 pt text ORIGINAL

```text
Muitos testes grandes de ponta a ponta, menos testes pequenos e isolados
```

### o2 pt text RETAINED_UNCHANGED

```text
Muitos testes grandes de ponta a ponta, menos testes pequenos e isolados
```

### o2 pt explanation ORIGINAL

```text
Isto inverte a pirâmide. Os testes grandes de ponta a ponta exigem geralmente mais tempo e dão feedback menos localizado do que os testes pequenos e isolados.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Isto inverte a pirâmide. Os testes grandes de ponta a ponta exigem geralmente mais tempo e dão feedback menos localizado do que os testes pequenos e isolados.
```

### o2 en text ORIGINAL

```text
Many large end-to-end tests, fewer isolated low-level tests
```

### o2 en text RETAINED_UNCHANGED

```text
Many large end-to-end tests, fewer isolated low-level tests
```

### o2 en explanation ORIGINAL

```text
This inverts the pyramid. Large end-to-end tests generally cost more time and provide less focused feedback than small isolated tests.
```

### o2 en explanation RETAINED_UNCHANGED

```text
This inverts the pyramid. Large end-to-end tests generally cost more time and provide less focused feedback than small isolated tests.
```

### o3 pt text ORIGINAL

```text
Um número igual de testes em cada nível
```

### o3 pt text RETAINED_UNCHANGED

```text
Um número igual de testes em cada nível
```

### o3 pt explanation ORIGINAL

```text
Uma pirâmide representa proporções diferentes de acordo com a granularidade, o isolamento e o custo de execução, não contagens iguais entre níveis.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Uma pirâmide representa proporções diferentes de acordo com a granularidade, o isolamento e o custo de execução, não contagens iguais entre níveis.
```

### o3 en text ORIGINAL

```text
Equal numbers of tests at each level
```

### o3 en text RETAINED_UNCHANGED

```text
Equal numbers of tests at each level
```

### o3 en explanation ORIGINAL

```text
A pyramid represents different proportions according to granularity, isolation and execution cost, not equal counts across levels.
```

### o3 en explanation RETAINED_UNCHANGED

```text
A pyramid represents different proportions according to granularity, isolation and execution cost, not equal counts across levels.
```

### o4 pt text ORIGINAL

```text
Muitos testes de integração, menos testes de componente e de ponta a ponta
```

### o4 pt text RETAINED_UNCHANGED

```text
Muitos testes de integração, menos testes de componente e de ponta a ponta
```

### o4 pt explanation ORIGINAL

```text
Uma concentração no meio corresponde a uma distribuição diferente. A pirâmide tem geralmente uma base larga de testes pequenos e isolados e menos testes maiores nos níveis superiores.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Uma concentração no meio corresponde a uma distribuição diferente. A pirâmide tem geralmente uma base larga de testes pequenos e isolados e menos testes maiores nos níveis superiores.
```

### o4 en text ORIGINAL

```text
Many integration tests, fewer component and end-to-end tests
```

### o4 en text RETAINED_UNCHANGED

```text
Many integration tests, fewer component and end-to-end tests
```

### o4 en explanation ORIGINAL

```text
A concentration in the middle is a different distribution. The pyramid generally has a broad base of small isolated tests and fewer larger tests above.
```

### o4 en explanation RETAINED_UNCHANGED

```text
A concentration in the middle is a different distribution. The pyramid generally has a broad base of small isolated tests and fewer larger tests above.
```

### pt general explanation ORIGINAL

```text
Os testes menores dão frequentemente feedback rápido e localizado.
```

### pt general explanation RETAINED_UNCHANGED

```text
Os testes menores dão frequentemente feedback rápido e localizado.
```

### en general explanation ORIGINAL

```text
Smaller tests often give fast, focused feedback.
```

### en general explanation RETAINED_UNCHANGED

```text
Smaller tests often give fast, focused feedback.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['options', 'o2', 'text']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
Muitos testes grandes de ponta a ponta, menos testes pequenos e isolados
```

### pt affected field OPTIONAL_CANDIDATE

```text
Muitos testes grandes de ponta a ponta, menos testes isolados de baixo nível
```

### en affected field ORIGINAL

```text
Many large end-to-end tests, fewer isolated low-level tests
```

### en affected field OPTIONAL_CANDIDATE

```text
Many large end-to-end tests, fewer isolated low-level tests
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão3→4 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-032 — ACCEPT_AS_IS

LO`FL-5.1.3`; K2; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`7f60217b3313eae469e74621d7576b74d6a2c7d565a401eb20f2f9d5d87a7c86` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Available environment before system-testing start is an entry criterion; stakeholder residual-risk acceptance before declaring testing complete is an exit criterion in this scenario. o2reverses temporal roles; o3mislabels the completion condition; o4mislabels the start condition. Risk acceptance is a local stated completion requirement, not proof of absence of defects or a universal sufficient release gate.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter5, §5.1.3; EN4.0.1pp.[47, 49]; PT4.0/v1.0pp.[52, 54]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Ambiente disponível antes de iniciar teste de sistema é critério de entrada. Aceitar risco residual antes de declarar testes concluídos é critério de saída definido pela equipa neste cenário. A ordem pedida determina o1.

**EN:** Environment availability before system-testing start is entry; residual-risk acceptance before declaring completion is this team’s exit condition. The requested order identifieso1.

## Comparação PT/EN / PT/EN comparison

**PT:** Before starts/antes de iniciar e before declaring complete/antes de declarar concluídos preservam o momento e finalidade. Stakeholder acceptance/aceitação pelos stakeholders preserva quem aceita o risco. Não se troca aceitação do risco por ausência de defeitos ou autorização automática de release.

**EN:** Before start and before declaring completion preserve timing/purpose. Stakeholder acceptance retains who accepts risk, without replacing it with defect absence or automatic release authorization.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Disponibilidade do ambiente poderia ser saída de uma tarefa de preparação, e aceitação de risco poderia preceder outra atividade. Aqui são explicitamente relacionadas ao início do teste e à sua conclusão. A classificação é contextual, não essência imutável da mesma condição.

**EN:** Environment availability could close a setup task, and risk acceptance could precede another activity. Here their roles explicitly concern test start/completion; classification is contextual.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-5.1.3/K2 compara critérios usando finalidades distintas. Dificuldade baixa; a frase geral é suficiente e o3/o4 explicitam as condições. Não é necessário acrescentar condições de release não dadas.

**EN:** FL-5.1.3/K2compares criteria by purpose; low difficulty. Existing rationales explain the conditions sufficiently without invented release requirements.

## Riscos de interpretação / Interpretation risks

**PT:** LOW se se generalizar aceitação do risco como critério suficiente universal. O texto diz que a equipa exige esta condição, não que seja a única exigência de todo projeto.

**EN:** LOWrisk of universalizing risk acceptance as sufficient; this team requires it, without claiming it is every project’s sole gate.

## Conceitos críticos / Critical concepts

| ENliteral                                   | PTliteral                                      | Avaliação / Assessment |
| ------------------------------------------- | ---------------------------------------------- | ---------------------- |
| before system testing starts                | antes de iniciar o teste de sistema            | EQUIVALENT_ENTRY       |
| before declaring testing complete           | antes de declarar os testes concluídos         | EQUIVALENT_EXIT        |
| stakeholder acceptance of the residual risk | aceitação do risco residual pelos stakeholders | EQUIVALENT_ACTOR       |
| Entry criterion, then exit criterion        | Critério de entrada, depois critério de saída  | EQUIVALENT_ORDER       |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: início primeiro, conclusão depois.

**EN:** Correct: start condition first, completion condition second.

### o2 — distrator/distractor

**PT:** Inverte as finalidades explicitamente dadas.

**EN:** Reverses the expressly given purposes.

### o3 — distrator/distractor

**PT:** A segunda condição é declarada para conclusão, não início.

**EN:** Second condition concerns completion, not start.

### o4 — distrator/distractor

**PT:** A primeira condiciona início de teste, não a sua conclusão.

**EN:** First condition gates test start, not completion.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Uma equipa exige a disponibilidade do ambiente de teste antes de iniciar o teste de sistema e a aceitação do risco residual pelos stakeholders antes de declarar os testes concluídos. Como se classificam estes critérios?
```

### pt statement RETAINED_UNCHANGED

```text
Uma equipa exige a disponibilidade do ambiente de teste antes de iniciar o teste de sistema e a aceitação do risco residual pelos stakeholders antes de declarar os testes concluídos. Como se classificam estes critérios?
```

### en statement ORIGINAL

```text
A team requires an available test environment before system testing starts and stakeholder acceptance of the residual risk before declaring testing complete. How are these classified?
```

### en statement RETAINED_UNCHANGED

```text
A team requires an available test environment before system testing starts and stakeholder acceptance of the residual risk before declaring testing complete. How are these classified?
```

### o1 pt text ORIGINAL

```text
Critério de entrada, depois critério de saída
```

### o1 pt text RETAINED_UNCHANGED

```text
Critério de entrada, depois critério de saída
```

### o1 pt explanation ORIGINAL

```text
A entrada apoia o início; a saída apoia a decisão de conclusão.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A entrada apoia o início; a saída apoia a decisão de conclusão.
```

### o1 en text ORIGINAL

```text
Entry criterion, then exit criterion
```

### o1 en text RETAINED_UNCHANGED

```text
Entry criterion, then exit criterion
```

### o1 en explanation ORIGINAL

```text
Entry supports starting; exit supports deciding completion.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Entry supports starting; exit supports deciding completion.
```

### o2 pt text ORIGINAL

```text
Critério de saída, depois critério de entrada
```

### o2 pt text RETAINED_UNCHANGED

```text
Critério de saída, depois critério de entrada
```

### o2 pt explanation ORIGINAL

```text
A ordem está invertida.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
A ordem está invertida.
```

### o2 en text ORIGINAL

```text
Exit criterion, then entry criterion
```

### o2 en text RETAINED_UNCHANGED

```text
Exit criterion, then entry criterion
```

### o2 en explanation ORIGINAL

```text
The order is reversed.
```

### o2 en explanation RETAINED_UNCHANGED

```text
The order is reversed.
```

### o3 pt text ORIGINAL

```text
Ambos são critérios de entrada
```

### o3 pt text RETAINED_UNCHANGED

```text
Ambos são critérios de entrada
```

### o3 pt explanation ORIGINAL

```text
A disponibilidade do ambiente é uma pré-condição para começar, mas o risco residual aceite é aqui especificado como condição para declarar os testes concluídos.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
A disponibilidade do ambiente é uma pré-condição para começar, mas o risco residual aceite é aqui especificado como condição para declarar os testes concluídos.
```

### o3 en text ORIGINAL

```text
Both are entry criteria
```

### o3 en text RETAINED_UNCHANGED

```text
Both are entry criteria
```

### o3 en explanation ORIGINAL

```text
Environment availability is a precondition for starting, but accepted residual risk is specified here as a condition for declaring testing complete.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Environment availability is a precondition for starting, but accepted residual risk is specified here as a condition for declaring testing complete.
```

### o4 pt text ORIGINAL

```text
Ambos são critérios de saída
```

### o4 pt text RETAINED_UNCHANGED

```text
Ambos são critérios de saída
```

### o4 pt explanation ORIGINAL

```text
A primeira condição tem de ser satisfeita antes de começar o teste de sistema, pelo que é um critério de entrada. A segunda apoia a decisão de conclusão.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A primeira condição tem de ser satisfeita antes de começar o teste de sistema, pelo que é um critério de entrada. A segunda apoia a decisão de conclusão.
```

### o4 en text ORIGINAL

```text
Both are exit criteria
```

### o4 en text RETAINED_UNCHANGED

```text
Both are exit criteria
```

### o4 en explanation ORIGINAL

```text
The first condition must be met before system testing starts, so it is an entry criterion. The second supports the completion decision.
```

### o4 en explanation RETAINED_UNCHANGED

```text
The first condition must be met before system testing starts, so it is an entry criterion. The second supports the completion decision.
```

### pt general explanation ORIGINAL

```text
A entrada apoia o início; a saída apoia a decisão de conclusão.
```

### pt general explanation RETAINED_UNCHANGED

```text
A entrada apoia o início; a saída apoia a decisão de conclusão.
```

### en general explanation ORIGINAL

```text
Entry supports starting; exit supports deciding completion.
```

### en general explanation RETAINED_UNCHANGED

```text
Entry supports starting; exit supports deciding completion.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Não se propõe alteração apenas por preferência estilística. O conteúdo e explicações existentes são suficientes. / No change merely for style; existing content and explanations are sufficient.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-033 — ACCEPT_AS_IS

LO`FL-5.2.2`; K2; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`1dc16a58ba1ddf343dad01afe41b833ff1e0c141d0331f646367f592541c2815` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

The statement asks which possibility is a product risk. Incorrect tax in an invoice affects product functional correctness. Staff loss, late environment and supplier delay threaten project delivery/resources. The present-tense invoice example is scoped as a possible event, not a confirmed existing defect; invoice calculates is shorthand for invoicing functionality, not a physical paper calculating. Project risks can indirectly affect product quality without changing the primary classification of these offered examples.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter5, §5.2.2; EN4.0.1pp.[47, 52]; PT4.0/v1.0pp.[52, 57, 58]. Referências complementares / supporting sections: [{'section': '5.2.1', 'EN': [52], 'PT': [57]}]. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Imposto incorreto numa fatura ameaça correção funcional do produto. Saída de testador e atrasos de ambiente/fornecedor ameaçam recursos, calendário e execução do projeto. O enunciado enquadra todos como possibilidades; não afirma defeito já observado.

**EN:** Incorrect invoice tax threatens product functional correctness; staff/environment/supplier issues threaten project resources/schedule. The statement frames possibilities, not an already demonstrated defect.

## Comparação PT/EN / PT/EN comparison

**PT:** Possibility/possibilidades mantém carácter potencial; product rather than project preserva contraste. Invoice/fatura é metonímia do sistema/função de faturação: não se atribui cálculo físico a papel. A mesma expressão abreviada existe nas duas línguas.

**EN:** Possibility preserves potential occurrence and product/project contrast. Invoice is shorthand for invoicing functionality, not physical paper calculating; the same shorthand appears in both languages.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Riscos de projeto podem prejudicar indiretamente a qualidade; defeitos de produto podem atrasar projetos. O critério é o alvo direto do exemplo. A opção de imposto não identifica uma taxa legal específica, pelo que não se inventa legislação nem cálculo fiscal.

**EN:** Project risks can indirectly harm quality and product defects can delay projects. Classification uses the direct target of each example; no legal tax rate or calculation is supplied or invented.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-5.2.2/K2 distingue categorias por exemplos; dificuldade baixa. A explicação breve liga erro de cálculo à qualidade funcional e as restantes ligam recursos/agenda à entrega. Reescrever a metonímia seria estilo, sem necessidade comprovada.

**EN:** FL-5.2.2/K2distinguishes categories by examples; low difficulty. Existing explanations adequately separate functional quality from project delivery. Rewriting the shorthand would be style without demonstrated need.

## Riscos de interpretação / Interpretation risks

**PT:** LOW de leitura literal de fatura como agente ou de confundir possibilidade com falha confirmada. Contexto e contraste resolvem a resposta.

**EN:** LOWrisk of literal invoice-agent reading or treating possibility as a confirmed failure; context resolves the answer.

## Conceitos críticos / Critical concepts

| ENliteral                               | PTliteral                                      | Avaliação / Assessment |
| --------------------------------------- | ---------------------------------------------- | ---------------------- |
| Which possibility                       | Qual das seguintes possibilidades              | EQUIVALENT_POTENTIAL   |
| product risk rather than a project risk | risco de produto em vez de um risco de projeto | EQUIVALENT_CONTRAST    |
| An invoice calculates the wrong tax     | Uma fatura calcula imposto incorreto           | CONTEXTUAL_METONYMY    |
| A tester leaves the team                | Um testador sai da equipa                      | EQUIVALENT_EVENT       |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: cálculo potencialmente incorreto afeta qualidade funcional do produto.

**EN:** Correct: potentially wrong calculation concerns product functional quality.

### o2 — distrator/distractor

**PT:** Disponibilidade de pessoas ameaça entrega e recursos.

**EN:** Staff availability threatens delivery/resources.

### o3 — distrator/distractor

**PT:** Atraso de ambiente ameaça o calendário; um defeito do ambiente seria outro enunciado.

**EN:** Environment delay threatens schedule; an environment defect would be another statement.

### o4 — distrator/distractor

**PT:** Atraso do fornecedor é risco de entrega/recursos, não cálculo funcional.

**EN:** Supplier delay threatens delivery/resources, not functional calculation.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Qual das seguintes possibilidades é um risco de produto em vez de um risco de projeto?
```

### pt statement RETAINED_UNCHANGED

```text
Qual das seguintes possibilidades é um risco de produto em vez de um risco de projeto?
```

### en statement ORIGINAL

```text
Which possibility is a product risk rather than a project risk?
```

### en statement RETAINED_UNCHANGED

```text
Which possibility is a product risk rather than a project risk?
```

### o1 pt text ORIGINAL

```text
Uma fatura calcula imposto incorreto
```

### o1 pt text RETAINED_UNCHANGED

```text
Uma fatura calcula imposto incorreto
```

### o1 pt explanation ORIGINAL

```text
Imposto incorreto ameaça a qualidade do produto.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Imposto incorreto ameaça a qualidade do produto.
```

### o1 en text ORIGINAL

```text
An invoice calculates the wrong tax
```

### o1 en text RETAINED_UNCHANGED

```text
An invoice calculates the wrong tax
```

### o1 en explanation ORIGINAL

```text
Wrong tax threatens product quality.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Wrong tax threatens product quality.
```

### o2 pt text ORIGINAL

```text
Um testador sai da equipa
```

### o2 pt text RETAINED_UNCHANGED

```text
Um testador sai da equipa
```

### o2 pt explanation ORIGINAL

```text
A disponibilidade da equipa ameaça a entrega do projeto.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
A disponibilidade da equipa ameaça a entrega do projeto.
```

### o2 en text ORIGINAL

```text
A tester leaves the team
```

### o2 en text RETAINED_UNCHANGED

```text
A tester leaves the team
```

### o2 en explanation ORIGINAL

```text
Staff availability threatens project delivery.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Staff availability threatens project delivery.
```

### o3 pt text ORIGINAL

```text
Um ambiente de teste chega atrasado
```

### o3 pt text RETAINED_UNCHANGED

```text
Um ambiente de teste chega atrasado
```

### o3 pt explanation ORIGINAL

```text
Um ambiente atrasado ameaça o calendário do projeto.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Um ambiente atrasado ameaça o calendário do projeto.
```

### o3 en text ORIGINAL

```text
A test environment arrives late
```

### o3 en text RETAINED_UNCHANGED

```text
A test environment arrives late
```

### o3 en explanation ORIGINAL

```text
A late environment threatens the project schedule.
```

### o3 en explanation RETAINED_UNCHANGED

```text
A late environment threatens the project schedule.
```

### o4 pt text ORIGINAL

```text
Um fornecedor de uma ferramenta de teste falha a data de entrega acordada
```

### o4 pt text RETAINED_UNCHANGED

```text
Um fornecedor de uma ferramenta de teste falha a data de entrega acordada
```

### o4 pt explanation ORIGINAL

```text
Um atraso de entrega do fornecedor ameaça o calendário e os recursos do projeto. Um cálculo fiscal incorreto diz respeito à qualidade funcional do produto.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Um atraso de entrega do fornecedor ameaça o calendário e os recursos do projeto. Um cálculo fiscal incorreto diz respeito à qualidade funcional do produto.
```

### o4 en text ORIGINAL

```text
A test-tool supplier misses the agreed delivery date
```

### o4 en text RETAINED_UNCHANGED

```text
A test-tool supplier misses the agreed delivery date
```

### o4 en explanation ORIGINAL

```text
A supplier delivery delay threatens the project schedule and resources. Incorrect tax calculation concerns the product's functional quality.
```

### o4 en explanation RETAINED_UNCHANGED

```text
A supplier delivery delay threatens the project schedule and resources. Incorrect tax calculation concerns the product's functional quality.
```

### pt general explanation ORIGINAL

```text
Imposto incorreto ameaça a qualidade do produto.
```

### pt general explanation RETAINED_UNCHANGED

```text
Imposto incorreto ameaça a qualidade do produto.
```

### en general explanation ORIGINAL

```text
Wrong tax threatens product quality.
```

### en general explanation RETAINED_UNCHANGED

```text
Wrong tax threatens product quality.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Não se propõe alteração apenas por preferência estilística. O conteúdo e explicações existentes são suficientes. / No change merely for style; existing content and explanations are sufficient.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-040 — ACCEPT_AS_IS

LO`FL-6.2.1`; K1; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`54c59daacf5d024cf447db42fd143f2d2f20e4f4bc918f8ab3861502da66e2ca` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Underestimating maintenance effort for automated scripts is a risk, unlike reduced repetitive work, greater repeatability and useful automated metrics, which are potential benefits. Maintenance effort itself is an expected cost; underestimating it creates planning/budget/sustainability risk. Benefits are not guaranteed, but alternative unforeseen costs do not reverse the requested risk-versus-benefit polarity.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter6, §6.2; EN4.0.1pp.[58, 59, 60]; PT4.0/v1.0pp.[64, 65, 66]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** O risco é subestimar esforço de manutenção: planeamento/custo/sustentabilidade irreais. Reduzir repetição manual, melhorar repetibilidade e recolher métricas são benefícios potenciais. Ter um custo de manutenção previsto não é por si o risco descrito.

**EN:** The risk is underestimating maintenance effort and planning sustainable resources unrealistically. Reduced manual repetition, repeatability and metrics are potential benefits. An anticipated maintenance cost itself is not the stated risk.

## Comparação PT/EN / PT/EN comparison

**PT:** Risk rather than expected benefit/risco em vez de benefício esperado mantém polaridade. Underestimating/subestimar não significa apenas manter scripts. As justificações usam potencial/can/pode, evitando benefícios garantidos.

**EN:** Risk-versus-benefit polarity is preserved. Underestimating is not merely maintaining scripts, and rationales retain potential/can rather than guaranteeing benefits.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Automação pode falhar em produzir benefícios e aumentar custos; esses cenários não tornam as descrições positivas em o2/o3/o4 riscos por si só. Métricas de cobertura não garantem qualidade. A explicação geral é breve, mas os distratores já distinguem estimativas irreais.

**EN:** Automation can fail to deliver benefits or add costs; those unprovided scenarios do not invert the positive descriptions in the options. Coverage metrics do not guarantee quality. The brief summary is supplemented by accurate estimation contrasts.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-6.2.1/K1 recorda benefício versus risco, dificuldade baixa. Explicitar o erro de estimativa melhora a explicação geral sem alterar o conceito já correto.

**EN:** FL-6.2.1/K1recalls benefits versus risks; low difficulty. Explaining the estimation error strengthens the already correct short summary.

## Riscos de interpretação / Interpretation risks

**PT:** LOW pedagógico: ler o resumo como se qualquer custo fosse o risco, omitindo “subestimar”. A própria alternativa e justificações impedem essa conclusão obrigatória.

**EN:** LOWteaching risk of equating any cost with risk and overlooking underestimation; the actual choice/rationales do not require that reading.

## Conceitos críticos / Critical concepts

| ENliteral                            | PTliteral                                | Avaliação / Assessment |
| ------------------------------------ | ---------------------------------------- | ---------------------- |
| risk rather than an expected benefit | risco em vez de benefício esperado       | EQUIVALENT_POLARITY    |
| Underestimating                      | Subestimar                               | EQUIVALENT_RISK_ACTION |
| maintain automated test scripts      | manter os scripts de teste automatizados | EQUIVALENT_OBJECT      |
| repeatability                        | repetibilidade                           | EQUIVALENT_BENEFIT     |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: estimativa insuficiente pode inviabilizar planeamento/manutenção realistas.

**EN:** Correct: insufficient estimation threatens realistic maintenance planning.

### o2 — distrator/distractor

**PT:** Reduzir trabalho repetitivo é benefício potencial, não o risco de estimativa.

**EN:** Reduced repetitive work is a potential benefit, not the estimation risk.

### o3 — distrator/distractor

**PT:** Repetibilidade é benefício potencial; não elimina manutenção.

**EN:** Repeatability is a potential benefit, not an elimination of maintenance.

### o4 — distrator/distractor

**PT:** Medições difíceis manualmente podem ser benefício, sem provar qualidade universal.

**EN:** Difficult-to-obtain manual measures can be a benefit without proving universal quality.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Uma equipa está a planear a automação de testes. Que questão deve ser registada como risco em vez de benefício esperado?
```

### pt statement RETAINED_UNCHANGED

```text
Uma equipa está a planear a automação de testes. Que questão deve ser registada como risco em vez de benefício esperado?
```

### en statement ORIGINAL

```text
A team is planning test automation. Which issue should be recorded as a risk rather than an expected benefit?
```

### en statement RETAINED_UNCHANGED

```text
A team is planning test automation. Which issue should be recorded as a risk rather than an expected benefit?
```

### o1 pt text ORIGINAL

```text
Subestimar o esforço necessário para manter os scripts de teste automatizados
```

### o1 pt text RETAINED_UNCHANGED

```text
Subestimar o esforço necessário para manter os scripts de teste automatizados
```

### o1 pt explanation ORIGINAL

```text
Os custos de manutenção têm de ser considerados.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Os custos de manutenção têm de ser considerados.
```

### o1 en text ORIGINAL

```text
Underestimating the effort to maintain automated test scripts
```

### o1 en text RETAINED_UNCHANGED

```text
Underestimating the effort to maintain automated test scripts
```

### o1 en explanation ORIGINAL

```text
Maintenance costs must be considered.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Maintenance costs must be considered.
```

### o2 pt text ORIGINAL

```text
Reduzir o esforço de execução manual repetitiva de testes
```

### o2 pt text RETAINED_UNCHANGED

```text
Reduzir o esforço de execução manual repetitiva de testes
```

### o2 pt explanation ORIGINAL

```text
Reduzir trabalho manual repetitivo é um benefício potencial da automação. O risco é não prever realisticamente o esforço de introdução e manutenção.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Reduzir trabalho manual repetitivo é um benefício potencial da automação. O risco é não prever realisticamente o esforço de introdução e manutenção.
```

### o2 en text ORIGINAL

```text
Reducing repetitive manual test execution effort
```

### o2 en text RETAINED_UNCHANGED

```text
Reducing repetitive manual test execution effort
```

### o2 en explanation ORIGINAL

```text
Reducing repetitive manual work is a potential benefit of automation. The risk is failing to budget realistically for introduction and maintenance effort.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Reducing repetitive manual work is a potential benefit of automation. The risk is failing to budget realistically for introduction and maintenance effort.
```

### o3 pt text ORIGINAL

```text
Melhorar a repetibilidade da execução de testes
```

### o3 pt text RETAINED_UNCHANGED

```text
Melhorar a repetibilidade da execução de testes
```

### o3 pt explanation ORIGINAL

```text
Uma execução consistente e repetível é um benefício potencial. Não elimina a necessidade de manter os scripts à medida que o produto muda.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Uma execução consistente e repetível é um benefício potencial. Não elimina a necessidade de manter os scripts à medida que o produto muda.
```

### o3 en text ORIGINAL

```text
Improving the repeatability of test execution
```

### o3 en text RETAINED_UNCHANGED

```text
Improving the repeatability of test execution
```

### o3 en explanation ORIGINAL

```text
Consistent, repeatable execution is a potential benefit. It does not eliminate the need to maintain scripts as the product changes.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Consistent, repeatable execution is a potential benefit. It does not eliminate the need to maintain scripts as the product changes.
```

### o4 pt text ORIGINAL

```text
Obter, com apoio de ferramentas, métricas de cobertura difíceis de recolher manualmente
```

### o4 pt text RETAINED_UNCHANGED

```text
Obter, com apoio de ferramentas, métricas de cobertura difíceis de recolher manualmente
```

### o4 pt explanation ORIGINAL

```text
A medição apoiada por ferramentas pode ser um benefício. Subestimar o esforço necessário para manter úteis os testes automatizados e as ferramentas é o risco aqui identificado.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A medição apoiada por ferramentas pode ser um benefício. Subestimar o esforço necessário para manter úteis os testes automatizados e as ferramentas é o risco aqui identificado.
```

### o4 en text ORIGINAL

```text
Obtaining tool-supported coverage metrics that would be difficult to collect by hand
```

### o4 en text RETAINED_UNCHANGED

```text
Obtaining tool-supported coverage metrics that would be difficult to collect by hand
```

### o4 en explanation ORIGINAL

```text
Tool-supported measurement can be a benefit. Underestimating the effort needed to keep automated tests and tools useful is the risk identified here.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Tool-supported measurement can be a benefit. Underestimating the effort needed to keep automated tests and tools useful is the risk identified here.
```

### pt general explanation ORIGINAL

```text
Os custos de manutenção têm de ser considerados.
```

### pt general explanation RETAINED_UNCHANGED

```text
Os custos de manutenção têm de ser considerados.
```

### en general explanation ORIGINAL

```text
Maintenance costs must be considered.
```

### en general explanation RETAINED_UNCHANGED

```text
Maintenance costs must be considered.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
Os custos de manutenção têm de ser considerados.
```

### pt affected field OPTIONAL_CANDIDATE

```text
Manter scripts automatizados exige esforço planeado. Subestimar esse esforço pode tornar orçamentos e planos de manutenção irrealistas; o risco é a estimativa imprecisa, não a mera existência de custos de manutenção.
```

### en affected field ORIGINAL

```text
Maintenance costs must be considered.
```

### en affected field OPTIONAL_CANDIDATE

```text
Maintaining automated scripts requires planned effort. Underestimating that effort can make budgets and maintenance plans unrealistic; the risk is the inaccurate estimate, not the mere existence of maintenance costs.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão3→4 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-044 — ACCEPT_AS_IS

LO`FL-5.1.7`; K2; version1; required=1; key`['o4']`; content revision2026-10-27.10.

Canonical SHA-256`8c0dbfcb05cce795cb2c9bc36175e347ebf375914e441e903aca16f02fa2a701` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Business representatives challenge a running dashboard against user workflow/needs: business-facing and product-critique, henceQ3. Q1is technology-facing team support;Q2business-facing team support rather than evaluating implemented product;Q4technology-facing critique. Working means operational, not proven correct;critique means reasoned evaluation, not gratuitous negativity. The four options’ quadrant number/axes must be checked against official model.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter5, §5.1.7; EN4.0.1pp.[47, 51]; PT4.0/v1.0pp.[52, 56, 57]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Necessidades/fluxos dos utilizadores dão eixo negócio; explorar e questionar o produto dá eixo avaliação crítica:Q3,o4. As quatro opções preservam número e combinação de eixos; cada distrator partilha nenhum ou um eixo com o caso.

**EN:** User needs/workflows establish business-facing; exploration challenging the product establishes critique:Q3,o4. All four options preserve quadrant numbers/axes; distractors match neither or only one of the required axes.

## Comparação PT/EN / PT/EN comparison

**PT:** Working/funcional significa operacional, não que todos os requisitos estão satisfeitos nem uma classificação automática de teste funcional. Critique/criticam significa avaliar comportamento face a expectativas; a PSTQB usa “critica o produto”, não negatividade gratuita. Business/technology e support/critique mantêm-se nas quatro alternativas.

**EN:** Working/funcional means operational, not proven correct or an automatic functional-test classification. Critique means evaluation against expectations, not gratuitous negativity; PSTQB uses that same model term. All four options preserve both axes.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Q2 também pode executar software já implementado; a existência de um painel operacional não basta paraQ3. Demonstrações podem guiar desenvolvimento. Aqui a finalidade expressa é explorar dificuldades e questionar necessidades, tornando avaliação crítica do produto o melhor eixo.

**EN:** Q2can execute implemented software; operational status alone does not identifyQ3. Demonstrations can guide development. Here the explicit purpose is exploring workflow difficulties and challenging needs, making product critique the best fit.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-5.1.7/K2: interpretar os dois eixos e relacionar atividade/tipo de teste; dificuldade média. Não classificar apenas pelo papel dos participantes ou por o produto existir. A explicação geral já invoca ambos os eixos.

**EN:** FL-5.1.7/K2interprets both axes and relates activity/type; moderate difficulty. Neither participant role nor product existence alone is decisive; the general explanation already uses both axes.

## Riscos de interpretação / Interpretation risks

**PT:** LOW se a frase de o2 for isolada e se inferir que sóQ3 testa produto implementado. Não é isso que diz o conjunto; uma expansão pedagógica pode torná-lo explícito.

**EN:** LOWrisk if the o2rationale is isolated and read as excluding implemented software fromQ2. The full item does not assert that; optional clarification can make it explicit.

## Conceitos críticos / Critical concepts

| ENliteral                              | PTliteral                                   | Avaliação / Assessment |
| -------------------------------------- | ------------------------------------------- | ---------------------- |
| working reporting dashboard            | painel de relatórios funcional              | CONTEXTUAL_OPERATIONAL |
| challenge whether it meets their needs | questionar se satisfaz as suas necessidades | EQUIVALENT_EVALUATION  |
| business-facing tests                  | testes orientados para o negócio            | EQUIVALENT_AXIS        |
| critique the product                   | criticam o produto                          | EQUIVALENT_MODEL_TERM  |
| support the team                       | suportam a equipa                           | EQUIVALENT_AXIS        |

## Todas as alternativas / Every alternative

### o1 — distrator/distractor

**PT:** Tecnologia+apoio da equipa não corresponde a explorar necessidades do negócio.

**EN:** Technology/team support does not match exploring business needs.

### o2 — distrator/distractor

**PT:** Acerta negócio, mas orientar desenvolvimento não é a finalidade crítica expressa.

**EN:** Business-facing matches, but guiding development is not the stated critique purpose.

### o3 — distrator/distractor

**PT:** Acerta avaliação crítica, mas a perspetiva dada é de utilizador/negócio.

**EN:** Critique matches, but the given perspective is user/business-facing.

### o4 — correta/correct

**PT:** Correta: negócio+avaliação crítica, compatível com exploração/usabilidade.

**EN:** Correct: business-facing product critique, consistent with exploration/usability.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Representantes do negócio exploram um painel de relatórios funcional para descobrir dificuldades nos fluxos dos utilizadores e questionar se satisfaz as suas necessidades. No modelo dos quadrantes de testes, que quadrante melhor descreve esta atividade?
```

### pt statement RETAINED_UNCHANGED

```text
Representantes do negócio exploram um painel de relatórios funcional para descobrir dificuldades nos fluxos dos utilizadores e questionar se satisfaz as suas necessidades. No modelo dos quadrantes de testes, que quadrante melhor descreve esta atividade?
```

### en statement ORIGINAL

```text
Business representatives explore a working reporting dashboard to discover awkward user workflows and challenge whether it meets their needs. In the testing quadrants model, which quadrant best describes this activity?
```

### en statement RETAINED_UNCHANGED

```text
Business representatives explore a working reporting dashboard to discover awkward user workflows and challenge whether it meets their needs. In the testing quadrants model, which quadrant best describes this activity?
```

### o1 pt text ORIGINAL

```text
Q1: testes orientados para a tecnologia que suportam a equipa.
```

### o1 pt text RETAINED_UNCHANGED

```text
Q1: testes orientados para a tecnologia que suportam a equipa.
```

### o1 pt explanation ORIGINAL

```text
Q1 inclui testes de componentes e de integração de componentes; o cenário avalia fluxos de utilizadores de uma perspetiva de negócio.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Q1 inclui testes de componentes e de integração de componentes; o cenário avalia fluxos de utilizadores de uma perspetiva de negócio.
```

### o1 en text ORIGINAL

```text
Q1: technology-facing tests that support the team.
```

### o1 en text RETAINED_UNCHANGED

```text
Q1: technology-facing tests that support the team.
```

### o1 en explanation ORIGINAL

```text
Q1 includes component and component integration tests; the scenario evaluates user workflows from a business perspective.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Q1 includes component and component integration tests; the scenario evaluates user workflows from a business perspective.
```

### o2 pt text ORIGINAL

```text
Q2: testes orientados para o negócio que suportam a equipa.
```

### o2 pt text RETAINED_UNCHANGED

```text
Q2: testes orientados para o negócio que suportam a equipa.
```

### o2 pt explanation ORIGINAL

```text
Os exemplos de Q2 orientam o desenvolvimento; este cenário critica um produto já funcional através da exploração.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Os exemplos de Q2 orientam o desenvolvimento; este cenário critica um produto já funcional através da exploração.
```

### o2 en text ORIGINAL

```text
Q2: business-facing tests that support the team.
```

### o2 en text RETAINED_UNCHANGED

```text
Q2: business-facing tests that support the team.
```

### o2 en explanation ORIGINAL

```text
Q2 examples guide development; this scenario critiques an existing working product through exploration.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Q2 examples guide development; this scenario critiques an existing working product through exploration.
```

### o3 pt text ORIGINAL

```text
Q4: testes orientados para a tecnologia que criticam o produto.
```

### o3 pt text RETAINED_UNCHANGED

```text
Q4: testes orientados para a tecnologia que criticam o produto.
```

### o3 pt explanation ORIGINAL

```text
Apesar de o produto ser criticado, as preocupações indicadas são os fluxos dos utilizadores e as necessidades do negócio, não uma avaliação orientada para a tecnologia.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Apesar de o produto ser criticado, as preocupações indicadas são os fluxos dos utilizadores e as necessidades do negócio, não uma avaliação orientada para a tecnologia.
```

### o3 en text ORIGINAL

```text
Q4: technology-facing tests that critique the product.
```

### o3 en text RETAINED_UNCHANGED

```text
Q4: technology-facing tests that critique the product.
```

### o3 en explanation ORIGINAL

```text
Although the product is being critiqued, the stated concerns are user workflows and business needs, not technology-facing quality evaluation.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Although the product is being critiqued, the stated concerns are user workflows and business needs, not technology-facing quality evaluation.
```

### o4 pt text ORIGINAL

```text
Q3: testes orientados para o negócio que criticam o produto.
```

### o4 pt text RETAINED_UNCHANGED

```text
Q3: testes orientados para o negócio que criticam o produto.
```

### o4 pt explanation ORIGINAL

```text
Q3 inclui testes exploratórios e de usabilidade da perspetiva do utilizador e do negócio, como no cenário descrito.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Q3 inclui testes exploratórios e de usabilidade da perspetiva do utilizador e do negócio, como no cenário descrito.
```

### o4 en text ORIGINAL

```text
Q3: business-facing tests that critique the product.
```

### o4 en text RETAINED_UNCHANGED

```text
Q3: business-facing tests that critique the product.
```

### o4 en explanation ORIGINAL

```text
Q3 includes exploratory and usability testing from the user/business perspective, as described.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Q3 includes exploratory and usability testing from the user/business perspective, as described.
```

### pt general explanation ORIGINAL

```text
A atividade é orientada para o negócio e critica o produto funcional. Estes dois eixos identificam Q3; o modelo não classifica todas as atividades orientadas para o negócio como Q2.
```

### pt general explanation RETAINED_UNCHANGED

```text
A atividade é orientada para o negócio e critica o produto funcional. Estes dois eixos identificam Q3; o modelo não classifica todas as atividades orientadas para o negócio como Q2.
```

### en general explanation ORIGINAL

```text
The activity is business-facing and critiques the working product. These two axes identify Q3; the model does not classify every business-facing activity as Q2.
```

### en general explanation RETAINED_UNCHANGED

```text
The activity is business-facing and critiques the working product. These two axes identify Q3; the model does not classify every business-facing activity as Q2.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['options', 'o2', 'explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
Os exemplos de Q2 orientam o desenvolvimento; este cenário critica um produto já funcional através da exploração.
```

### pt affected field OPTIONAL_CANDIDATE

```text
Q2 e Q3 podem ambos envolver software em execução. A distinção aqui é a finalidade: apoiar o desenvolvimento com exemplos de negócio ou explorar criticamente fluxos face às necessidades dos utilizadores. O cenário descreve a segunda finalidade, pelo que Q3 se adequa melhor do que Q2.
```

### en affected field ORIGINAL

```text
Q2 examples guide development; this scenario critiques an existing working product through exploration.
```

### en affected field OPTIONAL_CANDIDATE

```text
Q2 and Q3 can both involve running software. The distinction here is purpose: supporting development with business examples versus critically exploring workflows against user needs. The scenario describes the latter purpose, so Q3 fits better than Q2.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão1→2 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | False              | —                | —           |
| 2026-10-27.2       | False              | —                | —           |
| 2026-10-27.3       | True               | 1                | ['o4']      |
| 2026-10-27.4       | True               | 1                | ['o4']      |
| 2026-10-27.5       | True               | 1                | ['o4']      |
| 2026-10-27.6       | True               | 1                | ['o4']      |
| 2026-10-27.7       | True               | 1                | ['o4']      |
| 2026-10-27.8       | True               | 1                | ['o4']      |
| 2026-10-27.9       | True               | 1                | ['o4']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-055 — ACCEPT_AS_IS

LO`FL-3.1.2`; K2; version1; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`93eafb9f218b78b98e81fb520c5ebf355f546be186aa451da65a0b5e1825c043` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Static review identifies conflicting retention rules and the owner resolves them before code/test derivation. This prevents those conflicting rules from being propagated in this stated case and reduces potential later rework; it does not guarantee every downstream artifact or outcome. o2invented runtime compliance evidence; o3invented executed regression results; o4claims either incompatible rule satisfies needs without evidence. Retention/conservação refers to keeping data for policy-defined periods, without inventing a legal retention duration.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter3, §3.1.2; EN4.0.1pp.[32, 33, 34]; PT4.0/v1.0pp.[35, 36, 37]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** A revisão deteta regras incompatíveis; o product owner resolve-as antes de derivar código/testes. Essa sequência evita propagar a contradição concreta e reduz retrabalho potencial. Não se atribui correção automática ao ato de testar nem conformidade dinâmica a software ainda inexistente.

**EN:** Review detects incompatible rules; the owner resolves them before code/test derivation. This sequence avoids propagating this contradiction and reduces potential rework. Testing alone does not automatically correct it or establish runtime compliance.

## Comparação PT/EN / PT/EN comparison

**PT:** Retention/conservação refere manter dados segundo regras/períodos, não um mecanismo obrigatório de backup nem prazo legal inventado. Potential/potencial e later/posterior mantêm benefício não quantificado. Before implementation/antes da implementação e resolves/resolve preservam a ordem causal dada.

**EN:** Retention/conservação concerns keeping data under rules/periods, not mandatory backups or invented legal durations. Potential/later and the detection-resolution-before-derivation order remain equivalent.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** A revisão isolada não garante remoção/propagação evitada; aqui a resolução é dada expressamente. Resultados esperados poderiam ser definidos depois a partir da especificação esclarecida, mas o3 fala em resultados de regressão, não oferece execuções nem é o principal valor observado. A explicação geral usa “pode” e distingue evidência dinâmica.

**EN:** Review alone does not guarantee removal/prevention; owner resolution is explicit here. Expected results may later be derived from clarified specifications, but o3does not supply executions and is not the main observed value. The summary correctly uses can and separates runtime evidence.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-3.1.2/K2 explica benefício por um caso concreto, dificuldade baixa/média. A explicação geral e o1 já ligam deteção antecipada à correção antes de trabalho derivado. Não há necessidade de expandir apenas para produzir uma alteração.

**EN:** FL-3.1.2/K2explains value in a concrete case; low/moderate difficulty. Existing explanations already link early detection to correction before downstream work, so no gratuitous expansion is needed.

## Riscos de interpretação / Interpretation risks

**PT:** LOW de confundir encontrar com corrigir ou ler prevenção como garantia universal. O cenário e o resumo modal resolvem isso; nenhuma segunda resposta principal demonstrada.

**EN:** LOWrisk of conflating detection/correction or universalizing prevention; the scenario/modal summary resolve this without a second demonstrated best answer.

## Conceitos críticos / Critical concepts

| ENliteral              | PTliteral                      | Avaliação / Assessment   |
| ---------------------- | ------------------------------ | ------------------------ |
| Before implementation  | Antes da implementação         | EQUIVALENT_TIMING        |
| resolves the conflict  | resolve o conflito             | EQUIVALENT_RESOLUTION    |
| retention rules        | regras de conservação          | EQUIVALENT_DATA_CONTEXT  |
| potential later rework | potencial retrabalho posterior | EQUIVALENT_QUALIFICATION |
| can detect defects     | pode detetar defeitos          | EQUIVALENT_MODALITY      |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta no cenário: deteção seguida da resolução impede propagar aquelas regras e reduz retrabalho potencial.

**EN:** Correct in context: detection followed by resolution avoids those conflicting rules propagating and reduces potential rework.

### o2 — distrator/distractor

**PT:** Revisão não executa implementação inexistente nem mede conformidade em execução.

**EN:** Review does not execute a nonexistent implementation or measure runtime compliance.

### o3 — distrator/distractor

**PT:** Esclarecer a base ajuda testes futuros; não fornece resultados de execução de regressão.

**EN:** Clarifying a basis supports future tests but does not supply regression execution results.

### o4 — distrator/distractor

**PT:** Documentação contraditória não prova que qualquer regra satisfaz os utilizadores; a resolução é necessária.

**EN:** Conflicting documentation does not prove either rule meets user needs; resolution is necessary.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Antes da implementação, uma revisão da especificação de exportação de dados revela duas regras de conservação incompatíveis. O product owner resolve o conflito antes de serem derivados o código e os testes. Qual é o principal valor do teste estático nesta situação?
```

### pt statement RETAINED_UNCHANGED

```text
Antes da implementação, uma revisão da especificação de exportação de dados revela duas regras de conservação incompatíveis. O product owner resolve o conflito antes de serem derivados o código e os testes. Qual é o principal valor do teste estático nesta situação?
```

### en statement ORIGINAL

```text
Before implementation, a review of a data-export specification reveals two incompatible retention rules. The product owner resolves the conflict before code and tests are derived. What is the main value of static testing in this situation?
```

### en statement RETAINED_UNCHANGED

```text
Before implementation, a review of a data-export specification reveals two incompatible retention rules. The product owner resolves the conflict before code and tests are derived. What is the main value of static testing in this situation?
```

### o1 pt text ORIGINAL

```text
Evita que as regras contraditórias se propaguem para os produtos de trabalho derivados e reduz o potencial retrabalho posterior.
```

### o1 pt text RETAINED_UNCHANGED

```text
Evita que as regras contraditórias se propaguem para os produtos de trabalho derivados e reduz o potencial retrabalho posterior.
```

### o1 pt explanation ORIGINAL

```text
A deteção direta e antecipada na especificação permite corrigir antes de o trabalho subsequente se basear no defeito.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A deteção direta e antecipada na especificação permite corrigir antes de o trabalho subsequente se basear no defeito.
```

### o1 en text ORIGINAL

```text
It prevents the conflicting rules from propagating into derived work products and reduces potential later rework.
```

### o1 en text RETAINED_UNCHANGED

```text
It prevents the conflicting rules from propagating into derived work products and reduces potential later rework.
```

### o1 en explanation ORIGINAL

```text
Early direct detection in the specification allows correction before downstream work is based on the defect.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Early direct detection in the specification allows correction before downstream work is based on the defect.
```

### o2 pt text ORIGINAL

```text
Fornece evidência em execução de que os dados exportados cumprem o período de conservação acordado.
```

### o2 pt text RETAINED_UNCHANGED

```text
Fornece evidência em execução de que os dados exportados cumprem o período de conservação acordado.
```

### o2 pt explanation ORIGINAL

```text
A revisão não executa o serviço nem pode medir o cumprimento em execução por uma implementação que ainda não existe.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
A revisão não executa o serviço nem pode medir o cumprimento em execução por uma implementação que ainda não existe.
```

### o2 en text ORIGINAL

```text
It provides runtime evidence that exported data complies with the agreed retention period.
```

### o2 en text RETAINED_UNCHANGED

```text
It provides runtime evidence that exported data complies with the agreed retention period.
```

### o2 en explanation ORIGINAL

```text
The review does not execute the service and cannot measure runtime compliance of an implementation that does not yet exist.
```

### o2 en explanation RETAINED_UNCHANGED

```text
The review does not execute the service and cannot measure runtime compliance of an implementation that does not yet exist.
```

### o3 pt text ORIGINAL

```text
Estabelece os resultados dos testes de regressão que serão necessários após alterações à lógica de conservação.
```

### o3 pt text RETAINED_UNCHANGED

```text
Estabelece os resultados dos testes de regressão que serão necessários após alterações à lógica de conservação.
```

### o3 pt explanation ORIGINAL

```text
A revisão esclarece a base para testes posteriores; não fornece os seus resultados de execução.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
A revisão esclarece a base para testes posteriores; não fornece os seus resultados de execução.
```

### o3 en text ORIGINAL

```text
It establishes the regression test results that will be needed after the retention logic changes.
```

### o3 en text RETAINED_UNCHANGED

```text
It establishes the regression test results that will be needed after the retention logic changes.
```

### o3 en explanation ORIGINAL

```text
The review clarifies the basis for later tests; it does not supply their execution results.
```

### o3 en explanation RETAINED_UNCHANGED

```text
The review clarifies the basis for later tests; it does not supply their execution results.
```

### o4 pt text ORIGINAL

```text
Confirma que implementar qualquer uma das regras documentadas satisfaria as necessidades de conservação dos utilizadores.
```

### o4 pt text RETAINED_UNCHANGED

```text
Confirma que implementar qualquer uma das regras documentadas satisfaria as necessidades de conservação dos utilizadores.
```

### o4 pt explanation ORIGINAL

```text
As regras são contraditórias e exigem resolução pelos stakeholders; estarem documentadas não torna qualquer interpretação aceitável.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
As regras são contraditórias e exigem resolução pelos stakeholders; estarem documentadas não torna qualquer interpretação aceitável.
```

### o4 en text ORIGINAL

```text
It confirms that implementing either documented rule would satisfy the users' retention needs.
```

### o4 en text RETAINED_UNCHANGED

```text
It confirms that implementing either documented rule would satisfy the users' retention needs.
```

### o4 en explanation ORIGINAL

```text
The rules conflict and require stakeholder resolution; documentation alone does not make either interpretation acceptable.
```

### o4 en explanation RETAINED_UNCHANGED

```text
The rules conflict and require stakeholder resolution; documentation alone does not make either interpretation acceptable.
```

### pt general explanation ORIGINAL

```text
O teste estático pode detetar defeitos em produtos de trabalho não executáveis e reduzir o custo da correção posterior. Complementa a evidência dinâmica posterior em vez de a produzir.
```

### pt general explanation RETAINED_UNCHANGED

```text
O teste estático pode detetar defeitos em produtos de trabalho não executáveis e reduzir o custo da correção posterior. Complementa a evidência dinâmica posterior em vez de a produzir.
```

### en general explanation ORIGINAL

```text
Static testing can detect defects in non-executable work products and reduce the cost of downstream correction. It complements later dynamic evidence rather than producing it.
```

### en general explanation RETAINED_UNCHANGED

```text
Static testing can detect defects in non-executable work products and reduce the cost of downstream correction. It complements later dynamic evidence rather than producing it.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Não se propõe alteração apenas por preferência estilística. O conteúdo e explicações existentes são suficientes. / No change merely for style; existing content and explanations are sufficient.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | False              | —                | —           |
| 2026-10-27.2       | False              | —                | —           |
| 2026-10-27.3       | False              | —                | —           |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 1                | ['o1']      |
| 2026-10-27.8       | True               | 1                | ['o1']      |
| 2026-10-27.9       | True               | 1                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.


# tl-056 — ACCEPT_AS_IS

LO`FL-3.2.1`; K1; version1; required=1; key`['o3']`; content revision2026-10-27.10.

Canonical SHA-256`5bd11c686943a22717afee509b42357df3dc59c93fa170bb7b9f81cc946f9ae9` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Weekly feedback from intended warehouse users during workflow evolution can reveal misunderstood needs early and reduce rework risk. It neither makes later requirements changes unnecessary nor replaces acceptance criteria nor proves every staff member will accept final implementation. Weekly is this example’s frequency, not a universally required cadence. Picking versus broader preparação de encomendas has lexical scope difference but does not change the feedback principle.

Registada/recorded`2026-11-06T14:15:35.595829+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter3, §3.2.1; EN4.0.1pp.[32, 35]; PT4.0/v1.0pp.[35, 38]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Envolvimento semanal enquanto o fluxo evolui permite detetar mal-entendidos sobre necessidades cedo e reduzir risco de retrabalho:o3. Não congela requisitos, substitui critérios de aceitação ou garante aceitação final de todos.

**EN:** Weekly involvement while workflows evolve helps find misunderstood needs earlier and reduces rework risk:o3. It neither freezes requirements, replaces acceptance criteria nor guarantees everyone’s final acceptance.

## Comparação PT/EN / PT/EN comparison

**PT:** Each week/semanalmente e evolving/em evolução mantêm frequência e mudança. Picking workflow é mais estreito do que preparação de encomendas, que pode abranger outras operações; no cenário de armazém ambas identificam um fluxo dos utilizadores, sem afetar o benefício pedido. Short/pequenas demonstrações mantém brevidade contextual, não dimensão de produto.

**EN:** Each week/evolving preserve cadence/change. Picking is narrower than order preparation, but both identify a warehouse user workflow and preserve the feedback benefit. Short/pequenas demonstrations preserve contextual brevity rather than product size.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Demonstração pode executar software: esteLO está no capítulo de revisões, mas não se pede classificar toda demonstração como teste estático. Frequência semanal é exemplo, não norma universal. Mudanças futuras podem continuar necessárias; não é defeito do feedback.

**EN:** A demonstration may execute software: although theLOis in the review chapter, the item does not classify every demo as static testing. Weekly is an example, not a universal cadence; later changes remain possible.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-3.2.1/K1 recorda uma vantagem por exemplo, dificuldade baixa. Distratores absolutos facilitam eliminação mas são conceptualmente incorretos; não há motivo para redesenhar dificuldade nesta revisão.

**EN:** FL-3.2.1/K1recalls a benefit through an example; low difficulty. Absolute distractors are easy but conceptually wrong, without requiring redesign.

## Riscos de interpretação / Interpretation risks

**PT:** LOW: tradução de picking é mais abrangente e um leitor pode extrapolar frequência/aceitação. Nenhuma dessas leituras altera o3, explicitamente qualificado como redução de risco.

**EN:** LOWscope/cadence extrapolation risk; none changes o3’s expressly qualified rework-risk reduction.

## Conceitos críticos / Critical concepts

| ENliteral            | PTliteral                         | Avaliação / Assessment      |
| -------------------- | --------------------------------- | --------------------------- |
| each week            | semanalmente                      | EQUIVALENT_FREQUENCY        |
| evolving             | em evolução                       | EQUIVALENT_CHANGE           |
| picking workflow     | fluxo de preparação de encomendas | CONTEXTUAL_BROADER_PT_SCOPE |
| short demonstrations | pequenas demonstrações            | CONTEXTUAL_BREVITY          |
| all warehouse staff  | todos os trabalhadores do armazém | EQUIVALENT_ABSOLUTE         |

## Todas as alternativas / Every alternative

### o1 — distrator/distractor

**PT:** Feedback não torna desnecessária toda alteração futura.

**EN:** Feedback does not make all later requirement changes unnecessary.

### o2 — distrator/distractor

**PT:** Ter visto demonstrações não substitui critérios explícitos/testáveis.

**EN:** Having seen demos does not replace explicit testable criteria.

### o3 — correta/correct

**PT:** Correta: entendimento partilhado e adaptação antecipada reduzem risco de retrabalho.

**EN:** Correct: shared understanding/earlier adaptation reduce rework risk.

### o4 — distrator/distractor

**PT:** Amostras de feedback não provam aceitação por todos de uma implementação futura.

**EN:** Feedback samples do not prove everyone’s acceptance of a future implementation.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Uma equipa pede semanalmente aos trabalhadores do armazém que revejam pequenas demonstrações de um fluxo de preparação de encomendas em evolução. Que vantagem está associada ao feedback antecipado e frequente dos stakeholders?
```

### pt statement RETAINED_UNCHANGED

```text
Uma equipa pede semanalmente aos trabalhadores do armazém que revejam pequenas demonstrações de um fluxo de preparação de encomendas em evolução. Que vantagem está associada ao feedback antecipado e frequente dos stakeholders?
```

### en statement ORIGINAL

```text
A team asks warehouse staff to review short demonstrations of an evolving picking workflow each week. Which benefit is associated with early and frequent stakeholder feedback?
```

### en statement RETAINED_UNCHANGED

```text
A team asks warehouse staff to review short demonstrations of an evolving picking workflow each week. Which benefit is associated with early and frequent stakeholder feedback?
```

### o1 pt text ORIGINAL

```text
Uma base de referência estável que torna desnecessárias alterações posteriores aos requisitos.
```

### o1 pt text RETAINED_UNCHANGED

```text
Uma base de referência estável que torna desnecessárias alterações posteriores aos requisitos.
```

### o1 pt explanation ORIGINAL

```text
O feedback ajuda a compreender as alterações mais cedo; não elimina a possibilidade ou a necessidade de mudança.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
O feedback ajuda a compreender as alterações mais cedo; não elimina a possibilidade ou a necessidade de mudança.
```

### o1 en text ORIGINAL

```text
A stable baseline that makes later requirement changes unnecessary.
```

### o1 en text RETAINED_UNCHANGED

```text
A stable baseline that makes later requirement changes unnecessary.
```

### o1 en explanation ORIGINAL

```text
Feedback helps understand changes earlier; it does not remove the possibility or need for change.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Feedback helps understand changes earlier; it does not remove the possibility or need for change.
```

### o2 pt text ORIGINAL

```text
Uma substituição dos critérios de aceitação porque os utilizadores já viram o fluxo.
```

### o2 pt text RETAINED_UNCHANGED

```text
Uma substituição dos critérios de aceitação porque os utilizadores já viram o fluxo.
```

### o2 pt explanation ORIGINAL

```text
As demonstrações e o feedback não substituem critérios de aceitação explícitos e testáveis.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
As demonstrações e o feedback não substituem critérios de aceitação explícitos e testáveis.
```

### o2 en text ORIGINAL

```text
A replacement for acceptance criteria because users have already seen the workflow.
```

### o2 en text RETAINED_UNCHANGED

```text
A replacement for acceptance criteria because users have already seen the workflow.
```

### o2 en explanation ORIGINAL

```text
Demonstrations and feedback do not replace explicit, testable acceptance criteria.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Demonstrations and feedback do not replace explicit, testable acceptance criteria.
```

### o3 pt text ORIGINAL

```text
Descoberta mais cedo de equívocos sobre as necessidades dos utilizadores, reduzindo o risco de retrabalho dispendioso.
```

### o3 pt text RETAINED_UNCHANGED

```text
Descoberta mais cedo de equívocos sobre as necessidades dos utilizadores, reduzindo o risco de retrabalho dispendioso.
```

### o3 pt explanation ORIGINAL

```text
O feedback frequente apoia o entendimento partilhado e a adaptação antecipada às necessidades dos stakeholders.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
O feedback frequente apoia o entendimento partilhado e a adaptação antecipada às necessidades dos stakeholders.
```

### o3 en text ORIGINAL

```text
Earlier discovery of misunderstandings about user needs, reducing the risk of costly rework.
```

### o3 en text RETAINED_UNCHANGED

```text
Earlier discovery of misunderstandings about user needs, reducing the risk of costly rework.
```

### o3 en explanation ORIGINAL

```text
Frequent feedback supports shared understanding and earlier adaptation to stakeholder needs.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Frequent feedback supports shared understanding and earlier adaptation to stakeholder needs.
```

### o4 pt text ORIGINAL

```text
Evidência de que todos os trabalhadores do armazém aceitarão a implementação concluída.
```

### o4 pt text RETAINED_UNCHANGED

```text
Evidência de que todos os trabalhadores do armazém aceitarão a implementação concluída.
```

### o4 pt explanation ORIGINAL

```text
O feedback de demonstrações não estabelece a aceitação universal de um futuro produto concluído.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
O feedback de demonstrações não estabelece a aceitação universal de um futuro produto concluído.
```

### o4 en text ORIGINAL

```text
Evidence that all warehouse staff will accept the completed implementation.
```

### o4 en text RETAINED_UNCHANGED

```text
Evidence that all warehouse staff will accept the completed implementation.
```

### o4 en explanation ORIGINAL

```text
Feedback from demonstrations does not establish universal acceptance of a future completed product.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Feedback from demonstrations does not establish universal acceptance of a future completed product.
```

### pt general explanation ORIGINAL

```text
A participação antecipada e repetida ajuda a evitar equívocos e permite compreender as alterações mais cedo. Não é uma garantia de aceitação final ou de requisitos fixos.
```

### pt general explanation RETAINED_UNCHANGED

```text
A participação antecipada e repetida ajuda a evitar equívocos e permite compreender as alterações mais cedo. Não é uma garantia de aceitação final ou de requisitos fixos.
```

### en general explanation ORIGINAL

```text
Early, repeated involvement helps prevent misunderstandings and allows changes to be understood sooner. It is not a guarantee of final acceptance or fixed requirements.
```

### en general explanation RETAINED_UNCHANGED

```text
Early, repeated involvement helps prevent misunderstandings and allows changes to be understood sooner. It is not a guarantee of final acceptance or fixed requirements.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Não se propõe alteração apenas por preferência estilística. O conteúdo e explicações existentes são suficientes. / No change merely for style; existing content and explanations are sufficient.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | False              | —                | —           |
| 2026-10-27.2       | False              | —                | —           |
| 2026-10-27.3       | False              | —                | —           |
| 2026-10-27.4       | True               | 1                | ['o3']      |
| 2026-10-27.5       | True               | 1                | ['o3']      |
| 2026-10-27.6       | True               | 1                | ['o3']      |
| 2026-10-27.7       | True               | 1                | ['o3']      |
| 2026-10-27.8       | True               | 1                | ['o3']      |
| 2026-10-27.9       | True               | 1                | ['o3']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote10não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch9.

