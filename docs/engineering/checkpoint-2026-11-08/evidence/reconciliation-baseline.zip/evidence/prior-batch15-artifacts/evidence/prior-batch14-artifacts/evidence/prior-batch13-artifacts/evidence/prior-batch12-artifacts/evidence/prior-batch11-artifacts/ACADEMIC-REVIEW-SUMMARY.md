# TestLearn — Fase 10H, Lote 11

Revisão por IA de exatamente tl-002, tl-003, tl-004, tl-005, tl-007, tl-009, tl-010 e tl-012, com 32 alternativas. NONE na triagem anterior não foi usado como aprovação ou fundamento. As oito soluções foram registadas antes da revelação das chaves e explicações. Parecer final individual: ACCEPT_AS_IS para as oito, com fundamentação, contraexemplos e consulta oficial. Não se demonstra correção apenas por coincidência com o gabarito.

Baseline: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049; revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos. ZIP do Lote 10 validado: 255 membros, 254 hashes internos; SHA-256 13f36441a07f61ec1f6a5a79fdcb06a5166a7eccc22118658af79ef7cd8ec716. Estado inicial: 314 ficheiros, 100 não rastreados e 111 documentos dos Lotes 1–10.

Leia reports/, decision-matrix.json, alternative-assessments.json, exact-comparisons.json, blind-projection.json e blind-solutions.json. Todos os enunciados, alternativas e explicações PT/EN estão integralmente reproduzidos antes/depois sem alterações. Fontes, edições, páginas físicas e hashes em sources.json. O histórico está em cada relatório e matriz.

Orientações do pedido comparadas ao conteúdo real: tl-007 é rastreabilidade (FL-1.4.4), não independência; tl-005 exemplifica desgaste dos testes, com regressão útil; tl-010 reconhece TDD, sem exigir projeto de refatorização. Não se alterou o âmbito para rever outras questões. A diferença de formulação de diagnóstico entre os syllabi EN e PT foi explicitamente analisada em tl-003, sem declarar os PDFs idênticos ou tornar causa raiz organizacional obrigatória em todo debugging.

Sem defeito obrigatório confirmado. Uma proposta editorial opcional e não aplicada clarifica a explicação de o4 em tl-005: reordenação pode revelar dependências, mas não demonstra cobertura das lacunas sem análise. Chave, LO, K e dados atuais permanecem iguais; qualquer aplicação futura exige autorização e preservação de revisão/histórico.

Nenhum banco, ID, chave, versão, explicação, histórico, persistência, implementação ou documento anterior alterado. Não há nova revisão .11, OWNER_ACCEPTED ou HUMAN_APPROVED. A análise por IA não equivale a especialista humano certificado nem a validação humana independente. Dificuldade não foi calibrada empiricamente. A Fase 10H permanece aberta.

Os verificadores validam estrutura, integridade, preservação e coerência de evidência; não provam automaticamente equivalência semântica nem verdade académica. EN v4.0.1 e PT v4.0 tradução 1.0 foram consultados localmente; endpoint PT teve timeout. Não se alega novo download PT. Sem necessidade de glossário separado para os conceitos definidos no próprio syllabus.

Apresentação: este lote usa espaços legíveis nos identificadores e termos. As imperfeições históricas de formatação não foram reescritas. O ZIP é dossiê portátil de revisão, não repositório executável completo. Testes novos e históricos são separados em verification.md e evidence/.

Próximo passo: auditoria independente do pacote. Nenhum commit, push, merge, PR, deploy ou alteração de Production. Parar após Lote 11; não iniciar Lote 12.


# tl-002 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.2.2 / K1; versão 3; revisão 2026-10-27.10; SHA-256 canónico `0ff7fa41b7295ee5f5dc3087d11cfd116dc8e74da4f112af81121f9ae601b1df`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

Melhorar a forma como a equipa realiza revisões é melhoria preventiva do processo. Executar um teste, reportar uma falha ou rever um módulo são atividades centradas no produto, mesmo quando os seus resultados alimentam QA. Primarily/principalmente mantém esse foco principal, não uma separação absoluta de pessoas ou de toda a informação.

Independent reasoning (recorded before the key):

Melhorar o processo de revisão é prevenção e melhoria do processo. Executar um teste e reportar falhas avaliam o produto; rever código também avalia um produto de trabalho, não o processo de revisão. Mainly does not deny feedback from testing to QA.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 1.2.2: EN páginas [17]; PT páginas [18].

- LO FL-1.2.2/K1: EN página 14; PT página 15.

EN descreve testing como abordagem corretiva do produto; PT apresenta QC e situa testes como uma das suas formas. Ambos situam QA como prevenção e melhoria processual. Não se inferiu que QA tem sucesso garantido nem que testes sejam executados só por uma profissão.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Primarily/principalmente preserva o qualificador. Improving/melhorar descreve a mesma ação sobre o processo de revisão. Checkout/compra refere uma operação do produto. EN especifica product failure in a build; PT usa falha numa versão: produto e build são menos explícitos em PT, mas o contexto mantém falha do software, sem transformar a atividade em melhoria processual.

| EN literal                        | PT literal                               |
| --------------------------------- | ---------------------------------------- |
| primarily                         | principalmente                           |
| Improving the team review process | Melhorar o processo de revisão da equipa |
| Reviewing the source code         | Rever o código-fonte                     |

## Contraevidência e segunda resposta plausível

Uma revisão pode incluir avaliação do cumprimento de processos e ser usada numa auditoria de QA; contudo, a opção o4 especifica revisão do código-fonte do módulo, não auditoria do processo. Reportar falhas também pode desencadear melhoria, mas reportar o problema do produto não equivale por si a melhorar o processo.

## Qualidade pedagógica e dificuldade

K1: reconhecimento da relação entre testes e QA. Baixa dificuldade e distratores claros são adequados ao reconhecimento; a alternativa o4 exige distinguir o objeto revisto do processo de revisão. As explicações curtas de o2/o3 são suficientes em conjunto com a explicação geral e a de o4. A expressão finds defects directly descreve deteção estática, não garantia de encontrar defeitos em toda revisão.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Que atividade de garantia da qualidade se centra principalmente no processo?
```

Proposto atual — sem alteração

```text
Que atividade de garantia da qualidade se centra principalmente no processo?
```

### Enunciado EN

Original

```text
Which activity is primarily process-oriented quality assurance?
```

Proposto atual — sem alteração

```text
Which activity is primarily process-oriented quality assurance?
```

### o1 — alternativa PT

Original

```text
Melhorar o processo de revisão da equipa
```

Proposto atual — sem alteração

```text
Melhorar o processo de revisão da equipa
```

### o1 — explicação PT

Original

```text
A QA procura prevenir defeitos através da melhoria dos processos. Alterar o processo de revisão da equipa é QA; executar um teste de compra, reportar uma falha e rever código avaliam o produto.
```

Proposto atual — sem alteração

```text
A QA procura prevenir defeitos através da melhoria dos processos. Alterar o processo de revisão da equipa é QA; executar um teste de compra, reportar uma falha e rever código avaliam o produto.
```

### o1 — alternativa EN

Original

```text
Improving the team review process
```

Proposto atual — sem alteração

```text
Improving the team review process
```

### o1 — explicação EN

Original

```text
QA seeks to prevent defects by improving processes. Changing the team review process is QA; executing a checkout test, reporting a failure and reviewing code evaluate the product.
```

Proposto atual — sem alteração

```text
QA seeks to prevent defects by improving processes. Changing the team review process is QA; executing a checkout test, reporting a failure and reviewing code evaluate the product.
```

### o2 — alternativa PT

Original

```text
Executar um teste de compra
```

Proposto atual — sem alteração

```text
Executar um teste de compra
```

### o2 — explicação PT

Original

```text
A execução avalia o produto.
```

Proposto atual — sem alteração

```text
A execução avalia o produto.
```

### o2 — alternativa EN

Original

```text
Executing a checkout test
```

Proposto atual — sem alteração

```text
Executing a checkout test
```

### o2 — explicação EN

Original

```text
Execution evaluates the product.
```

Proposto atual — sem alteração

```text
Execution evaluates the product.
```

### o3 — alternativa PT

Original

```text
Reportar uma falha numa versão
```

Proposto atual — sem alteração

```text
Reportar uma falha numa versão
```

### o3 — explicação PT

Original

```text
Isto reporta um problema do produto.
```

Proposto atual — sem alteração

```text
Isto reporta um problema do produto.
```

### o3 — alternativa EN

Original

```text
Reporting a product failure in a build
```

Proposto atual — sem alteração

```text
Reporting a product failure in a build
```

### o3 — explicação EN

Original

```text
This reports a product problem.
```

Proposto atual — sem alteração

```text
This reports a product problem.
```

### o4 — alternativa PT

Original

```text
Rever o código-fonte do módulo fiscal
```

Proposto atual — sem alteração

```text
Rever o código-fonte do módulo fiscal
```

### o4 — explicação PT

Original

```text
Uma revisão de código avalia um produto e encontra defeitos diretamente. Melhorar a forma de realizar as revisões é a atividade de QA orientada para o processo.
```

Proposto atual — sem alteração

```text
Uma revisão de código avalia um produto e encontra defeitos diretamente. Melhorar a forma de realizar as revisões é a atividade de QA orientada para o processo.
```

### o4 — alternativa EN

Original

```text
Reviewing the source code of the tax module
```

Proposto atual — sem alteração

```text
Reviewing the source code of the tax module
```

### o4 — explicação EN

Original

```text
A code review evaluates a product and finds defects directly. Improving how reviews are performed is the process-oriented QA activity.
```

Proposto atual — sem alteração

```text
A code review evaluates a product and finds defects directly. Improving how reviews are performed is the process-oriented QA activity.
```

### Explicação geral PT

Original

```text
A QA procura prevenir defeitos através da melhoria dos processos. Alterar o processo de revisão da equipa é QA; executar um teste de compra, reportar uma falha e rever código avaliam o produto.
```

Proposto atual — sem alteração

```text
A QA procura prevenir defeitos através da melhoria dos processos. Alterar o processo de revisão da equipa é QA; executar um teste de compra, reportar uma falha e rever código avaliam o produto.
```

### Explicação geral EN

Original

```text
QA seeks to prevent defects by improving processes. Changing the team review process is QA; executing a checkout test, reporting a failure and reviewing code evaluate the product.
```

Proposto atual — sem alteração

```text
QA seeks to prevent defects by improving processes. Changing the team review process is QA; executing a checkout test, reporting a failure and reviewing code evaluate the product.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: melhorar o processo é o objeto da ação, e não apenas avaliar um produto.

Process improvement, not mere inspection of a particular product; matches primarily process-oriented QA.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta: executar compra testa comportamento do produto; feedback posterior não muda o foco primário.

Checkout execution is product-focused dynamic testing. It may inform QA indirectly, but that is not its primary direct objective.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: reportar falha comunica um problema do produto, sem descrever melhoria do processo.

Reporting a product failure provides product evaluation information, not process improvement by itself.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: a revisão do código é teste estático de um artefacto; melhorar o processo de revisão seria outra ação.

Source-code review is static testing of a work product; do not mistake a review instance for improving the review process.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | 0001a37ce447e7a46ad3688ba8e077b9016b71360caf4814701b5ad1ba12b1fe |
| 2026-10-27.2 | True     | 1      | ['o1'] | be587591b0485d8292577931de988ef73b0846ea6cfde546b24779254d5780dd |
| 2026-10-27.3 | True     | 1      | ['o1'] | be587591b0485d8292577931de988ef73b0846ea6cfde546b24779254d5780dd |
| 2026-10-27.4 | True     | 1      | ['o1'] | be587591b0485d8292577931de988ef73b0846ea6cfde546b24779254d5780dd |
| 2026-10-27.5 | True     | 2      | ['o1'] | 30b519fff79e908c8b5be9944ccb2c76a7c42f98843482b777710a092b6ee8c2 |
| 2026-10-27.6 | True     | 2      | ['o1'] | 30b519fff79e908c8b5be9944ccb2c76a7c42f98843482b777710a092b6ee8c2 |
| 2026-10-27.7 | True     | 3      | ['o1'] | 0ff7fa41b7295ee5f5dc3087d11cfd116dc8e74da4f112af81121f9ae601b1df |
| 2026-10-27.8 | True     | 3      | ['o1'] | 0ff7fa41b7295ee5f5dc3087d11cfd116dc8e74da4f112af81121f9ae601b1df |
| 2026-10-27.9 | True     | 3      | ['o1'] | 0ff7fa41b7295ee5f5dc3087d11cfd116dc8e74da4f112af81121f9ae601b1df |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-003 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.1.2 / K2; versão 4; revisão 2026-10-27.10; SHA-256 canónico `f2ab547f90da78a02814524f214fa362d4d799927e59f97a582b04e7529535e0`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

A combinação de diagnosticar o defeito que causou a falha e reparar código identifica debugging. A questão não diz que todo o ato de encontrar defeitos é debugging: testes estáticos encontram-nos diretamente. Comparar resultados de um novo teste, confirmar uma correção e procurar efeitos adversos são atividades de teste no contexto especificado.

Independent reasoning (recorded before the key):

Diagnosticar e reparar o defeito é debugging. Comparar resultados durante um novo teste é execução de testes; confirmação verifica a correção; regressão verifica efeitos adversos. A diferença não depende de quem faz o trabalho.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 1.1.2: EN páginas [16]; PT páginas [17].
- Secção 2.2.3: EN páginas [30]; PT páginas [33].

- LO FL-1.1.2/K2: EN página 14; PT página 15.

Diferença real dos textos: EN 4.0.1, p.16, diz “Diagnosis (finding the defect)”; PT 4.0 tradução 1.0, p.17, diz “Diagnóstico (encontrar a causa raiz do defeito)” e “Corrigir a causa”. O parágrafo PT envolvente continua a falar nas causas da falha (defeitos) e na sua eliminação. Não são PDFs textualmente idênticos. Para o item, localizar/reparar o defeito segue o EN primário e o contexto de ambos; não se impõe uma investigação organizacional de causa raiz em todo debugging.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Diagnosing/diagnosticar e repairing/corrigir conservam as duas ações de o1. May/pode na explicação evita tornar reprodução obrigatória. Actual and expected/obtidos e esperados, confirmation/confirmação e adverse effects/efeitos adversos são equivalentes. Debugging (depuração) torna o empréstimo explícito.

| EN literal                    | PT literal                           |
| ----------------------------- | ------------------------------------ |
| rather than testing           | em vez de aos testes                 |
| Diagnosing the defect         | Diagnosticar o defeito               |
| repairing the faulty code     | corrigir o código incorreto          |
| can also be part of debugging | também pode fazer parte do debugging |

## Contraevidência e segunda resposta plausível

Reproduzir uma falha, executar instrumentação e comparar resultados também podem ocorrer em debugging. Isso não faz da descrição completa de o2 a melhor resposta em vez de testes: ali se diz execução de um novo teste. Uma pessoa pode desempenhar ambos os trabalhos. A chave depende do diagnóstico/remoção em o1, não do cargo ou da reprodução isolada.

## Qualidade pedagógica e dificuldade

K2: diferenciar tipos de atividades, apesar de a opção correta ser reconhecível e o cenário mínimo. Compreender a diferença entre diagnóstico/remoção e verificação justifica o nível. A explicação de o2 explicita a sobreposição da reprodução e evita a falsa regra de exclusividade. A comparação lexical dos PDFs exige a ressalva de tradução abaixo.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Qual das seguintes atividades pertence ao debugging (depuração), em vez de aos testes?
```

Proposto atual — sem alteração

```text
Qual das seguintes atividades pertence ao debugging (depuração), em vez de aos testes?
```

### Enunciado EN

Original

```text
Which activity belongs to debugging rather than testing?
```

Proposto atual — sem alteração

```text
Which activity belongs to debugging rather than testing?
```

### o1 — alternativa PT

Original

```text
Diagnosticar o defeito que causou a falha e corrigir o código incorreto
```

Proposto atual — sem alteração

```text
Diagnosticar o defeito que causou a falha e corrigir o código incorreto
```

### o1 — explicação PT

Original

```text
O debugging pode reproduzir uma falha, diagnosticar a causa e remover o defeito. Localizar e corrigir a causa é debugging; o teste de confirmação posterior verifica a correção.
```

Proposto atual — sem alteração

```text
O debugging pode reproduzir uma falha, diagnosticar a causa e remover o defeito. Localizar e corrigir a causa é debugging; o teste de confirmação posterior verifica a correção.
```

### o1 — alternativa EN

Original

```text
Diagnosing the defect that caused the failure and repairing the faulty code
```

Proposto atual — sem alteração

```text
Diagnosing the defect that caused the failure and repairing the faulty code
```

### o1 — explicação EN

Original

```text
Debugging may reproduce a failure, diagnose its cause and remove the defect. Locating and repairing the cause is debugging; later confirmation testing checks the fix.
```

Proposto atual — sem alteração

```text
Debugging may reproduce a failure, diagnose its cause and remove the defect. Locating and repairing the cause is debugging; later confirmation testing checks the fix.
```

### o2 — alternativa PT

Original

```text
Comparar os resultados obtidos e esperados durante a execução de um novo teste
```

Proposto atual — sem alteração

```text
Comparar os resultados obtidos e esperados durante a execução de um novo teste
```

### o2 — explicação PT

Original

```text
Comparar resultados durante a execução de teste é uma atividade de teste. A reprodução de uma falha existente também pode fazer parte do debugging, pelo que a reprodução, por si só, não distingue as atividades.
```

Proposto atual — sem alteração

```text
Comparar resultados durante a execução de teste é uma atividade de teste. A reprodução de uma falha existente também pode fazer parte do debugging, pelo que a reprodução, por si só, não distingue as atividades.
```

### o2 — alternativa EN

Original

```text
Compare the actual and expected results while executing a new test
```

Proposto atual — sem alteração

```text
Compare the actual and expected results while executing a new test
```

### o2 — explicação EN

Original

```text
Comparing outcomes during test execution is testing. Reproducing an existing failure can also be part of debugging, so reproduction alone does not distinguish the activities.
```

Proposto atual — sem alteração

```text
Comparing outcomes during test execution is testing. Reproducing an existing failure can also be part of debugging, so reproduction alone does not distinguish the activities.
```

### o3 — alternativa PT

Original

```text
Executar um teste de confirmação após a correção
```

Proposto atual — sem alteração

```text
Executar um teste de confirmação após a correção
```

### o3 — explicação PT

Original

```text
Executar um teste de confirmação verifica se a correção resolveu o problema original; localizar e remover o defeito pertence ao debugging.
```

Proposto atual — sem alteração

```text
Executar um teste de confirmação verifica se a correção resolveu o problema original; localizar e remover o defeito pertence ao debugging.
```

### o3 — alternativa EN

Original

```text
Running a confirmation test after the fix
```

Proposto atual — sem alteração

```text
Running a confirmation test after the fix
```

### o3 — explicação EN

Original

```text
Running a confirmation test checks whether the fix resolved the original problem; locating and removing the defect is debugging.
```

Proposto atual — sem alteração

```text
Running a confirmation test checks whether the fix resolved the original problem; locating and removing the defect is debugging.
```

### o4 — alternativa PT

Original

```text
Verificar fluxos de pagamento relacionados para detetar efeitos adversos da correção
```

Proposto atual — sem alteração

```text
Verificar fluxos de pagamento relacionados para detetar efeitos adversos da correção
```

### o4 — explicação PT

Original

```text
Procurar efeitos adversos de uma alteração é teste de regressão. Diagnosticar e remover a causa da falha original é debugging.
```

Proposto atual — sem alteração

```text
Procurar efeitos adversos de uma alteração é teste de regressão. Diagnosticar e remover a causa da falha original é debugging.
```

### o4 — alternativa EN

Original

```text
Checking related payment flows for adverse effects of the fix
```

Proposto atual — sem alteração

```text
Checking related payment flows for adverse effects of the fix
```

### o4 — explicação EN

Original

```text
Checking for adverse effects of a change is regression testing. Diagnosing and removing the cause of the original failure is debugging.
```

Proposto atual — sem alteração

```text
Checking for adverse effects of a change is regression testing. Diagnosing and removing the cause of the original failure is debugging.
```

### Explicação geral PT

Original

```text
O debugging pode reproduzir uma falha, diagnosticar a causa e remover o defeito. Localizar e corrigir a causa é debugging; o teste de confirmação posterior verifica a correção.
```

Proposto atual — sem alteração

```text
O debugging pode reproduzir uma falha, diagnosticar a causa e remover o defeito. Localizar e corrigir a causa é debugging; o teste de confirmação posterior verifica a correção.
```

### Explicação geral EN

Original

```text
Debugging may reproduce a failure, diagnose its cause and remove the defect. Locating and repairing the cause is debugging; later confirmation testing checks the fix.
```

Proposto atual — sem alteração

```text
Debugging may reproduce a failure, diagnose its cause and remove the defect. Locating and repairing the cause is debugging; later confirmation testing checks the fix.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: diagnosticar o defeito e reparar o código é debugging, sem exigir análise formal de toda a causa organizacional.

The combined diagnosis and code repair characterises debugging, not merely revealing a failure.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta como melhor resposta: comparar resultados ao executar um novo teste é teste; a operação de comparação também pode apoiar debugging noutro contexto.

Comparing actual and expected outcomes while executing a new test is testing in this scenario. Similar comparison can occur in debugging; the whole wording and contrast matter.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: a confirmação verifica a correção já feita; não a implementa.

Confirmation after the fix is testing the fix, not repairing it.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: procurar efeitos adversos é regressão, não remoção da causa da falha original.

Checking related flows for adverse effects is regression testing, not defect repair.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | a27a7105aac68e3e46e55eb30af267af95181c8326135c58909eaee2dbcd7b61 |
| 2026-10-27.2 | True     | 2      | ['o1'] | 63022f92eb3bc79277cc1e875c00f13327383e2999fa71a9cb0f61ac1450befa |
| 2026-10-27.3 | True     | 2      | ['o1'] | 63022f92eb3bc79277cc1e875c00f13327383e2999fa71a9cb0f61ac1450befa |
| 2026-10-27.4 | True     | 2      | ['o1'] | 63022f92eb3bc79277cc1e875c00f13327383e2999fa71a9cb0f61ac1450befa |
| 2026-10-27.5 | True     | 3      | ['o1'] | 5c9274bacd737c25875f67dab6f4a545cf5571d84eb0c7a8e417a0448769de95 |
| 2026-10-27.6 | True     | 3      | ['o1'] | 5c9274bacd737c25875f67dab6f4a545cf5571d84eb0c7a8e417a0448769de95 |
| 2026-10-27.7 | True     | 4      | ['o1'] | f2ab547f90da78a02814524f214fa362d4d799927e59f97a582b04e7529535e0 |
| 2026-10-27.8 | True     | 4      | ['o1'] | f2ab547f90da78a02814524f214fa362d4d799927e59f97a582b04e7529535e0 |
| 2026-10-27.9 | True     | 4      | ['o1'] | f2ab547f90da78a02814524f214fa362d4d799927e59f97a582b04e7529535e0 |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-004 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.2.3 / K2; versão 2; revisão 2026-10-27.10; SHA-256 canónico `98cc0a0128b61d289938f3eadca49415717757d5adf7aafcdc0f11a08921ee0e`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

O objeto perguntado é a fórmula incorreta escrita, isto é, um defeito no produto de trabalho. A interpretação incorreta é erro humano. O cenário não declara execução nem resultado observado, e não fornece uma causa subjacente do processo. Pode haver falha ao executar o defeito, mas ela não é inevitável em todos os dados e percursos.

Independent reasoning (recorded before the key):

A interpretação incorreta é erro humano; a fórmula incorreta introduzida no produto é defeito. Não se observou execução ou falha. Uma causa subjacente do processo não foi demonstrada.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 1.2.3: EN páginas [17]; PT páginas [18, 19].

- LO FL-1.2.3/K2: EN página 14; PT página 15.

EN p.17 e PT pp.18–19 admitem falhas condicionais e causas subjacentes. PT explicita possibilidade também na introdução de defeitos. Não se transfere uma relação possível para uma regra inevitável.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Misunderstands/interpreta mal, wrong formula/fórmula errada e observed failure/falha observada preservam causa e objeto. May cause/pode causar conserva possibilidade. O exemplo fiscal é apenas domínio sintético; não pede conhecimento de regras tributárias.

| EN literal          | PT literal          |
| ------------------- | ------------------- |
| misunderstands      | interpreta mal      |
| An observed failure | Uma falha observada |
| may cause           | pode causar         |

## Contraevidência e segunda resposta plausível

Na linguagem comum chama-se erro à fórmula; neste contexto de conceitos ISTQB é necessário distinguir a ação humana da imperfeição no artefacto. Um defeito pode ser causa de uma falha, mas isso não prova que seja a causa raiz do processo de desenvolvimento pedida em o4. Não se exige que o leitor invente formação insuficiente, pressa ou uma execução específica.

## Qualidade pedagógica e dificuldade

K2: distinguir conceitos aplicando-os a um exemplo simples. A explicação geral liga os quatro conceitos e afirma explicitamente a ausência de causa raiz específica; a brevidade de o2/o3 não elimina essa fundamentação. Não se deduz que todos os erros produzam defeitos ou que todos os defeitos causem falhas.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Um programador interpreta mal uma regra fiscal e escreve uma fórmula errada. O que é a fórmula errada?
```

Proposto atual — sem alteração

```text
Um programador interpreta mal uma regra fiscal e escreve uma fórmula errada. O que é a fórmula errada?
```

### Enunciado EN

Original

```text
A programmer misunderstands a tax rule and writes the wrong formula. What is the wrong formula?
```

Proposto atual — sem alteração

```text
A programmer misunderstands a tax rule and writes the wrong formula. What is the wrong formula?
```

### o1 — alternativa PT

Original

```text
Um defeito
```

Proposto atual — sem alteração

```text
Um defeito
```

### o1 — explicação PT

Original

```text
A interpretação incorreta é um erro humano; a fórmula errada escrita no código é um defeito. Executar esse defeito pode causar um resultado fiscal incorreto, uma falha. O cenário não estabelece uma causa raiz específica no processo.
```

Proposto atual — sem alteração

```text
A interpretação incorreta é um erro humano; a fórmula errada escrita no código é um defeito. Executar esse defeito pode causar um resultado fiscal incorreto, uma falha. O cenário não estabelece uma causa raiz específica no processo.
```

### o1 — alternativa EN

Original

```text
A defect
```

Proposto atual — sem alteração

```text
A defect
```

### o1 — explicação EN

Original

```text
The misunderstanding is a human error; the wrong formula written in the code is a defect. Executing that defect may cause an incorrect tax result, a failure. The scenario does not establish a particular underlying process root cause.
```

Proposto atual — sem alteração

```text
The misunderstanding is a human error; the wrong formula written in the code is a defect. Executing that defect may cause an incorrect tax result, a failure. The scenario does not establish a particular underlying process root cause.
```

### o2 — alternativa PT

Original

```text
Um erro
```

Proposto atual — sem alteração

```text
Um erro
```

### o2 — explicação PT

Original

```text
A interpretação incorreta é o erro humano.
```

Proposto atual — sem alteração

```text
A interpretação incorreta é o erro humano.
```

### o2 — alternativa EN

Original

```text
An error
```

Proposto atual — sem alteração

```text
An error
```

### o2 — explicação EN

Original

```text
The misunderstanding is the human error.
```

Proposto atual — sem alteração

```text
The misunderstanding is the human error.
```

### o3 — alternativa PT

Original

```text
Uma falha observada
```

Proposto atual — sem alteração

```text
Uma falha observada
```

### o3 — explicação PT

Original

```text
Uma falha é observada durante a execução.
```

Proposto atual — sem alteração

```text
Uma falha é observada durante a execução.
```

### o3 — alternativa EN

Original

```text
An observed failure
```

Proposto atual — sem alteração

```text
An observed failure
```

### o3 — explicação EN

Original

```text
A failure is observed during execution.
```

Proposto atual — sem alteração

```text
A failure is observed during execution.
```

### o4 — alternativa PT

Original

```text
Uma causa raiz no processo de desenvolvimento
```

Proposto atual — sem alteração

```text
Uma causa raiz no processo de desenvolvimento
```

### o4 — explicação PT

Original

```text
Uma causa raiz é uma razão subjacente a um problema, como formação inadequada. A própria fórmula errada é o defeito no produto de trabalho, não essa causa subjacente do processo.
```

Proposto atual — sem alteração

```text
Uma causa raiz é uma razão subjacente a um problema, como formação inadequada. A própria fórmula errada é o defeito no produto de trabalho, não essa causa subjacente do processo.
```

### o4 — alternativa EN

Original

```text
A root cause in the development process
```

Proposto atual — sem alteração

```text
A root cause in the development process
```

### o4 — explicação EN

Original

```text
A root cause is an underlying reason for a problem, such as inadequate training. The erroneous formula itself is the defect in the work product, not that underlying process cause.
```

Proposto atual — sem alteração

```text
A root cause is an underlying reason for a problem, such as inadequate training. The erroneous formula itself is the defect in the work product, not that underlying process cause.
```

### Explicação geral PT

Original

```text
A interpretação incorreta é um erro humano; a fórmula errada escrita no código é um defeito. Executar esse defeito pode causar um resultado fiscal incorreto, uma falha. O cenário não estabelece uma causa raiz específica no processo.
```

Proposto atual — sem alteração

```text
A interpretação incorreta é um erro humano; a fórmula errada escrita no código é um defeito. Executar esse defeito pode causar um resultado fiscal incorreto, uma falha. O cenário não estabelece uma causa raiz específica no processo.
```

### Explicação geral EN

Original

```text
The misunderstanding is a human error; the wrong formula written in the code is a defect. Executing that defect may cause an incorrect tax result, a failure. The scenario does not establish a particular underlying process root cause.
```

Proposto atual — sem alteração

```text
The misunderstanding is a human error; the wrong formula written in the code is a defect. Executing that defect may cause an incorrect tax result, a failure. The scenario does not establish a particular underlying process root cause.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: a fórmula no código é o defeito, distinguível da ação humana anterior.

The incorrect formula is the flaw in a work product, i.e. a defect.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta: o erro humano é a interpretação incorreta, não o artefacto que resultou dela.

The misunderstanding/human action is the error; everyday use of error for any wrong thing is not the ISTQB distinction.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: falta uma execução com comportamento incorreto observado; o defeito existe antes dessa observação.

No executed result or observable failure is stated; a defect need not fail under every condition.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: uma causa subjacente do processo não está demonstrada; a fórmula é a imperfeição do produto.

A faulty formula could cause downstream incorrect behaviour, but that does not establish the underlying development-process root cause.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | 83f4853efe69021438443ae3c78a4d67ae4fdb4e99710b17d0292f3cefeae3b4 |
| 2026-10-27.2 | True     | 1      | ['o1'] | 0af925834384d989e10739299616e899121f54e52394d85aab51eef870fc6ff9 |
| 2026-10-27.3 | True     | 1      | ['o1'] | 0af925834384d989e10739299616e899121f54e52394d85aab51eef870fc6ff9 |
| 2026-10-27.4 | True     | 1      | ['o1'] | 0af925834384d989e10739299616e899121f54e52394d85aab51eef870fc6ff9 |
| 2026-10-27.5 | True     | 1      | ['o1'] | 0af925834384d989e10739299616e899121f54e52394d85aab51eef870fc6ff9 |
| 2026-10-27.6 | True     | 1      | ['o1'] | 0af925834384d989e10739299616e899121f54e52394d85aab51eef870fc6ff9 |
| 2026-10-27.7 | True     | 2      | ['o1'] | 98cc0a0128b61d289938f3eadca49415717757d5adf7aafcdc0f11a08921ee0e |
| 2026-10-27.8 | True     | 2      | ['o1'] | 98cc0a0128b61d289938f3eadca49415717757d5adf7aafcdc0f11a08921ee0e |
| 2026-10-27.9 | True     | 2      | ['o1'] | 98cc0a0128b61d289938f3eadca49415717757d5adf7aafcdc0f11a08921ee0e |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-005 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.3.1 / K2; versão 2; revisão 2026-10-27.10; SHA-256 canónico `1b88f7e791e80867a1296e28ce78fd90695c9f28328b9ccc74874b890dd49a35`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

As falhas relatadas não são exercitadas pela bateria existente. Rever testes e dados para lacunas, conservando regressão útil, responde ao princípio de desgaste dos testes. Não é um pedido para executar apenas confirmação da última correção nem para abandonar a bateria anterior; não há promessa de deteção exaustiva ou de ausência de defeitos.

Independent reasoning (recorded before the key):

As falhas relatadas estão fora dos cenários exercitados. Rever/adicionar testes e dados para essas lacunas mantendo regressão útil é a melhor resposta. A questão reconhece desgaste dos testes, não exige testes exaustivos ou garante ausência de defeitos.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 1.3: EN páginas [17, 18]; PT páginas [19].
- Secção 2.2.3: EN páginas [30]; PT páginas [33].

- LO FL-1.3.1/K2: EN página 14; PT página 15.

EN princípio 5 permite modificar testes/dados e criar novos testes, conservando o benefício de regressão repetida; PT p.19 faz a mesma ressalva. A terminologia de confirmação/regressão apoia a distinção mas o LO primário é 1.3, não 2.2.3.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Suite/bateria designa conjunto de testes, não um único caso ou uma ferramenta. Repeated/repetidas, unchanged/inalterados, missing/em falta e retaining/mantendo mantêm a política de conservar cobertura útil. A explicação o2 usa can/pode e a o4 may/pode, preservando benefícios possíveis sem garantia.

| EN literal                         | PT literal                               |
| ---------------------------------- | ---------------------------------------- |
| suite                              | bateria                                  |
| retaining useful regression checks | mantendo verificações de regressão úteis |
| may reveal order dependencies      | pode revelar dependências de ordem       |

## Contraevidência e segunda resposta plausível

Alterar a ordem pode revelar novas falhas dependentes de estado; repetir mais vezes pode revelar intermitência. Esses são contraexemplos reais a uma leitura universal dos distratores. Porém o cenário não identifica essas causas e o1 é a revisão abrangente que pode decidir os testes e dados adequados. O4 não é uma segunda melhor resposta apenas por poder ajudar num caso especializado. A explicação de o4 deve ser lida como insuficiência da técnica isolada face à lacuna, não impossibilidade universal de revelar novas falhas.

## Qualidade pedagógica e dificuldade

K2: relacionar o comportamento observado com um princípio e escolher uma resposta apropriada; não se exige cálculo ou desenho completo de uma bateria. É uma faceta do LO dos sete princípios, não prova de domínio dos sete. Há uma melhoria opcional da explicação de o4 para reforçar a ausência de garantia de cobertura, registada separadamente.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
As execuções repetidas de regressão passam, mas os utilizadores reportam novos tipos de falha que a bateria não exercita. Qual é a melhor resposta para melhorar a deteção de defeitos?
```

Proposto atual — sem alteração

```text
As execuções repetidas de regressão passam, mas os utilizadores reportam novos tipos de falha que a bateria não exercita. Qual é a melhor resposta para melhorar a deteção de defeitos?
```

### Enunciado EN

Original

```text
Repeated regression runs pass, but users report new failure types that the suite does not exercise. What is the best response to improve defect detection?
```

Proposto atual — sem alteração

```text
Repeated regression runs pass, but users report new failure types that the suite does not exercise. What is the best response to improve defect detection?
```

### o1 — alternativa PT

Original

```text
Rever testes e dados para cenários em falta, mantendo verificações de regressão úteis
```

Proposto atual — sem alteração

```text
Rever testes e dados para cenários em falta, mantendo verificações de regressão úteis
```

### o1 — explicação PT

Original

```text
Rever e variar os testes e os dados permite cobrir os novos tipos de falha observados, mantendo verificações de regressão úteis. Os testes podem perder eficácia; uma bateria inalterada passar não demonstra cobertura de novos cenários.
```

Proposto atual — sem alteração

```text
Rever e variar os testes e os dados permite cobrir os novos tipos de falha observados, mantendo verificações de regressão úteis. Os testes podem perder eficácia; uma bateria inalterada passar não demonstra cobertura de novos cenários.
```

### o1 — alternativa EN

Original

```text
Review tests and data for missing scenarios, retaining useful regression checks
```

Proposto atual — sem alteração

```text
Review tests and data for missing scenarios, retaining useful regression checks
```

### o1 — explicação EN

Original

```text
Review and vary tests and data to cover the newly observed failure types, while retaining useful regression checks. Tests can wear out; passing an unchanged suite does not demonstrate coverage of new scenarios.
```

Proposto atual — sem alteração

```text
Review and vary tests and data to cover the newly observed failure types, while retaining useful regression checks. Tests can wear out; passing an unchanged suite does not demonstrate coverage of new scenarios.
```

### o2 — alternativa PT

Original

```text
Executar mais vezes os casos existentes, mantendo os seus dados de teste inalterados
```

Proposto atual — sem alteração

```text
Executar mais vezes os casos existentes, mantendo os seus dados de teste inalterados
```

### o2 — explicação PT

Original

```text
Uma execução mais frequente pode detetar regressões mais cedo, mas não acrescenta cobertura dos cenários em falta.
```

Proposto atual — sem alteração

```text
Uma execução mais frequente pode detetar regressões mais cedo, mas não acrescenta cobertura dos cenários em falta.
```

### o2 — alternativa EN

Original

```text
Run the existing cases more frequently while keeping their data unchanged
```

Proposto atual — sem alteração

```text
Run the existing cases more frequently while keeping their data unchanged
```

### o2 — explicação EN

Original

```text
More frequent execution can detect regressions sooner, but does not add coverage of the missing scenarios.
```

Proposto atual — sem alteração

```text
More frequent execution can detect regressions sooner, but does not add coverage of the missing scenarios.
```

### o3 — alternativa PT

Original

```text
Substituir a bateria existente por casos para a falha reportada mais recentemente
```

Proposto atual — sem alteração

```text
Substituir a bateria existente por casos para a falha reportada mais recentemente
```

### o3 — explicação PT

Original

```text
Um novo teste focado é útil, mas substituir a bateria elimina cobertura de regressão útil para outros comportamentos.
```

Proposto atual — sem alteração

```text
Um novo teste focado é útil, mas substituir a bateria elimina cobertura de regressão útil para outros comportamentos.
```

### o3 — alternativa EN

Original

```text
Replace the existing suite with cases for the most recently reported failure
```

Proposto atual — sem alteração

```text
Replace the existing suite with cases for the most recently reported failure
```

### o3 — explicação EN

Original

```text
A focused new test is useful, but replacing the suite discards useful regression coverage for other behavior.
```

Proposto atual — sem alteração

```text
A focused new test is useful, but replacing the suite discards useful regression coverage for other behavior.
```

### o4 — alternativa PT

Original

```text
Variar a ordem de execução dos testes existentes, mantendo os seus dados inalterados
```

Proposto atual — sem alteração

```text
Variar a ordem de execução dos testes existentes, mantendo os seus dados inalterados
```

### o4 — explicação PT

Original

```text
Mudar a ordem pode revelar dependências de ordem, mas, por si só, não cobre os novos cenários de falha. É necessário rever a bateria e os dados.
```

Proposto atual — sem alteração

```text
Mudar a ordem pode revelar dependências de ordem, mas, por si só, não cobre os novos cenários de falha. É necessário rever a bateria e os dados.
```

### o4 — alternativa EN

Original

```text
Vary the execution order of existing tests while keeping their data unchanged
```

Proposto atual — sem alteração

```text
Vary the execution order of existing tests while keeping their data unchanged
```

### o4 — explicação EN

Original

```text
Changing order may reveal order dependencies, but it does not by itself cover the new failure scenarios. The suite and data need review.
```

Proposto atual — sem alteração

```text
Changing order may reveal order dependencies, but it does not by itself cover the new failure scenarios. The suite and data need review.
```

### Explicação geral PT

Original

```text
Rever e variar os testes e os dados permite cobrir os novos tipos de falha observados, mantendo verificações de regressão úteis. Os testes podem perder eficácia; uma bateria inalterada passar não demonstra cobertura de novos cenários.
```

Proposto atual — sem alteração

```text
Rever e variar os testes e os dados permite cobrir os novos tipos de falha observados, mantendo verificações de regressão úteis. Os testes podem perder eficácia; uma bateria inalterada passar não demonstra cobertura de novos cenários.
```

### Explicação geral EN

Original

```text
Review and vary tests and data to cover the newly observed failure types, while retaining useful regression checks. Tests can wear out; passing an unchanged suite does not demonstrate coverage of new scenarios.
```

Proposto atual — sem alteração

```text
Review and vary tests and data to cover the newly observed failure types, while retaining useful regression checks. Tests can wear out; passing an unchanged suite does not demonstrate coverage of new scenarios.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: investigar lacunas e adaptar testes/dados preservando regressão útil responde diretamente ao cenário.

Investigate missing scenarios and retain useful regression checks; directly targets the stated gap.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta como melhor resposta: mais frequência pode antecipar deteção, mas não analisa nem acrescenta os cenários não exercitados.

More frequency with unchanged scenarios does not address explicitly unexercised failure types. It can help intermittent failures in a different scenario.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: substituir toda a bateria pela falha mais recente descarta cobertura útil; acrescentar um teste focado seria diferente.

Replacing the whole suite with only the newest failure sacrifices useful existing coverage; adding focused tests is different.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta como melhor resposta: a ordem pode ajudar com dependências, mas não estabelece cobertura dos tipos de falha em falta; não é técnica universalmente inútil.

Reordering might expose order-dependent issues elsewhere, but no such dependency is given and it does not generally supply missing scenarios here.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | 3ab8f71c15eb84d361ad12acdb97658912a518d6125ddeebb1f5bd907c262b85 |
| 2026-10-27.2 | True     | 1      | ['o1'] | 05c5741f44fd7803bdfb021aa02a1af58c55e925322373017ea83cfa2999d0e6 |
| 2026-10-27.3 | True     | 1      | ['o1'] | 05c5741f44fd7803bdfb021aa02a1af58c55e925322373017ea83cfa2999d0e6 |
| 2026-10-27.4 | True     | 1      | ['o1'] | 05c5741f44fd7803bdfb021aa02a1af58c55e925322373017ea83cfa2999d0e6 |
| 2026-10-27.5 | True     | 1      | ['o1'] | 05c5741f44fd7803bdfb021aa02a1af58c55e925322373017ea83cfa2999d0e6 |
| 2026-10-27.6 | True     | 1      | ['o1'] | 05c5741f44fd7803bdfb021aa02a1af58c55e925322373017ea83cfa2999d0e6 |
| 2026-10-27.7 | True     | 2      | ['o1'] | 1b88f7e791e80867a1296e28ce78fd90695c9f28328b9ccc74874b890dd49a35 |
| 2026-10-27.8 | True     | 2      | ['o1'] | 1b88f7e791e80867a1296e28ce78fd90695c9f28328b9ccc74874b890dd49a35 |
| 2026-10-27.9 | True     | 2      | ['o1'] | 1b88f7e791e80867a1296e28ce78fd90695c9f28328b9ccc74874b890dd49a35 |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

A explicação atual reconhece dependências de ordem; a formulação proposta realça ausência de prova de cobertura em vez de uma leitura universal de impossibilidade. O cenário e a melhor resposta não mudam.

Sugestão opcional, não aplicada: explicação de o4. Texto atual integral reproduzido acima. Candidato completo e impacto de versão/persistência em optional-candidates.json.

PT

Original opcional:

```text
Mudar a ordem pode revelar dependências de ordem, mas, por si só, não cobre os novos cenários de falha. É necessário rever a bateria e os dados.
```

Sugerido opcional:

```text
Mudar a ordem de execução pode revelar falhas dependentes da ordem. Contudo, sem rever os cenários em falta, reordenar apenas os testes existentes não demonstra que os novos tipos de falha reportados estão cobertos. Deve rever-se a bateria e os dados, mantendo verificações de regressão úteis.
```

EN

Original opcional:

```text
Changing order may reveal order dependencies, but it does not by itself cover the new failure scenarios. The suite and data need review.
```

Sugerido opcional:

```text
Changing execution order can expose order-dependent failures. Without reviewing the missing scenarios, however, reordering existing tests alone does not establish that the newly reported failure types are covered. Review the suite and its data while retaining useful regression checks.
```

Chave, LO e K sem impacto. Nenhuma nova versão/revisão criada. Aplicação futura depende de autorização; preservar .10 e sessões antigas. Regressões propostas:

- Review PT/EN wording, all distractors and best-answer uniqueness
- Preserve all 90 keys/IDs and multi-select exact-set scoring
- History .10 snapshot plus unit backup/restore/history compatibility
- Proportionate typecheck/lint/build and rendered explanation checks

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-007 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.4.4 / K2; versão 2; revisão 2026-10-27.10; SHA-256 canónico `c0726c854ee926a619ced00e9776122368407abf3449771a1901b51b9b5e065a`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

As ligações ajudam a localizar testes potencialmente afetados por uma alteração do requisito. Não executam testes nem inferem automaticamente os resultados esperados atualizados. May/podem conserva a natureza potencial da necessidade de revisão: uma ligação não exige editar todos os testes.

Independent reasoning (recorded before the key):

Rastreabilidade de requisito para testes apoia análise de impacto: encontrar condições/resultados que podem exigir revisão. Não calcula oráculos atualizados, não demonstra que testes continuam a passar e não depende de editar scripts.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 1.4.4: EN páginas [20, 21]; PT páginas [22, 23].

- LO FL-1.4.4/K2: EN página 14; PT página 15.

EN pp.20–21 e PT pp.22–23 sustentam análise de impacto e cobertura. Independência de testes não é o conceito normativo deste item. Nenhuma evidência de execução nasce automaticamente de uma ligação.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Requirement-to-test links/ligações entre requisitos e testes conserva as extremidades da relação. Conditions/condições e expected results/resultados esperados referem o conteúdo do teste. May need revision/podem precisar de revisão é possibilidade em ambas as línguas; still pass/continuam a passar exige evidência que ligações isoladas não dão.

| EN literal                 | PT literal                         |
| -------------------------- | ---------------------------------- |
| requirement-to-test links  | ligações entre requisitos e testes |
| may need revision          | podem precisar de revisão          |
| not a new execution result | não um novo resultado de execução  |

## Contraevidência e segunda resposta plausível

Ferramentas podem ligar requisitos a resultados e mostrar cobertura ou gerar testes a partir de especificações executáveis. Contudo, o cenário apenas fornece ligações requisito-teste, não atualização automática validada nem uma nova execução. Esses contextos adicionais não justificam o2 ou o3. A ausência de edição do script também não prova ausência de impacto.

## Qualidade pedagógica e dificuldade

K2: explicar um benefício concreto de rastreabilidade numa mudança, distinguindo relações de resultados. A explicação correta é muito breve mas precisa; os distratores explicam limites e complementam-na. Não é questão de independência de testes, que corresponde a FL-1.5.3 e não a este ID/LO. Não se avaliou outra questão para forçar a orientação inicial.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Um requisito de pagamento muda. Como ajudam as ligações entre requisitos e testes?
```

Proposto atual — sem alteração

```text
Um requisito de pagamento muda. Como ajudam as ligações entre requisitos e testes?
```

### Enunciado EN

Original

```text
A payment requirement changes. How do requirement-to-test links help?
```

Proposto atual — sem alteração

```text
A payment requirement changes. How do requirement-to-test links help?
```

### o1 — alternativa PT

Original

```text
Identificar os testes ligados cujas condições ou resultados esperados podem precisar de revisão
```

Proposto atual — sem alteração

```text
Identificar os testes ligados cujas condições ou resultados esperados podem precisar de revisão
```

### o1 — explicação PT

Original

```text
A rastreabilidade apoia a análise de impacto das alterações.
```

Proposto atual — sem alteração

```text
A rastreabilidade apoia a análise de impacto das alterações.
```

### o1 — alternativa EN

Original

```text
Identify the linked tests whose conditions or expected results may need revision
```

Proposto atual — sem alteração

```text
Identify the linked tests whose conditions or expected results may need revision
```

### o1 — explicação EN

Original

```text
Traceability supports change impact analysis.
```

Proposto atual — sem alteração

```text
Traceability supports change impact analysis.
```

### o2 — alternativa PT

Original

```text
Usar as ligações como evidência de que os testes anteriormente aprovados continuam a passar após a alteração
```

Proposto atual — sem alteração

```text
Usar as ligações como evidência de que os testes anteriormente aprovados continuam a passar após a alteração
```

### o2 — explicação PT

Original

```text
Uma ligação regista uma relação, não um novo resultado de execução. É necessário avaliar o comportamento alterado e executar os testes relevantes.
```

Proposto atual — sem alteração

```text
Uma ligação regista uma relação, não um novo resultado de execução. É necessário avaliar o comportamento alterado e executar os testes relevantes.
```

### o2 — alternativa EN

Original

```text
Use the links as evidence that previously passed tests still pass after the change
```

Proposto atual — sem alteração

```text
Use the links as evidence that previously passed tests still pass after the change
```

### o2 — explicação EN

Original

```text
A link records a relationship, not a new execution result. The changed behavior must be assessed and relevant tests executed.
```

Proposto atual — sem alteração

```text
A link records a relationship, not a new execution result. The changed behavior must be assessed and relevant tests executed.
```

### o3 — alternativa PT

Original

```text
Obter resultados esperados atualizados das ligações em vez de consultar o requisito alterado
```

Proposto atual — sem alteração

```text
Obter resultados esperados atualizados das ligações em vez de consultar o requisito alterado
```

### o3 — explicação PT

Original

```text
A rastreabilidade aponta para o requisito afetado; o seu conteúdo atualizado, e não a existência da ligação, define o comportamento esperado.
```

Proposto atual — sem alteração

```text
A rastreabilidade aponta para o requisito afetado; o seu conteúdo atualizado, e não a existência da ligação, define o comportamento esperado.
```

### o3 — alternativa EN

Original

```text
Obtain revised expected results from the links instead of the changed requirement
```

Proposto atual — sem alteração

```text
Obtain revised expected results from the links instead of the changed requirement
```

### o3 — explicação EN

Original

```text
Traceability points to the affected requirement; its revised content, not the existence of the link, defines the expected behavior.
```

Proposto atual — sem alteração

```text
Traceability points to the affected requirement; its revised content, not the existence of the link, defines the expected behavior.
```

### o4 — alternativa PT

Original

```text
Considerar um teste ligado como não afetado quando o seu script não foi editado
```

Proposto atual — sem alteração

```text
Considerar um teste ligado como não afetado quando o seu script não foi editado
```

### o4 — explicação PT

Original

```text
Uma alteração de requisito pode invalidar um teste ou o seu resultado esperado mesmo sem alterações no ficheiro do teste. As ligações apoiam essa análise de impacto.
```

Proposto atual — sem alteração

```text
Uma alteração de requisito pode invalidar um teste ou o seu resultado esperado mesmo sem alterações no ficheiro do teste. As ligações apoiam essa análise de impacto.
```

### o4 — alternativa EN

Original

```text
Treat a linked test as unaffected when its script has not been edited
```

Proposto atual — sem alteração

```text
Treat a linked test as unaffected when its script has not been edited
```

### o4 — explicação EN

Original

```text
A requirement change can invalidate a test or its expected result even when the test file is unchanged. Links support that impact analysis.
```

Proposto atual — sem alteração

```text
A requirement change can invalidate a test or its expected result even when the test file is unchanged. Links support that impact analysis.
```

### Explicação geral PT

Original

```text
A rastreabilidade apoia a análise de impacto das alterações.
```

Proposto atual — sem alteração

```text
A rastreabilidade apoia a análise de impacto das alterações.
```

### Explicação geral EN

Original

```text
Traceability supports change impact analysis.
```

Proposto atual — sem alteração

```text
Traceability supports change impact analysis.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: relações de rastreabilidade permitem selecionar testes para análise de impacto, sem obrigar a alterar todos.

Links locate potentially affected tests and support impact analysis. May need revision is a possibility, not every linked test must change.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta: um vínculo ou resultado anterior não prova uma execução atual bem-sucedida após a mudança.

A link is not a fresh execution result; previous passes do not prove continued success after requirements change.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: os resultados esperados devem ser derivados da base atualizada, não da mera existência da ligação.

Links point to the changed basis; they do not replace interpreting requirements to derive revised expected results.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: o script pode estar intacto e, ainda assim, ter condições ou oráculos desatualizados.

A script can remain unedited and still be semantically out of date when its requirement changes.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | f199f05e5cc6ef6d6d4f314faa8961f3a07c46a774b5795be9cb236b7ade19fb |
| 2026-10-27.2 | True     | 1      | ['o1'] | 2f91a17a25f526a55cd85977d69509d26b597d507f244196889f391bdf68cf57 |
| 2026-10-27.3 | True     | 1      | ['o1'] | 2f91a17a25f526a55cd85977d69509d26b597d507f244196889f391bdf68cf57 |
| 2026-10-27.4 | True     | 1      | ['o1'] | 2f91a17a25f526a55cd85977d69509d26b597d507f244196889f391bdf68cf57 |
| 2026-10-27.5 | True     | 1      | ['o1'] | 2f91a17a25f526a55cd85977d69509d26b597d507f244196889f391bdf68cf57 |
| 2026-10-27.6 | True     | 1      | ['o1'] | 2f91a17a25f526a55cd85977d69509d26b597d507f244196889f391bdf68cf57 |
| 2026-10-27.7 | True     | 2      | ['o1'] | c0726c854ee926a619ced00e9776122368407abf3449771a1901b51b9b5e065a |
| 2026-10-27.8 | True     | 2      | ['o1'] | c0726c854ee926a619ced00e9776122368407abf3449771a1901b51b9b5e065a |
| 2026-10-27.9 | True     | 2      | ['o1'] | c0726c854ee926a619ced00e9776122368407abf3449771a1901b51b9b5e065a |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-009 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.2 / K1; versão 2; revisão 2026-10-27.10; SHA-256 canónico `ba36aeccb6125f2e08b34421709cc01f8f2a10421984874df19899b6a4c9382c`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

Boa prática transversal: iniciar análise de teste durante a atividade de desenvolvimento correspondente, a partir de produtos preliminares disponíveis. Isso não afirma que software inexistente pode ser executado; análise/revisão e execução têm pré-requisitos diferentes. Os níveis conservam objetivos distintos.

Independent reasoning (recorded before the key):

Análise de testes começa durante a atividade de desenvolvimento correspondente com rascunhos disponíveis. Não implica executar software inexistente ou aguardar implementação completa; níveis têm objetivos próprios e revisões não são substituídas por teste tardio.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 2.1.2: EN páginas [25, 26]; PT páginas [27, 28].

- LO FL-2.1.2/K1: EN página 24; PT página 26.

EN pp.25–26 e PT pp.27–28 distribuem as boas práticas por duas páginas. Não se assumiu um deslocamento universal entre documentos. As duas versões suportam análise correspondente e revisão de rascunhos.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

During related development work/durante o desenvolvimento relacionado conserva correspondência temporal. Available draft work products/produtos preliminares disponíveis mantém a condição de existência de uma base, não código final. Across/aos vários não obriga a todos os projetos terem o mesmo calendário ou formato de documentação.

| EN literal                      | PT literal                            |
| ------------------------------- | ------------------------------------- |
| during related development work | durante o desenvolvimento relacionado |
| available draft work products   | produtos preliminares disponíveis     |
| the same test objectives        | os mesmos objetivos de teste          |

## Contraevidência e segunda resposta plausível

Alguns testes dinâmicos precisam de código executável e um ambiente disponível, e os ciclos de vida organizam atividades de forma distinta. Isso não é fundamento para adiar toda análise até acabar implementação. Revisões podem ser informais e os objetivos entre níveis podem sobrepor-se parcialmente; nem isso torna os objetivos globalmente idênticos ou elimina o valor de revisões precoces.

## Qualidade pedagógica e dificuldade

K1: reconhecer boa prática geral; não requer aplicar um plano de ciclo de vida. As explicações de o2/o4 explicitam a distinção entre esperar por código e analisar rascunhos, compensando a brevidade da explicação geral. Não há contradição entre início precoce e adaptação de contexto.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Que prática se aplica aos vários ciclos de desenvolvimento?
```

Proposto atual — sem alteração

```text
Que prática se aplica aos vários ciclos de desenvolvimento?
```

### Enunciado EN

Original

```text
Which practice applies across development lifecycles?
```

Proposto atual — sem alteração

```text
Which practice applies across development lifecycles?
```

### o1 — alternativa PT

Original

```text
Iniciar a análise de teste durante o desenvolvimento relacionado, usando os produtos preliminares disponíveis
```

Proposto atual — sem alteração

```text
Iniciar a análise de teste durante o desenvolvimento relacionado, usando os produtos preliminares disponíveis
```

### o1 — explicação PT

Original

```text
Atividades de teste correspondentes e precoces apoiam o feedback.
```

Proposto atual — sem alteração

```text
Atividades de teste correspondentes e precoces apoiam o feedback.
```

### o1 — alternativa EN

Original

```text
Start test analysis during related development work, using available draft work products
```

Proposto atual — sem alteração

```text
Start test analysis during related development work, using available draft work products
```

### o1 — explicação EN

Original

```text
Early corresponding test activities support feedback.
```

Proposto atual — sem alteração

```text
Early corresponding test activities support feedback.
```

### o2 — alternativa PT

Original

```text
Concluir a implementação antes de iniciar a análise de teste correspondente
```

Proposto atual — sem alteração

```text
Concluir a implementação antes de iniciar a análise de teste correspondente
```

### o2 — explicação PT

Original

```text
Esperar por código concluído atrasa uma análise que pode começar a partir de produtos de desenvolvimento, como os requisitos.
```

Proposto atual — sem alteração

```text
Esperar por código concluído atrasa uma análise que pode começar a partir de produtos de desenvolvimento, como os requisitos.
```

### o2 — alternativa EN

Original

```text
Finish implementation before starting the corresponding test analysis
```

Proposto atual — sem alteração

```text
Finish implementation before starting the corresponding test analysis
```

### o2 — explicação EN

Original

```text
Waiting for completed code delays analysis that can start from development work products such as requirements.
```

Proposto atual — sem alteração

```text
Waiting for completed code delays analysis that can start from development work products such as requirements.
```

### o3 — alternativa PT

Original

```text
Atribuir os mesmos objetivos de teste aos testes de componente e de aceitação
```

Proposto atual — sem alteração

```text
Atribuir os mesmos objetivos de teste aos testes de componente e de aceitação
```

### o3 — explicação PT

Original

```text
Os diferentes níveis de teste têm objetivos distintos; uma boa prática aplicável a vários ciclos de vida não torna os seus objetivos idênticos.
```

Proposto atual — sem alteração

```text
Os diferentes níveis de teste têm objetivos distintos; uma boa prática aplicável a vários ciclos de vida não torna os seus objetivos idênticos.
```

### o3 — alternativa EN

Original

```text
Give component and acceptance testing the same test objectives
```

Proposto atual — sem alteração

```text
Give component and acceptance testing the same test objectives
```

### o3 — explicação EN

Original

```text
Different test levels have distinct objectives; lifecycle-independent good practice does not make their objectives identical.
```

Proposto atual — sem alteração

```text
Different test levels have distinct objectives; lifecycle-independent good practice does not make their objectives identical.
```

### o4 — alternativa PT

Original

```text
Substituir revisões de produtos de desenvolvimento pela execução posterior de testes de sistema
```

Proposto atual — sem alteração

```text
Substituir revisões de produtos de desenvolvimento pela execução posterior de testes de sistema
```

### o4 — explicação PT

Original

```text
As revisões de versões preliminares apoiam a deteção precoce de defeitos e complementam os testes dinâmicos posteriores. O teste de sistema posterior não substitui essas atividades iniciais.
```

Proposto atual — sem alteração

```text
As revisões de versões preliminares apoiam a deteção precoce de defeitos e complementam os testes dinâmicos posteriores. O teste de sistema posterior não substitui essas atividades iniciais.
```

### o4 — alternativa EN

Original

```text
Replace reviews of development work products with later system-test execution
```

Proposto atual — sem alteração

```text
Replace reviews of development work products with later system-test execution
```

### o4 — explicação EN

Original

```text
Reviews of drafts support early defect detection and complement later dynamic tests. Later system testing is not a replacement for those early activities.
```

Proposto atual — sem alteração

```text
Reviews of drafts support early defect detection and complement later dynamic tests. Later system testing is not a replacement for those early activities.
```

### Explicação geral PT

Original

```text
Atividades de teste correspondentes e precoces apoiam o feedback.
```

Proposto atual — sem alteração

```text
Atividades de teste correspondentes e precoces apoiam o feedback.
```

### Explicação geral EN

Original

```text
Early corresponding test activities support feedback.
```

Proposto atual — sem alteração

```text
Early corresponding test activities support feedback.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: análise a partir de produtos preliminares acompanha o desenvolvimento relacionado.

Early corresponding test analysis using draft work products is a cross-lifecycle good practice, adapted to context.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta: terminar implementação é pré-condição excessiva para análise, embora execução dinâmica tenha outras dependências.

Waiting for completed implementation postpones available test analysis unnecessarily; distinguish execution prerequisites.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: níveis podem partilhar alguma preocupação de qualidade, mas têm objetivos específicos distintos, não os mesmos objetivos como regra.

Component and acceptance levels have different objectives, not identical objectives by general rule.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: testes dinâmicos posteriores não substituem revisões precoces; as atividades são complementares.

Later dynamic system tests do not replace early work-product reviews; techniques complement one another.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | fde2f7e471fa7452e8dc63a8c295deab398fcfda5599b66cdfd2f677ad504d86 |
| 2026-10-27.2 | True     | 1      | ['o1'] | a4d42a3bdfbd788d2ea987af77add7653552c03d5ec514070a316293593e4ded |
| 2026-10-27.3 | True     | 1      | ['o1'] | a4d42a3bdfbd788d2ea987af77add7653552c03d5ec514070a316293593e4ded |
| 2026-10-27.4 | True     | 1      | ['o1'] | a4d42a3bdfbd788d2ea987af77add7653552c03d5ec514070a316293593e4ded |
| 2026-10-27.5 | True     | 1      | ['o1'] | a4d42a3bdfbd788d2ea987af77add7653552c03d5ec514070a316293593e4ded |
| 2026-10-27.6 | True     | 1      | ['o1'] | a4d42a3bdfbd788d2ea987af77add7653552c03d5ec514070a316293593e4ded |
| 2026-10-27.7 | True     | 2      | ['o1'] | ba36aeccb6125f2e08b34421709cc01f8f2a10421984874df19899b6a4c9382c |
| 2026-10-27.8 | True     | 2      | ['o1'] | ba36aeccb6125f2e08b34421709cc01f8f2a10421984874df19899b6a4c9382c |
| 2026-10-27.9 | True     | 2      | ['o1'] | ba36aeccb6125f2e08b34421709cc01f8f2a10421984874df19899b6a4c9382c |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-010 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.3 / K1; versão 3; revisão 2026-10-27.10; SHA-256 canónico `fb8e756c8ce786e34d7eda2dce5b6069220f646247bb339067e00b6359c48e7b`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

O ciclo repetido de teste de componente, código que o satisfaça e refatorização identifica TDD. ATDD e BDD também são test-first, mas a sua definição não é este ciclo específico; CI integra alterações e pode executar testes, sem definir por si a forma de programar.

Independent reasoning (recorded before the key):

O ciclo teste de componente primeiro, código para o satisfazer, refatorização de ambos identifica TDD. ATDD centra-se em aceitação; BDD no comportamento e linguagem compreensível; CI integra alterações e pode correr testes, mas não define este ciclo.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 2.1.3: EN páginas [26]; PT páginas [28].

- LO FL-2.1.3/K1: EN página 24; PT página 26.

PT p.28 usa reestruturados na descrição de TDD e Considerando/Quando/Então no BDD; o item usa refatorizar e Dado/Quando/Então, mantendo os conceitos. O reconhecimento do ciclo não implica que testes sejam desnecessários quando o comportamento pretendido se mantém.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Repeated cycle/ciclo repetido, writing a component test/escrever um teste de componente, satisfy/satisfaça e refactoring/refatorizar preservam sequência e objetos, incluindo testes e código. PT oficial usa reestruturados onde EN usa refactored; refatorizar é tecnicamente apropriado no item. BDD usually/frequentemente é preservado nas explicações.

| EN literal                     | PT literal                         |
| ------------------------------ | ---------------------------------- |
| refactoring the tests and code | refatorizar os testes e o código   |
| component test                 | teste de componente                |
| can run automated tests        | pode executar testes automatizados |

## Contraevidência e segunda resposta plausível

BDD pode ser descrito como evolução de TDD e uma equipa pode combinar TDD, ATDD, BDD e CI. Coexistência não torna todos os rótulos igualmente precisos para a descrição pedida. Não se exclui execução de testes após refatorização nem se infere que a ausência de alteração funcional pretendida elimina risco. A pergunta pede reconhecimento, não um plano completo de refatorização.

## Qualidade pedagógica e dificuldade

K1: reconhecer o exemplo característico de TDD é adequado; não exige demonstrar código, calcular cobertura ou escolher testes de regressão. O termo componente torna a opção mais discriminante face a ATDD/BDD. A explicação não promete que uma bateria limitada prove equivalência comportamental após toda refatorização.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Que abordagem orienta a programação através de um ciclo repetido de escrever um teste de componente, escrever código que o satisfaça e refatorizar os testes e o código?
```

Proposto atual — sem alteração

```text
Que abordagem orienta a programação através de um ciclo repetido de escrever um teste de componente, escrever código que o satisfaça e refatorizar os testes e o código?
```

### Enunciado EN

Original

```text
Which approach directs coding through a repeated cycle of writing a component test, writing code to satisfy it, and refactoring the tests and code?
```

Proposto atual — sem alteração

```text
Which approach directs coding through a repeated cycle of writing a component test, writing code to satisfy it, and refactoring the tests and code?
```

### o1 — alternativa PT

Original

```text
Desenvolvimento orientado para testes (TDD)
```

Proposto atual — sem alteração

```text
Desenvolvimento orientado para testes (TDD)
```

### o1 — explicação PT

Original

```text
O TDD orienta a programação através de testes: escrever um teste, implementar código que o satisfaça e depois refatorizar os testes e o código. O ATDD e o BDD também apoiam testes precoces, mas têm características distintivas diferentes.
```

Proposto atual — sem alteração

```text
O TDD orienta a programação através de testes: escrever um teste, implementar código que o satisfaça e depois refatorizar os testes e o código. O ATDD e o BDD também apoiam testes precoces, mas têm características distintivas diferentes.
```

### o1 — alternativa EN

Original

```text
Test-driven development (TDD)
```

Proposto atual — sem alteração

```text
Test-driven development (TDD)
```

### o1 — explicação EN

Original

```text
TDD directs coding through tests: write a test, implement code to satisfy it, then refactor tests and code. ATDD and BDD also support early testing, but have different defining characteristics.
```

Proposto atual — sem alteração

```text
TDD directs coding through tests: write a test, implement code to satisfy it, then refactor tests and code. ATDD and BDD also support early testing, but have different defining characteristics.
```

### o2 — alternativa PT

Original

```text
Desenvolvimento orientado para testes de aceitação (ATDD)
```

Proposto atual — sem alteração

```text
Desenvolvimento orientado para testes de aceitação (ATDD)
```

### o2 — explicação PT

Original

```text
O ATDD deriva testes de aceitação em colaboração a partir de critérios de aceitação antes da implementação. O ciclo teste-código-refatorização especificado identifica o TDD.
```

Proposto atual — sem alteração

```text
O ATDD deriva testes de aceitação em colaboração a partir de critérios de aceitação antes da implementação. O ciclo teste-código-refatorização especificado identifica o TDD.
```

### o2 — alternativa EN

Original

```text
Acceptance test-driven development (ATDD)
```

Proposto atual — sem alteração

```text
Acceptance test-driven development (ATDD)
```

### o2 — explicação EN

Original

```text
ATDD derives acceptance tests collaboratively from acceptance criteria before implementation. The specified test-code-refactor cycle identifies TDD.
```

Proposto atual — sem alteração

```text
ATDD derives acceptance tests collaboratively from acceptance criteria before implementation. The specified test-code-refactor cycle identifies TDD.
```

### o3 — alternativa PT

Original

```text
Desenvolvimento orientado para o comportamento (BDD)
```

Proposto atual — sem alteração

```text
Desenvolvimento orientado para o comportamento (BDD)
```

### o3 — explicação PT

Original

```text
O BDD expressa o comportamento pretendido em exemplos compreensíveis pelos stakeholders, frequentemente Dado/Quando/Então. Escrever testes primeiro é uma característica partilhada; o ciclo de teste de componente-código-refatorização é aqui a característica do TDD.
```

Proposto atual — sem alteração

```text
O BDD expressa o comportamento pretendido em exemplos compreensíveis pelos stakeholders, frequentemente Dado/Quando/Então. Escrever testes primeiro é uma característica partilhada; o ciclo de teste de componente-código-refatorização é aqui a característica do TDD.
```

### o3 — alternativa EN

Original

```text
Behavior-driven development (BDD)
```

Proposto atual — sem alteração

```text
Behavior-driven development (BDD)
```

### o3 — explicação EN

Original

```text
BDD expresses desired behavior in stakeholder-readable examples, often Given/When/Then. Writing tests first is shared; the component test-code-refactor cycle is the TDD characteristic here.
```

Proposto atual — sem alteração

```text
BDD expresses desired behavior in stakeholder-readable examples, often Given/When/Then. Writing tests first is shared; the component test-code-refactor cycle is the TDD characteristic here.
```

### o4 — alternativa PT

Original

```text
Integração contínua (CI)
```

Proposto atual — sem alteração

```text
Integração contínua (CI)
```

### o4 — explicação PT

Original

```text
A CI integra alterações com frequência e pode executar testes automatizados. Não define o ciclo de programação orientada por testes e refatorização descrito.
```

Proposto atual — sem alteração

```text
A CI integra alterações com frequência e pode executar testes automatizados. Não define o ciclo de programação orientada por testes e refatorização descrito.
```

### o4 — alternativa EN

Original

```text
Continuous integration (CI)
```

Proposto atual — sem alteração

```text
Continuous integration (CI)
```

### o4 — explicação EN

Original

```text
CI integrates changes frequently and can run automated tests. It does not define the test-first coding and refactoring cycle described.
```

Proposto atual — sem alteração

```text
CI integrates changes frequently and can run automated tests. It does not define the test-first coding and refactoring cycle described.
```

### Explicação geral PT

Original

```text
O TDD orienta a programação através de testes: escrever um teste, implementar código que o satisfaça e depois refatorizar os testes e o código. O ATDD e o BDD também apoiam testes precoces, mas têm características distintivas diferentes.
```

Proposto atual — sem alteração

```text
O TDD orienta a programação através de testes: escrever um teste, implementar código que o satisfaça e depois refatorizar os testes e o código. O ATDD e o BDD também apoiam testes precoces, mas têm características distintivas diferentes.
```

### Explicação geral EN

Original

```text
TDD directs coding through tests: write a test, implement code to satisfy it, then refactor tests and code. ATDD and BDD also support early testing, but have different defining characteristics.
```

Proposto atual — sem alteração

```text
TDD directs coding through tests: write a test, implement code to satisfy it, then refactor tests and code. ATDD and BDD also support early testing, but have different defining characteristics.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: testes primeiro, código para os satisfazer e refatorização reconhecem TDD.

A repeated component-test/code/refactor cycle recognises TDD; no actual refactoring implementation is requested.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta como melhor identificação: ATDD deriva testes de aceitação dos critérios, não o ciclo de componente especificado.

Acceptance-driven development derives tests from acceptance criteria, not the characteristic component-level cycle described. It can coexist with TDD.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta como melhor identificação: BDD foca comportamentos compreensíveis pelos stakeholders; pode coexistir, mas o ciclo descrito identifica TDD.

Behaviour-driven development expresses desired behaviour collaboratively, often in natural-language scenarios; the specific component-test cycle is better matched by TDD.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: CI integra/verifica alterações com frequência; executar testes num pipeline não é a definição do ciclo TDD.

Continuous integration integrates and verifies changes; it may run TDD tests but is not the described test-first coding cycle.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | c774707bdc18c7bcadfc629db1cb423e91a3fbcba9c0bb5e270308cb7e40ea47 |
| 2026-10-27.2 | True     | 2      | ['o1'] | 0e4ca87078aa0d7f7438565c76d36d61201f81c81deb343a245077804dda500a |
| 2026-10-27.3 | True     | 2      | ['o1'] | 0e4ca87078aa0d7f7438565c76d36d61201f81c81deb343a245077804dda500a |
| 2026-10-27.4 | True     | 2      | ['o1'] | 0e4ca87078aa0d7f7438565c76d36d61201f81c81deb343a245077804dda500a |
| 2026-10-27.5 | True     | 2      | ['o1'] | 0e4ca87078aa0d7f7438565c76d36d61201f81c81deb343a245077804dda500a |
| 2026-10-27.6 | True     | 2      | ['o1'] | 0e4ca87078aa0d7f7438565c76d36d61201f81c81deb343a245077804dda500a |
| 2026-10-27.7 | True     | 3      | ['o1'] | fb8e756c8ce786e34d7eda2dce5b6069220f646247bb339067e00b6359c48e7b |
| 2026-10-27.8 | True     | 3      | ['o1'] | fb8e756c8ce786e34d7eda2dce5b6069220f646247bb339067e00b6359c48e7b |
| 2026-10-27.9 | True     | 3      | ['o1'] | fb8e756c8ce786e34d7eda2dce5b6069220f646247bb339067e00b6359c48e7b |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


# tl-012 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.2.1 / K2; versão 3; revisão 2026-10-27.10; SHA-256 canónico `1a836bc3c8bfca0ab095e6e48d50a61b144f7105523bfb5612b008fc00510b44`.

Solução independente: `['o1']`, registada em `2026-11-06T16:05:50.466510+00:00` antes da consulta da chave/explicações. Chave publicada: `['o1']`. Uma coincidência de chave não é prova académica; análise e contraevidências seguem abaixo.

## Resolução e fundamento

A fronteira e o foco explícitos são interação entre dois módulos da mesma aplicação: integração de componentes. Testar o sistema completo pode atravessar a interface, mas não muda o melhor nível para um teste cujo alvo é essa interface. Integração de sistemas envolve outras aplicações/sistemas/serviços externos.

Independent reasoning (recorded before the key):

O foco são interações na interface de dois componentes dentro da mesma aplicação: integração de componentes. Não são sistemas externos nem componentes isolados nem validação de aceitação.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Capa conta como página física 1; não se assume deslocamento uniforme. URLs e hashes em sources.json.

- Secção 2.2.1: EN páginas [28, 29]; PT páginas [31, 32].

- LO FL-2.2.1/K2: EN página 24; PT página 26.

EN enumera níveis na p.29 após introdução na 28; PT enumera na 31 e continua atributos na 32. System testing aborda o sistema global, não é sinónimo de integração interna. O domínio fiscal/faturação não exige conhecer taxas nem legislação.

O conceito aplicado ao item é interpretação do revisor fundada nas secções citadas; não é uma regra adicional inventada. Os PDFs foram consultados localmente; EN acessível via web, fetch PT falhou. Não se alega novo download PT. Nenhuma qualificação humana é atribuída à IA.

## Equivalência PT/EN e ambiguidade

Focuses/centra-se, interface/interface e within one application/da mesma aplicação mantêm a fronteira. Fits best/mais adequado pede o melhor enquadramento, não a afirmação de que apenas um nível pode executar esse percurso. In isolation/isolado contrasta explicitamente com interação entre módulos.

| EN literal             | PT literal         |
| ---------------------- | ------------------ |
| within one application | da mesma aplicação |
| fits best              | mais adequado      |
| in isolation           | isolado            |

## Contraevidência e segunda resposta plausível

Arquiteturas distribuídas podem chamar módulos a serviços independentes; a pergunta especifica componentes dentro de uma aplicação e não dá evidência de sistemas externos. Um teste de aceitação pode percorrer o cálculo e a faturação, mas o objetivo descrito é a interface interna, não validação de negócio/prontidão. O termo module não é por si uma regra universal de nível.

## Qualidade pedagógica e dificuldade

K2: distinguir níveis a partir do âmbito/objetivo de um cenário curto. A explicação geral é breve mas correta e os distratores preservam os limites. Não confundir nível com tipo funcional ou com estrutura organizacional da equipa; uma equipa independente pode executar vários níveis.

## Comparação literal integral: original / proposto atual

Não há alteração aplicada. O proposto atual é igual ao original; uma eventual candidatura editorial é separada.

### Enunciado PT

Original

```text
Um teste centra-se na interface entre um módulo fiscal e um módulo de faturação da mesma aplicação. Qual é o nível mais adequado?
```

Proposto atual — sem alteração

```text
Um teste centra-se na interface entre um módulo fiscal e um módulo de faturação da mesma aplicação. Qual é o nível mais adequado?
```

### Enunciado EN

Original

```text
A test focuses on the interface between a tax module and an invoice module within one application. Which level fits best?
```

Proposto atual — sem alteração

```text
A test focuses on the interface between a tax module and an invoice module within one application. Which level fits best?
```

### o1 — alternativa PT

Original

```text
Teste de integração de componentes
```

Proposto atual — sem alteração

```text
Teste de integração de componentes
```

### o1 — explicação PT

Original

```text
O âmbito é a interação entre componentes internos.
```

Proposto atual — sem alteração

```text
O âmbito é a interação entre componentes internos.
```

### o1 — alternativa EN

Original

```text
Component integration testing
```

Proposto atual — sem alteração

```text
Component integration testing
```

### o1 — explicação EN

Original

```text
The scope is interaction between internal components.
```

Proposto atual — sem alteração

```text
The scope is interaction between internal components.
```

### o2 — alternativa PT

Original

```text
Teste de aceitação
```

Proposto atual — sem alteração

```text
Teste de aceitação
```

### o2 — explicação PT

Original

```text
A aceitação centra-se nas necessidades de negócio e na prontidão.
```

Proposto atual — sem alteração

```text
A aceitação centra-se nas necessidades de negócio e na prontidão.
```

### o2 — alternativa EN

Original

```text
Acceptance testing
```

Proposto atual — sem alteração

```text
Acceptance testing
```

### o2 — explicação EN

Original

```text
Acceptance focuses on business needs and readiness.
```

Proposto atual — sem alteração

```text
Acceptance focuses on business needs and readiness.
```

### o3 — alternativa PT

Original

```text
Teste de integração de sistemas com sistemas externos
```

Proposto atual — sem alteração

```text
Teste de integração de sistemas com sistemas externos
```

### o3 — explicação PT

Original

```text
O âmbito descrito não inclui um sistema externo.
```

Proposto atual — sem alteração

```text
O âmbito descrito não inclui um sistema externo.
```

### o3 — alternativa EN

Original

```text
System integration with external systems
```

Proposto atual — sem alteração

```text
System integration with external systems
```

### o3 — explicação EN

Original

```text
No external system is in the stated scope.
```

Proposto atual — sem alteração

```text
No external system is in the stated scope.
```

### o4 — alternativa PT

Original

```text
Teste de componente isolado
```

Proposto atual — sem alteração

```text
Teste de componente isolado
```

### o4 — explicação PT

Original

```text
Um teste de componente isolado centra-se num módulo individual. O âmbito indicado é a interface e a interação entre dois módulos internos.
```

Proposto atual — sem alteração

```text
Um teste de componente isolado centra-se num módulo individual. O âmbito indicado é a interface e a interação entre dois módulos internos.
```

### o4 — alternativa EN

Original

```text
Component testing in isolation
```

Proposto atual — sem alteração

```text
Component testing in isolation
```

### o4 — explicação EN

Original

```text
An isolated component test focuses on an individual module. The stated scope is the interface and interaction between two internal modules.
```

Proposto atual — sem alteração

```text
An isolated component test focuses on an individual module. The stated scope is the interface and interaction between two internal modules.
```

### Explicação geral PT

Original

```text
O âmbito é a interação entre componentes internos.
```

Proposto atual — sem alteração

```text
O âmbito é a interação entre componentes internos.
```

### Explicação geral EN

Original

```text
The scope is interaction between internal components.
```

Proposto atual — sem alteração

```text
The scope is interaction between internal components.
```

## Avaliação individual das quatro alternativas

### o1 — correta

Correta: interface e interação entre componentes internos são integração de componentes.

Testing the interface between internal modules targets component integration. System-level tests might traverse the interface, but the stated focus determines best fit.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o2 — distrator

Incorreta como melhor nível: aceitação visa necessidades de negócio e prontidão; isso não é o foco declarado.

Acceptance targets readiness and business/user needs, not primarily internal component interfaces.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o3 — distrator

Incorreta: nenhuma interação com sistemas ou serviços externos está no âmbito indicado.

The scenario explicitly confines both modules to one application, rather than interactions with external systems/services.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

### o4 — distrator

Incorreta: testar um módulo isolado não cobre o alvo explícito de interação entre os dois.

Isolation omits the actual interaction under test. Testing either module alone is a different focus.

Explicação coerente com a alternativa no cenário; a análise individual e os contraexemplos do relatório delimitam a sua leitura. Não se pressupõe garantia universal nem exclusividade de funções.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | Hash canónico                                                    |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | True     | 1      | ['o1'] | 73e75787fb8740e544a875bfc4e95cfc612e04fd6577aef0bfaf7e96ff4cb7b5 |
| 2026-10-27.2 | True     | 2      | ['o1'] | 60cf24c5d40171aaad342128b72836d7cb43e2dab96e54e46ebfba7ccbcc9f25 |
| 2026-10-27.3 | True     | 2      | ['o1'] | 60cf24c5d40171aaad342128b72836d7cb43e2dab96e54e46ebfba7ccbcc9f25 |
| 2026-10-27.4 | True     | 2      | ['o1'] | 60cf24c5d40171aaad342128b72836d7cb43e2dab96e54e46ebfba7ccbcc9f25 |
| 2026-10-27.5 | True     | 2      | ['o1'] | 60cf24c5d40171aaad342128b72836d7cb43e2dab96e54e46ebfba7ccbcc9f25 |
| 2026-10-27.6 | True     | 2      | ['o1'] | 60cf24c5d40171aaad342128b72836d7cb43e2dab96e54e46ebfba7ccbcc9f25 |
| 2026-10-27.7 | True     | 3      | ['o1'] | 1a836bc3c8bfca0ab095e6e48d50a61b144f7105523bfb5612b008fc00510b44 |
| 2026-10-27.8 | True     | 3      | ['o1'] | 1a836bc3c8bfca0ab095e6e48d50a61b144f7105523bfb5612b008fc00510b44 |
| 2026-10-27.9 | True     | 3      | ['o1'] | 1a836bc3c8bfca0ab095e6e48d50a61b144f7105523bfb5612b008fc00510b44 |

Históricos preservados sem substituir enunciados antigos. Diferenças históricas são evidência da evolução, não alterações deste lote.

## Problemas e propostas

Nenhum defeito académico obrigatório confirmado. Sem dúvida obrigatória por resolver; os riscos de interpretação e limitações de dificuldade acima não são aprovação humana.

Sem proposta de alteração apenas para justificar trabalho. Explicações breves mas corretas não foram automaticamente tratadas como defeito.

## Aprovações e limites

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído. Revisão humana independente PENDING. NONE na triagem anterior não é evidência de correção. Fase 10H aberta; parar após Lote 11 e aguardar auditoria; não iniciar Lote 12.


