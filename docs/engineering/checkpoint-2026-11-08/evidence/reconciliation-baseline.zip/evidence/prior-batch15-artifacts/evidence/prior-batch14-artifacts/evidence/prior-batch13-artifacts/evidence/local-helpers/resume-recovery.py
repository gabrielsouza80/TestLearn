from pathlib import Path
import json, hashlib, subprocess, sys, datetime, re, difflib

out=Path(__file__).parent
root=Path('C:/TestLearn/tmp/develop-workspace')
folder=root/'docs/academic/phase10h-batch13-2026-11-06'
rec=out/'recovery-evidence'
rec.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
pre=read(out/'preflight.json')
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
assert git('branch','--show-current').strip()=='develop' and git('rev-parse','HEAD').strip()==pre['head']
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
existing={p.relative_to(root).as_posix():sha(p.read_bytes()) for p in folder.rglob('*') if p.is_file()}
assert len(existing)==19
snapshot={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':'develop','head':pre['head'],'beforeBatchFilesSHA256':pre['existingFilesSHA256'],'batch13FilesSHA256':existing,'auxFilesSHA256':{p.name:sha(p.read_bytes()) for p in out.iterdir() if p.is_file()},'fullGitStatus':git('status','--untracked-files=all')}
(rec/'resume-snapshot.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
original=rec/'original';original.mkdir()
for name in ['BATCH13-RULES.py','GLOBAL13-RULES.py','batch13-specific-FAILURE.log','integrity-execution.json','integrity-result.json','targeted-vitest-result.json','targeted-vitest.log','multiple-answer-scoring-result.json','multiple-answer-scoring.log']:
    (original/name).write_bytes((out/name).read_bytes())
for name in ['STOP-FAILURE.json','verification.md','README.md']:(original/name).write_bytes((folder/name).read_bytes())
target=folder/'reports/tl-049.md';before=target.read_bytes();(original/'tl-049.md').write_bytes(before)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
cmd=[sys.executable,str(out/'verify.py'),'batch13-specific']
red=subprocess.run(cmd,cwd=root,capture_output=True,text=True,encoding='utf8')
(rec/'red.log').write_text(red.stdout+red.stderr,encoding='utf8')
(rec/'red-result.json').write_text(json.dumps({'command':cmd,'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':red.returncode},indent=2)+'\n')
assert red.returncode!=0 and 'BATCH13-RULES.py' in red.stderr and 'AssertionError' in red.stderr
raw=before.decode('utf8')
pattern=r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])'
prose=re.sub(r'```[\s\S]*?```','',raw)
matches=[{'match':m.group(),'context':prose[m.start()-70:m.end()+70]} for m in re.finditer(pattern,prose)]
assert len(matches)==1 and matches[0]['match']=='ão1'
# Exactly two verified tokens in the references paragraph; preserve all other bytes.
assert raw.count('continua na20;')==raw.count('secção1.4.2 na p.21.')==1
new=raw.replace('continua na20;','continua na 20;').replace('secção1.4.2 na p.21.','secção 1.4.2 na p.21.')
assert len(new)==len(raw)+2
target.write_bytes(new.encode('utf8'))
assert not re.search(pattern,re.sub(r'```[\s\S]*?```','',new))
assert re.search(pattern,re.sub(r'```[\s\S]*?```','',raw))
assert re.search(pattern,re.sub(r'```[\s\S]*?```','',new.replace('secção 1.4.2','secção1.4.2')))
# Literal published text blocks and pre-key records remain frozen.
assert re.findall(r'```text\n([\s\S]*?)\n```',raw)==re.findall(r'```text\n([\s\S]*?)\n```',new)
for n,h in existing.items():assert sha((root/n).read_bytes())==(sha(target.read_bytes()) if root/n==target else h),n
for name in ['BATCH13-RULES.py','GLOBAL13-RULES.py']:assert sha((out/name).read_bytes())==snapshot['auxFilesSHA256'][name]
diff=''.join(difflib.unified_diff(raw.splitlines(True),new.splitlines(True),fromfile='original/tl-049.md',tofile='corrected/tl-049.md'))
(rec/'report-only.diff').write_text(diff,encoding='utf8')
result={'result':'PASS','cause':'A: document spacing error; regex also broadly matches ão1, but the matched original really lacks spacing. No guard modification is needed.','originalMatches':matches,'originalSHA256':sha(before),'correctedSHA256':sha(target.read_bytes()),'changes':[{'before':'continua na20;','after':'continua na 20;','meaning':'continues on physical page 20; number unchanged'},{'before':'secção1.4.2 na p.21.','after':'secção 1.4.2 na p.21.','meaning':'PT section 1.4.2 on physical page 21; numbers unchanged'}],'insertedSpaces':2,'otherInitialBatch13FilesByteIdentical':18,'originalStillMatches':True,'correctedNoMatches':True,'syntheticSpaceRemovalDetected':True,'guardsUnchanged':True,'publishedTextBlocksUnchanged':True,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(rec/'spacing-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
