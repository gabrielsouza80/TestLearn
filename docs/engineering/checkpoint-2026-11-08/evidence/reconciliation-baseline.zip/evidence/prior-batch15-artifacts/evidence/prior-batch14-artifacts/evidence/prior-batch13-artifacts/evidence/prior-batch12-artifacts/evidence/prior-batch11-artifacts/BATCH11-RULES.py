"""Read-only consistency/identity checks. Not automated semantic or human approval."""
import copy,hashlib,json,re,datetime
IDS=['tl-002','tl-003','tl-004','tl-005','tl-007','tl-009','tl-010','tl-012']
EXPECTED={
'tl-002':('FL-1.2.2','K1',3,'0ff7fa41b7295ee5f5dc3087d11cfd116dc8e74da4f112af81121f9ae601b1df'),
'tl-003':('FL-1.1.2','K2',4,'f2ab547f90da78a02814524f214fa362d4d799927e59f97a582b04e7529535e0'),
'tl-004':('FL-1.2.3','K2',2,'98cc0a0128b61d289938f3eadca49415717757d5adf7aafcdc0f11a08921ee0e'),
'tl-005':('FL-1.3.1','K2',2,'1b88f7e791e80867a1296e28ce78fd90695c9f28328b9ccc74874b890dd49a35'),
'tl-007':('FL-1.4.4','K2',2,'c0726c854ee926a619ced00e9776122368407abf3449771a1901b51b9b5e065a'),
'tl-009':('FL-2.1.2','K1',2,'ba36aeccb6125f2e08b34421709cc01f8f2a10421984874df19899b6a4c9382c'),
'tl-010':('FL-2.1.3','K1',3,'fb8e756c8ce786e34d7eda2dce5b6069220f646247bb339067e00b6359c48e7b'),
'tl-012':('FL-2.2.1','K2',3,'1a836bc3c8bfca0ab095e6e48d50a61b144f7105523bfb5612b008fc00510b44')}
REFS={'tl-002':{'1.2.2':{'EN':[17],'PT':[18]}},'tl-003':{'1.1.2':{'EN':[16],'PT':[17]},'2.2.3':{'EN':[30],'PT':[33]}},'tl-004':{'1.2.3':{'EN':[17],'PT':[18,19]}},'tl-005':{'1.3':{'EN':[17,18],'PT':[19]},'2.2.3':{'EN':[30],'PT':[33]}},'tl-007':{'1.4.4':{'EN':[20,21],'PT':[22,23]}},'tl-009':{'2.1.2':{'EN':[25,26],'PT':[27,28]}},'tl-010':{'2.1.3':{'EN':[26],'PT':[28]}},'tl-012':{'2.2.1':{'EN':[28,29],'PT':[31,32]}}}
def canonical(q):return hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(bank,matrix,comparisons,blind,projections,alternatives,sources,optional,reports,archives):
 assert matrix['scope']=='Phase 10H Batch 11 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert [d['questionId'] for d in matrix['decisions']]==IDS and len(comparisons)==len(projections)==len(blind['solutions'])==8
 assert len(alternatives)==len({(a['questionId'],a['optionId']) for a in alternatives})==32 and set(reports)==set(IDS)
 assert blind['reviewerType']=='AI' and not blind['publishedKeysConsultedBeforeRecording'] and not blind['publishedExplanationsConsultedBeforeRecording'] and not blind['ownerAccepted'] and not blind['humanApproved']
 assert set(archives)=={f'2026-10-27.{i}' for i in range(1,10)}
 assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64
 for s in sources['sources']:
  assert s['sha256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 checks=[]
 for d,c,projection,s in zip(matrix['decisions'],comparisons,projections,blind['solutions']):
  ident=d['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],canonical(q))==(lo,k,v,h) and q['correct']==['o1'] and q['required']==1
  assert d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None and d['unresolvedMandatoryIssues']==[]
  assert d['existingKey']==d['proposedKey']==d['independentAnswer']==s['answer']==['o1'] and s['questionId']==ident and d['keyComparison']=='MATCH'
  assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged'] and not d['priorNONEUsedAsEvidence']
  assert (d['learningObjective'],d['cognitiveLevel'],d['questionVersion'],d['requiredAnswers'])==(lo,k,v,1)
  assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==h and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
  assert c=={'questionId':ident,'original':q,'proposed':q,'changed':False}
  assert set(projection)=={'id','lo','level','text','options'} and projection['id']==ident and projection['text']==q['text'] and (projection['lo'],projection['level'])==(lo,k)
  assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  assert s['shuffledOrder']==[o['id'] for o in projection['options']] and len(s['reasonPT'])>100 and set(s['optionAssessmentsEN'])=={'o1','o2','o3','o4'}
  assert datetime.datetime.fromisoformat(s['recordedAt']).tzinfo
  for field in ['assessmentPT','counterEvidencePT','translationAssessmentPT','pedagogyAssessmentPT','editionDifferencePT']:assert len(d[field])>100
  assert d['references']==REFS[ident] and d['LOPages']==({'EN':[14],'PT':[15]} if q['chapter']==1 else {'EN':[24],'PT':[26]})
  for refs in d['references'].values():
   for lang,pages in refs.items():assert set(pages)<=set(next(x['pagesConsulted'] for x in sources['sources'] if x['language']==lang))
  for a in [a for a in alternatives if a['questionId']==ident]:
   o=next(o for o in q['options'] if o['id']==a['optionId']);assert a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsAnswer']==(o['id']=='o1')
   assert len(a['reviewPT'])>50 and a['reviewEN']==s['optionAssessmentsEN'][o['id']] and len(a['reviewEN'])>50 and a['references']==REFS[ident]
  assert len([a for a in alternatives if a['questionId']==ident])==4
  for pair in d['criticalPairs']:assert pair['en'] in json.dumps(q,ensure_ascii=False) and pair['pt'] in json.dumps(q,ensure_ascii=False)
  assert len(d['history'])==9
  for entry in d['history']:
   a=next((a for a in archives[entry['contentRevision']] if a['id']==ident),None);assert entry['present']==(a is not None)
   if a is not None:assert (entry['version'],entry['key'],entry['canonicalSHA256'],entry['equalCurrent'])==(a['version'],a['correct'],canonical(a),a==q)
  blocks=[]
  for lang in ['pt','en']:blocks.extend([q['text'][lang]]*2)
  for o in q['options']:
   for lang in ['pt','en']:
    for field in ['text','explanation']:blocks.extend([o[field][lang]]*2)
  for lang in ['pt','en']:blocks.extend([q['explanation'][lang]]*2)
  actualBlocks=40
  if ident=='tl-005':
   assert len(optional)==1;o=optional[0];assert o['questionId']==ident and o['kind']=='OPTIONAL_EDITORIAL_NOT_CONFIRMED_DEFECT' and o['applied'] is False and o['requiresExplicitOwnerAuthorization']
   assert o['path']==['options','o4','explanation'] and o['original']==q and o['currentText']==q['options'][3]['explanation'] and o['keyImpact']=='NONE'
   candidate=copy.deepcopy(q);candidate['options'][3]['explanation']=o['suggestedText'];assert candidate==o['candidate'] and candidate!=q and canonical(candidate)==o['candidateCanonicalSHA256']
   for lang in ['pt','en']:blocks.extend([o['currentText'][lang],o['suggestedText'][lang]])
  assert re.findall(r'```text\n([\s\S]*?)\n```',reports[ident])==blocks
  prose=re.sub(r'```[\s\S]*?```','',reports[ident]);assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
  assert 'não aprovação humana' in prose and str(s['recordedAt']) in prose
  checks.append({'questionId':ident,'canonicalSHA256':h,'independentKey':['o1'],'publishedKey':['o1'],'alternativesVerified':4,'actualComparisonBlocks':actualBlocks,'optionalComparisonBlocks':len(blocks)-40,'priorNONEUsedAsEvidence':False})
 q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
 return {'result':'PASS','questions':checks,'reviewedQuestions':8,'reviewedAlternatives':32,'actualComparisonBlocks':320,'optionalComparisonBlocks':4,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args):
 check(*args)
 cases=[('wrong key',1,lambda a:a['decisions'][0].update(existingKey=['o2'])),('second answer accepted',5,lambda a:a[1].update(supportsAnswer=True)),('missing option assessment',5,lambda a:a.pop()),('PT text incompatible with source',5,lambda a:a[0]['text'].update(pt='adulterado')),('missing reasoning',3,lambda a:a['solutions'][0].update(reasonPT='')),('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank')),('false human approval',1,lambda a:a['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda a:a['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('invalid source pages',1,lambda a:a['decisions'][0]['references']['1.2.2'].update(EN=[999])),('corrupted historical question',9,lambda a:a['2026-10-27.9'][1]['explanation'].update(pt='adulterado')),('NONE reused as approval',1,lambda a:a['decisions'][0].update(priorNONEUsedAsEvidence=True)),('key leaked into blind projection',4,lambda a:a[0].update(correct=['o1'])),('optional candidate applied',7,lambda a:a[0].update(applied=True)),('missing counterevidence',1,lambda a:a['decisions'][1].update(counterEvidencePT=''))]
 rejected=[]
 for name,i,mutate in cases:
  a=copy.deepcopy(list(args));mutate(a[i])
  try:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'claimLimit':'Rejects structural, literal and recorded-evidence corruption, not arbitrary semantic errors.'}
