from pathlib import Path
import json,hashlib,subprocess,datetime,re,ast
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');f=root/'docs/academic/phase10h-batch15-2026-11-07'
read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
pre=read(p/'preflight.json')
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
for n in ['blind-projection.json','blind-solutions.json']:assert (f/n).read_bytes()==(p/n).read_bytes()
files=[q for q in f.rglob('*') if q.is_file()];assert len(files)==18
for q in files:
    t=q.read_text(encoding='utf8');assert t.endswith('\n') and '\x00' not in t
    if q.suffix=='.json':json.loads(t)
    assert not any(line.rstrip()!=line for line in t.splitlines()),str(q)
    if q.parent.name=='reports':
        prose=re.sub(r'```[\s\S]*?```','',t)
        assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose),q.name
        assert not re.search(r'\b(?:secção|página|páginas|na|em)(?=\d)',prose,flags=re.I),q.name
for n in ['VERIFY-PACKAGE.py','export.py','BATCH15-RULES.py','GLOBAL15-RULES.py']:ast.parse((p/n).read_text())
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
assert git('branch','--show-current').strip()=='develop' and git('rev-parse','HEAD').strip()==pre['head']
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
assert all(read(p/(n+'-result.json'))['exitCode']==0 for n in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check'])
result={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'existingFilesPreserved':391,'priorAcademicDocumentsPreserved':188,'newDocuments':18,'frozenBlindRecordsByteIdentical':True,'JSONValidated':True,'reportsSpacingChecked':8,'helperSyntaxInspected':True,'newOwnerAccepted':0,'newHumanApproved':0,'inventoryScope':'All Git-tracked and nonignored untracked project files; excludes ignored dependencies/private files, never exported.'}
(p/'final-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
