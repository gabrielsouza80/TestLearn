from pathlib import Path
import json,hashlib,sys,re,datetime
out=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
assert (out/'blind-solution.json').is_file()
q=next(q for q in read(out/'runtime-before.json')['bank'] if q['id']=='tl-062');print('FULL QUESTION AFTER BLIND RECORD\n'+json.dumps(q,ensure_ascii=False,indent=2))
matrix=read(root/'docs/academic/phase10h-2026-11-04/review-matrix.json');print('MATRIX TYPE',type(matrix).__name__)
if isinstance(matrix,list):print(json.dumps([r for r in matrix if r.get('questionId',r.get('id'))=='tl-062'],ensure_ascii=False,indent=2))
else:
 for key,value in matrix.items():
  if isinstance(value,list):print(key,json.dumps([r for r in value if isinstance(r,dict) and r.get('questionId',r.get('id'))=='tl-062'],ensure_ascii=False,indent=2))
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
base=Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0');records=[]
for lang,name,selected in [('EN','ISTQB_CTFL_Syllabus_v4.0.1.pdf',[47,48,49,23]),('PT','ISTQB_CTFL_Syllabus-v4.0-PT_v1.0 (1).pdf',[52,53,54,25,26])]:
 b=(base/name).read_bytes();doc=pymupdf.open(stream=b,filetype='pdf');texts=[p.get_text() for p in doc]
 found=[i+1 for i,t in enumerate(texts) if '5.1.2.' in t and i>13]
 print(lang,'5.1.2 occurrences',found)
 pages=sorted(set(selected)|set(found));records.append({'language':lang,'fileName':name,'localPath':str(base/name),'sha256':hashlib.sha256(b).hexdigest(),'pageCount':len(doc),'pages':[{'physicalPage':n,'text':texts[n-1]} for n in pages]})
 for n in pages:print('\n'+lang+' PHYSICAL PAGE '+str(n)+'\n'+texts[n-1])
(out/'source-pages.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'key-reveal.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'afterBlindRecordedAt':read(out/'blind-solution.json')['recordedAt'],'key':q['correct'],'match':q['correct']==read(out/'blind-solution.json')['answer']},indent=2)+'\n')
