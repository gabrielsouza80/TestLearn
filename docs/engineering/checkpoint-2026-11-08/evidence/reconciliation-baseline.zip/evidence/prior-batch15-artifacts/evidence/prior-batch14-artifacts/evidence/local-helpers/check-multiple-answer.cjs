// Read-only current-runtime check of tl-001 exact-set scoring, synthetic selections only.
const fs=require('node:fs'),root=process.argv[2],local=require('node:module').createRequire(root+'/package.json'),ts=local('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,esModuleInterop:true,target:ts.ScriptTarget.ES2022}}).outputText,f);
const q=local('./src/data/questions.ts').questions.find(q=>q.id==='tl-001'),{isCorrect}=local('./src/domain/engine.ts');
const cases=[{selection:[],expected:false},{selection:['o1'],expected:false},{selection:['o4'],expected:false},{selection:['o1','o4'],expected:true},{selection:['o4','o1'],expected:true},{selection:['o1','o4','o2'],expected:false},{selection:['o2','o3'],expected:false},{selection:['o1','o1','o4'],expected:false}];
for(const c of cases){c.actual=isCorrect(q,c.selection);if(c.actual!==c.expected)throw new Error('Exact-set scoring mismatch: '+JSON.stringify(c));}
process.stdout.write(JSON.stringify({result:'PASS',questionId:q.id,required:q.required,publishedKey:q.correct,syntheticSelections:cases,storageAccessed:false},null,2));
