"""Batch8 read-only evidence checks; does not prove semantic or academic truth.
Blind AI solutions are validated as prior evidence, not inferred by these checks.
"""
import hashlib,json,copy
IDS=['tl-001','tl-006','tl-013','tl-014','tl-015','tl-017','tl-019','tl-023']
EXPECTED={
'tl-001':('FL-1.1.1','K1',2,['o1','o4'],'15d923673172ffada0dbf7c1d3fed68d8ae56934ebf09586cb60331edc7c966f'),
'tl-006':('FL-1.4.1','K2',3,['o1'],'ba0d87c420b44384709fe07abefcf680bd7dbbc5f2daafd0c66bc78c2c76ad7c'),
'tl-013':('FL-2.1.5','K2',2,['o1'],'753f11a392722ef65a94fdecba5d1f345ce0495709007a7ef0cdb20986d0d900'),
'tl-014':('FL-2.3.1','K2',2,['o1'],'097b7b185935afe35bf1aa220c8be6d3ed7a121165a5b9136c2b5d44d15cca27'),
'tl-015':('FL-3.1.1','K1',2,['o1'],'3230a0db86ddcdf03432fd2813f478eb2b7827bc60876819ede181b22402649b'),
'tl-017':('FL-3.1.3','K2',2,['o1'],'d6970fd1e3c435ea6b01ceb5e26bcd68779b3490e3ce9c57592d1477164fe2f6'),
'tl-019':('FL-4.1.1','K2',2,['o1'],'87318d66d89b5640ca9aa15567d2d5d9520c80012c9117f22ff44eff058be100'),
'tl-023':('FL-4.4.2','K2',4,['o1'],'3267bc5ef044af2ec3f37e73b285884f97f3b851c44931c4edea46a0b84849d8')}
canonical=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
alltext=lambda q,l:'\n'.join([q['text'][l],q['explanation'][l],*[o[f][l] for o in q['options'] for f in ['text','explanation']]])
def check(bank,matrix,comparisons,blind,projection,sources,optionalAll):
 assert matrix['scope']=='Phase 10H Batch 8 only' and matrix['humanApprovedCount']==matrix['ownerAcceptedCount']==matrix['contentChanges']==0
 assert [r['questionId'] for r in matrix['decisions']]==IDS and len(comparisons)==len(blind['solutions'])==len(projection)==8 and len(optionalAll)==7
 result=[]
 for row,c,p in zip(matrix['decisions'],comparisons,projection):
  ident=row['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,key,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],q['correct'],canonical(q))==(lo,k,v,key,h)
  assert row['learningObjective']==lo and row['cognitiveLevel']==k and row['questionVersion']==v
  assert row['decision']=='ACCEPT_AS_IS' and row['ownerDecision'] is None and row['humanApproval']==q['humanApproval']=='PENDING'
  assert row['confirmedProblems']==[] and row['contentChanged'] is False and row['priorLOWLabelNotUsedAsDecision'] is True
  assert row['requiredAnswers']==q['required']==len(key) and row['existingKey']==row['proposedKey']==row['independentSolution']['answer']==key
  assert row['independentSolution']==next(s for s in blind['solutions'] if s['questionId']==ident)
  assert row['beforeCanonicalSHA256']==row['afterCanonicalSHA256']==h and row['contentRevisionBefore']==row['contentRevisionAfter']=='2026-10-27.10'
  assert c['questionId']==ident and c['original']==c['proposed']==q and c['changed'] is False
  assert p['id']==ident and p['text']==q['text'] and p['lo']==lo and p['level']==k and not set(p)&{'correct','explanation'}
  assert p['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  a=row['analysis'];assert set(a['options'])=={o['id'] for o in q['options']} and len(a['options'])==4
  assert [o for o,d in a['options'].items() if d['supportsAnswer']]==key
  for d in a['options'].values():assert isinstance(d['supportsAnswer'],bool) and d['concept'] and all(len(d[l])>20 for l in ['pt','en'])
  for f in ['reason','translation','contrary','teaching','risks']:assert all(len(a[f][l])>40 for l in ['pt','en'])
  for en,pt,status in a['criticalPairs']:assert en in alltext(q,'en') and pt in alltext(q,'pt') and status
  for refs in [row['references'],*row['references']['supporting']]:
   for lang in ['EN','PT']:assert set(refs[lang])<=set(next(s for s in sources['sources'] if s['language']==lang)['pagesConsulted'])
  optional=row['optionalEditorialCandidate']
  if ident=='tl-001':
   assert optional is None and q['type']=='multiple' and 'TWO' in q['text']['en'] and 'DOIS' in q['text']['pt'] and len(key)==2
  else:
   assert optional==next(o for o in optionalAll if o['questionId']==ident) and optional['applied'] is False and optional['requiresExplicitOwnerAuthorization'] is True
   assert optional['kind']=='OPTIONAL_EDITORIAL_NOT_CONFIRMED_DEFECT' and optional['original']==q and optional['originalCanonicalSHA256']==h
   assert optional['answerKeyImpact']==optional['ID_LO_K_optionIdentityImpact']=='NONE' and optional['futureVersionIfAuthorized']==v+1
   assert len(optional['testsIfAuthorized'])==4 and optional['candidateCanonicalSHA256']==canonical(optional['candidate'])
   expected=copy.deepcopy(q);path=optional['path']
   assert path==(['options','o2','text'] if ident=='tl-015' else ['explanation'])
   target=expected['explanation'] if path[0]=='explanation' else next(o for o in expected['options'] if o['id']=='o2')['text']
   assert optional['originalText']==target and set(optional['candidateText'])=={'pt','en'} and all(optional['candidateText'][l]!=target[l] for l in ['pt','en'])
   target.update(optional['candidateText']);assert expected==optional['candidate'] and expected!=q
  result.append({'questionId':ident,'LO':lo,'K':k,'version':v,'canonicalSHA256':h,'independentKey':key,'storedKeyMatchesBlind':True,'requiredAnswers':len(key),'alternativesReviewed':4,'criticalPairsAnchored':len(a['criticalPairs']),'optionalCandidate':optional is not None,'semanticTruthAutomaticallyProven':False})
 return {'result':'PASS','scope':'Batch8 identity, cardinality, review completeness, critical term anchors, counterevidence, optional-only deltas and approval boundaries','questions':result,'newOwnerAcceptances':0,'newHumanApprovals':0}
def negative_checks(bank,matrix,comparisons,blind,projection,sources,optionalAll):
 check(bank,matrix,comparisons,blind,projection,sources,optionalAll)
 mutations=[
 ('partial multi-answer key',lambda d:d['decisions'][0].update(proposedKey=['o1'])),
 ('wrong cardinality',lambda d:d['decisions'][0].update(requiredAnswers=1)),
 ('invented human approval',lambda d:d['decisions'][0].update(humanApproval='HUMAN_APPROVED')),
 ('invented owner acceptance',lambda d:d['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),
 ('unreviewed distractor',lambda d:d['decisions'][1]['analysis']['options'].pop('o4')),
 ('extra supported answer',lambda d:d['decisions'][1]['analysis']['options']['o4'].update(supportsAnswer=True)),
 ('missing contrary evidence',lambda d:d['decisions'][1]['analysis']['contrary'].update(pt='')),
 ('unauthorized optional application',lambda d:d['decisions'][1]['optionalEditorialCandidate'].update(applied=True)),
 ('invented source page',lambda d:d['decisions'][1]['references'].update(EN=[999])),
 ('LOW reused as decision',lambda d:d['decisions'][1].update(priorLOWLabelNotUsedAsDecision=False)),
 ('modality anchor invented',lambda d:d['decisions'][3]['analysis']['criticalPairs'][1].__setitem__(0,'will certainly affect'))]
 rejected=[]
 for name,mutate in mutations:
  d=copy.deepcopy(matrix);mutate(d)
  try:check(bank,d,comparisons,blind,projection,sources,optionalAll)
  except AssertionError:rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 p=copy.deepcopy(projection);p[0]['correct']=['o1','o4']
 try:check(bank,matrix,comparisons,blind,p,sources,optionalAll)
 except AssertionError:rejected.append('key leaked into blind projection')
 else:raise AssertionError('Blind leakage accepted')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'semanticTruthAutomaticallyProven':False}
