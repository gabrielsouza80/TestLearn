from pathlib import Path
import json,hashlib,subprocess,sys,runpy,datetime
out=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch7-2026-11-06'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
pre=read(out/'preflight.json');baseline=read(out/'runtime-before.json')
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
newfiles=lambda:[n for n in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if n.startswith(folder+'/')]
def specific():
 rules=runpy.run_path(str(out/'batch7-rules.py'));args=[baseline['bank'],read(root/folder/'decision-matrix.json'),read(root/folder/'exact-comparisons.json'),read(root/folder/'blind-solutions.json'),read(root/folder/'blind-projection.json'),read(root/folder/'sources.json')]
 result=rules['check'](*args);negative=rules['negative_checks'](*args)
 result.update({'command':['python',str(out/'verify.py'),'batch7-specific'],'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'negativeChecks':negative,'claimLimit':'Evidence consistency and anchored critical terms, not automated proof of academic or linguistic truth.'})
 (out/'batch7-specific-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
def integrity():
 current=json.loads(subprocess.check_output(['node','C:/TestLearn/tmp/phase10h-batch6-20261106/current-bank.cjs',str(root)]));assert current==baseline and current['revision']=='2026-10-27.10'
 bank=current['bank'];assert len(bank)==len({q['id'] for q in bank})==90
 assert git('rev-parse','HEAD').decode().strip()==pre['head'] and git('branch','--show-current').decode().strip()=='develop'
 assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
 pending={n for n in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if n};assert pending==set(pre['existingUncommittedDocuments'])|set(newfiles())
 history={}
 for i in range(1,10):
  n=f'src/data/archive/questions-2026-10-27.{i}.json';b=(root/n).read_bytes();assert b==git('show','HEAD:'+n);history[n]=sha(b)
 old=read(root/'src/data/archive/questions-2026-10-27.9.json');assert [q['id'] for q in bank]==[q['id'] for q in old] and all(a['correct']==b['correct'] for a,b in zip(old,bank))
 assert [a['id'] for a,b in zip(old,bank) if a!=b]==['tl-011','tl-090']
 priorDocs={n:h for n,h in pre['existingFilesSHA256'].items() if any(n.startswith('docs/academic/phase10h-batch'+str(i)+'-') for i in range(1,7))};assert len(priorDocs)==57
 extra=['src/data/syllabus-questions.ts','src/data/variability-questions.ts','src/domain/blueprint.ts','tests/unit/academic-audit.test.ts','tests/unit/blueprint.test.ts','tests/unit/quality-maintenance.test.ts','tests/unit/variability.test.ts']
 import zipfile
 with zipfile.ZipFile('C:/Users/gabri/Downloads/TestLearn-Phase10H-Batch5-Academic-Review-20261106.zip') as z:
  for n in extra:assert (root/n).is_file() and (root/n).read_bytes()==z.read(n),n
 result={'result':'PASS','command':['python',str(out/'verify.py'),'integrity'],'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'branch':'develop','head':pre['head'],'contentRevision':current['revision'],'existingFilesByteIdentical':len(pre['existingFilesSHA256']),'priorUncommittedDocumentsPreserved':len(pre['existingUncommittedDocuments']),'priorBatchDocumentsSHA256':priorDocs,'questionBankIdentical':True,'uniqueIDsAndKeysPreserved':90,'allVersionsAndExplanationsPreserved':True,'historicalSHA256':history,'requiredComparisonFilesSHA256':{n:sha((root/n).read_bytes()) for n in extra},'comparisonFilesMatchBatch5ZIP':True,'newRepositoryFiles':newfiles(),'newOwnerAcceptances':0,'newHumanApprovals':0}
 (out/'integrity-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k not in ['priorBatchDocumentsSHA256','historicalSHA256','requiredComparisonFilesSHA256']},indent=2))
commands={
 'legacy-academic-context':['node','scripts/check-academic-deliverables.mjs','--phase10h-batch2'],
 'targeted-vitest':['node','node_modules/vitest/vitest.mjs','run','tests/unit/academic-audit.test.ts','tests/unit/quality-maintenance.test.ts','tests/unit/bank-history.test.ts','tests/unit/backup.test.ts'],
 'format-check':['node','node_modules/prettier/bin/prettier.cjs','--check',*newfiles()],
 'diff-check':['git','diff','--check']}
mode=sys.argv[1]
if mode=='format':raise SystemExit(subprocess.call(['node','node_modules/prettier/bin/prettier.cjs','--write',*newfiles()],cwd=root))
if mode in ['integrity','batch7-specific']:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  integrity() if mode=='integrity' else specific()
 except Exception:raise
 else:
  meta={'command':['python',str(out/'verify.py'),mode],'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0}
  (out/(mode+'-execution.json')).write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
 raise SystemExit()
args=commands[mode];started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=root,capture_output=True,text=True,encoding='utf8',errors='replace');output=p.stdout+p.stderr
(out/(mode+'.log')).write_text(output,encoding='utf8');meta={'command':args,'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'scopeNote':'Legacy Batch1/2 context guard, NOT Batch7-specific linguistic validation' if mode=='legacy-academic-context' else 'Fresh scoped execution'}
(out/(mode+'-result.json')).write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8');print(json.dumps(meta));print(output);raise SystemExit(p.returncode)
