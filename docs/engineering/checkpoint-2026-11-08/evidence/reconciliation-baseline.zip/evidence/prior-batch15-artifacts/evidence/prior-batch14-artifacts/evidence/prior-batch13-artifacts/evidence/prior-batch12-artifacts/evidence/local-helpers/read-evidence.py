from pathlib import Path
import json,hashlib,datetime,sys,re
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');r=lambda x:json.loads(Path(x).read_text(encoding='utf-8-sig'));blind=r(p/'blind-solutions.json');bank=r(p/'runtime-before.json')['bank'];ids=[s['questionId'] for s in blind['solutions']]
if len(sys.argv)>1 and sys.argv[1]=='questions':
 for ident in ids:
  q=next(q for q in bank if q['id']==ident);print(json.dumps(q,ensure_ascii=False,indent=2))
 (p/'key-reveal.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'questions':[{'questionId':i,'key':next(q['correct'] for q in bank if q['id']==i),'independentAnswer':next(s['answer'] for s in blind['solutions'] if s['questionId']==i)} for i in ids]},indent=2)+'\n');raise SystemExit()
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
base=Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0');records=[]
for lang,name,pages in [('EN','ISTQB_CTFL_Syllabus_v4.0.1.pdf',[14,20,24,28,32,35,36,37,47,48,52,53,54,55,58,59]),('PT','ISTQB_CTFL_Syllabus-v4.0-PT_v1.0 (1).pdf',[15,22,26,30,35,38,39,40,52,53,57,58,59,60,61,64,65])]:
 b=(base/name).read_bytes();d=pymupdf.open(stream=b,filetype='pdf');texts=[pg.get_text() for pg in d]
 records.append({'language':lang,'fileName':name,'sha256':hashlib.sha256(b).hexdigest(),'pageCount':len(d),'pages':[{'physicalPage':n,'text':texts[n-1]} for n in pages]})
 if len(sys.argv)>1 and sys.argv[1]==lang:
  for n in map(int,sys.argv[2:]):print('\n'+lang+' PHYSICAL PAGE '+str(n)+'\n'+texts[n-1])
(p/'source-pages.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
