# TestLearn — Fase 10H, Lote 14

Âmbito exclusivo: tl-058, tl-059, tl-060, tl-061, tl-065, tl-066, tl-067 e tl-068; 32 alternativas. Revisão por IA, não SME humano. Oito pareceres ACCEPT_AS_IS, fundamentados sem usar a triagem NONE como evidência. Não houve defeito obrigatório nem proposta editorial justificada; o banco permanece inalterado.

Soluções cegas foram registadas antes da revelação de chaves e explicações, com horário e SHA-256. Coincidência de respostas não prova correção. Os relatórios preservam os textos integrais PT/EN em blocos literais antes/depois idênticos, avaliam todos os distratores, as explicações, hipóteses alternativas, LO/K e nove revisões históricas.

Baseline: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos. ZIP do Lote 13 autenticado: 78162d4c4582d296e66f3bb6c57483988aec78214f366710c655d4f14b9f63d6; 432 ficheiros e 431 hashes. Inventário inicial: 373 ficheiros, 159 não rastreados, 170 documentos académicos anteriores. Todos são preservados; interrupções e recuperações dos Lotes 12 e 13 mantêm os resultados históricos.

Fontes: EN v4.0.1 e PT v4.0 tradução 1.0, com páginas físicas verificadas individualmente. Ambos os endpoints oficiais ficaram acessíveis nesta execução; cópias oficiais locais foram lidas e hashed. Não se afirma igualdade textual de edições ou igualdade remota dos bytes. Referências e limites em sources.json. Não foi necessária consulta separada do glossário.

Distinções essenciais: fatores de sucesso não são garantia; cobertura estrutural não prova requisitos completos; checklist de alto nível admite variabilidade; confirmação dos três C não é reteste de defeito; prioridade não é severidade; comunicação adapta-se ao público; aprovação salarial é premissa de negócio; análise antecipada não exige software executável.

Duas camadas: BATCH14-RULES verifica os oito objetos e a coerência do dossiê. GLOBAL14-RULES compara os 90 objetos completos com referência fixa extraída do ZIP autenticado anterior, nunca gerada a partir do candidato. A mutação fora do lote em tl-002 é responsabilidade global. Guardas e verificação de pacote comprovam consistência, não verdade académica automática.

Sem alteração a banco, históricos, código, testes, persistência, versões ou pontuação. tl-001 mantém exatamente as duas respostas o1 e o4. Sem OWNER_ACCEPTED ou HUMAN_APPROVED novo; aprovação humana PENDING. Propostas opcionais permanecem vazias e não aplicadas.

Exportar apenas após todos os gates, contabilizando por comparação direta os 432 membros anteriores. O pacote é um dossiê de evidência, não um repositório executável completo. Datas reais UTC são conservadas. Ver verification.md para execuções novas, limites e testes não executados.

Fase 10H aberta. Sem commit, push, merge, PR, deploy ou Production. Concluir só Lote 14 e aguardar auditoria; não iniciar Lote 15.


## Verificação portátil

Inspecionar VERIFY-PACKAGE.py, BATCH14-RULES.py e GLOBAL14-RULES.py. Depois de extrair numa pasta limpa, executar `python -B VERIFY-PACKAGE.py` com Python 3.9+ standard library, sem -O. Os três ficheiros são somente leitura, sem rede nem subprocessos. Os auxiliares em evidence/local-helpers requerem o checkout original e não são entradas portáteis. Verificadores históricos são evidência e não pacotes autónomos.

EXPORT-CONTINUITY.json mapeia todos os 432 membros do ZIP autenticado do Lote 13, comparados diretamente byte a byte. As 208 referências anteriores do repositório mantêm caminhos relativos. Cargas históricas idênticas podem partilhar destino, sem omissões. MANIFEST.json cobre todas as cargas exceto ele próprio para evitar circularidade; o SHA-256 externo do ZIP cobre também o manifesto. Hashes mostram consistência, não certificação académica ou assinatura digital.

Os logs históricos de falha e recuperação dos Lotes 12 e 13 são preservados sem reescrita e não são apresentados como novos testes. Os resultados novos estão em evidence/checks. O dossiê é uma exportação de evidência, não um repositório executável completo. A Fase 10H permanece aberta; aprovação humana PENDING; sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Não iniciar Lote 15. Nenhuma publicação, commit ou operação Git remota.
