# Lote 12 — diagnóstico e resolução da interrupção

Este documento complementa, sem substituir, o README e verification.md da interrupção. Esses ficheiros, STOP-FAILURE.json e os 18 documentos académicos existentes foram preservados byte a byte. O estado técnico atual é sustentado por revalidation.md e pelas evidências RED/GREEN do pacote. A revisão académica não foi repetida e as soluções pré-gabarito conservam os seus horários.

## Causa raiz confirmada: hipótese B

O caso `unauthorized bank edit` faz uma cópia profunda dos argumentos e altera `bank[1].text.en` para `adulterated bank`. O elemento é tl-002. A cópia é passada diretamente como primeiro argumento a `check(*a)`: o hash de tl-002 muda, pelo que a injeção funciona. Não é a hipótese C de uma cópia ignorada.

`BATCH12-RULES.py:check` compara os hashes e a evidência das oito questões do lote. Também verifica cardinalidades estruturais do banco, mas não compara o conteúdo dos outros 82 objetos. O caso fora do lote estava, portanto, colocado na camada errada. A verificação global em `verify.py:integrity` já comparava o banco completo reavaliado com o snapshot. Essa condição rejeita a mesma adulteração de tl-002. Não foi demonstrada uma falha na igualdade global; havia uma lacuna real na organização dos testes negativos, que esperava uma responsabilidade global do guard específico.

A investigação reproduziu a falha original antes da alteração, com exit 1 e a mesma mensagem. `evidence/recovery/red.log`, red-result.json, diagnosis.json e as cópias dos auxiliares originais permitem auditar o RED. O resultado anterior permanece uma falha, não foi reclassificado como aprovação.

## Comparação com os Lotes 10 e 11

- No Lote 10, tl-002 está fora da questão revista; o guard específico aceita essa alteração fora do seu âmbito, enquanto a igualdade global a rejeita.
- No Lote 11, tl-002 faz parte das oito questões; a mesma posição da lista é rejeitada pelo hash específico. O teste passava por coincidência entre o índice escolhido e o âmbito desse lote.
- No Lote 12, tl-002 volta a estar fora do âmbito. Copiar o mesmo teste sem encaminhamento global fez surgir a falha.

As implementações anteriores foram lidas e os seus comportamentos comparados em memória, sem modificar documentos ou auxiliares desses lotes.

## Correção mínima e responsabilidades

1. Novo `GLOBAL12-RULES.py`: extrai a proteção de igualdade completa do banco para uma função pura reutilizável. `check_bank` compara todos os 90 objetos, incluindo textos, explicações, chaves, versões e metadados. Confirma também 364 alternativas, 64 objetivos e a seleção múltipla de tl-001.
2. O caso original de tl-002 permanece com o mesmo texto adulterado e a mesma expectativa de rejeição. Só esse caso é encaminhado para a proteção global. Os casos de coerência académica continuam no guard específico; foi acrescentada uma mutação de tl-016 para demonstrar a rejeição dentro do lote.
3. `verify.py` usa a mesma função global na integridade do banco real e nos testes negativos. O guard específico recebe agora o banco reavaliado atual; a referência esperada não é obtida desse candidato.

Referência imutável: `review-data/current-bank.json` do ZIP do Lote 11, autenticado por SHA-256 `57db2636f49d56402944f71f8b87d14b0235cc25cd2d47d5b01951b3730c6188`. Os bytes do membro foram conferidos com o manifesto anterior antes de serem usados. SHA-256 desses bytes: `9a6bc09d6ab5a512cb53ea26dc7a1da5ae465167bf5e2b6ba8c9c9b34f332615`; hash canónico dos 90 objetos: `3b1faffe3e89031fac6a76ee30e8f82e5a81d3ebea58f1857d0f36391bf9320a`. Ambos são constantes na regra global. Um candidato adulterado acompanhado de uma referência igualmente adulterada é rejeitado, evitando rebaseline silencioso.

## Demonstração da correção

- RED: o comando original `python verify.py batch12-specific` termina com exit 1 e `False positive: unauthorized bank edit`.
- GREEN: o mesmo comando termina com exit 0; a mesma adulteração de tl-002 é rejeitada pela proteção global, com controlo do banco intacto aprovado.
- O guard específico continua deliberadamente limitado aos oito itens. A alteração fora do lote não o transforma num segundo verificador global.
- A alteração sintética de tl-016 é rejeitada pelo guard específico.
- Os 16 casos negativos combinados foram rejeitados: 15 específicos e o caso original encaminhado para a proteção global.
- A proteção global rejeita 96 casos: uma mutação em cada uma das 90 questões, alteração de chave, versão e explicação, ID ausente, ID duplicado e referência adulterada.

Não foram eliminadas asserções, ignoradas exceções ou atualizados hashes para aceitar conteúdo adulterado. Nenhum banco ou teste de produção foi alterado. `replay-recovery.py` e os resultados guardados demonstram o fluxo dos dados em cópias sintéticas, sem LocalStorage ou dados reais.

## Preservação e limites

Todos os ficheiros anteriores ao Lote 12 permanecem iguais; os 18 documentos já existentes deste lote e STOP-FAILURE.json também foram congelados e conferidos por hash. Foram apenas alterados os auxiliares novos afetados e acrescentadas evidências/documentação desta recuperação. Não houve commits, operações Git remotas ou publicação.

Os oito pareceres académicos continuam ACCEPT_AS_IS; não se acrescentaram propostas nem se repetiu a avaliação. Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Verificadores demonstram consistência e proteção dos dados, não verdade académica ou certificação humana. A Fase 10H permanece aberta; parar após Lote 12 e aguardar auditoria antes de Lote 13.


# tl-016 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-3.2.3 / K1; versão 3; revisão 2026-10-27.10; SHA-256 canónico `8b262220a636b7ce047fa7127c111fa231496642e4409759e3a7c5b17a908b7c`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

A função que facilita a reunião, gere tempo, medeia e cria participação segura é o moderador. Redator regista anomalias e decisões; gestor fornece recursos e decide o objeto; líder organiza globalmente a revisão. Autor cria/corrige o produto e revisor avalia-o. A pergunta identifica uma responsabilidade típica, não uma regra de uma pessoa diferente para cada função.

Reasoning recorded before revealing the key:

Facilitar a reunião e proteger a eficácia corresponde ao moderador. Redator regista; gestor decide/apoia recursos; líder organiza a revisão. Uma pessoa pode acumular funções, mas a função perguntada é a moderação habitual.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 3.2.3: EN páginas [36]; PT páginas [39].
- Apoio 3.2.4 (restrições de inspeção): EN páginas [36,37]; PT páginas [39,40].

- LO FL-3.2.3/K1: EN página 32; PT página 35.

EN p.36 e PT p.39 permitem que stakeholders assumam vários papéis e distinguem as mesmas responsabilidades. Autor e revisor foram consultados como contraste, sem inventar alternativas adicionais. O qualificador não elimina as restrições especiais de inspeções.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Normally/normalmente preserva a função habitual. Facilitates/facilita e effective/eficaz mantêm o objetivo. Scribe/redator(anotador), review leader/líder de revisão e manager/gestor correspondem aos papéis oficiais. O singular identifica a função, não estabelece um organigrama exclusivo.

| EN literal | PT literal |
| --- | --- |
| normally | normalmente |
| facilitates a review meeting | facilita uma reunião de revisão |
| The scribe | O redator (anotador) |

## Contraexemplos e segunda resposta plausível

Um líder, gestor ou redator pode também moderar se acumular essa função. Isso não torna o título mais geral a melhor resposta para a responsabilidade específica. A acumulação não é ilimitada: inspeções têm restrições explícitas para o autor, segundo 3.2.4, mas o enunciado não especifica uma inspeção. Não se exige que o moderador produza o conteúdo revisto.

## Adequação ao LO, K e pedagogia

K1: recordar a responsabilidade do papel principal é apropriado. O contraste moderador/líder é útil e não depende de regras organizacionais não dadas. Explicação geral e quatro justificações distinguem os papéis; não se garante que toda reunião moderada seja bem-sucedida.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Quem normalmente facilita uma reunião de revisão e ajuda a mantê-la eficaz?
```

Proposto atual — sem alteração

```text
Quem normalmente facilita uma reunião de revisão e ajuda a mantê-la eficaz?
```

### Enunciado EN

Original

```text
Who normally facilitates a review meeting and helps keep it effective?
```

Proposto atual — sem alteração

```text
Who normally facilitates a review meeting and helps keep it effective?
```

### o1 — alternativa PT

Original

```text
O moderador
```

Proposto atual — sem alteração

```text
O moderador
```

### o1 — explicação PT

Original

```text
O moderador facilita a reunião de revisão através da mediação, da gestão do tempo e de um ambiente seguro para a participação. O redator regista informação; o gestor disponibiliza recursos; o líder de revisão organiza a revisão no seu conjunto.
```

Proposto atual — sem alteração

```text
O moderador facilita a reunião de revisão através da mediação, da gestão do tempo e de um ambiente seguro para a participação. O redator regista informação; o gestor disponibiliza recursos; o líder de revisão organiza a revisão no seu conjunto.
```

### o1 — alternativa EN

Original

```text
The moderator
```

Proposto atual — sem alteração

```text
The moderator
```

### o1 — explicação EN

Original

```text
The moderator facilitates the review meeting through mediation, time management and a safe environment for participation. The scribe records information; the manager provides resources; the review leader organizes the review overall.
```

Proposto atual — sem alteração

```text
The moderator facilitates the review meeting through mediation, time management and a safe environment for participation. The scribe records information; the manager provides resources; the review leader organizes the review overall.
```

### o2 — alternativa PT

Original

```text
O redator (anotador)
```

Proposto atual — sem alteração

```text
O redator (anotador)
```

### o2 — explicação PT

Original

```text
O redator regista anomalias e decisões da revisão; facilitar a reunião não é esta responsabilidade.
```

Proposto atual — sem alteração

```text
O redator regista anomalias e decisões da revisão; facilitar a reunião não é esta responsabilidade.
```

### o2 — alternativa EN

Original

```text
The scribe
```

Proposto atual — sem alteração

```text
The scribe
```

### o2 — explicação EN

Original

```text
The scribe records anomalies and review decisions; this is not the meeting facilitation responsibility.
```

Proposto atual — sem alteração

```text
The scribe records anomalies and review decisions; this is not the meeting facilitation responsibility.
```

### o3 — alternativa PT

Original

```text
O gestor
```

Proposto atual — sem alteração

```text
O gestor
```

### o3 — explicação PT

Original

```text
O gestor disponibiliza recursos e decide o que será revisto; o moderador facilita a reunião.
```

Proposto atual — sem alteração

```text
O gestor disponibiliza recursos e decide o que será revisto; o moderador facilita a reunião.
```

### o3 — alternativa EN

Original

```text
The manager
```

Proposto atual — sem alteração

```text
The manager
```

### o3 — explicação EN

Original

```text
The manager provides resources and decides what will be reviewed; the moderator facilitates the meeting.
```

Proposto atual — sem alteração

```text
The manager provides resources and decides what will be reviewed; the moderator facilitates the meeting.
```

### o4 — alternativa PT

Original

```text
O líder de revisão
```

Proposto atual — sem alteração

```text
O líder de revisão
```

### o4 — explicação PT

Original

```text
O líder de revisão tem responsabilidade global e organiza participantes, data e local. O moderador é especificamente responsável pela facilitação eficaz da reunião.
```

Proposto atual — sem alteração

```text
O líder de revisão tem responsabilidade global e organiza participantes, data e local. O moderador é especificamente responsável pela facilitação eficaz da reunião.
```

### o4 — alternativa EN

Original

```text
The review leader
```

Proposto atual — sem alteração

```text
The review leader
```

### o4 — explicação EN

Original

```text
The review leader has overall responsibility and organizes participation, timing and location. The moderator is specifically responsible for effective meeting facilitation.
```

Proposto atual — sem alteração

```text
The review leader has overall responsibility and organizes participation, timing and location. The moderator is specifically responsible for effective meeting facilitation.
```

### Explicação geral PT

Original

```text
O moderador facilita a reunião de revisão através da mediação, da gestão do tempo e de um ambiente seguro para a participação. O redator regista informação; o gestor disponibiliza recursos; o líder de revisão organiza a revisão no seu conjunto.
```

Proposto atual — sem alteração

```text
O moderador facilita a reunião de revisão através da mediação, da gestão do tempo e de um ambiente seguro para a participação. O redator regista informação; o gestor disponibiliza recursos; o líder de revisão organiza a revisão no seu conjunto.
```

### Explicação geral EN

Original

```text
The moderator facilitates the review meeting through mediation, time management and a safe environment for participation. The scribe records information; the manager provides resources; the review leader organizes the review overall.
```

Proposto atual — sem alteração

```text
The moderator facilitates the review meeting through mediation, time management and a safe environment for participation. The scribe records information; the manager provides resources; the review leader organizes the review overall.
```

## Análise das quatro alternativas

### o1 — correta

Correta: moderação é a responsabilidade específica de facilitar eficazmente a reunião.

Moderating/facilitating the meeting and maintaining effectiveness is the moderator role. This is a role distinction, not an assertion that a different individual must occupy each role.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta como função pedida: redator regista, mesmo que a pessoa também possa moderar noutro papel.

The scribe records anomalies, decisions and review information; recording alone is not facilitating the meeting. The same person might also act as moderator, but that is another role.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta: recursos e decisão do que rever não equivalem à facilitação específica da reunião.

A manager sponsors or decides review-related scope/resources rather than normally facilitating the review meeting as that role. A manager who facilitates is acting in a facilitator role.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta como resposta mais específica: a responsabilidade global de organização é distinta da moderação.

The review leader has overall responsibility for organizing the review. That wider organizing responsibility does not make it the most specific answer for meeting facilitation.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | True | 1 | ['o1'] | 1c61c92c4bf820610dc9d98cf00a1ad6aade83d8fb790910e8dcb8710d81049e |
| 2026-10-27.2 | True | 2 | ['o1'] | e85a14c9c27aea46b64b33d8a52822c361ff498cd0b9e85ce3dcd072f8297b9b |
| 2026-10-27.3 | True | 2 | ['o1'] | e85a14c9c27aea46b64b33d8a52822c361ff498cd0b9e85ce3dcd072f8297b9b |
| 2026-10-27.4 | True | 2 | ['o1'] | e85a14c9c27aea46b64b33d8a52822c361ff498cd0b9e85ce3dcd072f8297b9b |
| 2026-10-27.5 | True | 2 | ['o1'] | e85a14c9c27aea46b64b33d8a52822c361ff498cd0b9e85ce3dcd072f8297b9b |
| 2026-10-27.6 | True | 2 | ['o1'] | e85a14c9c27aea46b64b33d8a52822c361ff498cd0b9e85ce3dcd072f8297b9b |
| 2026-10-27.7 | True | 3 | ['o1'] | 8b262220a636b7ce047fa7127c111fa231496642e4409759e3a7c5b17a908b7c |
| 2026-10-27.8 | True | 3 | ['o1'] | 8b262220a636b7ce047fa7127c111fa231496642e4409759e3a7c5b17a908b7c |
| 2026-10-27.9 | True | 3 | ['o1'] | 8b262220a636b7ce047fa7127c111fa231496642e4409759e3a7c5b17a908b7c |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-018 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-3.2.4 / K2; versão 3; revisão 2026-10-27.10; SHA-256 canónico `9444c9830675b08a4435e5b969ea682d63039bf116249bf5300a9f51e5c397b9`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

Entre os tipos CTFL apresentados, a inspeção é o mais formal, segue o processo genérico completo e recolhe métricas para melhoria. A decisão depende da combinação e do superlativo, não da falsa ideia de que só inspeções podem ter papéis ou métricas.

Reasoning recorded before revealing the key:

O tipo mais formal, com papéis definidos e métricas recolhidas, é inspeção. Revisão técnica também pode usar moderador/métricas, mas isso não a torna o tipo mais formal. Walkthrough costuma ser conduzido pelo autor; informal não exige processo formal.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 3.2.4: EN páginas [36, 37]; PT páginas [39, 40].
- Secção 3.2.2: EN páginas [35, 36]; PT páginas [38, 39].

- LO FL-3.2.4/K2: EN página 32; PT página 35.

EN pp.36–37 e PT pp.39–40 concordam quanto ao tipo mais formal e à finalidade das métricas. O processo genérico é tratado em EN pp.35–36/PT pp.38–39; não se atribuiu formalidade máxima apenas a uma reunião com moderador.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Most formal/mais formal conserva o superlativo decisivo. Defined roles/papéis definidos e collected metrics/métricas recolhidas são equivalentes. A explicação inclui complete generic review process/processo genérico completo e explicita que outros tipos também podem recolher métricas.

| EN literal | PT literal |
| --- | --- |
| most formal | mais formal |
| defined roles | papéis definidos |
| collected metrics | métricas recolhidas |

## Contraexemplos e segunda resposta plausível

Revisões técnicas podem ser muito estruturadas e recolher métricas; walkthroughs podem usar preparação e registo. Uma organização pode adaptar práticas, mas isso não altera a classificação CTFL pedida. Sem o requisito mais formal, métricas isoladas não garantiriam resposta única; esse requisito está presente em ambas as línguas.

## Adequação ao LO, K e pedagogia

K2: comparar características e escolher o tipo que responde à necessidade é adequado, embora a pergunta seja fácil por usar o traço distintivo mais formal. Não se exige uma inspeção real completa nem se presume que mais formal seja sempre melhor. A escolha depende dos objetivos e contexto.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Uma equipa precisa do tipo de revisão mais formal, com papéis definidos e métricas recolhidas. Qual é adequado?
```

Proposto atual — sem alteração

```text
Uma equipa precisa do tipo de revisão mais formal, com papéis definidos e métricas recolhidas. Qual é adequado?
```

### Enunciado EN

Original

```text
A team needs the most formal review type, with defined roles and collected metrics. Which fits?
```

Proposto atual — sem alteração

```text
A team needs the most formal review type, with defined roles and collected metrics. Which fits?
```

### o1 — alternativa PT

Original

```text
Inspeção
```

Proposto atual — sem alteração

```text
Inspeção
```

### o1 — explicação PT

Original

```text
A inspeção é o tipo de revisão CTFL mais formal: segue o processo genérico de revisão completo e recolhe métricas para melhorar o processo. Papéis definidos ou métricas, isoladamente, não transformam outro tipo de revisão numa inspeção.
```

Proposto atual — sem alteração

```text
A inspeção é o tipo de revisão CTFL mais formal: segue o processo genérico de revisão completo e recolhe métricas para melhorar o processo. Papéis definidos ou métricas, isoladamente, não transformam outro tipo de revisão numa inspeção.
```

### o1 — alternativa EN

Original

```text
Inspection
```

Proposto atual — sem alteração

```text
Inspection
```

### o1 — explicação EN

Original

```text
Inspection is the most formal CTFL review type: it follows the complete generic review process and collects metrics for process improvement. Defined roles or metrics in isolation do not turn another review type into an inspection.
```

Proposto atual — sem alteração

```text
Inspection is the most formal CTFL review type: it follows the complete generic review process and collects metrics for process improvement. Defined roles or metrics in isolation do not turn another review type into an inspection.
```

### o2 — alternativa PT

Original

```text
Revisão técnica
```

Proposto atual — sem alteração

```text
Revisão técnica
```

### o2 — explicação PT

Original

```text
Uma revisão técnica envolve revisores tecnicamente qualificados e um moderador, mas a inspeção é o tipo mais formal descrito.
```

Proposto atual — sem alteração

```text
Uma revisão técnica envolve revisores tecnicamente qualificados e um moderador, mas a inspeção é o tipo mais formal descrito.
```

### o2 — alternativa EN

Original

```text
Technical review
```

Proposto atual — sem alteração

```text
Technical review
```

### o2 — explicação EN

Original

```text
A technical review uses technically qualified reviewers and a moderator, but inspection is the most formal type described.
```

Proposto atual — sem alteração

```text
A technical review uses technically qualified reviewers and a moderator, but inspection is the most formal type described.
```

### o3 — alternativa PT

Original

```text
Walkthrough
```

Proposto atual — sem alteração

```text
Walkthrough
```

### o3 — explicação PT

Original

```text
Um walkthrough é conduzido pelo autor e não exige todo o processo de inspeção nem as suas métricas.
```

Proposto atual — sem alteração

```text
Um walkthrough é conduzido pelo autor e não exige todo o processo de inspeção nem as suas métricas.
```

### o3 — alternativa EN

Original

```text
Walkthrough
```

Proposto atual — sem alteração

```text
Walkthrough
```

### o3 — explicação EN

Original

```text
A walkthrough is led by the author and does not require the full inspection process and metrics.
```

Proposto atual — sem alteração

```text
A walkthrough is led by the author and does not require the full inspection process and metrics.
```

### o4 — alternativa PT

Original

```text
Revisão informal
```

Proposto atual — sem alteração

```text
Revisão informal
```

### o4 — explicação PT

Original

```text
Uma revisão informal não exige o processo completo definido e as métricas recolhidas característicos de uma inspeção. Outros tipos podem recolher métricas, mas a inspeção é o tipo CTFL mais formal.
```

Proposto atual — sem alteração

```text
Uma revisão informal não exige o processo completo definido e as métricas recolhidas característicos de uma inspeção. Outros tipos podem recolher métricas, mas a inspeção é o tipo CTFL mais formal.
```

### o4 — alternativa EN

Original

```text
Informal review
```

Proposto atual — sem alteração

```text
Informal review
```

### o4 — explicação EN

Original

```text
An informal review does not require the complete defined process and collected metrics characteristic of an inspection. Other review types may collect metrics, but inspection is the most formal CTFL type.
```

Proposto atual — sem alteração

```text
An informal review does not require the complete defined process and collected metrics characteristic of an inspection. Other review types may collect metrics, but inspection is the most formal CTFL type.
```

### Explicação geral PT

Original

```text
A inspeção é o tipo de revisão CTFL mais formal: segue o processo genérico de revisão completo e recolhe métricas para melhorar o processo. Papéis definidos ou métricas, isoladamente, não transformam outro tipo de revisão numa inspeção.
```

Proposto atual — sem alteração

```text
A inspeção é o tipo de revisão CTFL mais formal: segue o processo genérico de revisão completo e recolhe métricas para melhorar o processo. Papéis definidos ou métricas, isoladamente, não transformam outro tipo de revisão numa inspeção.
```

### Explicação geral EN

Original

```text
Inspection is the most formal CTFL review type: it follows the complete generic review process and collects metrics for process improvement. Defined roles or metrics in isolation do not turn another review type into an inspection.
```

Proposto atual — sem alteração

```text
Inspection is the most formal CTFL review type: it follows the complete generic review process and collects metrics for process improvement. Defined roles or metrics in isolation do not turn another review type into an inspection.
```

## Análise das quatro alternativas

### o1 — correta

Correta: inspeção é o tipo CTFL mais formal com processo genérico completo e métricas.

Inspection matches the most formal review type and its defined process, roles and metrics, rather than merely the presence of any meeting or checklist.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta como tipo mais formal: revisão técnica tem revisores qualificados e moderador, mas não é a inspeção pedida.

Technical reviews can be structured and may collect metrics, but the full most-formal requirement points to inspection, not every structured review.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta: walkthrough é conduzido pelo autor; preparação ou métricas locais não satisfazem por si a classificação mais formal.

A walkthrough can use a scribe and preparation and can be formalized locally; it is not the syllabus most-formal type. Its usual author-led character is a useful contrast.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: revisão informal não exige o processo completo definido nem saída formal, embora possa produzir apontamentos.

An informal review does not follow a defined process or require a formally documented output. Local recording does not turn it into the most formal type.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | True | 1 | ['o1'] | 183aefc50c12d776ebbbb75aa06ed17ddf01723696bca642b65c5e7935632dfa |
| 2026-10-27.2 | True | 2 | ['o1'] | 3b6ce0a46c577074c083cd39cba6623101c0703537f512c7c9fe02f1116ec49e |
| 2026-10-27.3 | True | 2 | ['o1'] | 3b6ce0a46c577074c083cd39cba6623101c0703537f512c7c9fe02f1116ec49e |
| 2026-10-27.4 | True | 2 | ['o1'] | 3b6ce0a46c577074c083cd39cba6623101c0703537f512c7c9fe02f1116ec49e |
| 2026-10-27.5 | True | 2 | ['o1'] | 3b6ce0a46c577074c083cd39cba6623101c0703537f512c7c9fe02f1116ec49e |
| 2026-10-27.6 | True | 2 | ['o1'] | 3b6ce0a46c577074c083cd39cba6623101c0703537f512c7c9fe02f1116ec49e |
| 2026-10-27.7 | True | 3 | ['o1'] | 9444c9830675b08a4435e5b969ea682d63039bf116249bf5300a9f51e5c397b9 |
| 2026-10-27.8 | True | 3 | ['o1'] | 9444c9830675b08a4435e5b969ea682d63039bf116249bf5300a9f51e5c397b9 |
| 2026-10-27.9 | True | 3 | ['o1'] | 9444c9830675b08a4435e5b969ea682d63039bf116249bf5300a9f51e5c397b9 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-031 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.1.1 / K2; versão 3; revisão 2026-10-27.10; SHA-256 canónico `0def0fa4d9038c8059cd8ad5d0f5d7b3c43ba08bcfbb23f345f6adf682b9c1e0`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

A necessidade é reunir acordos específicos do projeto sobre âmbito, recursos e abordagem: plano de testes. Política orienta ao nível organizacional; cronograma organiza execuções; conclusão resume resultados de atividade concluída. Casos de teste detalham verificações, não consolidam por si estes acordos de projeto.

Reasoning recorded before revealing the key:

Plano de testes reúne âmbito, recursos e abordagem acordada do projeto. Política dá direção geral; cronograma ordena execução mas não reúne tudo; relatório de conclusão avalia o trabalho já terminado.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 5.1.1: EN páginas [48]; PT páginas [53].
- Secção 1.4.3: EN páginas [20]; PT páginas [22].

- LO FL-5.1.1/K2: EN página 47; PT página 52.

EN p.48 e PT p.53 descrevem objetivos, recursos e processos e incluem âmbito e abordagem no conteúdo. EN p.20/PT p.22 relacionam plano/cronograma e outros produtos. Não é necessário impor um template ou uma forma documental universal.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Project-level/ao nível do projeto, bringing together/reúna e agreed/acordados conservam abrangência e compromisso. Scope/âmbito, resources/recursos e approach/abordagem mantêm os elementos. Acordados não significa que toda alteração futura esteja proibida.

| EN literal | PT literal |
| --- | --- |
| project-level | ao nível do projeto |
| agreed test scope | âmbito |
| resources and approach | recursos e a abordagem |

## Contraexemplos e segunda resposta plausível

Um plano pode incorporar cronograma e referenciar a política; documentos podem coexistir numa ferramenta única. Isso não torna um cronograma isolado ou a política o artefacto funcionalmente mais adequado. Um plano pode evoluir durante a execução e não exige necessariamente um ficheiro separado ou aprovação cerimonial não descrita.

## Adequação ao LO, K e pedagogia

K2: reconhecer o artefacto pela finalidade num pequeno cenário exemplifica propósito e conteúdo do plano. A dificuldade é baixa, mas exige discriminar documentos relacionados. As explicações distinguem finalidade prospetiva, orientação organizacional e relato posterior. Não se afirma que um plano garante qualidade ou sucesso.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Uma equipa precisa de um documento ao nível do projeto que reúna o âmbito, os recursos e a abordagem de teste acordados. Que artefacto responde a esta necessidade?
```

Proposto atual — sem alteração

```text
Uma equipa precisa de um documento ao nível do projeto que reúna o âmbito, os recursos e a abordagem de teste acordados. Que artefacto responde a esta necessidade?
```

### Enunciado EN

Original

```text
A team needs a project-level document bringing together the agreed test scope, resources and approach. Which artifact addresses this need?
```

Proposto atual — sem alteração

```text
A team needs a project-level document bringing together the agreed test scope, resources and approach. Which artifact addresses this need?
```

### o1 — alternativa PT

Original

```text
Plano de testes
```

Proposto atual — sem alteração

```text
Plano de testes
```

### o1 — explicação PT

Original

```text
Um plano de testes comunica objetivos, âmbito, recursos e processos de teste específicos do projeto. Reúne esses acordos; uma política, um cronograma de execução ou um relatório de conclusão têm finalidades diferentes.
```

Proposto atual — sem alteração

```text
Um plano de testes comunica objetivos, âmbito, recursos e processos de teste específicos do projeto. Reúne esses acordos; uma política, um cronograma de execução ou um relatório de conclusão têm finalidades diferentes.
```

### o1 — alternativa EN

Original

```text
Test plan
```

Proposto atual — sem alteração

```text
Test plan
```

### o1 — explicação EN

Original

```text
A test plan communicates project-specific test objectives, scope, resources and processes. It brings these agreements together; a policy, execution schedule or completion report has a different purpose.
```

Proposto atual — sem alteração

```text
A test plan communicates project-specific test objectives, scope, resources and processes. It brings these agreements together; a policy, execution schedule or completion report has a different purpose.
```

### o2 — alternativa PT

Original

```text
Política de testes
```

Proposto atual — sem alteração

```text
Política de testes
```

### o2 — explicação PT

Original

```text
Uma política fornece orientação organizacional. O plano de testes do projeto comunica o âmbito, os recursos e a abordagem específicos deste esforço de teste.
```

Proposto atual — sem alteração

```text
Uma política fornece orientação organizacional. O plano de testes do projeto comunica o âmbito, os recursos e a abordagem específicos deste esforço de teste.
```

### o2 — alternativa EN

Original

```text
Test policy
```

Proposto atual — sem alteração

```text
Test policy
```

### o2 — explicação EN

Original

```text
A policy provides organizational direction. The project test plan communicates the specific scope, resources and approach for this testing effort.
```

Proposto atual — sem alteração

```text
A policy provides organizational direction. The project test plan communicates the specific scope, resources and approach for this testing effort.
```

### o3 — alternativa PT

Original

```text
Cronograma de execução de testes
```

Proposto atual — sem alteração

```text
Cronograma de execução de testes
```

### o3 — explicação PT

Original

```text
Um cronograma de execução organiza execuções e dependências. Não reúne os objetivos, o âmbito, os recursos e a abordagem de teste do projeto como um plano de testes.
```

Proposto atual — sem alteração

```text
Um cronograma de execução organiza execuções e dependências. Não reúne os objetivos, o âmbito, os recursos e a abordagem de teste do projeto como um plano de testes.
```

### o3 — alternativa EN

Original

```text
Test execution schedule
```

Proposto atual — sem alteração

```text
Test execution schedule
```

### o3 — explicação EN

Original

```text
An execution schedule arranges test runs and dependencies. It does not bring together the project test objectives, scope, resources and approach as a test plan does.
```

Proposto atual — sem alteração

```text
An execution schedule arranges test runs and dependencies. It does not bring together the project test objectives, scope, resources and approach as a test plan does.
```

### o4 — alternativa PT

Original

```text
Relatório de conclusão do teste
```

Proposto atual — sem alteração

```text
Relatório de conclusão do teste
```

### o4 — explicação PT

Original

```text
Um relatório de conclusão resume os resultados dos testes concluídos. Não é o documento de planeamento usado para acordar como serão organizados os testes do projeto.
```

Proposto atual — sem alteração

```text
Um relatório de conclusão resume os resultados dos testes concluídos. Não é o documento de planeamento usado para acordar como serão organizados os testes do projeto.
```

### o4 — alternativa EN

Original

```text
Test completion report
```

Proposto atual — sem alteração

```text
Test completion report
```

### o4 — explicação EN

Original

```text
A completion report summarizes the outcomes of completed testing. It is not the planning document used to agree how the project testing will be organized.
```

Proposto atual — sem alteração

```text
A completion report summarizes the outcomes of completed testing. It is not the planning document used to agree how the project testing will be organized.
```

### Explicação geral PT

Original

```text
Um plano de testes comunica objetivos, âmbito, recursos e processos de teste específicos do projeto. Reúne esses acordos; uma política, um cronograma de execução ou um relatório de conclusão têm finalidades diferentes.
```

Proposto atual — sem alteração

```text
Um plano de testes comunica objetivos, âmbito, recursos e processos de teste específicos do projeto. Reúne esses acordos; uma política, um cronograma de execução ou um relatório de conclusão têm finalidades diferentes.
```

### Explicação geral EN

Original

```text
A test plan communicates project-specific test objectives, scope, resources and processes. It brings these agreements together; a policy, execution schedule or completion report has a different purpose.
```

Proposto atual — sem alteração

```text
A test plan communicates project-specific test objectives, scope, resources and processes. It brings these agreements together; a policy, execution schedule or completion report has a different purpose.
```

## Análise das quatro alternativas

### o1 — correta

Correta: o plano consolida o âmbito, os recursos e a abordagem específicos deste projeto.

A project-level test plan combines the agreed scope, resources and approach and guides the work; this is the complete need described.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta: política informa o plano, mas não é o acordo específico ao nível do projeto pedido.

A test policy supplies higher-level organizational direction. It can inform the project plan but is not the project-specific consolidation requested.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta: cronograma pode integrar o plano, mas ordem e dependências de execução não esgotam os acordos.

An execution schedule orders and times execution. It may be included in a plan, but does not by itself supply all agreed scope/resources/approach.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: conclusão é síntese posterior, não documento de planeamento que reúne como os testes serão organizados.

A completion report summarizes completed testing rather than being the prospective agreement governing the project work.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | True | 1 | ['o1'] | 7a09777042db9519bd46f7ee1c2884fbb8d551ffed7881b9224dcb6a15dcc0ed |
| 2026-10-27.2 | True | 2 | ['o1'] | 077099ff02a2228f385805a462574764d6c86058d02e079ca95dcbb3f0c9fe35 |
| 2026-10-27.3 | True | 2 | ['o1'] | 077099ff02a2228f385805a462574764d6c86058d02e079ca95dcbb3f0c9fe35 |
| 2026-10-27.4 | True | 2 | ['o1'] | 077099ff02a2228f385805a462574764d6c86058d02e079ca95dcbb3f0c9fe35 |
| 2026-10-27.5 | True | 2 | ['o1'] | 077099ff02a2228f385805a462574764d6c86058d02e079ca95dcbb3f0c9fe35 |
| 2026-10-27.6 | True | 2 | ['o1'] | 077099ff02a2228f385805a462574764d6c86058d02e079ca95dcbb3f0c9fe35 |
| 2026-10-27.7 | True | 3 | ['o1'] | 0def0fa4d9038c8059cd8ad5d0f5d7b3c43ba08bcfbb23f345f6adf682b9c1e0 |
| 2026-10-27.8 | True | 3 | ['o1'] | 0def0fa4d9038c8059cd8ad5d0f5d7b3c43ba08bcfbb23f345f6adf682b9c1e0 |
| 2026-10-27.9 | True | 3 | ['o1'] | 0def0fa4d9038c8059cd8ad5d0f5d7b3c43ba08bcfbb23f345f6adf682b9c1e0 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-034 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.2.3 / K2; versão 2; revisão 2026-10-27.10; SHA-256 canónico `176b0c0fd90712ddaf00158b871ce4ed8a4b769d54cf1f86607539a81d713ca7`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

O cenário já estabelece probabilidades comparáveis e impacto muito maior das transferências. A resposta que usa as duas dimensões e direciona maior profundidade para as transferências aplica a análise de risco à intensidade dos testes. Não pede um score numérico nem uma ordem absoluta para toda execução.

Reasoning recorded before revealing the key:

Com probabilidade comparável, impacto muito maior implica maior risco de produto das transferências. Atribuir maior profundidade de testes responde ao risco. Notoriedade ou rapidez de verificação não substituem a análise de impacto e probabilidade; não se pede fórmula numérica nem só ordenar execuções.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 5.2.3: EN páginas [52, 53]; PT páginas [58, 59].
- Secção 5.2.1: EN páginas [52]; PT páginas [57].

- LO FL-5.2.3/K2: EN página 47; PT página 52.

EN pp.52–53 e PT pp.58–59 associam análise a profundidade, âmbito, cobertura e esforço. A fórmula quantitativa existe no syllabus, mas não é imposta a uma comparação qualitativa sem números. O risco residual é um objetivo de gestão, não garantia de eliminação de todo risco.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Comparable estimated likelihood/probabilidades estimadas comparáveis conserva incerteza e comparação. Much higher impact/impacto muito superior não é omitido. Deeper testing/testes mais aprofundados refere profundidade, e não apenas prioridade temporal. Split effort equally/dividir o esforço igualmente ignora o impacto em ambas as línguas.

| EN literal | PT literal |
| --- | --- |
| comparable estimated likelihood | probabilidades estimadas comparáveis |
| much higher impact | impacto muito superior |
| deeper testing | testes mais aprofundados |

## Contraexemplos e segunda resposta plausível

Uma verificação visual rápida pode ser executada primeiro por conveniência e visibilidade pode contribuir para impacto. Contudo, não substitui a avaliação explícita que atribui impacto muito maior às transferências. Comparable é avaliação qualitativa, não igualdade matemática exata; sem números não se calcula rácio ou ótimo global de esforço. O item não pede ignorar o risco visual nem testar só transferências.

## Adequação ao LO, K e pedagogia

K2: explicar como a avaliação altera esforço e profundidade é apropriado. Não exige cálculo K3 ou desenho de um plano de mitigação completo. Explicação geral breve mas correta, apoiada pelas justificações de o2–o4 que distinguem rapidez, visibilidade e duas dimensões de risco.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Transferências incorretas e um desalinhamento visual têm probabilidades estimadas comparáveis, mas as transferências incorretas têm impacto muito superior. Que escolha baseia melhor o esforço de teste no risco de produto avaliado?
```

Proposto atual — sem alteração

```text
Transferências incorretas e um desalinhamento visual têm probabilidades estimadas comparáveis, mas as transferências incorretas têm impacto muito superior. Que escolha baseia melhor o esforço de teste no risco de produto avaliado?
```

### Enunciado EN

Original

```text
Incorrect transfers and a cosmetic alignment issue have comparable estimated likelihood, but incorrect transfers have much higher impact. Which choice best bases test effort on the assessed product risk?
```

Proposto atual — sem alteração

```text
Incorrect transfers and a cosmetic alignment issue have comparable estimated likelihood, but incorrect transfers have much higher impact. Which choice best bases test effort on the assessed product risk?
```

### o1 — alternativa PT

Original

```text
Atribuir testes mais aprofundados às transferências, considerando a probabilidade e o impacto
```

Proposto atual — sem alteração

```text
Atribuir testes mais aprofundados às transferências, considerando a probabilidade e o impacto
```

### o1 — explicação PT

Original

```text
A análise de risco orienta esforço e âmbito; impacto e probabilidade contam.
```

Proposto atual — sem alteração

```text
A análise de risco orienta esforço e âmbito; impacto e probabilidade contam.
```

### o1 — alternativa EN

Original

```text
Allocate deeper testing to transfers, considering their likelihood and impact
```

Proposto atual — sem alteração

```text
Allocate deeper testing to transfers, considering their likelihood and impact
```

### o1 — explicação EN

Original

```text
Risk analysis guides effort and scope; both impact and likelihood matter.
```

Proposto atual — sem alteração

```text
Risk analysis guides effort and scope; both impact and likelihood matter.
```

### o2 — alternativa PT

Original

```text
Dar prioridade ao problema visual porque os utilizadores o notam imediatamente
```

Proposto atual — sem alteração

```text
Dar prioridade ao problema visual porque os utilizadores o notam imediatamente
```

### o2 — explicação PT

Original

```text
A visibilidade, por si só, não é o nível de risco avaliado. Com probabilidades comparáveis, o impacto muito superior das transferências incorretas exige testes mais aprofundados.
```

Proposto atual — sem alteração

```text
A visibilidade, por si só, não é o nível de risco avaliado. Com probabilidades comparáveis, o impacto muito superior das transferências incorretas exige testes mais aprofundados.
```

### o2 — alternativa EN

Original

```text
Prioritize the visual issue because users notice it immediately
```

Proposto atual — sem alteração

```text
Prioritize the visual issue because users notice it immediately
```

### o2 — explicação EN

Original

```text
Visibility alone is not the assessed risk level. With comparable likelihood, the much higher impact of incorrect transfers calls for deeper testing.
```

Proposto atual — sem alteração

```text
Visibility alone is not the assessed risk level. With comparable likelihood, the much higher impact of incorrect transfers calls for deeper testing.
```

### o3 — alternativa PT

Original

```text
Dar prioridade ao problema visual porque é mais rápido de verificar
```

Proposto atual — sem alteração

```text
Dar prioridade ao problema visual porque é mais rápido de verificar
```

### o3 — explicação PT

Original

```text
A rapidez de execução pode afetar o planeamento, mas não se sobrepõe ao risco de produto superior indicado ao decidir a profundidade dos testes.
```

Proposto atual — sem alteração

```text
A rapidez de execução pode afetar o planeamento, mas não se sobrepõe ao risco de produto superior indicado ao decidir a profundidade dos testes.
```

### o3 — alternativa EN

Original

```text
Prioritize the visual issue because it is quicker to verify
```

Proposto atual — sem alteração

```text
Prioritize the visual issue because it is quicker to verify
```

### o3 — explicação EN

Original

```text
Execution speed can affect scheduling, but it does not outweigh the stated higher product risk when deciding test thoroughness.
```

Proposto atual — sem alteração

```text
Execution speed can affect scheduling, but it does not outweigh the stated higher product risk when deciding test thoroughness.
```

### o4 — alternativa PT

Original

```text
Tratar probabilidades comparáveis como riscos comparáveis e dividir o esforço igualmente
```

Proposto atual — sem alteração

```text
Tratar probabilidades comparáveis como riscos comparáveis e dividir o esforço igualmente
```

### o4 — explicação PT

Original

```text
O nível de risco considera a probabilidade e o impacto. Probabilidades comparáveis não implicam riscos comparáveis quando os impactos diferem substancialmente.
```

Proposto atual — sem alteração

```text
O nível de risco considera a probabilidade e o impacto. Probabilidades comparáveis não implicam riscos comparáveis quando os impactos diferem substancialmente.
```

### o4 — alternativa EN

Original

```text
Treat comparable likelihood as comparable risk and split effort equally
```

Proposto atual — sem alteração

```text
Treat comparable likelihood as comparable risk and split effort equally
```

### o4 — explicação EN

Original

```text
Risk level considers both likelihood and impact. Comparable likelihood does not imply comparable risk when the impacts differ substantially.
```

Proposto atual — sem alteração

```text
Risk level considers both likelihood and impact. Comparable likelihood does not imply comparable risk when the impacts differ substantially.
```

### Explicação geral PT

Original

```text
A análise de risco orienta esforço e âmbito; impacto e probabilidade contam.
```

Proposto atual — sem alteração

```text
A análise de risco orienta esforço e âmbito; impacto e probabilidade contam.
```

### Explicação geral EN

Original

```text
Risk analysis guides effort and scope; both impact and likelihood matter.
```

Proposto atual — sem alteração

```text
Risk analysis guides effort and scope; both impact and likelihood matter.
```

## Análise das quatro alternativas

### o1 — correta

Correta: maior profundidade nas transferências decorre do risco avaliado usando impacto e probabilidade.

Deeper transfer testing follows the higher assessed product risk when likelihoods are comparable and impact is much higher. No exact quantitative risk score is needed.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta como base de esforço: ser notado imediatamente não contraria o impacto comparativo já dado.

Visibility can matter to impact, but the scenario already states the assessed transfer impact is much higher. Immediate notice alone does not overturn that risk assessment.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta como fundamento de profundidade: rapidez pode afetar ordem, mas não elimina a necessidade de maior intensidade no risco superior.

Quick checks may be scheduled opportunistically, but speed of verification alone does not justify allocating risk-based depth away from transfers.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: probabilidade comparável não implica risco comparável quando o impacto difere muito.

Equal or comparable likelihood is not equal risk when impact differs substantially; equal allocation ignores one explicitly assessed dimension.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | True | 1 | ['o1'] | 731347dce99d1a40141f50a57a997d910d8150dc83d6a4e93dd75557f2d4b753 |
| 2026-10-27.2 | True | 1 | ['o1'] | 4587ca916fb9d18785a018f19b1041f7b20afda541f8084ae6def60574989f8e |
| 2026-10-27.3 | True | 1 | ['o1'] | 4587ca916fb9d18785a018f19b1041f7b20afda541f8084ae6def60574989f8e |
| 2026-10-27.4 | True | 1 | ['o1'] | 4587ca916fb9d18785a018f19b1041f7b20afda541f8084ae6def60574989f8e |
| 2026-10-27.5 | True | 1 | ['o1'] | 4587ca916fb9d18785a018f19b1041f7b20afda541f8084ae6def60574989f8e |
| 2026-10-27.6 | True | 1 | ['o1'] | 4587ca916fb9d18785a018f19b1041f7b20afda541f8084ae6def60574989f8e |
| 2026-10-27.7 | True | 2 | ['o1'] | 176b0c0fd90712ddaf00158b871ce4ed8a4b769d54cf1f86607539a81d713ca7 |
| 2026-10-27.8 | True | 2 | ['o1'] | 176b0c0fd90712ddaf00158b871ce4ed8a4b769d54cf1f86607539a81d713ca7 |
| 2026-10-27.9 | True | 2 | ['o1'] | 176b0c0fd90712ddaf00158b871ce4ed8a4b769d54cf1f86607539a81d713ca7 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-039 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-6.1.1 / K2; versão 2; revisão 2026-10-27.10; SHA-256 canónico `593a5bd756107b0387eb6803ca9e06a2fa38d9a4f47014c969f5381dbfe4692f`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

A ferramenta deve gerar milhares de pedidos concorrentes e medir a latência nessa carga controlada. Teste de carga satisfaz a necessidade conjunta; monitorização sozinha pode observar tempos, mas não substitui o gerador. Análise estática e gestão não executam esse ensaio por si.

Reasoning recorded before revealing the key:

A necessidade é dupla: gerar milhares de pedidos simultâneos e medir a latência nessa carga. Ferramenta de teste de carga responde às duas. Monitorização pode medir latência mas não gera por si a carga requerida; análise estática não executa a carga; gestão de testes organiza informação.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 6.1: EN páginas [59]; PT páginas [65].

- LO FL-6.1.1/K2: EN página 58; PT página 64.

EN p.59 e PT p.65 listam suporte não funcional, gestão e análise estática. Não declaram que as categorias sejam mutuamente exclusivas em todo produto. A distinção entre gerar carga e observar tráfego é fundamentação aplicada ao cenário; não se alega consulta separada ao glossário ou prova empírica de ferramentas.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Generate/gerar e measure/medir permanecem requisitos cumulativos. Thousands/milhares, simultaneous/simultâneos e under that generated load/sob essa carga gerada conservam escala, concorrência e contexto. Latency/latência é tempo de resposta, não contagem de pedidos ou cobertura de código. Against/contra é expressão técnica compreensível para dirigir pedidos ao ambiente, sem dimensão de ataque.

| EN literal | PT literal |
| --- | --- |
| generate thousands of simultaneous requests | gerar milhares de pedidos simultâneos |
| measure response latency | medir a latência de resposta |
| under that generated load | sob essa carga gerada |

## Contraexemplos e segunda resposta plausível

Produtos comerciais podem combinar monitorização, testes sintéticos e geração de carga; ferramentas funcionais podem ser orquestradas em paralelo. O cenário pede o tipo mais adequado à função dupla, não um julgamento sobre todas as marcas ou uma proibição de integrar ferramentas. Uma ferramenta de monitorização com módulo de carga precisaria justamente dessa capacidade adicional.

## Adequação ao LO, K e pedagogia

K2: explicar suporte de ferramentas através de uma necessidade concreta é adequado. A explicação geral é sucinta mas os distratores explicitam as duas capacidades. O syllabus 6.1 fornece categorias de ferramentas não funcionais e limitações de teste manual; a escolha específica carga versus observação é aplicação técnica do revisor, não uma citação de exemplos de marcas que o syllabus não enumera. Não foi executada carga real.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Uma equipa tem de gerar milhares de pedidos simultâneos contra um ambiente de teste e medir a latência de resposta sob essa carga gerada. Que ferramenta é mais adequada?
```

Proposto atual — sem alteração

```text
Uma equipa tem de gerar milhares de pedidos simultâneos contra um ambiente de teste e medir a latência de resposta sob essa carga gerada. Que ferramenta é mais adequada?
```

### Enunciado EN

Original

```text
A team must generate thousands of simultaneous requests against a test environment and measure response latency under that generated load. Which tool fits best?
```

Proposto atual — sem alteração

```text
A team must generate thousands of simultaneous requests against a test environment and measure response latency under that generated load. Which tool fits best?
```

### o1 — alternativa PT

Original

```text
Ferramenta de teste de carga
```

Proposto atual — sem alteração

```text
Ferramenta de teste de carga
```

### o1 — explicação PT

Original

```text
As ferramentas de carga geram tráfego e medem desempenho.
```

Proposto atual — sem alteração

```text
As ferramentas de carga geram tráfego e medem desempenho.
```

### o1 — alternativa EN

Original

```text
Load testing tool
```

Proposto atual — sem alteração

```text
Load testing tool
```

### o1 — explicação EN

Original

```text
Load tools generate traffic and measure performance.
```

Proposto atual — sem alteração

```text
Load tools generate traffic and measure performance.
```

### o2 — alternativa PT

Original

```text
Ferramenta de análise estática
```

Proposto atual — sem alteração

```text
Ferramenta de análise estática
```

### o2 — explicação PT

Original

```text
A análise estática examina código sem executar o serviço. Não gera o tráfego concorrente solicitado nem mede a latência sob esse tráfego.
```

Proposto atual — sem alteração

```text
A análise estática examina código sem executar o serviço. Não gera o tráfego concorrente solicitado nem mede a latência sob esse tráfego.
```

### o2 — alternativa EN

Original

```text
Static analysis tool
```

Proposto atual — sem alteração

```text
Static analysis tool
```

### o2 — explicação EN

Original

```text
Static analysis examines code without executing the service. It does not generate the requested concurrent traffic or measure latency under that traffic.
```

Proposto atual — sem alteração

```text
Static analysis examines code without executing the service. It does not generate the requested concurrent traffic or measure latency under that traffic.
```

### o3 — alternativa PT

Original

```text
Ferramenta de monitorização de aplicações
```

Proposto atual — sem alteração

```text
Ferramenta de monitorização de aplicações
```

### o3 — explicação PT

Original

```text
A monitorização pode observar a latência do tráfego existente, mas o requisito inclui gerar ativamente pedidos concorrentes controlados contra um ambiente de teste.
```

Proposto atual — sem alteração

```text
A monitorização pode observar a latência do tráfego existente, mas o requisito inclui gerar ativamente pedidos concorrentes controlados contra um ambiente de teste.
```

### o3 — alternativa EN

Original

```text
Application monitoring tool
```

Proposto atual — sem alteração

```text
Application monitoring tool
```

### o3 — explicação EN

Original

```text
Monitoring can observe latency from existing traffic, but the requirement includes actively generating controlled concurrent requests against a test environment.
```

Proposto atual — sem alteração

```text
Monitoring can observe latency from existing traffic, but the requirement includes actively generating controlled concurrent requests against a test environment.
```

### o4 — alternativa PT

Original

```text
Ferramenta de gestão de testes
```

Proposto atual — sem alteração

```text
Ferramenta de gestão de testes
```

### o4 — explicação PT

Original

```text
A gestão de testes organiza planos, casos e resultados. A sua função principal não é gerar carga concorrente num serviço nem medir o desempenho em execução.
```

Proposto atual — sem alteração

```text
A gestão de testes organiza planos, casos e resultados. A sua função principal não é gerar carga concorrente num serviço nem medir o desempenho em execução.
```

### o4 — alternativa EN

Original

```text
Test management tool
```

Proposto atual — sem alteração

```text
Test management tool
```

### o4 — explicação EN

Original

```text
Test management organizes plans, cases and results. Its primary role is not generating concurrent service load and measuring runtime performance.
```

Proposto atual — sem alteração

```text
Test management organizes plans, cases and results. Its primary role is not generating concurrent service load and measuring runtime performance.
```

### Explicação geral PT

Original

```text
As ferramentas de carga geram tráfego e medem desempenho.
```

Proposto atual — sem alteração

```text
As ferramentas de carga geram tráfego e medem desempenho.
```

### Explicação geral EN

Original

```text
Load tools generate traffic and measure performance.
```

Proposto atual — sem alteração

```text
Load tools generate traffic and measure performance.
```

## Análise das quatro alternativas

### o1 — correta

Correta: uma ferramenta de carga gera tráfego controlado e recolhe medições sob essa carga.

A load-testing tool is designed to generate concurrent load and collect timing/latency results under that load, meeting both required functions.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta: inspeção estática sem execução do serviço não gera tráfego concorrente nem mede esta latência em execução.

Static analysis inspects artifacts without executing the loaded system; it cannot supply the generated concurrent traffic and runtime latency measurement requested.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta como resposta isolada: monitorizar latência não cumpre também a geração controlada de milhares de pedidos.

Application monitoring can observe latency and resources under existing traffic, but monitoring alone does not necessarily create thousands of simultaneous requests. A combined suite would need a load generator.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: gestão organiza planos/casos/resultados; integrar uma ferramenta de carga não faz a gestão isolada executar o requisito.

Test management records and coordinates testing work and results. Integrating with a load generator does not make management alone the tool that produces this load and measures it.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | True | 1 | ['o1'] | b214e20991bd8247a1e81267d9ecf7a9acae2254f85284ffa47f23bc3e650948 |
| 2026-10-27.2 | True | 1 | ['o1'] | 325173bf62e832ea23b28428300ef84f5019c550d6ba171dfdf0b5e474d29799 |
| 2026-10-27.3 | True | 1 | ['o1'] | 325173bf62e832ea23b28428300ef84f5019c550d6ba171dfdf0b5e474d29799 |
| 2026-10-27.4 | True | 1 | ['o1'] | 325173bf62e832ea23b28428300ef84f5019c550d6ba171dfdf0b5e474d29799 |
| 2026-10-27.5 | True | 1 | ['o1'] | 325173bf62e832ea23b28428300ef84f5019c550d6ba171dfdf0b5e474d29799 |
| 2026-10-27.6 | True | 1 | ['o1'] | 325173bf62e832ea23b28428300ef84f5019c550d6ba171dfdf0b5e474d29799 |
| 2026-10-27.7 | True | 2 | ['o1'] | 593a5bd756107b0387eb6803ca9e06a2fa38d9a4f47014c969f5381dbfe4692f |
| 2026-10-27.8 | True | 2 | ['o1'] | 593a5bd756107b0387eb6803ca9e06a2fa38d9a4f47014c969f5381dbfe4692f |
| 2026-10-27.9 | True | 2 | ['o1'] | 593a5bd756107b0387eb6803ca9e06a2fa38d9a4f47014c969f5381dbfe4692f |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-042 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.4.3 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735`.

Resposta independente `['o1']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o1']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

Na análise identificam-se condições priorizadas que exprimem o que testar e a sua base. O enunciado exclui explicitamente casos e scripts já escritos. Casos detalham verificações na conceção; scripts implementam; relatório de conclusão resume trabalho terminado. Ordem por risco não converte a lista em casos detalhados.

Reasoning recorded before revealing the key:

Identificar o que testar a partir dos requisitos, antes de casos e scripts, produz condições de teste priorizadas e rastreáveis. Casos detalham como verificar; scripts implementam; conclusão relata trabalho terminado. A ordenação por risco não converte condições num plano completo.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 1.4.3: EN páginas [20]; PT páginas [22].

- LO FL-1.4.3/K2: EN página 14; PT página 15.

EN p.20 e PT p.22 listam condições de análise, casos de conceção e scripts de implementação. EN explicita scripts manuais e automatizados na lista de testware; a lista PT de implementação realça automatizados. A alternativa trata scripts de automação, não há conflito que altere a chave.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

What needs testing/o que deve ser testado conserva o nível de abstração. No test cases or scripts/ainda não foram escritos casos nem scripts preserva a exclusão. Prioritised/priorizadas e linked/ligadas mantêm prioridade e rastreabilidade. Não se confundem produtos de trabalho com fases rígidas irreversíveis.

| EN literal | PT literal |
| --- | --- |
| what needs testing | o que deve ser testado |
| No test cases or scripts | Ainda não foram escritos casos de teste nem scripts |
| Prioritised test conditions | Condições de teste priorizadas |

## Contraexemplos e segunda resposta plausível

Num processo iterativo, análise e conceção podem sobrepor-se e algumas equipas usam nomenclaturas diferentes. Essa flexibilidade não anula a premissa de que ainda não foram escritos casos/scripts e se regista o que testar. Condições podem incluir critérios de aceitação; não precisam já conter todos os dados e resultados esperados de cada caso.

## Adequação ao LO, K e pedagogia

K2: distinguir testware pela atividade/finalidade é adequado. A pista explícita de ausência de casos reduz dificuldade, sem invalidar a diferenciação. A explicação geral mapeia as quatro alternativas e evita a falsa ideia de que uma condição equivale a um script executável.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Um testador analisa requisitos de reservas e regista o que deve ser testado, ordenado por risco. Ainda não foram escritos casos de teste nem scripts. Que produto de trabalho melhor representa o resultado desta análise?
```

Proposto atual — sem alteração

```text
Um testador analisa requisitos de reservas e regista o que deve ser testado, ordenado por risco. Ainda não foram escritos casos de teste nem scripts. Que produto de trabalho melhor representa o resultado desta análise?
```

### Enunciado EN

Original

```text
A tester analyses booking requirements and records what needs testing, ordered by risk. No test cases or scripts have been written yet. Which work product best represents the output of this analysis?
```

Proposto atual — sem alteração

```text
A tester analyses booking requirements and records what needs testing, ordered by risk. No test cases or scripts have been written yet. Which work product best represents the output of this analysis?
```

### o1 — alternativa PT

Original

```text
Condições de teste priorizadas e ligadas aos requisitos.
```

Proposto atual — sem alteração

```text
Condições de teste priorizadas e ligadas aos requisitos.
```

### o1 — explicação PT

Original

```text
A análise de teste produz condições de teste, identificando o que testar e relacionando-o com a base para testes.
```

Proposto atual — sem alteração

```text
A análise de teste produz condições de teste, identificando o que testar e relacionando-o com a base para testes.
```

### o1 — alternativa EN

Original

```text
Prioritised test conditions linked to the requirements.
```

Proposto atual — sem alteração

```text
Prioritised test conditions linked to the requirements.
```

### o1 — explicação EN

Original

```text
Test analysis produces test conditions, identifying what to test and relating it to the test basis.
```

Proposto atual — sem alteração

```text
Test analysis produces test conditions, identifying what to test and relating it to the test basis.
```

### o2 — alternativa PT

Original

```text
Scripts de automação executáveis para o fluxo de reservas.
```

Proposto atual — sem alteração

```text
Scripts de automação executáveis para o fluxo de reservas.
```

### o2 — explicação PT

Original

```text
Os scripts são produtos de trabalho da implementação do teste, não o resultado da análise descrita.
```

Proposto atual — sem alteração

```text
Os scripts são produtos de trabalho da implementação do teste, não o resultado da análise descrita.
```

### o2 — alternativa EN

Original

```text
Executable automation scripts for the booking workflow.
```

Proposto atual — sem alteração

```text
Executable automation scripts for the booking workflow.
```

### o2 — explicação EN

Original

```text
Scripts are test implementation work products, not the described analysis output.
```

Proposto atual — sem alteração

```text
Scripts are test implementation work products, not the described analysis output.
```

### o3 — alternativa PT

Original

```text
Um relatório de conclusão do teste com resultados arquivados.
```

Proposto atual — sem alteração

```text
Um relatório de conclusão do teste com resultados arquivados.
```

### o3 — explicação PT

Original

```text
Um relatório de conclusão resume testes concluídos; o cenário ainda está na análise dos requisitos.
```

Proposto atual — sem alteração

```text
Um relatório de conclusão resume testes concluídos; o cenário ainda está na análise dos requisitos.
```

### o3 — alternativa EN

Original

```text
A test completion report with archived results.
```

Proposto atual — sem alteração

```text
A test completion report with archived results.
```

### o3 — explicação EN

Original

```text
A completion report summarises completed testing; the scenario is still analysing requirements.
```

Proposto atual — sem alteração

```text
A completion report summarises completed testing; the scenario is still analysing requirements.
```

### o4 — alternativa PT

Original

```text
Casos de teste detalhados com dados de entrada e resultados esperados.
```

Proposto atual — sem alteração

```text
Casos de teste detalhados com dados de entrada e resultados esperados.
```

### o4 — explicação PT

Original

```text
Concretizar condições em casos de teste é conceção de teste, explicitamente ainda não realizada neste cenário.
```

Proposto atual — sem alteração

```text
Concretizar condições em casos de teste é conceção de teste, explicitamente ainda não realizada neste cenário.
```

### o4 — alternativa EN

Original

```text
Detailed test cases with input data and expected results.
```

Proposto atual — sem alteração

```text
Detailed test cases with input data and expected results.
```

### o4 — explicação EN

Original

```text
Elaborating conditions into test cases is test design, explicitly not yet performed here.
```

Proposto atual — sem alteração

```text
Elaborating conditions into test cases is test design, explicitly not yet performed here.
```

### Explicação geral PT

Original

```text
O resultado descrito é um conjunto priorizado de condições de teste. Os casos de teste pertencem à conceção, os scripts à implementação e os relatórios de conclusão à conclusão.
```

Proposto atual — sem alteração

```text
O resultado descrito é um conjunto priorizado de condições de teste. Os casos de teste pertencem à conceção, os scripts à implementação e os relatórios de conclusão à conclusão.
```

### Explicação geral EN

Original

```text
The described output is a prioritised set of test conditions. Test cases belong to design, scripts to implementation, and completion reports to completion.
```

Proposto atual — sem alteração

```text
The described output is a prioritised set of test conditions. Test cases belong to design, scripts to implementation, and completion reports to completion.
```

## Análise das quatro alternativas

### o1 — correta

Correta: condições priorizadas são produto de análise que identifica o que testar e mantém ligação à base.

Prioritized test conditions express what needs testing during analysis and connect it to the requirements; this matches the explicitly stated stage.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta: scripts são implementação e o cenário diz que ainda não existem.

Executable scripts are implementation work products, explicitly not written yet; the scenario has analysis rather than automation ready to run.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — distrator

Incorreta: não há trabalho concluído nem resultados arquivados no cenário de análise inicial.

A completion report is produced at completion and summarizes results; no completed test campaign or archived results are stated.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: casos detalhados são conceção e foram explicitamente excluídos do estado atual.

Detailed cases with inputs and expected results are design work products and explicitly not yet written. Do not confuse a condition with a fully specified case.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.4 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.5 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.6 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.7 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.8 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |
| 2026-10-27.9 | True | 1 | ['o1'] | 3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-043 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.6 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8`.

Resposta independente `['o3']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o3']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

Revisões antecipadas acordadas, responsabilidade pela ação e verificação na iteração seguinte tornam a observação numa melhoria executável e avaliável. O seguimento importa; registar passivamente, classificar indivíduos ou excluir mudanças do processo não responde ao problema recorrente.

Reasoning recorded before revealing the key:

Uma melhoria concreta deve ser acordada, ter responsabilidade de implementação e seguimento para avaliar efeito. Revisões de interface mais cedo com verificação na próxima iteração satisfazem isso. Arquivar sem seguimento, culpabilizar indivíduos ou excluir melhoria do processo não resolve o objetivo.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 2.1.6: EN páginas [28]; PT páginas [30].

- LO FL-2.1.6/K2: EN página 24; PT página 26.

EN p.28 e PT p.30 pedem discutir sucessos/melhorias e acompanhar recomendações, com participação além de testadores. Dono da ação e próxima iteração são implementação plausível no cenário, não campos normativos obrigatórios citados do syllabus.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Agree/acordar, assign responsibility/atribuir responsabilidades e check the outcome/verificar o resultado conservam decisão, execução responsável e avaliação. Next iteration/iteração seguinte é o momento proposto no exercício, não periodicidade universal. Rank individual testers/classificar individualmente torna a alternativa o2 diferente de acompanhamento de ações.

| EN literal | PT literal |
| --- | --- |
| recurring problem | problema recorrente |
| assign responsibility | atribuir responsabilidades |
| check the outcome in the next iteration | verificar o resultado na iteração seguinte |

## Contraexemplos e segunda resposta plausível

A ação acordada pode revelar-se ineficaz e exigir outra adaptação; a opção não promete resolver definitivamente as interfaces. Corrigir defeitos atuais é útil, mas a restrição de o4 exclui o processo que gerou feedback tardio. Atribuir responsabilidade por uma ação não é culpabilizar pela falha anterior. O syllabus exige seguimento, não este calendário exato para todos os projetos.

## Adequação ao LO, K e pedagogia

K2: relacionar retrospetiva com melhoria concreta e seguimento é adequado. As alternativas negativas são claras e tornam a dificuldade baixa; isso não cria defeito obrigatório. Não é necessário definir métricas quantitativas ou um programa de melhoria inteiro para reconhecer a melhor ação.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
Numa retrospetiva de iteração, a equipa identifica o feedback tardio sobre interfaces como um problema recorrente. Que ação melhor transforma esta conclusão numa melhoria do processo?
```

Proposto atual — sem alteração

```text
Numa retrospetiva de iteração, a equipa identifica o feedback tardio sobre interfaces como um problema recorrente. Que ação melhor transforma esta conclusão numa melhoria do processo?
```

### Enunciado EN

Original

```text
At an iteration retrospective, the team identifies late interface feedback as a recurring problem. Which action best turns this finding into process improvement?
```

Proposto atual — sem alteração

```text
At an iteration retrospective, the team identifies late interface feedback as a recurring problem. Which action best turns this finding into process improvement?
```

### o1 — alternativa PT

Original

```text
Arquivar a sugestão sem verificar posteriormente se alguma coisa muda.
```

Proposto atual — sem alteração

```text
Arquivar a sugestão sem verificar posteriormente se alguma coisa muda.
```

### o1 — explicação PT

Original

```text
O registo, por si só, não assegura o acompanhamento da melhoria recomendada.
```

Proposto atual — sem alteração

```text
O registo, por si só, não assegura o acompanhamento da melhoria recomendada.
```

### o1 — alternativa EN

Original

```text
Archive the suggestion without checking later whether anything changes.
```

Proposto atual — sem alteração

```text
Archive the suggestion without checking later whether anything changes.
```

### o1 — explicação EN

Original

```text
Recording alone does not ensure that the recommended improvement is followed up.
```

Proposto atual — sem alteração

```text
Recording alone does not ensure that the recommended improvement is followed up.
```

### o2 — alternativa PT

Original

```text
Usar a retrospetiva para classificar individualmente os testadores pelo número de defeitos que não detetaram.
```

Proposto atual — sem alteração

```text
Usar a retrospetiva para classificar individualmente os testadores pelo número de defeitos que não detetaram.
```

### o2 — explicação PT

Original

```text
Culpabilizar pessoas não resolve o problema de processo identificado nem apoia a aprendizagem da equipa.
```

Proposto atual — sem alteração

```text
Culpabilizar pessoas não resolve o problema de processo identificado nem apoia a aprendizagem da equipa.
```

### o2 — alternativa EN

Original

```text
Use the retrospective to rank individual testers by the number of defects they missed.
```

Proposto atual — sem alteração

```text
Use the retrospective to rank individual testers by the number of defects they missed.
```

### o2 — explicação EN

Original

```text
Blaming individuals does not address the identified process issue or support team learning.
```

Proposto atual — sem alteração

```text
Blaming individuals does not address the identified process issue or support team learning.
```

### o3 — alternativa PT

Original

```text
Acordar revisões de interfaces mais cedo, atribuir responsabilidades e verificar o resultado na iteração seguinte.
```

Proposto atual — sem alteração

```text
Acordar revisões de interfaces mais cedo, atribuir responsabilidades e verificar o resultado na iteração seguinte.
```

### o3 — explicação PT

Original

```text
Isto torna a melhoria executável e permite acompanhá-la, apoiando a melhoria contínua.
```

Proposto atual — sem alteração

```text
Isto torna a melhoria executável e permite acompanhá-la, apoiando a melhoria contínua.
```

### o3 — alternativa EN

Original

```text
Agree on earlier interface reviews, assign responsibility, and check the outcome in the next iteration.
```

Proposto atual — sem alteração

```text
Agree on earlier interface reviews, assign responsibility, and check the outcome in the next iteration.
```

### o3 — explicação EN

Original

```text
This makes an improvement actionable and follows it up, supporting continuous improvement.
```

Proposto atual — sem alteração

```text
This makes an improvement actionable and follows it up, supporting continuous improvement.
```

### o4 — alternativa PT

Original

```text
Limitar a discussão à correção dos defeitos atuais das interfaces e excluir alterações ao processo de teste.
```

Proposto atual — sem alteração

```text
Limitar a discussão à correção dos defeitos atuais das interfaces e excluir alterações ao processo de teste.
```

### o4 — explicação PT

Original

```text
Corrigir defeitos do produto é útil, mas excluir alterações ao processo não cumpre o objetivo de melhoria da retrospetiva.
```

Proposto atual — sem alteração

```text
Corrigir defeitos do produto é útil, mas excluir alterações ao processo não cumpre o objetivo de melhoria da retrospetiva.
```

### o4 — alternativa EN

Original

```text
Restrict the discussion to fixing the current interface defects and exclude changes to the testing process.
```

Proposto atual — sem alteração

```text
Restrict the discussion to fixing the current interface defects and exclude changes to the testing process.
```

### o4 — explicação EN

Original

```text
Fixing product defects is useful, but excluding process changes misses the retrospective improvement objective.
```

Proposto atual — sem alteração

```text
Fixing product defects is useful, but excluding process changes misses the retrospective improvement objective.
```

### Explicação geral PT

Original

```text
Uma retrospetiva analisa o que funcionou, o que pode melhorar e como aplicar melhorias. As ações acordadas exigem acompanhamento, em vez de culpabilização ou arquivo passivo.
```

Proposto atual — sem alteração

```text
Uma retrospetiva analisa o que funcionou, o que pode melhorar e como aplicar melhorias. As ações acordadas exigem acompanhamento, em vez de culpabilização ou arquivo passivo.
```

### Explicação geral EN

Original

```text
A retrospective examines what worked, what can improve and how to apply improvements. Agreed actions require follow-up rather than blame or passive archiving.
```

Proposto atual — sem alteração

```text
A retrospective examines what worked, what can improve and how to apply improvements. Agreed actions require follow-up rather than blame or passive archiving.
```

## Análise das quatro alternativas

### o1 — distrator

Incorreta: registar sem seguimento não implementa nem avalia a melhoria proposta.

Archiving without follow-up preserves a note but does not implement or assess improvement of the recurring late-feedback problem.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta: classificar pessoas por defeitos não detetados não atua sobre o processo identificado nem promove aprendizagem.

Ranking individuals by missed defects shifts to blame and a weak metric, rather than addressing the identified recurring feedback-process issue. Accountability for actions is different.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — correta

Correta: acordo, responsabilidade e avaliação posterior concretizam melhoria sem assegurar antecipadamente o sucesso.

Earlier interface reviews, assigned responsibility and a next-iteration outcome check translate the finding into a concrete inspectable improvement, without guaranteeing success.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: corrigir produto é útil, mas excluir explicitamente mudanças no processo falha o objetivo da retrospetiva.

Fixing current interface defects is useful, but excluding process change prevents the requested improvement of the recurring late-feedback pattern.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.4 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.5 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.6 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.7 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.8 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |
| 2026-10-27.9 | True | 1 | ['o3'] | 70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


# tl-045 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.3.2 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79`.

Resposta independente `['o3']` registada em `2026-11-06T16:44:10.746392+00:00` antes da consulta do gabarito/explicações. Publicada: `['o3']`. Coincidência não é prova suficiente; fundamentos e contraexemplos são analisados abaixo.

## Resolução e fundamento

Durante testes em curso, decisões de recursos precisam de progresso face ao plano, impedimentos e riscos. O relatório de progresso com período, desvios e trabalho seguinte fornece essa visão; o nome do documento sem conteúdo relevante não basta. Um defeito isolado não agrega o necessário e a conclusão declarada em o1 contradiz o estado do cenário.

Reasoning recorded before revealing the key:

Durante a execução, a gestão precisa de progresso atual face ao plano, impedimentos, riscos e trabalho seguinte para ajustar recursos. O relatório de progresso completo fornece esse contexto; conclusão com critérios cumpridos contradiz o cenário; defeito único e totais sem riscos não bastam.

## Fontes oficiais, conceito e LO/K

ISTQB EN CTFL v4.0.1 (2024-09-15) e PT oficial v4.0 tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1. URLs, origem local e hashes em sources.json.
- Secção 5.3.2: EN páginas [54, 55]; PT páginas [60, 61].
- Secção 5.3: EN páginas [53, 54]; PT páginas [59].

- LO FL-5.3.2/K2: EN página 47; PT página 52.

EN pp.54–55 e PT pp.60–61 concordam na função e conteúdo. Na autoria, EN menciona equipa de teste e PT gestor de testes; o item pergunta o relatório para a gestão decidir, não impõe autor exclusivo. Ambos qualificam o cumprimento de critérios na conclusão como ideal, não garantia absoluta.

As secções foram efetivamente consultadas nesta execução. A aplicação ao cenário é raciocínio do revisor, não texto normativo adicional. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se declara igualdade textual das edições nem revisão humana certificada.

## Equivalência PT/EN

Still in progress/ainda em curso, behind plan/abaixo do planeado e remains untested/ainda não testada mantêm situação atual. Must decide/tem de decidir não impõe a decisão de aumentar recursos; apoia avaliar se ajusta. Without/sem em o4 preserva a falta deliberada dos dados críticos. All exit criteria/todos os critérios conserva a afirmação excessiva de o1.

| EN literal | PT literal |
| --- | --- |
| still in progress | ainda está em curso |
| all exit criteria have been met | todos os critérios de saída foram cumpridos |
| without plan deviations, impediments or risk information | sem desvios do plano, impedimentos ou informação sobre riscos |

## Contraexemplos e segunda resposta plausível

Um relatório de conclusão pode incluir riscos residuais e critérios não cumpridos numa atividade formalmente encerrada. Logo, não se exige ausência absoluta de riscos para toda conclusão. Aqui a atividade está em curso e o1 ainda declara todos os critérios cumpridos, sem evidência. Métricas individuais ou um defeito podem informar a gestão, mas as opções o2/o4 omitem explicitamente os dados necessários à decisão descrita.

## Adequação ao LO, K e pedagogia

K2: comparar finalidade e conteúdo dos relatórios para um público e decisão definidos é adequado. As duas opções com nome relatório de progresso evitam acerto apenas por rótulo. Explicações distinguem síntese agregada, controlo contínuo e momento de conclusão, sem garantir que o relatório por si resolva o bloqueio.

## Comparação integral original / proposto atual

Nenhuma alteração aplicada. Todos os campos PT/EN abaixo estão completos e o proposto atual é idêntico ao original.

### Enunciado PT

Original

```text
O teste de sistema ainda está em curso. A cobertura está abaixo do planeado, uma indisponibilidade do ambiente bloqueia o trabalho e uma área de risco elevado ainda não foi testada. A gestão tem de decidir se ajusta os recursos. Que relatório melhor apoia esta decisão?
```

Proposto atual — sem alteração

```text
O teste de sistema ainda está em curso. A cobertura está abaixo do planeado, uma indisponibilidade do ambiente bloqueia o trabalho e uma área de risco elevado ainda não foi testada. A gestão tem de decidir se ajusta os recursos. Que relatório melhor apoia esta decisão?
```

### Enunciado EN

Original

```text
System testing is still in progress. Coverage is behind plan, an environment outage blocks work, and a high-risk area remains untested. Management must decide whether to adjust resources. Which report best supports this decision?
```

Proposto atual — sem alteração

```text
System testing is still in progress. Coverage is behind plan, an environment outage blocks work, and a high-risk area remains untested. Management must decide whether to adjust resources. Which report best supports this decision?
```

### o1 — alternativa PT

Original

```text
Um relatório de conclusão que declara que o nível de teste terminou e todos os critérios de saída foram cumpridos.
```

Proposto atual — sem alteração

```text
Um relatório de conclusão que declara que o nível de teste terminou e todos os critérios de saída foram cumpridos.
```

### o1 — explicação PT

Original

```text
O nível está em curso e uma área importante não foi testada; declarar a conclusão contradiz a situação apresentada.
```

Proposto atual — sem alteração

```text
O nível está em curso e uma área importante não foi testada; declarar a conclusão contradiz a situação apresentada.
```

### o1 — alternativa EN

Original

```text
A completion report declaring that the test level has ended and all exit criteria have been met.
```

Proposto atual — sem alteração

```text
A completion report declaring that the test level has ended and all exit criteria have been met.
```

### o1 — explicação EN

Original

```text
The level is ongoing and an important area is untested; declaring completion contradicts the given situation.
```

Proposto atual — sem alteração

```text
The level is ongoing and an important area is untested; declaring completion contradicts the given situation.
```

### o2 — alternativa PT

Original

```text
Um relatório de defeito que descreve apenas uma falha observada na aplicação.
```

Proposto atual — sem alteração

```text
Um relatório de defeito que descreve apenas uma falha observada na aplicação.
```

### o2 — explicação PT

Original

```text
Um relatório de um único defeito não resume o progresso face ao plano, os impedimentos do ambiente e o risco de teste restante.
```

Proposto atual — sem alteração

```text
Um relatório de um único defeito não resume o progresso face ao plano, os impedimentos do ambiente e o risco de teste restante.
```

### o2 — alternativa EN

Original

```text
A defect report describing only one observed application failure.
```

Proposto atual — sem alteração

```text
A defect report describing only one observed application failure.
```

### o2 — explicação EN

Original

```text
A single defect report does not summarise progress against plan, environment impediments and the remaining test risk.
```

Proposto atual — sem alteração

```text
A single defect report does not summarise progress against plan, environment impediments and the remaining test risk.
```

### o3 — alternativa PT

Original

```text
Um relatório de progresso que apresenta o período reportado, os desvios do plano, os impedimentos, as alterações de risco e o trabalho seguinte planeado.
```

Proposto atual — sem alteração

```text
Um relatório de progresso que apresenta o período reportado, os desvios do plano, os impedimentos, as alterações de risco e o trabalho seguinte planeado.
```

### o3 — explicação PT

Original

```text
Os relatórios de progresso fornecem informação durante os testes para apoiar decisões de controlo, como alterar recursos ou calendário.
```

Proposto atual — sem alteração

```text
Os relatórios de progresso fornecem informação durante os testes para apoiar decisões de controlo, como alterar recursos ou calendário.
```

### o3 — alternativa EN

Original

```text
A progress report showing the reporting period, plan deviations, impediments, risk changes and planned next work.
```

Proposto atual — sem alteração

```text
A progress report showing the reporting period, plan deviations, impediments, risk changes and planned next work.
```

### o3 — explicação EN

Original

```text
Progress reports provide information during testing to support control decisions such as changing resources or schedule.
```

Proposto atual — sem alteração

```text
Progress reports provide information during testing to support control decisions such as changing resources or schedule.
```

### o4 — alternativa PT

Original

```text
Um relatório de progresso que lista totais de atividade individuais sem desvios do plano, impedimentos ou informação sobre riscos.
```

Proposto atual — sem alteração

```text
Um relatório de progresso que lista totais de atividade individuais sem desvios do plano, impedimentos ou informação sobre riscos.
```

### o4 — explicação PT

Original

```text
Os totais de atividade, por si só, omitem a evidência de que a gestão precisa para avaliar o problema de recursos e risco descrito.
```

Proposto atual — sem alteração

```text
Os totais de atividade, por si só, omitem a evidência de que a gestão precisa para avaliar o problema de recursos e risco descrito.
```

### o4 — alternativa EN

Original

```text
A progress report listing individual activity totals without plan deviations, impediments or risk information.
```

Proposto atual — sem alteração

```text
A progress report listing individual activity totals without plan deviations, impediments or risk information.
```

### o4 — explicação EN

Original

```text
Activity totals alone omit the evidence management needs to judge the stated resource and risk problem.
```

Proposto atual — sem alteração

```text
Activity totals alone omit the evidence management needs to judge the stated resource and risk problem.
```

### Explicação geral PT

Original

```text
Durante os testes em curso, um relatório de progresso comunica desvios, impedimentos e riscos para os stakeholders poderem tomar decisões de controlo. Um relatório de conclusão corresponde a outro momento do ciclo de teste.
```

Proposto atual — sem alteração

```text
Durante os testes em curso, um relatório de progresso comunica desvios, impedimentos e riscos para os stakeholders poderem tomar decisões de controlo. Um relatório de conclusão corresponde a outro momento do ciclo de teste.
```

### Explicação geral EN

Original

```text
During ongoing testing, a progress report communicates deviations, impediments and risks so stakeholders can make control decisions. A completion report serves a different point in the test lifecycle.
```

Proposto atual — sem alteração

```text
During ongoing testing, a progress report communicates deviations, impediments and risks so stakeholders can make control decisions. A completion report serves a different point in the test lifecycle.
```

## Análise das quatro alternativas

### o1 — distrator

Incorreta: declarar nível terminado e todos os critérios satisfeitos contradiz testes ainda em curso e sem encerramento autorizado.

Declaring completion and all exit criteria met contradicts ongoing testing, blocked work and an untested high-risk area; no authorized early closure is stated.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o2 — distrator

Incorreta como substituto: um único defeito não resume desvios, impedimentos e risco restante relevantes.

One defect report can provide useful detail but cannot substitute the aggregated progress, plan deviations, impediments and risk information needed for resource control.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o3 — correta

Correta: conteúdo do progresso permite controlo durante a execução e decisões de recursos/calendário.

An informative progress report gives the reporting period, deviations, blockers, risk changes and next work, supporting an in-progress resource decision.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

### o4 — distrator

Incorreta: chamar-lhe progresso não compensa omitir precisamente desvios, impedimentos e riscos.

The label progress report is insufficient: activity totals stripped of deviations, blockers and risks omit precisely the decision-relevant information in the scenario.

A explicação publicada é correta no cenário. A análise individual e as ressalvas do relatório limitam a sua leitura; não se transforma uma finalidade habitual em exclusividade ou garantia universal.

## Histórico preservado

| Revisão | Presente | Versão | Chave | Hash canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.4 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.5 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.6 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.7 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.8 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |
| 2026-10-27.9 | True | 1 | ['o3'] | ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79 |

Revisões ausentes não foram inventadas. Históricos são evidência de evolução, não mudanças deste lote.

## Problemas, dúvidas e propostas

Nenhum defeito académico obrigatório confirmado. Não ficou ambiguidade decisiva por resolver. Contraexemplos contextuais e dificuldade baixa não constituem, por si, defeitos. Não há proposta de alteração para produzir atividade artificial; as explicações existentes são suficientes no conjunto. Preferências de estilo sem impacto não foram promovidas a correções.

## Aprovações e limites

Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED atribuído. Revisão humana independente PENDING. A triagem NONE não foi fundamento da decisão. Avaliação qualitativa por IA, sem calibração empírica da dificuldade; verificações mecânicas não provam verdade académica. Fase 10H aberta. Parar após Lote 12, aguardar auditoria e não iniciar Lote 13.


