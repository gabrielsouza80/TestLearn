"""Read-only consistency/identity checks. Not automated semantic or human approval."""
import copy,hashlib,json,re,datetime
IDS=['tl-058', 'tl-059', 'tl-060', 'tl-061', 'tl-065', 'tl-066', 'tl-067', 'tl-068']
EXPECTED={'tl-058': ('FL-3.2.5', 'K1', 2, 'f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7'), 'tl-059': ('FL-4.3.3', 'K2', 1, '530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc'), 'tl-060': ('FL-4.4.3', 'K2', 1, 'fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba'), 'tl-061': ('FL-4.5.1', 'K2', 1, '76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271'), 'tl-065': ('FL-5.3.1', 'K1', 1, '04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1'), 'tl-066': ('FL-5.3.3', 'K2', 1, '828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f'), 'tl-067': ('FL-1.3.1', 'K2', 1, 'b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd'), 'tl-068': ('FL-2.1.2', 'K1', 1, '40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24')}
REFS={'tl-058': {'3.2.5': {'EN': [37], 'PT': [40]}, '3.2.4': {'EN': [36, 37], 'PT': [39, 40]}}, 'tl-059': {'4.3.3': {'EN': [43], 'PT': [47]}, '4.3.2': {'EN': [43], 'PT': [46, 47]}}, 'tl-060': {'4.4.3': {'EN': [44, 45], 'PT': [48, 49]}}, 'tl-061': {'4.5.1': {'EN': [45], 'PT': [49]}, '4.5.2': {'EN': [45, 46], 'PT': [49, 50]}, '2.2.3': {'EN': [30], 'PT': [33]}}, 'tl-065': {'5.3.1': {'EN': [54], 'PT': [60]}}, 'tl-066': {'5.3.3': {'EN': [55], 'PT': [61]}, '5.3.2': {'EN': [54, 55], 'PT': [60, 61]}}, 'tl-067': {'1.3': {'EN': [17, 18], 'PT': [19]}}, 'tl-068': {'2.1.2': {'EN': [25, 26], 'PT': [27, 28]}}}
KEYS={'tl-058': ['o4'], 'tl-059': ['o1'], 'tl-060': ['o3'], 'tl-061': ['o2'], 'tl-065': ['o2'], 'tl-066': ['o4'], 'tl-067': ['o2'], 'tl-068': ['o1']}
LOPAGES={1: {'EN': [14], 'PT': [15]}, 2: {'EN': [24], 'PT': [26]}, 3: {'EN': [32], 'PT': [35]}, 4: {'EN': [38], 'PT': [41]}, 5: {'EN': [47], 'PT': [52]}}
def canonical(q):return hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(bank,matrix,comparisons,blind,projections,alternatives,sources,optional,reports,archives):
 assert matrix['scope']=='Phase 10H Batch 14 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert [d['questionId'] for d in matrix['decisions']]==IDS and len(comparisons)==len(projections)==len(blind['solutions'])==8
 assert len(alternatives)==len({(a['questionId'],a['optionId']) for a in alternatives})==32 and set(reports)==set(IDS)
 assert blind['reviewerType']=='AI' and not blind['publishedKeysConsultedBeforeRecording'] and not blind['publishedExplanationsConsultedBeforeRecording'] and not blind['ownerAccepted'] and not blind['humanApproved']
 assert set(archives)=={f'2026-10-27.{i}' for i in range(1,10)}
 assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64
 for s in sources['sources']:
  assert s['sha256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 checks=[]
 for d,c,projection,s in zip(matrix['decisions'],comparisons,projections,blind['solutions']):
  ident=d['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],canonical(q))==(lo,k,v,h) and q['correct']==KEYS[ident] and q['required']==1
  assert d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None and d['unresolvedMandatoryIssues']==[]
  assert d['existingKey']==d['proposedKey']==d['independentAnswer']==s['answer']==KEYS[ident] and s['questionId']==ident and d['keyComparison']=='MATCH'
  assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged'] and not d['priorNONEUsedAsEvidence']
  assert (d['learningObjective'],d['cognitiveLevel'],d['questionVersion'],d['requiredAnswers'])==(lo,k,v,1)
  assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==h and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
  assert c=={'questionId':ident,'original':q,'proposed':q,'changed':False}
  assert set(projection)=={'id','lo','level','text','options'} and projection['id']==ident and projection['text']==q['text'] and (projection['lo'],projection['level'])==(lo,k)
  assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  assert s['shuffledOrder']==[o['id'] for o in projection['options']] and len(s['reasonPT'])>100 and set(s['optionAssessmentsEN'])=={'o1','o2','o3','o4'}
  assert datetime.datetime.fromisoformat(s['recordedAt']).tzinfo
  for field in ['assessmentPT','counterEvidencePT','translationAssessmentPT','pedagogyAssessmentPT','editionDifferencePT']:assert len(d[field])>100
  assert d['references']==REFS[ident] and d['LOPages']==LOPAGES[q['chapter']]
  for refs in d['references'].values():
   for lang,pages in refs.items():assert set(pages)<=set(next(x['pagesConsulted'] for x in sources['sources'] if x['language']==lang))
  for a in [a for a in alternatives if a['questionId']==ident]:
   o=next(o for o in q['options'] if o['id']==a['optionId']);assert a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsAnswer']==(o['id'] in KEYS[ident])
   assert len(a['reviewPT'])>50 and a['reviewEN']==s['optionAssessmentsEN'][o['id']] and len(a['reviewEN'])>50 and a['references']==REFS[ident]
  assert len([a for a in alternatives if a['questionId']==ident])==4
  for pair in d['criticalPairs']:assert pair['en'] in json.dumps(q,ensure_ascii=False) and pair['pt'] in json.dumps(q,ensure_ascii=False)
  assert len(d['history'])==9
  for entry in d['history']:
   a=next((a for a in archives[entry['contentRevision']] if a['id']==ident),None);assert entry['present']==(a is not None)
   if a is not None:assert (entry['version'],entry['key'],entry['canonicalSHA256'],entry['equalCurrent'])==(a['version'],a['correct'],canonical(a),a==q)
  blocks=[]
  for lang in ['pt','en']:blocks.extend([q['text'][lang]]*2)
  for o in q['options']:
   for lang in ['pt','en']:
    for field in ['text','explanation']:blocks.extend([o[field][lang]]*2)
  for lang in ['pt','en']:blocks.extend([q['explanation'][lang]]*2)
  actualBlocks=40
  assert optional==[], 'No bank proposal is authorized or necessary in Batch14'
  assert re.findall(r'```text\n([\s\S]*?)\n```',reports[ident])==blocks
  prose=re.sub(r'```[\s\S]*?```','',reports[ident]);assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
  assert 'não aprovação humana' in prose and str(s['recordedAt']) in prose
  checks.append({'questionId':ident,'canonicalSHA256':h,'independentKey':KEYS[ident],'publishedKey':KEYS[ident],'alternativesVerified':4,'actualComparisonBlocks':actualBlocks,'optionalComparisonBlocks':len(blocks)-40,'priorNONEUsedAsEvidence':False})
 q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
 return {'result':'PASS','questions':checks,'reviewedQuestions':8,'reviewedAlternatives':32,'actualComparisonBlocks':320,'optionalComparisonBlocks':0,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args, global_check, reference_bank):
 check(*args)
 cases=[('wrong key',1,lambda a:a['decisions'][0].update(existingKey=['o1'])),('second answer accepted',5,lambda a:a[0].update(supportsAnswer=True)),('missing option assessment',5,lambda a:a.pop()),('PT text incompatible with source',5,lambda a:a[0]['text'].update(pt='adulterado')),('missing published explanation',5,lambda a:a[0]['publishedExplanation'].update(pt='')),('missing reasoning',3,lambda a:a['solutions'][0].update(reasonPT='')),('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank')),('false human approval',1,lambda a:a['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda a:a['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('invalid source pages',1,lambda a:a['decisions'][0]['references']['3.2.5'].update(EN=[999])),('corrupted historical question',9,lambda a:next(q for q in a['2026-10-27.9'] if q['id']=='tl-058')['explanation'].update(pt='adulterado')),('NONE reused as approval',1,lambda a:a['decisions'][0].update(priorNONEUsedAsEvidence=True)),('key leaked into blind projection',4,lambda a:a[0].update(correct=['o1'])),('unauthorized proposal added or applied',7,lambda a:a.append({'questionId':'tl-058','applied':True})),('missing counterevidence',1,lambda a:a['decisions'][1].update(counterEvidencePT=''))]
 rejected=[]
 for name,i,mutate in cases:
  a=copy.deepcopy(list(args));mutate(a[i])
  # Preserve the exact original tl-002 mutation and rejection expectation.
  # It belongs to full-bank protection; all review-evidence cases stay scoped.
  try:
   if name=='unauthorized bank edit':global_check(a[0],reference_bank)
   else:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 scoped=copy.deepcopy(list(args));next(q for q in scoped[0] if q['id']=='tl-058')['text']['en']='adulterated bank'
 try:check(*scoped)
 except AssertionError:rejected.append('reviewed question tl-058 edit rejected by scoped guard')
 else:raise AssertionError('Scoped false positive for tl-058')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'originalTl002CasePreserved':True,'globalCases':['unauthorized bank edit'],'scopedCases':len(rejected)-1,'claimLimit':'Combined dispatch preserves separate scoped and global contracts; not automatic semantic proof.'}
