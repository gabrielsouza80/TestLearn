"""Inspect before execution. Python 3.9+ standard library; read-only, no network.
Consistency is not academic truth or a human approval. External ZIP SHA authenticates delivery.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Do not use Python -O: assertions must remain enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,runpy,re,datetime,copy
root=Path(__file__).resolve().parent
def safe(n):
    assert isinstance(n,str) and n and '\\' not in n and ':' not in n and '\x00' not in n
    pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and pp.as_posix()==n
    p=root/n;assert p.resolve().is_relative_to(root) and not any(a.is_symlink() for a in [p,*p.parents] if a.is_relative_to(root))
    return p
read=lambda n:json.loads(safe(n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
m=read('MANIFEST.json');entries=m['files'];names=[e['relativePath'] for e in entries]
assert len(names)==len(set(names))==len({n.casefold() for n in names})
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert actual==set(names)|{'MANIFEST.json'},'Missing or unexpected payload'
for e in entries:
    b=safe(e['relativePath']).read_bytes();assert (len(b),sha(b))==(e['sizeBytes'],e['sha256']) and e['provenance'],e['relativePath']
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049' and pre['contentRevision']=='2026-10-27.10'
assert pre['priorPackageSHA256']=='5467564b85dbacf310ab8986a3b9249efd1bb3ed994504d6dfcff70d679f130e' and pre['priorManifestHashCount']==365 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical'] and proof['existingFilesByteIdentical']==len(pre['existingFilesSHA256'])==352
assert len(proof['priorBatchDocumentsSHA256'])==149 and proof['priorUncommittedDocumentsPreserved']==138
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
for e in entries:
    if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
continuity=read('EXPORT-CONTINUITY.json');oldBytes=safe(continuity['priorManifestPath']).read_bytes()
assert sha(oldBytes)==continuity['priorManifestSHA256']
old=json.loads(oldBytes);oldFiles={e['relativePath']:e for e in old['files']}
assert len(oldFiles)==365 and continuity['previousPackageSHA256']==pre['priorPackageSHA256'] and continuity['previousFileCount']==len(continuity['files'])==366 and continuity['omittedFiles']==[]
assert len({e['previousRelativePath'] for e in continuity['files']})==366 and {e['previousRelativePath'] for e in continuity['files']}==set(oldFiles)|{'MANIFEST.json'}
assert sum(e['kind']=='preserved_repository_reference' for e in continuity['files'])==187
oldMap={e['previousRelativePath']:e['currentRelativePath'] for e in continuity['files']}
for e in continuity['files']:
    b=safe(e['currentRelativePath']).read_bytes();assert (len(b),sha(b))==(e['sizeBytes'],e['sha256'])
    if e['previousRelativePath']!='MANIFEST.json':assert (len(b),sha(b))==(oldFiles[e['previousRelativePath']]['sizeBytes'],oldFiles[e['previousRelativePath']]['sha256'])
bank=read('review-data/current-bank.json');g=runpy.run_path(str(safe('GLOBAL13-RULES.py')))
reference=g['load_reference'](safe('reference-bank.json').read_bytes())
assert safe('reference-bank.json').read_bytes()==safe(oldMap['review-data/current-bank.json']).read_bytes()
globalResult=g['check_bank'](bank,reference);globalNegative=g['negative_checks'](reference)
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
pres=read('BANK-PRESERVATION.json');assert pres['contentRevision']=='2026-10-27.10' and len(pres['questions'])==90
for a,q in zip(pres['questions'],bank):assert a['id']==q['id'] and a['beforeCanonicalSHA256']==a['afterCanonicalSHA256']==canonical(q) and a['beforeKey']==a['afterKey']==q['correct'] and a['beforeVersion']==a['afterVersion']==q['version']
folder='docs/academic/phase10h-batch13-2026-11-06/'
matrix=read(folder+'decision-matrix.json');blind=read(folder+'blind-solutions.json');projection=read(folder+'blind-projection.json')
assert blind==read('evidence/blind-solutions.json') and projection==read('evidence/blind-projection.json') and blind['projectionSHA256']==sha(safe('evidence/blind-projection.json').read_bytes())
reveal=read('evidence/key-reveal.json');assert len(reveal['questions'])==8
for s,k in zip(blind['solutions'],reveal['questions']):assert s['questionId']==k['questionId'] and s['answer']==k['key']==k['independentAnswer'] and datetime.datetime.fromisoformat(s['recordedAt'])<datetime.datetime.fromisoformat(reveal['at'])
reports={d['questionId']:safe(folder+'reports/'+d['questionId']+'.md').read_text(encoding='utf8') for d in matrix['decisions']}
archives={f'2026-10-27.{i}':read(f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}
args=[bank,matrix,read(folder+'exact-comparisons.json'),blind,projection,read(folder+'alternative-assessments.json'),read(folder+'sources.json'),read(folder+'optional-candidates.json'),reports,archives]
rules=runpy.run_path(str(safe('BATCH13-RULES.py')));specific=rules['check'](*args)
negative=rules['negative_checks'](*args,global_check=g['check_bank'],reference_bank=reference)
logged=read('evidence/checks/batch13-specific-result.json')
assert {k:logged[k] for k in specific}==specific and logged['negativeChecks']==negative and logged['globalBankCheck']==globalResult and logged['globalNegativeChecks']==globalNegative and logged['exitCode']==0
blocks=[b for d in matrix['decisions'] for b in re.findall(r'```text\n([\s\S]*?)\n```',reports[d['questionId']])]
assert len(blocks)==320 and re.findall(r'```text\n([\s\S]*?)\n```',safe('ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==blocks
resume=read('evidence/recovery/resume-snapshot.json');spacing=read('evidence/recovery/spacing-result.json')
assert len(resume['batch13FilesSHA256'])==19 and len(resume['beforeBatchFilesSHA256'])==352
for n,h in resume['batch13FilesSHA256'].items():assert sha(safe(n).read_bytes())==(spacing['correctedSHA256'] if n==folder+'reports/tl-049.md' else h)
for n in ['BATCH13-RULES.py','GLOBAL13-RULES.py']:
    assert sha(safe(n).read_bytes())==resume['auxFilesSHA256'][n] and safe(n).read_bytes()==safe('evidence/recovery/original/'+n).read_bytes()
original=safe('evidence/recovery/original/tl-049.md').read_bytes();current=safe(folder+'reports/tl-049.md').read_bytes()
assert sha(original)==spacing['originalSHA256'] and sha(current)==spacing['correctedSHA256']
assert original.replace(b'continua na20;',b'continua na 20;').replace('secção1.4.2 na p.21.'.encode(),'secção 1.4.2 na p.21.'.encode())==current and len(current)==len(original)+2
assert safe(folder+'STOP-FAILURE.json').read_bytes()==safe('evidence/recovery/original/STOP-FAILURE.json').read_bytes() and read(folder+'STOP-FAILURE.json')['exitCode']==1
assert read('evidence/recovery/red-result.json')['exitCode']!=0 and 'AssertionError' in safe('evidence/recovery/red.log').read_text()
oldArgs=copy.deepcopy(args);oldArgs[8]['tl-049']=original.decode('utf8')
def rejects(call):
    try:call()
    except AssertionError:return True
    return False
assert rejects(lambda:rules['check'](*oldArgs)),'Original RED no longer reproduces'
badSpacing=copy.deepcopy(args);badSpacing[8]['tl-049']=reports['tl-049'].replace('secção 1.4.2','secção1.4.2');assert rejects(lambda:rules['check'](*badSpacing))
outside=copy.deepcopy(args);outside[0][1]['text']['en']='adulterated bank';assert outside[0][1]['id']=='tl-002' and outside[0][1]!=bank[1]
assert rules['check'](*outside)['result']=='PASS' and rejects(lambda:g['check_bank'](outside[0],reference)) and rejects(lambda:g['check_bank'](outside[0],outside[0]))
inside=copy.deepcopy(args);next(q for q in inside[0] if q['id']=='tl-048')['text']['en']='adulterated bank';assert rejects(lambda:rules['check'](*inside))
route=read('evidence/recovery/red-green-routing.json');assert route['result']=='PASS' and all(route[k] for k in ['originalFullGuardStillRED','correctedFullGuardGREEN','syntheticSpacingRegressionRejected','tl002MutationActuallyInjected','tl002ScopedControlPassed','tl002GlobalRejected','tl048ScopedRejected','poisonedReferenceRejected'])
for mode in ['targeted-vitest','multiple-answer-scoring','diff-check','format-check']:
    meta=read('evidence/checks/'+mode+'-result.json');assert meta['exitCode']==0 and meta['startedAt'] and meta['completedAt']
score=json.loads(safe('evidence/checks/multiple-answer-scoring.log').read_text());assert len(score['syntheticSelections'])==8 and all(c['expected']==c['actual'] for c in score['syntheticSelections']) and not score['storageAccessed']
inventory=read('GIT-CHANGE-INVENTORY.json');assert inventory['existingFilesChanged']==[] and len(inventory['newFiles'])==21
for e in inventory['newFiles']:assert sha(safe(e['relativePath']).read_bytes())==e['sha256'] and safe(e['relativePath']).stat().st_size==e['sizeBytes']
assert proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(entries),'priorMembersPreserved':366,'priorAcademicDocumentsPreserved':149,'preRecoveryDocumentsUnchanged':18,'authorizedReportChanges':1,'spacesInserted':2,'questions':90,'alternatives':364,'learningObjectives':64,'historicalArchives':9,'reviewedQuestions':8,'reviewedAlternatives':32,'combinedNegativeCasesRejected':negative['negativeCasesRejected'],'globalNegativeCasesRejected':globalNegative['negativeCasesRejected'],'originalREDReproduced':True,'correctedGREEN':True,'spacingRegressionRejected':True,'scopedAndGlobalContractsDemonstrated':True,'syntheticScoringChecks':8,'newOwnerAccepted':0,'newHumanApproved':0,'semanticTruthAutomaticallyProven':False},indent=2))
