# TestLearn — Fase 10H, Lote 10

Âmbito exclusivo: tl-062, FL-5.1.2, K1. Parecer por IA: **ACCEPT_AS_IS**. Resposta independente e publicada: **o4**. Não foi confirmado defeito académico obrigatório; há uma sugestão editorial opcional, não aplicada.

Estado inicial: develop; HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049; revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos. O baseline é exclusivamente o ZIP final do Lote 9 com sufixo 143003-1 e SHA-256 35e71e828849d682da4fa08b0412e7530fef061e9f76cc4ee8733838e62b60e4. Os seus 219 membros foram validados. A versão anterior sem sufixo não foi usada.

Leia tl-062.md, blind-projection.json, blind-solution.json, alternative-assessments.json, exact-comparisons.json, sources.json, decision-matrix.json e optional-candidate.json. Todas as quatro alternativas e explicações PT/EN estão reproduzidas integralmente, com original e proposto atual iguais. A solução por IA foi registada antes da revelação da chave; isto não equivale a revisão humana nem garante ausência de conhecimento prévio do modelo.

Typically/tipicamente indica contribuição característica, não monopólio profissional. Next iteration/próxima iteração preserva o horizonte de uma iteração. Testing tasks/tarefas de teste mantém o sentido de trabalho técnico planeado. Participar em estimativas não exige calcular um valor nesta questão K1. Uma pessoa pode acumular funções; isso não transforma os distratores completos em respostas típicas equivalentes.

Observação de apresentação: os dossiês históricos contêm palavras encostadas a identificadores, tal como assinalado pelo proprietário. O novo relatório usa espaçamento legível e o guard específico verifica os contextos de identificadores. Não se reescrevem evidências anteriores. IDs, caminhos, hashes e termos dentro de blocos literais são preservados exatamente.

Sem alterações ao banco, código, históricos, persistência ou documentos anteriores. Nenhuma revisão .11. Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED novo. A Fase 10H permanece aberta. Este pacote é evidência de revisão portátil, não um repositório executável completo. Testes automáticos não provam verdade académica ou equivalência semântica.

Fontes oficiais EN 4.0.1 e PT 4.0 tradução 1.0: secção 5.1.2 e apoio1.4.5 / 1.5.2; páginas físicas, origem, hashes e limites em sources.json. A cópia local oficial PT foi consultada; a tentativa de acesso web PT falhou.

Próximo passo: auditoria independente deste pacote. Qualquer aplicação da sugestão exige autorização explícita e análise de revisão/histórico/regressão. Parar após Lote 10; não iniciar Lote 11.


# tl-062 — revisão académica bilingue / bilingual academic review

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

Versão 1; FL-5.1.2; K1; revisão 2026-10-27.10; SHA-256 canónico `387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a`.

Resposta independente `['o4']` registada em `2026-11-06T15:48:39.944525+00:00`; gabarito consultado depois: `['o4']`. Consulte blind-solution.json e a projeção sem chaves/justificações.

## Resolução independente / Independent solution

O planeamento da próxima iteração requer preparar o trabalho de teste das stories candidatas. Avaliar testabilidade, identificar tarefas de teste e ajudar a estimar esforço é um contributo direto e típico. A pergunta não concede responsabilidade exclusiva ao testador.

Planning the next iteration calls for preparing testing work for candidate stories. Assessing testability, identifying testing tasks and helping estimate test effort are direct typical contributions, without claiming tester exclusivity.

## Referências oficiais e limites

ISTQB EN v4.0.1: LO FL-5.1.2/K1, página física 47; secção 5.1.2, páginas 48–49. PSTQB PT v4.0 tradução 1.0: LO página 52; secção 5.1.2, páginas 53–54. A lista EN começa no fim da página 48 e continua na 49; a lista PT da iteração está na 54. Apoio específico sobre funções: 1.4.5 EN 21/PT 23; colaboração: 1.5.2 EN 22/PT 24. Todas as páginas foram lidas nesta execução; capa conta como 1. Veja URLs, edições e hashes em sources.json. EN e PT não são declarados textualmente idênticos. Endpoint PT indisponível nesta consulta; cópia oficial local disponível e consultada.

Paráfrase do syllabus: o planeamento da entrega trata o produto e várias iterações; o da iteração concentra-se num backlog e horizonte de uma iteração. O testador contribui com testabilidade, decomposição em tarefas, esforço e outros aspetos. O texto sobre colaboração não restringe essas tarefas a uma profissão. Esta aplicação à alternativa é interpretação do revisor, não citação normativa de uma matriz de responsabilidades.

## Equivalência literal dos conceitos críticos

| EN                                            | PT                                                   | Avaliação                                                               |
| --------------------------------------------- | ---------------------------------------------------- | ----------------------------------------------------------------------- |
| typically                                     | tipicamente                                          | Frequency/typicality, never exclusive responsibility.                   |
| next iteration                                | próxima iteração                                     | Single iteration horizon, not entire release.                           |
| entire product backlog                        | todo o backlog do produto                            | Entire product scope retained in distractor o1.                         |
| before the team discusses acceptance criteria | antes de a equipa discutir os critérios de aceitação | Temporal ordering retained, not a universal prohibition.                |
| only                                          | apenas                                               | Restrictive quantifier in distractor o3 retained.                       |
| until execution starts                        | para o início da execução                            | Deferral to execution retained.                                         |
| testing tasks                                 | tarefas de teste                                     | Technical testing work, not unrelated generic tasks.                    |
| help estimate                                 | ajudar a estimar                                     | Participation in estimation, not sole ownership or guaranteed duration. |

## Comparação integral, sem alterações / Full unchanged before–after

Os blocos seguintes reproduzem o repositório literalmente; original e proposto atual são iguais. A candidatura editorial posterior é separada e não aplicada.

### Enunciado PT

Original

```text
Durante o planeamento da próxima iteração de um sistema de reservas de um museu, que contributo é tipicamente dado por um testador?
```

Proposto atual — sem alteração

```text
Durante o planeamento da próxima iteração de um sistema de reservas de um museu, que contributo é tipicamente dado por um testador?
```

### Enunciado EN

Original

```text
During planning for the next iteration of a museum booking system, which contribution is typically made by a tester?
```

Proposto atual — sem alteração

```text
During planning for the next iteration of a museum booking system, which contribution is typically made by a tester?
```

### o1 — alternativa PT

Original

```text
Definir a ordenação de negócio de todo o backlog do produto em nome do product owner.
```

Proposto atual — sem alteração

```text
Definir a ordenação de negócio de todo o backlog do produto em nome do product owner.
```

### o1 — explicação PT

Original

```text
Os testadores apoiam as prioridades com conhecimento de riscos e testes, mas esse não é o contributo típico de teste para o planeamento da iteração.
```

Proposto atual — sem alteração

```text
Os testadores apoiam as prioridades com conhecimento de riscos e testes, mas esse não é o contributo típico de teste para o planeamento da iteração.
```

### o1 — alternativa EN

Original

```text
Set the business ordering of the entire product backlog on behalf of the product owner.
```

Proposto atual — sem alteração

```text
Set the business ordering of the entire product backlog on behalf of the product owner.
```

### o1 — explicação EN

Original

```text
Testers inform priorities through risk and testing knowledge, but this is not the typical testing contribution to iteration planning.
```

Proposto atual — sem alteração

```text
Testers inform priorities through risk and testing knowledge, but this is not the typical testing contribution to iteration planning.
```

### o2 — alternativa PT

Original

```text
Selecionar a arquitetura de implementação antes de a equipa discutir os critérios de aceitação.
```

Proposto atual — sem alteração

```text
Selecionar a arquitetura de implementação antes de a equipa discutir os critérios de aceitação.
```

### o2 — explicação PT

Original

```text
As decisões de arquitetura podem envolver várias funções; isto não descreve o contributo característico do testador para o planeamento.
```

Proposto atual — sem alteração

```text
As decisões de arquitetura podem envolver várias funções; isto não descreve o contributo característico do testador para o planeamento.
```

### o2 — alternativa EN

Original

```text
Select the implementation architecture before the team discusses acceptance criteria.
```

Proposto atual — sem alteração

```text
Select the implementation architecture before the team discusses acceptance criteria.
```

### o2 — explicação EN

Original

```text
Architecture decisions may involve many roles; this does not describe the tester's characteristic planning contribution.
```

Proposto atual — sem alteração

```text
Architecture decisions may involve many roles; this does not describe the tester's characteristic planning contribution.
```

### o3 — alternativa PT

Original

```text
Reportar apenas a contagem de defeitos da iteração anterior, deixando a testabilidade e o esforço para o início da execução.
```

Proposto atual — sem alteração

```text
Reportar apenas a contagem de defeitos da iteração anterior, deixando a testabilidade e o esforço para o início da execução.
```

### o3 — explicação PT

Original

```text
A testabilidade, os riscos, as tarefas e o esforço de teste são contributos úteis durante o planeamento, não assuntos a adiar até à execução.
```

Proposto atual — sem alteração

```text
A testabilidade, os riscos, as tarefas e o esforço de teste são contributos úteis durante o planeamento, não assuntos a adiar até à execução.
```

### o3 — alternativa EN

Original

```text
Report only the previous iteration's defect count, leaving testability and effort until execution starts.
```

Proposto atual — sem alteração

```text
Report only the previous iteration's defect count, leaving testability and effort until execution starts.
```

### o3 — explicação EN

Original

```text
Testability, risks, testing tasks and effort are useful inputs during planning, not matters to defer until execution.
```

Proposto atual — sem alteração

```text
Testability, risks, testing tasks and effort are useful inputs during planning, not matters to defer until execution.
```

### o4 — alternativa PT

Original

```text
Avaliar a testabilidade das stories, identificar tarefas de teste e ajudar a estimar o esforço de teste associado.
```

Proposto atual — sem alteração

```text
Avaliar a testabilidade das stories, identificar tarefas de teste e ajudar a estimar o esforço de teste associado.
```

### o4 — explicação PT

Original

```text
Estes são contributos típicos do testador para o planeamento da iteração, a par da análise detalhada de riscos e do refinamento de aspetos funcionais e não funcionais.
```

Proposto atual — sem alteração

```text
Estes são contributos típicos do testador para o planeamento da iteração, a par da análise detalhada de riscos e do refinamento de aspetos funcionais e não funcionais.
```

### o4 — alternativa EN

Original

```text
Assess story testability, identify testing tasks and help estimate the associated test effort.
```

Proposto atual — sem alteração

```text
Assess story testability, identify testing tasks and help estimate the associated test effort.
```

### o4 — explicação EN

Original

```text
These are typical tester contributions to iteration planning alongside detailed risk analysis and refinement of functional and non-functional aspects.
```

Proposto atual — sem alteração

```text
These are typical tester contributions to iteration planning alongside detailed risk analysis and refinement of functional and non-functional aspects.
```

### Explicação geral PT

Original

```text
Os testadores contribuem antes da execução, esclarecendo testabilidade, riscos, tarefas e esforço. Reconhece-se aqui um contributo para o planeamento; não é exigido cálculo nem algoritmo de priorização.
```

Proposto atual — sem alteração

```text
Os testadores contribuem antes da execução, esclarecendo testabilidade, riscos, tarefas e esforço. Reconhece-se aqui um contributo para o planeamento; não é exigido cálculo nem algoritmo de priorização.
```

### Explicação geral EN

Original

```text
Testers contribute before execution by clarifying testability, risks, tasks and effort. This recognises a planning contribution; no calculation or prioritisation algorithm is required.
```

Proposto atual — sem alteração

```text
Testers contribute before execution by clarifying testability, risks, tasks and effort. This recognises a planning contribution; no calculation or prioritisation algorithm is required.
```

## Avaliação das quatro alternativas / All four alternatives

### o1 — distrator / distractor

Um testador pode informar prioridades com risco e qualidade, mas ordenar todo o backlog de negócio em nome do product owner não é o contributo típico de teste pedido. Não depende de proibir papéis acumulados.

A tester may inform priorities with risk and quality information, but ordering the whole business backlog on behalf of the product owner is not the typical testing contribution asked for. This does not prohibit combined roles.

Combined tester/product-owner responsibilities or invitation to advise on backlog priority do not make whole-product business ordering the characteristic testing contribution. The syllabus does not establish a universal RACI or forbid collaboration.

A explicação publicada mantém o sentido PT/EN e é correta quando lida no âmbito do contributo típico pedido. Não estabelece proibição absoluta nem exclusividade de funções.

### o2 — distrator / distractor

Um testador pode colaborar na arquitetura e levantar testabilidade; escolher a arquitetura antes de discutir critérios de aceitação não corresponde ao contributo típico de planeamento de teste da iteração.

A tester can collaborate on architecture and raise testability concerns; selecting implementation architecture before discussing acceptance criteria does not describe the typical iteration testing-planning contribution.

Architecture specialists and testers can collaborate; early architectural work can be appropriate. The option as a whole is not the characteristic testing input asked for, not an assertion that architecture is always forbidden before acceptance discussion.

A explicação publicada mantém o sentido PT/EN e é correta quando lida no âmbito do contributo típico pedido. Não estabelece proibição absoluta nem exclusividade de funções.

### o3 — distrator / distractor

Métricas anteriores podem informar o planeamento, mas reportar apenas uma contagem e adiar testabilidade e esforço até à execução omite preparação essencial explicitamente pedida.

Previous metrics can inform planning, but reporting only a count and deferring testability and effort until execution omits the relevant preparation.

Previous defect metrics can legitimately inform planning, but ONLY reporting counts and deferring testability/effort are the restrictive defects in this alternative. Estimates may later be refined; the explanation does not prohibit that.

A explicação publicada mantém o sentido PT/EN e é correta quando lida no âmbito do contributo típico pedido. Não estabelece proibição absoluta nem exclusividade de funções.

### o4 — correta / correct

O planeamento da próxima iteração requer preparar o trabalho de teste das stories candidatas. Avaliar testabilidade, identificar tarefas de teste e ajudar a estimar esforço é um contributo direto e típico. A pergunta não concede responsabilidade exclusiva ao testador.

Planning the next iteration calls for preparing testing work for candidate stories. Assessing testability, identifying testing tasks and helping estimate test effort are direct typical contributions, without claiming tester exclusivity.

Story testability, testing tasks and effort can also involve other team members. This is one valid contribution, not an exhaustive checklist or an exclusive profession. No museum-domain expertise, estimate calculation or scheduling algorithm is needed.

A explicação publicada mantém o sentido PT/EN e é correta quando lida no âmbito do contributo típico pedido. Não estabelece proibição absoluta nem exclusividade de funções.

## Unicidade, LO, nível e pedagogia

A opção o4 reconhece atividades explícitas da secção 5.1.2; o1 desloca o foco para todo o produto, o2 para arquitetura, e o3 adia preparação útil. A unicidade não depende de exclusividade de funções.

Option o4 recognises explicit 5.1.2 activities; o1 shifts to whole-product business ordering, o2 to architecture, and o3 defers useful preparation. Uniqueness does not depend on role exclusivity.

K1 recognition: a museum scenario supplies context, but no estimate calculation, prioritization algorithm or substantive K 3 application is required. Easy distractors are a difficulty limitation, not a validity defect. This item assesses iteration planning, one part of the broader iteration-and-release LO; it does not alone prove mastery of the whole LO.

A tester may also be a product owner or architect; previous defect metrics are useful and effort estimation also occurs in release planning. These facts do not make the full distractors the characteristic contribution asked for. Correctness is based on the scenario and complete option, not job-title prohibitions.

All four published option explanations are bilingual and accurate. General rationale correctly distinguishes recognition from calculation; its cognitive-level meta-comment is optional editorial matter, not academic misinformation.

Não há número, unidade, negação ou condição omitida entre PT/EN. Stories é empréstimo técnico consistente; tarefas de teste refere trabalho planeado e esforço, não duração de calendário. A descrição do museu não acrescenta restrições escondidas. A resposta não requer que todos os contributos de um testador sejam listados.

## Histórico preservado

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |
| 2026-10-27.5 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |
| 2026-10-27.6 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |
| 2026-10-27.7 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |
| 2026-10-27.8 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |
| 2026-10-27.9 | True     | 1      | ['o4'] | 387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a |

O item não é inventado em revisões onde está ausente. Comparações de arquivo e banco completo são mecânicas; não são aprovação académica.

## Sugestão editorial opcional, não aplicada

A explicação atual é correta. Opcionalmente, substituir o comentário sobre cálculo/algoritmo por um reforço de colaboração pode focar melhor a aprendizagem, como sugerido no registo preliminar. Não existe necessidade académica obrigatória.

The current rationale is correct. Optionally replacing the calculation/algorithm meta-comment with collaboration reinforces the learning point. This is a teaching preference, not a confirmed defect.

O texto anterior integral está acima. Abaixo segue a explicação geral sugerida; todas as outras propriedades do candidato completo permanecem iguais em optional-candidate.json.

PT

```text
Durante o planeamento da iteração, os testadores ajudam a avaliar a testabilidade das stories, identificar tarefas de teste e estimar o esforço de teste, a par da análise detalhada de riscos e do refinamento de aspetos funcionais e não funcionais. Estes contributos são colaborativos e não exclusivos dos testadores.
```

EN

```text
During iteration planning, testers help assess story testability, identify testing tasks and estimate test effort, alongside detailed risk analysis and refinement of functional and non-functional aspects. These contributions are collaborative and are not exclusive to testers.
```

Chave, LO e K: sem impacto. Makes non-exclusivity explicit; slightly longer rationale. No claim of measured learning improvement.

No version change applied. If later authorized as a real bank edit, follow immutable snapshot policy for current .10 and increment item version 1 to 2 plus a separately authorized content revision.

None now. Any later edit must preserve old sessions and exact historical wording.

Testes necessários caso autorizada:

- PT/EN semantic review of the new explanation and all unchanged alternatives
- Exact 90 IDs/keys plus exact-set scoring and targeted unit tests
- Archive .10 before a real bank revision; history/backup/restoration compatibility
- Proportionate TypeScript/lint/build and rendered explanation E2E verification

## Aprovações e conclusão

Nenhum defeito obrigatório confirmado; não alterar o banco. OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. Fase 10H aberta. Aguardar auditoria externa; não iniciar Lote 11.
