# TestLearn — Phase10H Batch7 / Lote7

**Two AI recommendations ACCEPT_AS_IS; no bank changes. / Duas recomendaçõesAI sem alterações ao banco.**

| ID | LO/K | Independent / Published | Decision |
| --- | --- | --- | --- |
| tl-022 | FL-4.4.1/K2 | o1/o1 | ACCEPT_AS_IS |
| tl-041 | FL-1.5.2/K1 | o2/o2 | ACCEPT_AS_IS |

Both reports below include all PT/EN statements/options/rationales/general explanations literally, unchanged before/after. Each optional wording candidate is clearly separate, unapplied and not a confirmed-defect correction. Full original/candidate PT/EN text, source sections/pages, critical concept comparison, every distractor, historical versions/hashes and future test/versioning impact are provided.

tl-022 uses prior-failure knowledge as selection basis; leap-day wording is a minor lexical clarity risk, not demonstrated changed answer. tl-041can denote a cross-functional development team; programmers-only interpretation is not imposed. The official PSTQB text retains Whole Team Approach. Its Portuguese gloss in the optional candidate is reviewer wording, not an official translation.

Fresh60/60Vitest tests across4files, independent Batch7-specific evidence checks with9rejected corruptions, preservation of260existing files/46pending documents/57prior batch documents/90IDs and keys/9archives, format/diff. Legacy --phase10h-batch2is context only, not Batch7linguistic validation. Automatic checks do not certify linguistic or academic truth.

Phase10H remains open; Batch8not started. No owner acceptance or human academic approval is conferred. All required seven previously omitted comparison files are included and byte-equal to the Batch5ZIP. This is scoped self-contained review evidence, not a complete executable checkout.

# tl-022 — ACCEPT_AS_IS

LO`FL-4.4.1`; K2; versão/version3; chave publicada/published key`['o1']`; revisão/content revision2026-10-27.10.

Canonical SHA-256`093dc2e2ddc74cfea383381171b9fcacd36f787bc3d66e04e61de85369a4932c` cobre o objeto inteiro / covers the complete object.

Avaliação AI, não humana/SME; sem OWNER_ACCEPTED/HUMAN_APPROVED. Contextualmente equivalente com risco lexical baixo; não se afirma tradução literal perfeita. / AI review only, contextual equivalence with minor lexical risk, not perfect literal equivalence.

## Solução antes da chave / Pre-key independent solution

The basis is the tester’s personal knowledge of failures in similar products, an experience-based selection rationale: error guessing. Statement testing requires code statements; no such basis is given. Exploratory testing emphasizes concurrent learning/design/execution, which is not described. Dates including29February could be used in boundary tests, but no ordered partitions, limits, precision or boundary-derived selection are given; date subject matter alone does not establish BVA. The Portuguese leap-day phrase is awkward/potentially less precise but does not remove the explicitly experiential selection basis. “O seu conhecimento” retains personal possession without requiring first-hand witnessing. Unique offered answero1.

Registada/recorded`2026-11-06T13:02:28.905505+00:00`; projeção sem chaves/justificações, alternativas ordenadas porSHA-256; pistas do pedido conhecidas. / Keys/rationales not consulted before recording; user hints known.

## Fontes oficiais / Official references

Capítulo/chapter4; §4.4.1; EN4.0.1pp.[38, 43, 44]; PT4.0/v1.0pp.[41, 47, 48]. Páginas físicas com capa; referências complementares em matriz. / Physical pages counting cover; supporting sections in matrix.

URLs/hashes/métodos/limitações: ../sources.json. ENaberto na web;PTwebtimeout, PDFoficial local consultado integralmente nas páginas indicadas. Não se inventou êxito de download nem identidade de bytes remotos. / PTweb fetch timed out; local official translation was read.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** O fundamento explicitamente fornecido é conhecimento do testador sobre falhas em produtos semelhantes. Antecipação de erros explica essa base; não é necessário inventar partições, fronteiras ou observação simultânea durante exploração. A pergunta pede a técnica que melhor explica a seleção, não exclusividade de execução. Só o1 corresponde diretamente à evidência dada.

**EN:** The stated basis is the tester’s knowledge of failures in similar products. Error guessing explains that basis without inventing partitions, boundaries or simultaneous exploratory learning. The question asks what best explains selection, not an exclusive execution technique. Only o1 directly matches the evidence.

## Syllabus e interpretação / Syllabus and reviewer interpretation

**PT:** §4.4.1 inclui conhecimento de falhas em aplicações semelhantes como fundamento da antecipação de erros. §4.4.2 caracteriza exploração pela conceção/execução/avaliação em simultâneo com aprendizagem; experiência também a favorece, mas a simples menção a conhecimento não demonstra esse processo. §4.2.2 exige fronteiras de partições ordenadas para derivação BVA. A data escolhida pode coincidir em técnicas distintas.

**EN:** Section4.4.1 includes knowledge of failures in similar applications as an error-guessing basis. Section4.4.2 characterizes exploration through concurrent design/execution/evaluation and learning. Knowledge alone does not establish that process. Section4.2.2 derives BVA from ordered partition boundaries; identical date inputs can arise through different techniques.

## Equivalência crítica / Critical bilingual equivalence

**PT:** “Personal knowledge” identifica o conhecimento do testador; “o seu conhecimento” preserva posse e papel na decisão. Nenhum texto exige que ele tenha presenciado pessoalmente as falhas: conhecimento adquirido por registos também é admissível. “Dias bissextos” pode ser entendido como os dias intercalares de29de fevereiro em anos diferentes; é menos natural/preciso do que nomear a data. Uma leitura vaga como quaisquer dias de anos bissextos é um risco possível, não significado imposto nem erro de resposta demonstrado. A base experiencial mantém-se mesmo sob essa leitura mais ampla.

**EN:** Personal knowledge and o seu conhecimento preserve whose knowledge guides selection, without requiring first-hand witnessing. Dias bissextos can denote leap days across years but is less idiomatic/precise than naming29February in the usual civil-calendar reading. Interpreting it loosely as days in leap years is a possible lexical risk, not a demonstrated changed answer. The experiential basis survives even that broader reading.

## LO e nível cognitivo / LO and cognitive level

**PT:** FL-4.4.1/K2: interpretar e explicar por que a técnica corresponde ao fundamento do cenário. Não é K3, pois não se pede derivar casos/cobertura; dificuldade qualitativa baixa/média. Não há calibração empírica.

**EN:** FL-4.4.1/K2: interpret and explain the technique matching the scenario’s selection rationale. No K3case derivation/coverage calculation is required; qualitative low/moderate difficulty, without empirical calibration.

## Risco potencial versus editorial / Potential risk versus optional editorial

**PT:** Preferência editorial opcional: “falhas no processamento de 29 de fevereiro”, no contexto civil habitual implícito. Isto torna o referente mais explícito sem trocar a origem da seleção. “O seu conhecimento” deve manter-se; substituir por experiência direta/pessoal poderia restringir indevidamente como o conhecimento foi adquirido. O syllabus não determina uma data ou calendário: essa redação é proposta do revisor, não citação oficial.

**EN:** Optional clarity wording names failures processing29February in the usual implicit civil-calendar context. It clarifies the date without changing selection basis. Retain o seu conhecimento: direct personal experience would unnecessarily narrow how knowledge was obtained. The syllabus does not prescribe this date/calendar wording; it is reviewer interpretation.

## Conceitos críticos lado a lado / Critical concepts side by side

| ENliteral                       | PTliteral                       | Avaliação / Assessment | Fundamentação / Reason                                                                                                               |
| ------------------------------- | ------------------------------- | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| personal knowledge              | o seu conhecimento              | CONTEXTUAL_EQUIVALENCE | Posse do conhecimento; não exige ter testemunhado falhas. / Ownership, not necessarily first-hand experience.                        |
| leap-day failures               | falhas em dias bissextos        | MINOR_LEXICAL_RISK     | Leitura habitual29fevereiro; expressãoPTmenosidiomática. / Usual29February reading, less idiomatic PT.                               |
| in similar products             | em produtos semelhantes         | EQUIVALENT             | Falhas noutros produtos dão a base experiencial. / Similar-product failures support experience-based selection.                      |
| basis for selecting these cases | base de seleção destes casos    | EQUIVALENT             | Critério de seleção, não exclusividade técnica. / Selection criterion, not technique exclusivity.                                    |
| date-parsing cases              | casos de interpretação de datas | CONTEXTUAL_EQUIVALENCE | Tema de processamento de datas; não deriva fronteiras por si só. / Date-processing subject matter is not itself boundary derivation. |

## Todas as alternativas e justificações / All alternatives and rationales

### o1 — correta/correct

**PT:** Correta: conhecimento de falhas anteriores orienta alvos de defeitos prováveis. A explicação geral é breve mas correta.

**EN:** Correct: prior-failure knowledge directs likely defect targets. The short general explanation is accurate.

### o2 — distrator/distractor

**PT:** Não há instruções de código nem critério de cobertura fornecido; a justificação não diz que testes de datas nunca exercitam código.

**EN:** No code statements or statement-coverage criterion are supplied; the rationale does not claim date tests never execute code.

### o3 — distrator/distractor

**PT:** Aprendizagem/conceção/execução simultâneas não são descritas. A justificação reconhece corretamente que técnicas podem combinar-se; não transforma antecipação e exploração em categorias mutuamente exclusivas na prática.

**EN:** Concurrent learning/design/execution is not described. The rationale correctly permits combining techniques instead of claiming practical mutual exclusion.

### o4 — distrator/distractor

**PT:** 29de fevereiro pode participar em BVA, mas o cenário não deriva casos de fronteiras. A justificação rejeita a base não fornecida, não a possibilidade da data em BVA.

**EN:** 29February can appear in BVA, but these cases are not derived from boundaries in the scenario. The rationale rejects the unsupported basis, not the date’s possible use in BVA.

## Conteúdo real antes/depois / Actual original/proposed content

ACCEPT_AS_IS: original eproposto são idênticos. O candidato editorial opcional aparece separado a seguir; não está aplicado nem proposto como correção obrigatória. / Actual objects remain identical; optional wording is separate and unapplied.

### pt statement ORIGINAL

```text
Um testador seleciona casos de interpretação de datas usando o seu conhecimento de falhas em dias bissextos em produtos semelhantes. Que técnica melhor explica a base de seleção destes casos?
```

### pt statement PROPOSED_UNCHANGED

```text
Um testador seleciona casos de interpretação de datas usando o seu conhecimento de falhas em dias bissextos em produtos semelhantes. Que técnica melhor explica a base de seleção destes casos?
```

### en statement ORIGINAL

```text
A tester selects date-parsing cases using personal knowledge of leap-day failures in similar products. Which technique best explains the basis for selecting these cases?
```

### en statement PROPOSED_UNCHANGED

```text
A tester selects date-parsing cases using personal knowledge of leap-day failures in similar products. Which technique best explains the basis for selecting these cases?
```

### o1 pt text ORIGINAL

```text
Antecipação de erros
```

### o1 pt text PROPOSED_UNCHANGED

```text
Antecipação de erros
```

### o1 pt explanation ORIGINAL

```text
A experiência anterior orienta a procura de defeitos prováveis.
```

### o1 pt explanation PROPOSED_UNCHANGED

```text
A experiência anterior orienta a procura de defeitos prováveis.
```

### o1 en text ORIGINAL

```text
Error guessing
```

### o1 en text PROPOSED_UNCHANGED

```text
Error guessing
```

### o1 en explanation ORIGINAL

```text
Prior experience guides likely defect targets.
```

### o1 en explanation PROPOSED_UNCHANGED

```text
Prior experience guides likely defect targets.
```

### o2 pt text ORIGINAL

```text
Teste de instruções
```

### o2 pt text PROPOSED_UNCHANGED

```text
Teste de instruções
```

### o2 pt explanation ORIGINAL

```text
Não é indicado um critério de cobertura do código.
```

### o2 pt explanation PROPOSED_UNCHANGED

```text
Não é indicado um critério de cobertura do código.
```

### o2 en text ORIGINAL

```text
Statement testing
```

### o2 en text PROPOSED_UNCHANGED

```text
Statement testing
```

### o2 en explanation ORIGINAL

```text
No code coverage criterion is given.
```

### o2 en explanation PROPOSED_UNCHANGED

```text
No code coverage criterion is given.
```

### o3 pt text ORIGINAL

```text
Teste exploratório
```

### o3 pt text PROPOSED_UNCHANGED

```text
Teste exploratório
```

### o3 pt explanation ORIGINAL

```text
O teste exploratório combina aprendizagem, conceção e execução de testes. A base de seleção descrita é o conhecimento de falhas anteriores, o que ilustra especificamente a antecipação de erros; as técnicas podem ser combinadas na prática.
```

### o3 pt explanation PROPOSED_UNCHANGED

```text
O teste exploratório combina aprendizagem, conceção e execução de testes. A base de seleção descrita é o conhecimento de falhas anteriores, o que ilustra especificamente a antecipação de erros; as técnicas podem ser combinadas na prática.
```

### o3 en text ORIGINAL

```text
Exploratory testing
```

### o3 en text PROPOSED_UNCHANGED

```text
Exploratory testing
```

### o3 en explanation ORIGINAL

```text
Exploratory testing combines learning, test design and execution. The described selection basis is knowledge of past failures, which specifically illustrates error guessing; the techniques can be combined in practice.
```

### o3 en explanation PROPOSED_UNCHANGED

```text
Exploratory testing combines learning, test design and execution. The described selection basis is knowledge of past failures, which specifically illustrates error guessing; the techniques can be combined in practice.
```

### o4 pt text ORIGINAL

```text
Análise de valor fronteira
```

### o4 pt text PROPOSED_UNCHANGED

```text
Análise de valor fronteira
```

### o4 pt explanation ORIGINAL

```text
A BVA deriva casos das fronteiras de partições ordenadas. O cenário fornece conhecimento de falhas anteriores como base, não fronteiras de partições das quais tenham sido derivados estes casos.
```

### o4 pt explanation PROPOSED_UNCHANGED

```text
A BVA deriva casos das fronteiras de partições ordenadas. O cenário fornece conhecimento de falhas anteriores como base, não fronteiras de partições das quais tenham sido derivados estes casos.
```

### o4 en text ORIGINAL

```text
Boundary value analysis
```

### o4 en text PROPOSED_UNCHANGED

```text
Boundary value analysis
```

### o4 en explanation ORIGINAL

```text
BVA derives cases from boundaries of ordered partitions. The scenario supplies past failure knowledge as the basis, not partition boundaries from which these cases were derived.
```

### o4 en explanation PROPOSED_UNCHANGED

```text
BVA derives cases from boundaries of ordered partitions. The scenario supplies past failure knowledge as the basis, not partition boundaries from which these cases were derived.
```

### pt general explanation ORIGINAL

```text
A experiência anterior orienta a procura de defeitos prováveis.
```

### pt general explanation PROPOSED_UNCHANGED

```text
A experiência anterior orienta a procura de defeitos prováveis.
```

### en general explanation ORIGINAL

```text
Prior experience guides likely defect targets.
```

### en general explanation PROPOSED_UNCHANGED

```text
Prior experience guides likely defect targets.
```

## Candidato editorial opcional — NÃO aplicado / Optional wording — NOT applied

Não há problema académico confirmado nem classificação PROPOSE_CORRECTION. A comparação seguinte permite ao proprietário decidir uma melhoria, sem alterar silenciosamente o banco. / This is optional clarity, not a confirmed-defect correction.

### pt statement ORIGINAL

```text
Um testador seleciona casos de interpretação de datas usando o seu conhecimento de falhas em dias bissextos em produtos semelhantes. Que técnica melhor explica a base de seleção destes casos?
```

### pt statement OPTIONAL_UNAPPLIED

```text
Um testador seleciona casos de interpretação de datas usando o seu conhecimento de falhas no processamento de 29 de fevereiro em produtos semelhantes. Que técnica melhor explica a base de seleção destes casos?
```

### en statement ORIGINAL

```text
A tester selects date-parsing cases using personal knowledge of leap-day failures in similar products. Which technique best explains the basis for selecting these cases?
```

### en statement OPTIONAL_UNAPPLIED

```text
A tester selects date-parsing cases using personal knowledge of leap-day failures in similar products. Which technique best explains the basis for selecting these cases?
```

Gravidade: risco lexical residual LOW; impacto pedagógico potencial de clareza, não erro de chave demonstrado. / LOWlexical risk; potential clarity benefit, no demonstrated key error.

Alternativas/chave/explicações: sem mudança. Versão e revisão atuais: sem mudança. Se o proprietário autorizar posteriormente sobre esta base, cada questão alterada exige incremento de versão (tl-022:3→4; tl-041:1→2 conforme item aprovado), snapshot imutável da.10 e nova revisão de conteúdo seguinte; nada disso é criado nesta tarefa. / No option/key/rationale/version/revision changes now; future authorized wording changes need versioning and immutable history.

Testes se autorizada: pin90IDs/chaves/LO/K e campos não alterados; textoPTaprovado/ENinalterado no render e troca de língua; banco.10arquivado/sessões/backups próprios preservados; guards/revisões/contratos atualizados com regressão, TypeScript/lint/build ePlaywrightdirecionado. / Future tests must cover exact wording, versioned historical compatibility and rendered language switching.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Metadados e hashes completos em decision-matrix.json. Presença/ausência respeita introdução histórica. A decisão nova não apaga revisões anteriores nem reclassifica sessões. / Full historical metadata/hashes are retained; no historical attempt is regraded.

## Decisão e aprovação / Decision and approval

ACCEPT_AS_ISporAI. Nenhuma correção obrigatória, nenhum aceite deGabriel, nenhuma aprovação humana independente. Melhorias opcionais requerem autorização antes de aplicação. Fase10Haberta; Lote8não iniciado. / AIrecommendation only; owner and independent human academic gates remain pending.


# tl-041 — ACCEPT_AS_IS

LO`FL-1.5.2`; K1; versão/version1; chave publicada/published key`['o2']`; revisão/content revision2026-10-27.10.

Canonical SHA-256`bb2ef546b854b9c48951dfd3433466464e54eaf0b37f16c99811ecebe7be01b4` cobre o objeto inteiro / covers the complete object.

Avaliação AI, não humana/SME; sem OWNER_ACCEPTED/HUMAN_APPROVED. Contextualmente equivalente com risco lexical baixo; não se afirma tradução literal perfeita. / AI review only, contextual equivalence with minor lexical risk, not perfect literal equivalence.

## Solução antes da chave / Pre-key independent solution

Whole-team approach benefits from complementary competencies and collaboration toward quality goals. It does not transfer all accountability to testers, exclude testers from discussion, or require a completed-development handover before testing. Thereforeo2 is uniquely defensible. Delivery team is broader than a programmers-only reading of equipa de desenvolvimento, but development team can also mean a cross-functional product team; the named approach and explicit team options favour the latter. Need inspect full explanations and official PT terminology before deciding whether this lexical scope risk is a confirmed defect or optional clarity improvement.

Registada/recorded`2026-11-06T13:02:28.905505+00:00`; projeção sem chaves/justificações, alternativas ordenadas porSHA-256; pistas do pedido conhecidas. / Keys/rationales not consulted before recording; user hints known.

## Fontes oficiais / Official references

Capítulo/chapter1; §1.5.2; EN4.0.1pp.[14, 22]; PT4.0/v1.0pp.[15, 24]. Páginas físicas com capa; referências complementares em matriz. / Physical pages counting cover; supporting sections in matrix.

URLs/hashes/métodos/limitações: ../sources.json. ENaberto na web;PTwebtimeout, PDFoficial local consultado integralmente nas páginas indicadas. Não se inventou êxito de download nem identidade de bytes remotos. / PTweb fetch timed out; local official translation was read.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** o2 recorda uma vantagem do whole team approach: competências complementares e colaboração apoiam objetivos de qualidade. o1 transfere integralmente responsabilidade para testes; o3 exclui testadores; o4 impõe início tardio obrigatório após entrega de toda a implementação. Nenhuma dessas exclusões é vantagem da abordagem. As opções permitem uma única resposta defensável mesmo sem ler a explicação posterior.

**EN:** o2 recalls a whole-team benefit: complementary skills and collaboration support quality goals. o1transfers all quality accountability to testing; o3excludes testers; o4requires testing to wait for complete implementation handover. None is a benefit of the approach. Only o2is defensible from the statement/options before reading explanations.

## Syllabus e interpretação / Syllabus and reviewer interpretation

**PT:** §1.5.2 relaciona competências adequadas, colaboração, objetivos de qualidade e responsabilidade partilhada, incluindo interação com negócio/programadores/testadores. Não exige que toda a pessoa faça qualquer tarefa sem competência nem elimina independência quando o contexto a exige. A explicação geral da questão já contém estas ressalvas.

**EN:** Section1.5.2 relates appropriate skills, collaboration and shared quality responsibility, including business/development/testing cooperation. It does not allow unqualified people to perform any task or eliminate context-required independence. The question’s general explanation already preserves those caveats.

## Equivalência crítica / Critical bilingual equivalence

**PT:** “Delivery team” não é equivalente literal a “equipa de desenvolvimento”. Esta última pode significar equipa multifuncional que desenvolve o produto, ou ser lida restritivamente como só programadores. O enunciado não diz “exclusivamente programadores”; o nome técnico e as opções favorecem a leitura colaborativa. A justificação de o2 explicita negócio, desenvolvimento e testes e a geral preserva competências/independência. Há risco lexical de estreitamento, não demonstração de que a resposta ou conceito completo foram invertidos.

**EN:** Delivery team and equipa de desenvolvimento are not literally identical. The latter can denote a cross-functional product-development team or be read narrowly as programmers only. No explicit programmers-only restriction is stated; the named approach/options support collaboration. o2’s rationale explicitly includes business/development/testing; general rationale preserves competence/independence. This is lexical-scope risk, not a demonstrated reversal of the answer or complete concept.

## LO e nível cognitivo / LO and cognitive level

**PT:** FL-1.5.2/K1: recordar uma vantagem, sem aplicar um modelo K3. Dificuldade qualitativa baixa; distratores muito excludentes ajudam a unicidade, sem obrigar a aumentar dificuldade nesta revisão.

**EN:** FL-1.5.2/K1 recalls a benefit without a K3model application. Qualitatively low difficulty; strongly exclusionary distractors establish uniqueness, without requiring a difficulty increase in this review.

## Risco potencial versus editorial / Potential risk versus optional editorial

**PT:** A PSTQB mantém “Whole Team Approach” no título e no corpo: conservar inglês não é falha de alinhamento oficial. Uma glosa “abordagem de toda a equipa” pode ajudar leitores, mas é tradução explicativa do revisor, não termo oficial citado. “Equipa responsável pela entrega” evita a leitura só-programadores sem acrescentar pista explícita de multidisciplinaridade. “Equipa de entrega” é curta, mas pode evocar logística; “equipa multidisciplinar” é clara, porém acrescenta informação que aproxima da opção correta. A preferência proposta decorre de clareza contextual, não de literalidade automática.

**EN:** PSTQB retains Whole Team Approach as heading/body terminology; retaining English is not an official-alignment defect. A Portuguese gloss can aid readers but is reviewer wording, not an official quoted term. Equipa responsável pela entrega avoids a programmers-only reading without explicitly cueing multidisciplinarity. Equipa de entrega may suggest logistics; equipa multidisciplinar adds information close to the correct option. The preference is contextual clarity, not automatic literalism.

## Conceitos críticos lado a lado / Critical concepts side by side

| ENliteral                                    | PTliteral                                             | Avaliação / Assessment      | Fundamentação / Reason                                                                                                                                  |
| -------------------------------------------- | ----------------------------------------------------- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| delivery team                                | equipa de desenvolvimento                             | MINOR_LEXICAL_RISK          | Equipa multifuncional é possível; leitura só-programadores não é imposta. / Cross-functional reading remains possible; programmers-only is not imposed. |
| whole team approach                          | whole team approach                                   | OFFICIAL_LOAN_TERM_RETAINED | A PSTQB conserva inglês; glosaPTéopcional. / PSTQB retains English; PT gloss optional.                                                                  |
| Complementary skills and close collaboration | Competências complementares e colaboração próxima     | EQUIVALENT                  | Benefício colaborativo preservado. / Collaborative benefit preserved.                                                                                   |
| entirely                                     | integralmente                                         | EQUIVALENT                  | Quantificador exclusivo tornao1incorreta. / Exclusive quantifier makeso1incorrect.                                                                      |
| outside team discussions                     | fora das discussões da equipa                         | EQUIVALENT                  | Isolamentoo3preservado. / o3isolation preserved.                                                                                                        |
| only after developers have handed over all   | só começam depois de os programadores entregarem todo | EQUIVALENT                  | Só/depois/todo preservam restriçãoo4. / Only/after/all preserveo4restriction.                                                                           |
| business, development and testing            | negócio, desenvolvimento e testes                     | EQUIVALENT                  | Domínios na justificaçãoo2. / Domains ino2rationale.                                                                                                    |
| responsibility shared by everyone            | responsabilidade partilhada por todos                 | EQUIVALENT                  | Responsabilidade coletiva, não transferência exclusiva. / Collective responsibility, not exclusive transfer.                                            |

## Todas as alternativas e justificações / All alternatives and rationales

### o1 — distrator/distractor

**PT:** “Integralmente” torna a transferência de responsabilidade exclusiva; contraria responsabilidade partilhada. Justificação mantém todos responsáveis, sem negar funções especializadas.

**EN:** Entirely makes quality accountability exclusive to testing, contradicting shared responsibility. The rationale preserves responsibility without abolishing specialist roles.

### o2 — correta/correct

**PT:** Correta: competências complementares/colaboração próxima apoiam objetivos. A justificação nomeia negócio, desenvolvimento e testes. Não exige que toda a pessoa possua todas as competências.

**EN:** Correct: complementary skills/close collaboration support goals; the rationale names business, development and testing without requiring every person to have every skill.

### o3 — distrator/distractor

**PT:** Excluir testadores das discussões elimina cooperação, não a preserva; independente não equivale a isolado.

**EN:** Excluding testers from discussion defeats collaboration; independence is not synonymous with isolation.

### o4 — distrator/distractor

**PT:** “Só” após “todo” o trabalho impõe passagem sequencial tardia como requisito. A abordagem promove cooperação ao longo do trabalho; não impede níveis de teste posteriores.

**EN:** Only after all implementation imposes a mandatory late sequential handover; the approach promotes cooperation throughout work, without banning later test levels.

## Conteúdo real antes/depois / Actual original/proposed content

ACCEPT_AS_IS: original eproposto são idênticos. O candidato editorial opcional aparece separado a seguir; não está aplicado nem proposto como correção obrigatória. / Actual objects remain identical; optional wording is separate and unapplied.

### pt statement ORIGINAL

```text
Uma equipa de desenvolvimento adota a whole team approach. Que vantagem está associada a esta abordagem?
```

### pt statement PROPOSED_UNCHANGED

```text
Uma equipa de desenvolvimento adota a whole team approach. Que vantagem está associada a esta abordagem?
```

### en statement ORIGINAL

```text
A delivery team adopts the whole team approach. Which benefit is associated with this approach?
```

### en statement PROPOSED_UNCHANGED

```text
A delivery team adopts the whole team approach. Which benefit is associated with this approach?
```

### o1 pt text ORIGINAL

```text
A responsabilidade pela qualidade é transferida integralmente dos programadores para a função de teste.
```

### o1 pt text PROPOSED_UNCHANGED

```text
A responsabilidade pela qualidade é transferida integralmente dos programadores para a função de teste.
```

### o1 pt explanation ORIGINAL

```text
A qualidade continua a ser uma responsabilidade partilhada por todos, em vez de ser transferida para uma função.
```

### o1 pt explanation PROPOSED_UNCHANGED

```text
A qualidade continua a ser uma responsabilidade partilhada por todos, em vez de ser transferida para uma função.
```

### o1 en text ORIGINAL

```text
Quality accountability is transferred entirely from developers to the testing role.
```

### o1 en text PROPOSED_UNCHANGED

```text
Quality accountability is transferred entirely from developers to the testing role.
```

### o1 en explanation ORIGINAL

```text
Quality remains a responsibility shared by everyone, rather than being transferred to one role.
```

### o1 en explanation PROPOSED_UNCHANGED

```text
Quality remains a responsibility shared by everyone, rather than being transferred to one role.
```

### o2 pt text ORIGINAL

```text
Competências complementares e colaboração próxima ajudam a equipa a alcançar os seus objetivos de qualidade.
```

### o2 pt text PROPOSED_UNCHANGED

```text
Competências complementares e colaboração próxima ajudam a equipa a alcançar os seus objetivos de qualidade.
```

### o2 pt explanation ORIGINAL

```text
Partilhar competências e colaborar entre negócio, desenvolvimento e testes apoia os objetivos coletivos de qualidade.
```

### o2 pt explanation PROPOSED_UNCHANGED

```text
Partilhar competências e colaborar entre negócio, desenvolvimento e testes apoia os objetivos coletivos de qualidade.
```

### o2 en text ORIGINAL

```text
Complementary skills and close collaboration help the team achieve its quality goals.
```

### o2 en text PROPOSED_UNCHANGED

```text
Complementary skills and close collaboration help the team achieve its quality goals.
```

### o2 en explanation ORIGINAL

```text
Sharing skills and collaborating across business, development and testing supports collective quality goals.
```

### o2 en explanation PROPOSED_UNCHANGED

```text
Sharing skills and collaborating across business, development and testing supports collective quality goals.
```

### o3 pt text ORIGINAL

```text
Manter os testadores fora das discussões da equipa preserva a principal vantagem desta abordagem.
```

### o3 pt text PROPOSED_UNCHANGED

```text
Manter os testadores fora das discussões da equipa preserva a principal vantagem desta abordagem.
```

### o3 pt explanation ORIGINAL

```text
A abordagem incentiva a colaboração, não o isolamento dos testes em relação à equipa.
```

### o3 pt explanation PROPOSED_UNCHANGED

```text
A abordagem incentiva a colaboração, não o isolamento dos testes em relação à equipa.
```

### o3 en text ORIGINAL

```text
Keeping testers outside team discussions preserves the main benefit of this approach.
```

### o3 en text PROPOSED_UNCHANGED

```text
Keeping testers outside team discussions preserves the main benefit of this approach.
```

### o3 en explanation ORIGINAL

```text
The approach encourages collaboration, not isolation of testing from the team.
```

### o3 en explanation PROPOSED_UNCHANGED

```text
The approach encourages collaboration, not isolation of testing from the team.
```

### o4 pt text ORIGINAL

```text
Os testes só começam depois de os programadores entregarem todo o trabalho de implementação concluído.
```

### o4 pt text PROPOSED_UNCHANGED

```text
Os testes só começam depois de os programadores entregarem todo o trabalho de implementação concluído.
```

### o4 pt explanation ORIGINAL

```text
Isto impõe uma passagem de trabalho sequencial; a whole team approach promove a cooperação ao longo do trabalho.
```

### o4 pt explanation PROPOSED_UNCHANGED

```text
Isto impõe uma passagem de trabalho sequencial; a whole team approach promove a cooperação ao longo do trabalho.
```

### o4 en text ORIGINAL

```text
Testing starts only after developers have handed over all completed implementation work.
```

### o4 en text PROPOSED_UNCHANGED

```text
Testing starts only after developers have handed over all completed implementation work.
```

### o4 en explanation ORIGINAL

```text
This imposes a sequential handover; the whole team approach promotes cooperation throughout the work.
```

### o4 en explanation PROPOSED_UNCHANGED

```text
This imposes a sequential handover; the whole team approach promotes cooperation throughout the work.
```

### pt general explanation ORIGINAL

```text
A whole team approach combina competências e responsabilidade partilhada. As tarefas continuam a exigir competências e conhecimentos adequados; o contexto pode exigir independência adicional.
```

### pt general explanation PROPOSED_UNCHANGED

```text
A whole team approach combina competências e responsabilidade partilhada. As tarefas continuam a exigir competências e conhecimentos adequados; o contexto pode exigir independência adicional.
```

### en general explanation ORIGINAL

```text
The whole team approach combines skills and shared responsibility. Tasks still require suitable skills and knowledge; context can require additional independence.
```

### en general explanation PROPOSED_UNCHANGED

```text
The whole team approach combines skills and shared responsibility. Tasks still require suitable skills and knowledge; context can require additional independence.
```

## Candidato editorial opcional — NÃO aplicado / Optional wording — NOT applied

Não há problema académico confirmado nem classificação PROPOSE_CORRECTION. A comparação seguinte permite ao proprietário decidir uma melhoria, sem alterar silenciosamente o banco. / This is optional clarity, not a confirmed-defect correction.

### pt statement ORIGINAL

```text
Uma equipa de desenvolvimento adota a whole team approach. Que vantagem está associada a esta abordagem?
```

### pt statement OPTIONAL_UNAPPLIED

```text
Uma equipa responsável pela entrega adota a whole team approach (abordagem de toda a equipa). Que vantagem está associada a esta abordagem?
```

### en statement ORIGINAL

```text
A delivery team adopts the whole team approach. Which benefit is associated with this approach?
```

### en statement OPTIONAL_UNAPPLIED

```text
A delivery team adopts the whole team approach. Which benefit is associated with this approach?
```

Gravidade: risco lexical residual LOW; impacto pedagógico potencial de clareza, não erro de chave demonstrado. / LOWlexical risk; potential clarity benefit, no demonstrated key error.

Alternativas/chave/explicações: sem mudança. Versão e revisão atuais: sem mudança. Se o proprietário autorizar posteriormente sobre esta base, cada questão alterada exige incremento de versão (tl-022:3→4; tl-041:1→2 conforme item aprovado), snapshot imutável da.10 e nova revisão de conteúdo seguinte; nada disso é criado nesta tarefa. / No option/key/rationale/version/revision changes now; future authorized wording changes need versioning and immutable history.

Testes se autorizada: pin90IDs/chaves/LO/K e campos não alterados; textoPTaprovado/ENinalterado no render e troca de língua; banco.10arquivado/sessões/backups próprios preservados; guards/revisões/contratos atualizados com regressão, TypeScript/lint/build ePlaywrightdirecionado. / Future tests must cover exact wording, versioned historical compatibility and rendered language switching.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | False              | —                | —           |
| 2026-10-27.2       | False              | —                | —           |
| 2026-10-27.3       | True               | 1                | ['o2']      |
| 2026-10-27.4       | True               | 1                | ['o2']      |
| 2026-10-27.5       | True               | 1                | ['o2']      |
| 2026-10-27.6       | True               | 1                | ['o2']      |
| 2026-10-27.7       | True               | 1                | ['o2']      |
| 2026-10-27.8       | True               | 1                | ['o2']      |
| 2026-10-27.9       | True               | 1                | ['o2']      |

Metadados e hashes completos em decision-matrix.json. Presença/ausência respeita introdução histórica. A decisão nova não apaga revisões anteriores nem reclassifica sessões. / Full historical metadata/hashes are retained; no historical attempt is regraded.

## Decisão e aprovação / Decision and approval

ACCEPT_AS_ISporAI. Nenhuma correção obrigatória, nenhum aceite deGabriel, nenhuma aprovação humana independente. Melhorias opcionais requerem autorização antes de aplicação. Fase10Haberta; Lote8não iniciado. / AIrecommendation only; owner and independent human academic gates remain pending.

