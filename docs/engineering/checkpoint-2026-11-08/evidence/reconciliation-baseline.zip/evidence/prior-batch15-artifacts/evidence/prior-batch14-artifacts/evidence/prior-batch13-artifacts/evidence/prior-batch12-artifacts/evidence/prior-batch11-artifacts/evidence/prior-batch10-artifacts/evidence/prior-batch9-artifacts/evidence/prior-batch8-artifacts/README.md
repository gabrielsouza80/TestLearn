# TestLearn — Phase10H Batch8 academic/editorial review evidence

Start with [ACADEMIC-REVIEW-SUMMARY.md](ACADEMIC-REVIEW-SUMMARY.md), [docs/academic/phase10h-batch8-2026-11-06/README.md](docs/academic/phase10h-batch8-2026-11-06/README.md),8reports,decision-matrix.json,optional-candidates.json and verification.md.

## Identity, outcome and approval boundaries

develop;HEAD`3fd0a85d95ecb79539515833ee3cbe7869c58049`;content2026-10-27.10. Exactlytl-001,tl-006,tl-013,tl-014,tl-015,tl-017,tl-019,tl-023were newly reviewed. All8AIrecommendations ACCEPT_AS_IS. tl-001independent/published set[o1,o4],required2; all other reviewed items[o1],required1. No confirmed mandatory academic defect or answer-changing ambiguity. PriorLOWratings were hypotheses, not automatic decisions.

No bank,ID,key,version,explanation,history,persistence,runtime,test or existing-document change. All269existing files,55pending documents and66prior Batch1–7documents remain byte-identical. Current.10and archives.1–.9remain intact; no.11created. Zero new OWNER_ACCEPTED/HUMAN_APPROVED. Prior owner records retain exact scope; AIreview is not independent human SME certification. Phase10HremainsOPEN;Batch9not started. No git add/commit/push/merge/PR/deploy/Production/real student-data operation.

## Academic findings and optional wording

tl-001TWO/DOISrequires exactly two; absolute distractors are easy but valid forK1. tl-006analysis defines test conditions; the short correct rationale is supported by the design contrast. tl-013early review is shift left, not later execution. tl-014can/podepreserves migration risk without guaranteeing failures or mandating data conversion. tl-015offers written requirements, not an unmentioned report of dynamic measurements. tl-017distinguishes a requirements defect from observed failure without locating code or human error. tl-019classifies derivation basis, not a whole-project exclusion of risk/experience. tl-023includes concurrent learning/design/execution/evaluation,timebox and charter without requiring every exploration to use sessions.

Seven OPTIONALunapplied candidates: expand general explanations fortl-006,013,014,017,019,023; clarifytl-015o2as measuring rather than measured latency. All original/candidate PT/ENobjects are complete, with path-limited changes and key/LO/K/options/version/persistence impact documented. Future application needs explicit authorization, item-version increment, immutable.10history and next content revision with regression. None is implemented. tl-001has no candidate merely to raise difficulty.

## Sources and verification limits

ISTQBEN4.0.1and PSTQBPT4.0translation1.0are primary references. Exact URLs,local-byte hashes,editions and physical pages counting cover are in sources.json/per-report references. Relevant primary sections:1.1.1,1.4.1,2.1.5,2.3,3.1.1,3.1.3,4.1,4.4.2;supporting1.2.3/1.3. PTshift-left starts physicalp.29and maintenancep.33; do not assume a uniform offset. ENweb open succeeded;PTweb fetch timed out; local official PDFs were freshly read. No successful freshPTdownload/remote-byte identity or inclusion of everyENerratum inPTis claimed. Full copyrighted PDFs/pages are not bundled. Difficulty/teaching sufficiency are qualitative, not empirically calibrated.

Fresh60/60Vitest tests in4files,no reported failures/skips. Eight synthetic current-engine scoring selections verify exact-set behaviour fortl-001without storage. Batch8-specific checks validate8identities,32option assessments,33critical phrase anchors,contrary evidence,7unapplied candidates and12rejected corruptions. Legacy--phase10h-batch2ran as context only, not Batch8approval. Commands,timestamps,exit codes and concise full logs are included; historical logs are clearly separated. One source-display helper failed on a page not yet selected, then was corrected and source consultation completed. No test was disabled. TypeScript/lint/build/fullE2Ewere not repeated for documentation-only additions; current-engine scoring is not a fulltypecheck.

## Export continuity

All104repository-reference files in Batch7are preserved byte-exact at their original repository-relative paths; all16new Batch8documents are added. Seven recovered files remain included:src/data/syllabus-questions.ts,src/data/variability-questions.ts,src/domain/blueprint.ts,tests/unit/academic-audit.test.ts,tests/unit/blueprint.test.ts,tests/unit/quality-maintenance.test.ts,tests/unit/variability.test.ts.

All26previous generated artifacts, including the prior manifest/README/logs/verifier/rules, are retained under evidence/prior-batch7-artifacts. They are **historical**, not fresh Batch8executions. That nested artifact folder is not a standalone extracted Batch7package: its repository files are preserved at the current root. Do not run historical verifier copies there. EXPORT-CONTINUITY.json maps every previous130member to its current location and hash; no previous member was silently dropped.

## Portable read-only verification

Inspect top-level VERIFY-PACKAGE.py and BATCH8-RULES.py; run `python VERIFY-PACKAGE.py` with Python3.9+standard library,without-O,after extraction into a new empty directory. Bytecode writes are disabled; no network/subprocesses in the portable verifier/rules. It validates every payload hash/size;66prior documents;104prior repository references/all130previous member bytes;7extra comparison files;9archives;90IDs/keys/per-object hashes;8current questions;320actual comparison blocks;28optional-field blocks;33concept pairs;7candidate deltas;12negative cases;and recorded8synthetic scoring results. It does not rerunTypeScriptor automatically prove semantic truth, approve content or confer human review.

MANIFEST.json records every other file with relative path,size,SHA-256 and provenance; it excludes itself to avoid recursive hashing. The fullZIP SHA supplied externally covers the manifest. Hashes establish consistency,not authenticity signatures. A deliberately tampered copied payload is rejected and the restored package reverified before archiving; CRC,safe clean extraction and portable execution are then checked.

This is self-contained review evidence, **not a complete executable repository**. PortablePythonverification needs only extracted files; originalVitest/TypeScriptcommands need the complete checkout/dependencies. Source/test copies are comparison context,not full module closure. Local helpers under evidence require the original workspace/PDFtools where indicated; they are not the portable entry point. No credentials,tokens,.env,.git,node_modules,dist,test-results,browser profiles,real student data,LocalStorage exports or private backups are included.
