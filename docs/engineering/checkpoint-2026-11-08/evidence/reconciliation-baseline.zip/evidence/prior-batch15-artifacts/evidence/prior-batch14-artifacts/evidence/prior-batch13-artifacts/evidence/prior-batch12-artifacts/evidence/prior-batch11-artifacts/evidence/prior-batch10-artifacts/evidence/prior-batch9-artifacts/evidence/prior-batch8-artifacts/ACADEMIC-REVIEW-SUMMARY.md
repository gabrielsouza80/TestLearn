# TestLearn — Phase10H Batch8 / Lote8

**8AIrecommendations ACCEPT_AS_IS;0mandatory corrections;0bank changes.**

| ID | LO/K | Independent / Published | Decision |
| --- | --- | --- | --- |
| tl-001 | FL-1.1.1/K1 | ['o1', 'o4']/['o1', 'o4'] | ACCEPT_AS_IS |
| tl-006 | FL-1.4.1/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-013 | FL-2.1.5/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-014 | FL-2.3.1/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-015 | FL-3.1.1/K1 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-017 | FL-3.1.3/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-019 | FL-4.1.1/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |
| tl-023 | FL-4.4.2/K2 | ['o1']/['o1'] | ACCEPT_AS_IS |

Each report below gives full PT/ENstatements, all options/rationales/general explanations, exact unchanged before/after text, LO/K, official sections/physical pages, independent pre-key reasoning, every distractor, contrary evidence, historical versions/hashes and residual teaching risks. Prior LOWlabels did not automatically determine verdicts.

Seven unapplied editorial candidates are separate: six general-explanation expansions and one tl-015o2text clarification. Complete original/candidate objects, bilingual fields, exact paths, hashes, key/version/history/persistence impact and future tests are in optional-candidates.json. No new version/revision or runtime wording is applied. tl-001retains exactly two correct options, not a single answer.

Fresh60/60Vitest across4files;8current-runtime synthetic exact-set scoring checks fortl-001;Batch8-specific review/evidence checks with12rejected corruptions;preservation of269existing files/55pending documents/66prior batch documents/90objects and keys/9archives;format/diff. Legacy--phase10h-batch2is contextual only. Mechanical checks do not prove semantic equivalence or human approval.

All104repository references from Batch7remain byte-exact at repository-relative paths, including the seven recovered code/test files. All26generated artifacts from that prior package are archived separately under evidence/prior-batch7-artifacts, as historical evidence, never fresh tests. EXPORT-CONTINUITY.json maps all130previous members: no silent omissions.

AIreview only; no new OWNER_ACCEPTED/HUMAN_APPROVED. Phase10Hopen;Batch9not started. Scoped self-contained review evidence, not a complete executable repository.

# tl-001 — ACCEPT_AS_IS

LO`FL-1.1.1`; K1; version2; required=2; key`['o1', 'o4']`; content revision2026-10-27.10.

Canonical SHA-256`15d923673172ffada0dbf7c1d3fed68d8ae56934ebf09586cb60331edc7c966f` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

TWO/DOIS requires exactly two. Information for a release decision and finding defects are useful objectives. Proving absence of all defects and guaranteeing every user’s satisfaction are absolute claims testing cannot establish. This is recognition of objectives, K1; no translation alters cardinality.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter1, §1.1.1; EN4.0.1pp.[14, 15]; PT4.0/v1.0pp.[15, 16, 17]. Referências complementares / supporting sections: [{'section': '1.3', 'EN': [17, 18], 'PT': [19]}]. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** São pedidos exatamente DOIS objetivos. o1 fornece informação para decisões; o4 procura defeitos. o2 pretende provar ausência total de defeitos e o3 garantir satisfação universal: absolutos que os testes não asseguram. A única combinação correta oferecida é{o1,o4}, não uma resposta única de um só elemento.

**EN:** Exactly TWO objectives are requested. o1supplies decision information and o4finds defects. o2claims proof of total absence and o3universal satisfaction, which testing cannot guarantee. The unique offered correct set is{o1,o4}, not a single-element answer.

## Comparação PT/EN / PT/EN comparison

**PT:** TWO/DOIS e required=2 coincidem. Useful/úteis não exige uma lista exaustiva de objetivos. No defects/não existem defeitos e every user/todos os utilizadores preservam os absolutos. Work products/produtos de trabalho preserva que testes não se limitam a executar código.

**EN:** TWO/DOIS match required=2; useful does not require exhaustive objective coverage. No defects/every user retain the absolute quantifiers. Work products preserves the scope beyond executing code.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Distratores absolutos tornam a pergunta fácil; isso não os torna corretos nem invalida K1. Encontrar defeitos não é promessa de que todo teste encontrará defeitos. “Imperfeições” na justificação é sinónimo informal contextual, sem redefinir o termo defeito da alternativa.

**EN:** Absolute distractors make the item easy, not invalid forK1. Finding defects is an objective, not a promise that every test finds one. The rationale’s informal flaws wording does not redefine the explicit defect term in the option.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** K1/FL-1.1.1: reconhecimento de objetivos, dificuldade qualitativa baixa. A explicação geral contrasta evidência útil e limites dos testes; é suficiente para este objetivo. Não se propõe tornar distratores mais difíceis apenas por preferência.

**EN:** K1/FL-1.1.1recognizes objectives; qualitatively low difficulty. The general explanation contrasts useful evidence with testing limits and is sufficient. No distractor redesign is proposed merely to increase difficulty.

## Riscos de interpretação / Interpretation risks

**PT:** Nenhuma ambiguidade de cardinalidade ou segunda combinação defensável demonstrada. Baixa dificuldade não é defeito académico.

**EN:** No demonstrated cardinality ambiguity or second defensible set. Low difficulty is not an academic defect.

## Conceitos críticos / Critical concepts

| ENliteral        | PTliteral             | Avaliação / Assessment |
| ---------------- | --------------------- | ---------------------- |
| TWO              | DOIS                  | EQUIVALENT_CARDINALITY |
| no defects exist | não existem defeitos  | EQUIVALENT_ABSOLUTE    |
| every user       | todos os utilizadores | EQUIVALENT_ABSOLUTE    |
| work products    | produtos de trabalho  | EQUIVALENT_SCOPE       |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: informação para decisão de lançamento é um objetivo útil; não substitui a decisão do responsável.

**EN:** Correct: release-decision information is useful without making the release decision itself.

### o2 — distrator/distractor

**PT:** Incorreta: não se prova ausência global de defeitos através de testes.

**EN:** Incorrect: testing does not establish global absence of defects.

### o3 — distrator/distractor

**PT:** Incorreta: garantir satisfação de todos vai além da evidência possível dos testes.

**EN:** Incorrect: guaranteeing every user’s satisfaction exceeds testing evidence.

### o4 — correta/correct

**PT:** Correta: descobrir defeitos em produtos de trabalho é objetivo típico, incluindo documentos.

**EN:** Correct: finding defects in work products, including documents, is a typical objective.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Selecione DOIS objetivos úteis dos testes.
```

### pt statement RETAINED_UNCHANGED

```text
Selecione DOIS objetivos úteis dos testes.
```

### en statement ORIGINAL

```text
Select TWO useful testing objectives.
```

### en statement RETAINED_UNCHANGED

```text
Select TWO useful testing objectives.
```

### o1 pt text ORIGINAL

```text
Fornecer informação para uma decisão de lançamento
```

### o1 pt text RETAINED_UNCHANGED

```text
Fornecer informação para uma decisão de lançamento
```

### o1 pt explanation ORIGINAL

```text
Os testes fornecem evidência para decisões e encontram defeitos. Não garantem a ausência de defeitos nem a satisfação de todos os utilizadores.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Os testes fornecem evidência para decisões e encontram defeitos. Não garantem a ausência de defeitos nem a satisfação de todos os utilizadores.
```

### o1 en text ORIGINAL

```text
Provide information for a release decision
```

### o1 en text RETAINED_UNCHANGED

```text
Provide information for a release decision
```

### o1 en explanation ORIGINAL

```text
Testing provides decision evidence and finds defects. It cannot guarantee defect absence or universal user satisfaction.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Testing provides decision evidence and finds defects. It cannot guarantee defect absence or universal user satisfaction.
```

### o2 pt text ORIGINAL

```text
Provar que não existem defeitos
```

### o2 pt text RETAINED_UNCHANGED

```text
Provar que não existem defeitos
```

### o2 pt explanation ORIGINAL

```text
Testes finitos não provam a ausência de defeitos.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Testes finitos não provam a ausência de defeitos.
```

### o2 en text ORIGINAL

```text
Prove that no defects exist
```

### o2 en text RETAINED_UNCHANGED

```text
Prove that no defects exist
```

### o2 en explanation ORIGINAL

```text
Finite testing cannot prove defect absence.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Finite testing cannot prove defect absence.
```

### o3 pt text ORIGINAL

```text
Garantir a satisfação de todos os utilizadores
```

### o3 pt text RETAINED_UNCHANGED

```text
Garantir a satisfação de todos os utilizadores
```

### o3 pt explanation ORIGINAL

```text
Os testes não garantem satisfação.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Os testes não garantem satisfação.
```

### o3 en text ORIGINAL

```text
Guarantee every user is satisfied
```

### o3 en text RETAINED_UNCHANGED

```text
Guarantee every user is satisfied
```

### o3 en explanation ORIGINAL

```text
Satisfaction cannot be guaranteed by testing.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Satisfaction cannot be guaranteed by testing.
```

### o4 pt text ORIGINAL

```text
Encontrar defeitos em produtos de trabalho
```

### o4 pt text RETAINED_UNCHANGED

```text
Encontrar defeitos em produtos de trabalho
```

### o4 pt explanation ORIGINAL

```text
Encontrar imperfeições é um objetivo dos testes.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Encontrar imperfeições é um objetivo dos testes.
```

### o4 en text ORIGINAL

```text
Find defects in work products
```

### o4 en text RETAINED_UNCHANGED

```text
Find defects in work products
```

### o4 en explanation ORIGINAL

```text
Finding flaws is a testing objective.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Finding flaws is a testing objective.
```

### pt general explanation ORIGINAL

```text
Os testes fornecem evidência para decisões e encontram defeitos. Não garantem a ausência de defeitos nem a satisfação de todos os utilizadores.
```

### pt general explanation RETAINED_UNCHANGED

```text
Os testes fornecem evidência para decisões e encontram defeitos. Não garantem a ausência de defeitos nem a satisfação de todos os utilizadores.
```

### en general explanation ORIGINAL

```text
Testing provides decision evidence and finds defects. It cannot guarantee defect absence or universal user satisfaction.
```

### en general explanation RETAINED_UNCHANGED

```text
Testing provides decision evidence and finds defects. It cannot guarantee defect absence or universal user satisfaction.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Não se propõe alteração concreta. Tornar distratores mais difíceis seria opção de conceção de exame, não correção necessária. / No wording change proposed; harder distractors would be an assessment-design choice, not a required fix.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key  |
| ------------------ | ------------------ | ---------------- | ------------ |
| 2026-10-27.1       | True               | 1                | ['o1', 'o4'] |
| 2026-10-27.2       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.3       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.4       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.5       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.6       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.7       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.8       | True               | 2                | ['o1', 'o4'] |
| 2026-10-27.9       | True               | 2                | ['o1', 'o4'] |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-006 — ACCEPT_AS_IS

LO`FL-1.4.1`; K2; version3; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`ba0d87c420b44384709fe07abefcf680bd7dbbc5f2daafd0c66bc78c2c76ad7c` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Deriving test conditions from requirements identifies what to test: test analysis. Test design elaborates cases/data/how to test, execution runs tests, completion consolidates outcomes/testware. Activities may overlap in practice, but the described work product is a test condition, making o1 the best match.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter1, §1.4.1; EN4.0.1pp.[14, 18, 19]; PT4.0/v1.0pp.[15, 20, 21]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Derivar condições a partir de requisitos define o que testar: análise. Conceção desenvolve condições em casos/dados e como testar. Execução corre testes e compara resultados; conclusão consolida trabalho. O produto descrito, não uma cronologia rígida, identifica o1.

**EN:** Deriving conditions from requirements establishes what to test: analysis. Design elaborates conditions into cases/data and how to test. Execution runs/compares tests and completion consolidates outcomes. The described work product, not a rigid chronology, identifieso1.

## Comparação PT/EN / PT/EN comparison

**PT:** Test conditions/condições de teste, requirements/requisitos e derives/deriva mantêm a atividade. Análise/analysis e conceção/design não foram trocadas. A justificação longa de o4 preserva condições→casos e o que→como.

**EN:** Conditions, requirements and derivation preserve the activity. Analysis and design are not interchanged. o4’s longer rationale preserves conditions→cases and what→how.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Na prática análise e conceção podem iterar ou sobrepor-se, e ambas usam técnicas. Isso não faz de definir condições a melhor descrição de execução/conclusão. A explicação de o1 é curta; contudo, contém o critério correto e o4 já o contrasta explicitamente.

**EN:** Analysis/design may iterate or overlap and both use techniques; that does not make defining conditions execution or completion. o1is brief but gives the correct criterion, supplemented by the explicit contrast ino4.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-1.4.1/K2: classificar a tarefa e explicar o seu resultado; não exige derivaçãoK3. Dificuldade baixa. A brevidade não impede a resposta nem transmite conceito falso; um exemplo adicional ajuda um principiante, mas é opcional.

**EN:** FL-1.4.1/K2classifies a task and explains its output, withoutK3derivation. Low difficulty. Brevity neither prevents answering nor teaches a false concept; an example can help beginners but is optional.

## Riscos de interpretação / Interpretation risks

**PT:** Risco pedagógico baixo se o aluno ler só a frase de o1 e não o contraste de o4; não é ambiguidade confirmada da chave.

**EN:** Low pedagogical risk if only the brief o1line is read; not demonstrated key ambiguity.

## Conceitos críticos / Critical concepts

| ENliteral         | PTliteral              | Avaliação / Assessment |
| ----------------- | ---------------------- | ---------------------- |
| test conditions   | condições de teste     | EQUIVALENT             |
| from requirements | a partir de requisitos | EQUIVALENT             |
| Test analysis     | Análise de teste       | EQUIVALENT             |
| Test design       | Conceção de teste      | EQUIVALENT             |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: analisar requisitos para identificar condições é análise de teste.

**EN:** Correct: identifying test conditions from requirements is analysis.

### o2 — distrator/distractor

**PT:** Não se executam casos nem se comparam resultados neste cenário.

**EN:** No test runs or result comparisons are described.

### o3 — distrator/distractor

**PT:** Não há consolidação/arquivo/relatório de conclusão.

**EN:** No completion consolidation, archival or reporting is described.

### o4 — distrator/distractor

**PT:** Desenvolver condições em casos é diferente de as identificar; a própria justificação distingue os dois.

**EN:** Elaborating conditions into cases differs from identifying conditions, as the rationale correctly explains.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Um testador deriva condições de teste a partir de requisitos. Que atividade é esta?
```

### pt statement RETAINED_UNCHANGED

```text
Um testador deriva condições de teste a partir de requisitos. Que atividade é esta?
```

### en statement ORIGINAL

```text
A tester derives test conditions from requirements. Which activity is this?
```

### en statement RETAINED_UNCHANGED

```text
A tester derives test conditions from requirements. Which activity is this?
```

### o1 pt text ORIGINAL

```text
Análise de teste
```

### o1 pt text RETAINED_UNCHANGED

```text
Análise de teste
```

### o1 pt explanation ORIGINAL

```text
A análise identifica o que é necessário testar.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A análise identifica o que é necessário testar.
```

### o1 en text ORIGINAL

```text
Test analysis
```

### o1 en text RETAINED_UNCHANGED

```text
Test analysis
```

### o1 en explanation ORIGINAL

```text
Analysis identifies what needs testing.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Analysis identifies what needs testing.
```

### o2 pt text ORIGINAL

```text
Execução de teste
```

### o2 pt text RETAINED_UNCHANGED

```text
Execução de teste
```

### o2 pt explanation ORIGINAL

```text
A execução realiza testes e compara resultados.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
A execução realiza testes e compara resultados.
```

### o2 en text ORIGINAL

```text
Test execution
```

### o2 en text RETAINED_UNCHANGED

```text
Test execution
```

### o2 en explanation ORIGINAL

```text
Execution runs tests and compares results.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Execution runs tests and compares results.
```

### o3 pt text ORIGINAL

```text
Conclusão do teste
```

### o3 pt text RETAINED_UNCHANGED

```text
Conclusão do teste
```

### o3 pt explanation ORIGINAL

```text
A conclusão consolida resultados e recursos.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
A conclusão consolida resultados e recursos.
```

### o3 en text ORIGINAL

```text
Test completion
```

### o3 en text RETAINED_UNCHANGED

```text
Test completion
```

### o3 en explanation ORIGINAL

```text
Completion consolidates outcomes and assets.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Completion consolidates outcomes and assets.
```

### o4 pt text ORIGINAL

```text
Conceção de teste
```

### o4 pt text RETAINED_UNCHANGED

```text
Conceção de teste
```

### o4 pt explanation ORIGINAL

```text
A análise define o que testar através de condições de teste. A conceção desenvolve essas condições em casos de teste e determina como as testar.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A análise define o que testar através de condições de teste. A conceção desenvolve essas condições em casos de teste e determina como as testar.
```

### o4 en text ORIGINAL

```text
Test design
```

### o4 en text RETAINED_UNCHANGED

```text
Test design
```

### o4 en explanation ORIGINAL

```text
Analysis defines what to test as test conditions. Design elaborates those conditions into test cases and determines how to test them.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Analysis defines what to test as test conditions. Design elaborates those conditions into test cases and determines how to test them.
```

### pt general explanation ORIGINAL

```text
A análise identifica o que é necessário testar.
```

### pt general explanation RETAINED_UNCHANGED

```text
A análise identifica o que é necessário testar.
```

### en general explanation ORIGINAL

```text
Analysis identifies what needs testing.
```

### en general explanation RETAINED_UNCHANGED

```text
Analysis identifies what needs testing.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A análise identifica o que é necessário testar.
```

### pt affected field OPTIONAL_CANDIDATE

```text
A análise de teste examina requisitos para identificar características testáveis e condições de teste: o que testar. Por exemplo, uma condição pode ser a rejeição de uma data inválida; a conceção transforma depois essa condição em casos com entradas concretas e resultados esperados.
```

### en affected field ORIGINAL

```text
Analysis identifies what needs testing.
```

### en affected field OPTIONAL_CANDIDATE

```text
Test analysis examines requirements to identify testable features and test conditions: what to test. For example, a condition may be that an invalid date is rejected; test design then turns that condition into cases with specific inputs and expected results.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão3→4 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 2                | ['o1']      |
| 2026-10-27.6       | True               | 2                | ['o1']      |
| 2026-10-27.7       | True               | 3                | ['o1']      |
| 2026-10-27.8       | True               | 3                | ['o1']      |
| 2026-10-27.9       | True               | 3                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-013 — ACCEPT_AS_IS

LO`FL-2.1.5`; K2; version2; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`753f11a392722ef65a94fdecba5d1f345ce0495709007a7ef0cdb20986d0d900` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Reviewing acceptance criteria before coding is early static review, hence shift left. It is not executing the application, regression after changes, or end-of-test completion. Before coding and antes de programar carry the same timing for the work under discussion; no claim that all testing must occur before all project code.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter2, §2.1.5; EN4.0.1pp.[24, 27]; PT4.0/v1.0pp.[26, 29, 30]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Rever critérios antes de programar antecipa avaliação e feedback: shift left. É uma revisão estática, mas essa classificação não é uma das opções. Não se descreve execução do software, regressão por alteração ou conclusão dos testes.

**EN:** Review before coding brings evaluation/feedback earlier: shift left. It is also a static review, but that is not a competing offered answer. No software execution, change regression or completion is described.

## Comparação PT/EN / PT/EN comparison

**PT:** Reviewing/rever e before coding/antes de programar preservam revisão e anterioridade. Acceptance criteria/critérios de aceitação são a mesma base. Não se transformou revisão em execução nem se disse que todo o código do projeto tem de estar ausente.

**EN:** Reviewing and before coding preserve review and relative timing. Acceptance criteria are the same basis. Neither text turns review into execution or requires that no project code exist at all.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Critérios podem ser revistos também depois de código existir, e testes dinâmicos podem ser antecipados. O cenário dá um exemplo específico, não definição exclusiva. A explicação breve não diz que se dispensam testes posteriores.

**EN:** Criteria may also be reviewed after code exists and dynamic testing can shift earlier too. This is a specific example, not an exclusive definition. The short explanation does not say later testing is unnecessary.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-2.1.5/K2: reconhecer e explicar um exemplo de antecipação, dificuldade baixa. A explicação é correta mas pode ligar mais claramente a revisão à descoberta de ambiguidades/lacunas; enriquecimento é opcional.

**EN:** FL-2.1.5/K2recognizes/explains an early-testing example; low difficulty. The rationale is correct, with optional scope to explain ambiguity/gap detection more clearly.

## Riscos de interpretação / Interpretation risks

**PT:** Risco baixo de extrapolar shift left para “só testar antes do código”; o enunciado não faz essa afirmação.

**EN:** Low risk of extrapolating shift left to testing only before coding; the item does not make that claim.

## Conceitos críticos / Critical concepts

| ENliteral                     | PTliteral                    | Avaliação / Assessment |
| ----------------------------- | ---------------------------- | ---------------------- |
| Reviewing acceptance criteria | Rever critérios de aceitação | EQUIVALENT             |
| before coding                 | antes de programar           | EQUIVALENT_TIMING      |
| Earlier evaluation            | A avaliação antecipada       | EQUIVALENT             |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: a avaliação de critérios é antecipada no ciclo de vida.

**EN:** Correct: evaluation of criteria is brought earlier in the lifecycle.

### o2 — distrator/distractor

**PT:** Revisão de critérios antes da implementação é estática, não uma execução do objeto.

**EN:** Pre-implementation criteria review is static, not execution of the object.

### o3 — distrator/distractor

**PT:** Não se pede detetar efeitos adversos de uma alteração; a justificação mantém essa diferença.

**EN:** Checking adverse effects of a change is not the stated purpose.

### o4 — distrator/distractor

**PT:** Não se descreve consolidação final; descreve-se feedback antecipado.

**EN:** This is early feedback, not completion consolidation.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Rever critérios de aceitação antes de programar é um exemplo de quê?
```

### pt statement RETAINED_UNCHANGED

```text
Rever critérios de aceitação antes de programar é um exemplo de quê?
```

### en statement ORIGINAL

```text
Reviewing acceptance criteria before coding is an example of what?
```

### en statement RETAINED_UNCHANGED

```text
Reviewing acceptance criteria before coding is an example of what?
```

### o1 pt text ORIGINAL

```text
Shift left
```

### o1 pt text RETAINED_UNCHANGED

```text
Shift left
```

### o1 pt explanation ORIGINAL

```text
A avaliação antecipada permite feedback mais cedo.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A avaliação antecipada permite feedback mais cedo.
```

### o1 en text ORIGINAL

```text
Shift left
```

### o1 en text RETAINED_UNCHANGED

```text
Shift left
```

### o1 en explanation ORIGINAL

```text
Earlier evaluation gives earlier feedback.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Earlier evaluation gives earlier feedback.
```

### o2 pt text ORIGINAL

```text
Execução de teste
```

### o2 pt text RETAINED_UNCHANGED

```text
Execução de teste
```

### o2 pt explanation ORIGINAL

```text
A execução de teste executa o objeto de teste e compara os resultados obtidos e esperados. Rever critérios antes da implementação é uma atividade estática antecipada que ilustra shift left.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
A execução de teste executa o objeto de teste e compara os resultados obtidos e esperados. Rever critérios antes da implementação é uma atividade estática antecipada que ilustra shift left.
```

### o2 en text ORIGINAL

```text
Test execution
```

### o2 en text RETAINED_UNCHANGED

```text
Test execution
```

### o2 en explanation ORIGINAL

```text
Executing tests runs the test object and compares actual and expected results. Reviewing criteria before implementation is an earlier, static activity illustrating shift left.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Executing tests runs the test object and compares actual and expected results. Reviewing criteria before implementation is an earlier, static activity illustrating shift left.
```

### o3 pt text ORIGINAL

```text
Teste de regressão
```

### o3 pt text RETAINED_UNCHANGED

```text
Teste de regressão
```

### o3 pt explanation ORIGINAL

```text
O teste de regressão procura efeitos adversos de alterações. A finalidade descrita é obter feedback mais cedo sobre critérios de aceitação, não verificar efeitos de uma alteração.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
O teste de regressão procura efeitos adversos de alterações. A finalidade descrita é obter feedback mais cedo sobre critérios de aceitação, não verificar efeitos de uma alteração.
```

### o3 en text ORIGINAL

```text
Regression testing
```

### o3 en text RETAINED_UNCHANGED

```text
Regression testing
```

### o3 en explanation ORIGINAL

```text
Regression testing checks adverse effects of changes. The described purpose is earlier feedback on acceptance criteria, not checking effects of a change.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Regression testing checks adverse effects of changes. The described purpose is earlier feedback on acceptance criteria, not checking effects of a change.
```

### o4 pt text ORIGINAL

```text
Conclusão do teste
```

### o4 pt text RETAINED_UNCHANGED

```text
Conclusão do teste
```

### o4 pt explanation ORIGINAL

```text
A conclusão consolida resultados e recursos de teste após as atividades de teste. Rever critérios antes da programação antecipa a avaliação no ciclo de vida.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A conclusão consolida resultados e recursos de teste após as atividades de teste. Rever critérios antes da programação antecipa a avaliação no ciclo de vida.
```

### o4 en text ORIGINAL

```text
Test completion
```

### o4 en text RETAINED_UNCHANGED

```text
Test completion
```

### o4 en explanation ORIGINAL

```text
Completion consolidates results and test assets after test activities. Reviewing criteria before coding brings evaluation earlier in the lifecycle.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Completion consolidates results and test assets after test activities. Reviewing criteria before coding brings evaluation earlier in the lifecycle.
```

### pt general explanation ORIGINAL

```text
A avaliação antecipada permite feedback mais cedo.
```

### pt general explanation RETAINED_UNCHANGED

```text
A avaliação antecipada permite feedback mais cedo.
```

### en general explanation ORIGINAL

```text
Earlier evaluation gives earlier feedback.
```

### en general explanation RETAINED_UNCHANGED

```text
Earlier evaluation gives earlier feedback.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A avaliação antecipada permite feedback mais cedo.
```

### pt affected field OPTIONAL_CANDIDATE

```text
Rever critérios de aceitação antes da implementação proporciona feedback antecipado e pode revelar ambiguidades, lacunas e inconsistências. Isto ilustra shift left; não elimina a necessidade de testar mais tarde no ciclo de vida.
```

### en affected field ORIGINAL

```text
Earlier evaluation gives earlier feedback.
```

### en affected field OPTIONAL_CANDIDATE

```text
Reviewing acceptance criteria before implementation provides early feedback and can reveal ambiguities, gaps and inconsistencies. This illustrates shift left; it does not remove the need for testing later in the lifecycle.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão2→3 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 2                | ['o1']      |
| 2026-10-27.9       | True               | 2                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-014 — ACCEPT_AS_IS

LO`FL-2.3.1`; K2; version2; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`097b7b185935afe35bf1aa220c8be6d3ed7a121165a5b9136c2b5d44d15cca27` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

An operational service migrating database engine changes its environment and can affect data/behaviour even with unchanged application code. Maintenance testing considers migration impacts; prior results do not automatically prove compatibility, maintenance is not code-only, and data checks do not substitute all behavioural regression. Can/pode describes potential impact, not guaranteed failure or a universal fixed test obligation.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter2, §2.3; EN4.0.1pp.[24, 31]; PT4.0/v1.0pp.[26, 33, 34]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Mudar o motor de base de dados altera o ambiente de um serviço operacional e pode afetar dados/comportamento. Migração é motivo de manutenção; sucesso da alteração e regressões são relevantes mesmo com código da aplicação inalterado. o1 mantém modalidade de possibilidade.

**EN:** A database-engine migration changes an operational service’s environment and may affect data/behaviour. Migration triggers maintenance considerations; change success/regressions matter even with unchanged application code. o1correctly states possibility.

## Comparação PT/EN / PT/EN comparison

**PT:** Operational/em operação, can/pode, existing behavior/comportamento existente e even without/mesmo sem mantêm contexto e modalidade. Não se traduziu “pode” como “vai” ou “tem de”, nem se tornou obrigatória conversão de dados.

**EN:** Operational, can, existing behaviour and even without preserve context and modality. Can is not translated as will/must, and data conversion is not made universally mandatory.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Nem toda mudança causa defeitos nem toda migração exige conversão de dados. Isso não invalida planear testes: o1 fala em risco possível. O âmbito depende do risco, do sistema e da dimensão da alteração; não se infere uma suite fixa para qualquer migração.

**EN:** Not every change causes defects or requires data conversion. That does not invalidate planning tests: o1states possible impact. Scope depends on change risk/system/change size, not a universal fixed suite.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-2.3.1/K2: explicar um gatilho concreto de manutenção; dificuldade baixa/média. A frase geral é suficiente, e as justificações dos distratores já explicam risco/regressão. Uma expansão é útil mas opcional.

**EN:** FL-2.3.1/K2explains a concrete maintenance trigger; low/moderate difficulty. The short summary is sufficient and distractor rationales explain risk/regression; expansion is optional.

## Riscos de interpretação / Interpretation risks

**PT:** Risco baixo de inferir regressão garantida ou conversão obrigatória; nenhuma é afirmada.

**EN:** Low risk of reading guaranteed regression or mandatory conversion into wording that states neither.

## Conceitos críticos / Critical concepts

| ENliteral           | PTliteral              | Avaliação / Assessment |
| ------------------- | ---------------------- | ---------------------- |
| operational service | serviço em operação    | EQUIVALENT             |
| can affect          | pode afetar            | EQUIVALENT_MODALITY    |
| even without        | mesmo sem              | EQUIVALENT_CONDITION   |
| database engine     | motor de base de dados | EQUIVALENT             |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: possibilidade de impacto justifica avaliar alteração e regressões.

**EN:** Correct: potential impact justifies evaluating change and regressions.

### o2 — distrator/distractor

**PT:** Requisitos iguais não demonstram comportamento correto num motor diferente.

**EN:** Unchanged requirements do not prove correct behaviour on another engine.

### o3 — distrator/distractor

**PT:** Excluir migrações do ambiente contradiz os gatilhos de manutenção.

**EN:** Excluding environment migration contradicts maintenance triggers.

### o4 — distrator/distractor

**PT:** Verificar dados não substitui avaliar comportamento existente.

**EN:** Data verification does not replace evaluating existing behaviour.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Um serviço em operação muda para outro motor de base de dados. Porquê planear testes de manutenção?
```

### pt statement RETAINED_UNCHANGED

```text
Um serviço em operação muda para outro motor de base de dados. Porquê planear testes de manutenção?
```

### en statement ORIGINAL

```text
An operational service moves to a new database engine. Why plan maintenance testing?
```

### en statement RETAINED_UNCHANGED

```text
An operational service moves to a new database engine. Why plan maintenance testing?
```

### o1 pt text ORIGINAL

```text
A migração pode afetar dados e comportamento existente, mesmo sem alterar o código da aplicação
```

### o1 pt text RETAINED_UNCHANGED

```text
A migração pode afetar dados e comportamento existente, mesmo sem alterar o código da aplicação
```

### o1 pt explanation ORIGINAL

```text
A migração do ambiente é um motivo para testes de manutenção.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A migração do ambiente é um motivo para testes de manutenção.
```

### o1 en text ORIGINAL

```text
Migration can affect the data and existing behavior, even without application code changes
```

### o1 en text RETAINED_UNCHANGED

```text
Migration can affect the data and existing behavior, even without application code changes
```

### o1 en explanation ORIGINAL

```text
Environment migration is a maintenance-testing trigger.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Environment migration is a maintenance-testing trigger.
```

### o2 pt text ORIGINAL

```text
Os resultados anteriores continuam a ser suficientes para o novo ambiente porque as funcionalidades da aplicação não mudaram
```

### o2 pt text RETAINED_UNCHANGED

```text
Os resultados anteriores continuam a ser suficientes para o novo ambiente porque as funcionalidades da aplicação não mudaram
```

### o2 pt explanation ORIGINAL

```text
Requisitos funcionais inalterados não demonstram que a aplicação se comporta corretamente com outro motor de base de dados. A migração pode introduzir regressões.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Requisitos funcionais inalterados não demonstram que a aplicação se comporta corretamente com outro motor de base de dados. A migração pode introduzir regressões.
```

### o2 en text ORIGINAL

```text
Existing test results remain sufficient for the new environment because application features are unchanged
```

### o2 en text RETAINED_UNCHANGED

```text
Existing test results remain sufficient for the new environment because application features are unchanged
```

### o2 en explanation ORIGINAL

```text
Unchanged feature requirements do not establish that the application behaves correctly with a different database engine. Migration can introduce regressions.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Unchanged feature requirements do not establish that the application behaves correctly with a different database engine. Migration can introduce regressions.
```

### o3 pt text ORIGINAL

```text
Os testes de manutenção dizem respeito a alterações de código, não a migrações de ambiente
```

### o3 pt text RETAINED_UNCHANGED

```text
Os testes de manutenção dizem respeito a alterações de código, não a migrações de ambiente
```

### o3 pt explanation ORIGINAL

```text
Os testes de manutenção podem ser desencadeados por atualizações ou migrações do ambiente, não apenas por alterações ao código-fonte.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Os testes de manutenção podem ser desencadeados por atualizações ou migrações do ambiente, não apenas por alterações ao código-fonte.
```

### o3 en text ORIGINAL

```text
Maintenance testing concerns code changes rather than environment migrations
```

### o3 en text RETAINED_UNCHANGED

```text
Maintenance testing concerns code changes rather than environment migrations
```

### o3 en explanation ORIGINAL

```text
Maintenance testing can be triggered by environment upgrades or migrations, not just source-code changes.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Maintenance testing can be triggered by environment upgrades or migrations, not just source-code changes.
```

### o4 pt text ORIGINAL

```text
As verificações da migração de dados substituem as verificações de regressão do comportamento do serviço
```

### o4 pt text RETAINED_UNCHANGED

```text
As verificações da migração de dados substituem as verificações de regressão do comportamento do serviço
```

### o4 pt explanation ORIGINAL

```text
A correção dos dados é importante, mas o novo motor também pode afetar o comportamento existente da aplicação. Os testes de manutenção incluem avaliar a alteração e possíveis regressões.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A correção dos dados é importante, mas o novo motor também pode afetar o comportamento existente da aplicação. Os testes de manutenção incluem avaliar a alteração e possíveis regressões.
```

### o4 en text ORIGINAL

```text
Data-migration checks replace regression checks of the service behavior
```

### o4 en text RETAINED_UNCHANGED

```text
Data-migration checks replace regression checks of the service behavior
```

### o4 en explanation ORIGINAL

```text
Data correctness matters, but the new engine can also affect existing application behavior. Maintenance testing includes evaluating the change and possible regressions.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Data correctness matters, but the new engine can also affect existing application behavior. Maintenance testing includes evaluating the change and possible regressions.
```

### pt general explanation ORIGINAL

```text
A migração do ambiente é um motivo para testes de manutenção.
```

### pt general explanation RETAINED_UNCHANGED

```text
A migração do ambiente é um motivo para testes de manutenção.
```

### en general explanation ORIGINAL

```text
Environment migration is a maintenance-testing trigger.
```

### en general explanation RETAINED_UNCHANGED

```text
Environment migration is a maintenance-testing trigger.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A migração do ambiente é um motivo para testes de manutenção.
```

### pt affected field OPTIONAL_CANDIDATE

```text
Migrar o ambiente operacional é um motivo para testes de manutenção. Avaliam-se a migração e possíveis regressões, com âmbito baseado no risco da alteração e nas dimensões do sistema e da alteração. As verificações de conversão de dados aplicam-se quando pertinentes, não automaticamente a todas as migrações.
```

### en affected field ORIGINAL

```text
Environment migration is a maintenance-testing trigger.
```

### en affected field OPTIONAL_CANDIDATE

```text
Migrating the operational environment is a maintenance-testing trigger. Evaluate the migration and possible regressions, with scope based on the change risk, system size and change size. Data-conversion checks apply when relevant, not automatically to every migration.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão2→3 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 2                | ['o1']      |
| 2026-10-27.9       | True               | 2                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-015 — ACCEPT_AS_IS

LO`FL-3.1.1`; K1; version2; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`3230a0db86ddcdf03432fd2813f478eb2b7827bc60876819ede181b22402649b` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Documented checkout-validation requirements are written work products that can be reviewed without running the application. Measured latency, memory growth under concurrent load and actual checkout behaviour describe dynamic observations, not their documentary representations. One could review a report of those observations statically, but no such report is the offered item. Checkout/compra has some lexical scope difference, without changing the artifact-versus-behaviour criterion.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter3, §3.1.1; EN4.0.1pp.[32, 33]; PT4.0/v1.0pp.[35, 36]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** o1 oferece requisitos escritos, examináveis por revisão sem executar a aplicação. As outras opções são propriedades/comportamentos observados dinamicamente. A restrição “diretamente” e “conteúdo escrito” distingue o objeto avaliado de um eventual relatório sobre ele.

**EN:** o1offers written requirements reviewable without running the application. Other options describe dynamically observed properties/behaviour. Directly and written content distinguish the evaluated object from a possible report about it.

## Comparação PT/EN / PT/EN comparison

**PT:** Written content/conteúdo escrito e documented requirements/requisitos escritos preservam artefacto legível. Directly/diretamente e without/sem preservam a restrição. Checkout/compra é menos específico em PT, mas não altera o critério documento versus observação; Pay/Pagar é consistente.

**EN:** Written content/documented requirements retain a readable artifact. Directly and without preserve the restriction. Compra is less specific than checkout but leaves the document-versus-observation criterion intact; Pay/Pagar is consistent.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Uma medição já registada pode ser lida num relatório, e esse relatório pode ser revisto estaticamente. A opção diz latência medida, não relatório; o enunciado pede conteúdo escrito. A justificação de o3 reconhece explicitamente o relatório como outra atividade. Risco residual existe, sem segunda alternativa direta demonstrada.

**EN:** An already recorded measurement can be reviewed in a report, which is a static activity. The option offers measured latency, not a report, and the statement requires written content. o3’s rationale explicitly recognizes that report review is different. Residual risk exists without a demonstrated second direct answer.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-3.1.1/K1: reconhecer um produto revisto estaticamente, dificuldade baixa. A distinção não deve ser ensinada como “só requisitos admitem revisão”; muitos produtos de trabalho, incluindo relatórios, podem ser revistos.

**EN:** FL-3.1.1/K1recognizes a statically reviewable work product; low difficulty. It must not be taught as only requirements being reviewable; many work products, including reports, qualify.

## Riscos de interpretação / Interpretation risks

**PT:** Risco interpretativo LOW em “measured/medida” permitir pensar num resultado documentado, não oferecido explicitamente. Uma redação verbal da opção reduz a inferência sem mudar a chave.

**EN:** LOWinterpretation risk: measured may prompt an unoffered documented-result reading. A verbal option wording reduces that inference without changing the key.

## Conceitos críticos / Critical concepts

| ENliteral                 | PTliteral                   | Avaliação / Assessment       |
| ------------------------- | --------------------------- | ---------------------------- |
| written content           | conteúdo escrito            | EQUIVALENT_ARTIFACT          |
| Documented requirements   | Os requisitos escritos      | EQUIVALENT_ARTIFACT          |
| directly                  | diretamente                 | EQUIVALENT_RESTRICTION       |
| without executing         | sem executar                | EQUIVALENT_RESTRICTION       |
| measured response latency | latência de resposta medida | SAME_RESIDUAL_REPORT_READING |
| after selecting Pay       | após selecionar Pagar       | EQUIVALENT_CONTEXT           |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: os requisitos estão expressamente documentados/escritos.

**EN:** Correct: requirements are explicitly documented/written.

### o2 — distrator/distractor

**PT:** A latência medida é observação dinâmica, não conteúdo documental oferecido; reconhecer a leitura alternativa de relatório sem a inventar.

**EN:** Measured latency is a dynamic observation, not an offered document; acknowledge report interpretation without inventing one.

### o3 — distrator/distractor

**PT:** Memória sob carga é observada com execução; rever relatório posterior é outra atividade.

**EN:** Memory under load is observed during execution; reviewing a later report is different.

### o4 — distrator/distractor

**PT:** Observar o efeito de Pagar exige execução; um requisito desse efeito seria revisto estaticamente, mas não é esta opção.

**EN:** Observing Pay behaviour requires execution; a written requirement about it would be a different static object.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Que item pode ser examinado diretamente através da revisão do seu conteúdo escrito, sem executar a aplicação?
```

### pt statement RETAINED_UNCHANGED

```text
Que item pode ser examinado diretamente através da revisão do seu conteúdo escrito, sem executar a aplicação?
```

### en statement ORIGINAL

```text
Which item is directly examinable by reviewing its written content, without executing the application?
```

### en statement RETAINED_UNCHANGED

```text
Which item is directly examinable by reviewing its written content, without executing the application?
```

### o1 pt text ORIGINAL

```text
Os requisitos escritos sobre regras de validação da compra
```

### o1 pt text RETAINED_UNCHANGED

```text
Os requisitos escritos sobre regras de validação da compra
```

### o1 pt explanation ORIGINAL

```text
Os requisitos podem ser inspecionados diretamente.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
Os requisitos podem ser inspecionados diretamente.
```

### o1 en text ORIGINAL

```text
Documented requirements for checkout validation rules
```

### o1 en text RETAINED_UNCHANGED

```text
Documented requirements for checkout validation rules
```

### o1 en explanation ORIGINAL

```text
Requirements can be inspected directly.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Requirements can be inspected directly.
```

### o2 pt text ORIGINAL

```text
A latência de resposta medida no serviço de compras
```

### o2 pt text RETAINED_UNCHANGED

```text
A latência de resposta medida no serviço de compras
```

### o2 pt explanation ORIGINAL

```text
Medir a latência de resposta exige execução em condições definidas; é uma avaliação dinâmica, não a inspeção de um documento.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Medir a latência de resposta exige execução em condições definidas; é uma avaliação dinâmica, não a inspeção de um documento.
```

### o2 en text ORIGINAL

```text
The checkout service's measured response latency
```

### o2 en text RETAINED_UNCHANGED

```text
The checkout service's measured response latency
```

### o2 en explanation ORIGINAL

```text
Measuring response latency requires execution under defined conditions; it is a dynamic evaluation rather than inspection of a document.
```

### o2 en explanation RETAINED_UNCHANGED

```text
Measuring response latency requires execution under defined conditions; it is a dynamic evaluation rather than inspection of a document.
```

### o3 pt text ORIGINAL

```text
O crescimento de memória da aplicação sob carga concorrente
```

### o3 pt text RETAINED_UNCHANGED

```text
O crescimento de memória da aplicação sob carga concorrente
```

### o3 pt explanation ORIGINAL

```text
O crescimento da memória durante um teste de carga é observado com a aplicação em execução. Rever posteriormente um relatório escrito seria uma atividade diferente, estática.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
O crescimento da memória durante um teste de carga é observado com a aplicação em execução. Rever posteriormente um relatório escrito seria uma atividade diferente, estática.
```

### o3 en text ORIGINAL

```text
The application's memory growth under concurrent load
```

### o3 en text RETAINED_UNCHANGED

```text
The application's memory growth under concurrent load
```

### o3 en explanation ORIGINAL

```text
Memory growth during a load test is observed while the application executes. A later review of a written report would be a different, static activity.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Memory growth during a load test is observed while the application executes. A later review of a written report would be a different, static activity.
```

### o4 pt text ORIGINAL

```text
O comportamento da compra observado após selecionar Pagar
```

### o4 pt text RETAINED_UNCHANGED

```text
O comportamento da compra observado após selecionar Pagar
```

### o4 pt explanation ORIGINAL

```text
Observar o comportamento após uma ação exige executar a aplicação. Um requisito que descreva esse comportamento pode, em alternativa, ser revisto estaticamente.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
Observar o comportamento após uma ação exige executar a aplicação. Um requisito que descreva esse comportamento pode, em alternativa, ser revisto estaticamente.
```

### o4 en text ORIGINAL

```text
The observed checkout behavior after selecting Pay
```

### o4 en text RETAINED_UNCHANGED

```text
The observed checkout behavior after selecting Pay
```

### o4 en explanation ORIGINAL

```text
Observing the behavior after an action requires executing the application. A requirement describing that behavior can instead be reviewed statically.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Observing the behavior after an action requires executing the application. A requirement describing that behavior can instead be reviewed statically.
```

### pt general explanation ORIGINAL

```text
Os requisitos podem ser inspecionados diretamente.
```

### pt general explanation RETAINED_UNCHANGED

```text
Os requisitos podem ser inspecionados diretamente.
```

### en general explanation ORIGINAL

```text
Requirements can be inspected directly.
```

### en general explanation RETAINED_UNCHANGED

```text
Requirements can be inspected directly.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['options', 'o2', 'text']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A latência de resposta medida no serviço de compras
```

### pt affected field OPTIONAL_CANDIDATE

```text
Medir a latência de resposta do serviço de compras
```

### en affected field ORIGINAL

```text
The checkout service's measured response latency
```

### en affected field OPTIONAL_CANDIDATE

```text
Measuring the checkout service's response latency
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão2→3 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 2                | ['o1']      |
| 2026-10-27.9       | True               | 2                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-017 — ACCEPT_AS_IS

LO`FL-3.1.3`; K2; version2; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`d6970fd1e3c435ea6b01ceb5e26bcd68779b3490e3ce9c57592d1477164fe2f6` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Contradictory requirements are a defect directly found in a work product by review. An incorrectly displayed date observed during execution is a failure. Neither observation alone locates the faulty code statement or proves a particular human mistake/root cause. Defect/failure is not interchangeable with human error. Only o1 preserves this distinction.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter3, §3.1.3; EN4.0.1pp.[32, 34]; PT4.0/v1.0pp.[35, 37]. Referências complementares / supporting sections: [{'section': '1.2.3', 'EN': [17], 'PT': [18, 19]}]. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** A revisão identifica diretamente contradição nos requisitos: defeito no produto de trabalho. A execução observa data incorreta: falha. Não se identificam automaticamente uma instrução de código ou um erro humano específico; o cenário não demonstra ligação causal entre os dois achados.

**EN:** Review directly identifies contradictory requirements: a work-product defect. Execution observes an incorrect date: a failure. Neither automatically identifies a faulty code statement or specific human mistake; no causal link between the two findings is demonstrated.

## Comparação PT/EN / PT/EN comparison

**PT:** Contradictory/contraditórios, directly/diretamente, defect/defeito e failure/falha mantêm conceitos. “Data incorreta apresentada” é resultado observado, não tradução de erro humano. A explicação geral usa “imperfeições” informalmente; as alternativas e justificações usam os termos precisos.

**EN:** Contradictory, directly, defect and failure preserve the concepts. An incorrectly displayed date is an observed outcome, not a human error. The informal flaws word in the summary does not replace the precise terms in the options/rationales.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Testes dinâmicos, seguidos de análise, podem levar à localização de defeitos. Isso não significa que a observação por si só já identificou a instrução defeituosa. “Execution exposes failures” é descrição do mecanismo no cenário com falha observada, não garantia de que qualquer execução falhe.

**EN:** Dynamic testing plus analysis may lead to defects; the observation alone does not locate the faulty statement. Execution exposes failures describes the mechanism in this failed scenario, not a guarantee that every run fails.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-3.1.3/K2: comparar dois mecanismos a partir de achados concretos, dificuldade baixa/média. Convém separar erro humano, defeito, falha e causa raiz; a questão não atribui culpados nem prova uma causa comum.

**EN:** FL-3.1.3/K2compares mechanisms using concrete findings; low/moderate difficulty. Human error, defect, failure and root cause must remain distinct; no blame or shared cause is established.

## Riscos de interpretação / Interpretation risks

**PT:** Risco baixo de generalizar a explicação breve para toda execução ou supor causa comum; a chave não depende dessas inferências.

**EN:** Low risk of generalizing the brief summary to every run or assuming common causation; neither is needed for the key.

## Conceitos críticos / Critical concepts

| ENliteral                       | PTliteral                          | Avaliação / Assessment     |
| ------------------------------- | ---------------------------------- | -------------------------- |
| contradictory date requirements | requisitos contraditórios de datas | EQUIVALENT_DEFECT          |
| defect directly                 | diretamente um defeito             | EQUIVALENT_DEFECT          |
| observed a failure              | observou uma falha                 | EQUIVALENT_FAILURE         |
| faulty statement                | instrução incorreta                | SAME_UNSUPPORTED_DIAGNOSIS |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: defeito direto na revisão, falha observada na execução.

**EN:** Correct: direct review defect, observed execution failure.

### o2 — distrator/distractor

**PT:** Inverte os mecanismos e inventa diagnóstico direto de código.

**EN:** Reverses the mechanisms and invents direct code diagnosis.

### o3 — distrator/distractor

**PT:** Contradição documental não é falha de execução só por contrariar expectativas.

**EN:** A document contradiction is not an execution failure merely because it conflicts with expectations.

### o4 — distrator/distractor

**PT:** O requisito defeituoso não é código; o resultado incorreto não localiza por si só uma instrução.

**EN:** The requirement defect is not code, and the output alone does not locate a statement.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Uma revisão encontra requisitos contraditórios de datas; a execução encontra uma data incorreta apresentada. Qual afirmação é correta?
```

### pt statement RETAINED_UNCHANGED

```text
Uma revisão encontra requisitos contraditórios de datas; a execução encontra uma data incorreta apresentada. Qual afirmação é correta?
```

### en statement ORIGINAL

```text
Review finds contradictory date requirements; execution finds an incorrect date displayed. Which statement is accurate?
```

### en statement RETAINED_UNCHANGED

```text
Review finds contradictory date requirements; execution finds an incorrect date displayed. Which statement is accurate?
```

### o1 pt text ORIGINAL

```text
O teste estático encontrou diretamente um defeito; o dinâmico observou uma falha
```

### o1 pt text RETAINED_UNCHANGED

```text
O teste estático encontrou diretamente um defeito; o dinâmico observou uma falha
```

### o1 pt explanation ORIGINAL

```text
A revisão pode encontrar imperfeições sem execução; a execução revela falhas.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A revisão pode encontrar imperfeições sem execução; a execução revela falhas.
```

### o1 en text ORIGINAL

```text
Static testing found a defect directly; dynamic testing observed a failure
```

### o1 en text RETAINED_UNCHANGED

```text
Static testing found a defect directly; dynamic testing observed a failure
```

### o1 en explanation ORIGINAL

```text
Review can find flaws without execution; execution exposes failures.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Review can find flaws without execution; execution exposes failures.
```

### o2 pt text ORIGINAL

```text
O teste estático observou uma falha; o dinâmico localizou diretamente o defeito no código
```

### o2 pt text RETAINED_UNCHANGED

```text
O teste estático observou uma falha; o dinâmico localizou diretamente o defeito no código
```

### o2 pt explanation ORIGINAL

```text
Os mecanismos estão invertidos: a revisão do documento encontra diretamente a inconsistência, enquanto a data incorreta apresentada é uma falha observada que exige análise adicional para localizar a causa.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
Os mecanismos estão invertidos: a revisão do documento encontra diretamente a inconsistência, enquanto a data incorreta apresentada é uma falha observada que exige análise adicional para localizar a causa.
```

### o2 en text ORIGINAL

```text
Static testing observed a failure; dynamic testing directly located the code defect
```

### o2 en text RETAINED_UNCHANGED

```text
Static testing observed a failure; dynamic testing directly located the code defect
```

### o2 en explanation ORIGINAL

```text
The mechanisms are reversed: a document review finds the inconsistency directly, while the wrong displayed date is an observed failure requiring further analysis to locate its cause.
```

### o2 en explanation RETAINED_UNCHANGED

```text
The mechanisms are reversed: a document review finds the inconsistency directly, while the wrong displayed date is an observed failure requiring further analysis to locate its cause.
```

### o3 pt text ORIGINAL

```text
Ambos encontraram falhas porque ambos os resultados contrariam as expectativas
```

### o3 pt text RETAINED_UNCHANGED

```text
Ambos encontraram falhas porque ambos os resultados contrariam as expectativas
```

### o3 pt explanation ORIGINAL

```text
Uma falha é um desvio observado durante a execução. Requisitos escritos contraditórios são defeitos encontrados sem executar a aplicação.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
Uma falha é um desvio observado durante a execução. Requisitos escritos contraditórios são defeitos encontrados sem executar a aplicação.
```

### o3 en text ORIGINAL

```text
Both found failures because both results conflict with expectations
```

### o3 en text RETAINED_UNCHANGED

```text
Both found failures because both results conflict with expectations
```

### o3 en explanation ORIGINAL

```text
A failure is a deviation observed during execution. Contradictory written requirements are defects found without executing the application.
```

### o3 en explanation RETAINED_UNCHANGED

```text
A failure is a deviation observed during execution. Contradictory written requirements are defects found without executing the application.
```

### o4 pt text ORIGINAL

```text
Ambos encontraram diretamente defeitos no código porque cada resultado identifica a instrução incorreta
```

### o4 pt text RETAINED_UNCHANGED

```text
Ambos encontraram diretamente defeitos no código porque cada resultado identifica a instrução incorreta
```

### o4 pt explanation ORIGINAL

```text
A revisão encontrou um defeito nos requisitos, não uma instrução de código. A falha apresentada, por si só, não identifica a instrução de código que a causou.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
A revisão encontrou um defeito nos requisitos, não uma instrução de código. A falha apresentada, por si só, não identifica a instrução de código que a causou.
```

### o4 en text ORIGINAL

```text
Both directly found code defects because each result identifies the faulty statement
```

### o4 en text RETAINED_UNCHANGED

```text
Both directly found code defects because each result identifies the faulty statement
```

### o4 en explanation ORIGINAL

```text
The review found a requirements defect, not a code statement. The displayed failure alone does not identify which code statement caused it.
```

### o4 en explanation RETAINED_UNCHANGED

```text
The review found a requirements defect, not a code statement. The displayed failure alone does not identify which code statement caused it.
```

### pt general explanation ORIGINAL

```text
A revisão pode encontrar imperfeições sem execução; a execução revela falhas.
```

### pt general explanation RETAINED_UNCHANGED

```text
A revisão pode encontrar imperfeições sem execução; a execução revela falhas.
```

### en general explanation ORIGINAL

```text
Review can find flaws without execution; execution exposes failures.
```

### en general explanation RETAINED_UNCHANGED

```text
Review can find flaws without execution; execution exposes failures.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A revisão pode encontrar imperfeições sem execução; a execução revela falhas.
```

### pt affected field OPTIONAL_CANDIDATE

```text
A revisão identifica diretamente um defeito nos requisitos. A data incorreta apresentada é uma falha observada cuja causa exige análise adicional. O cenário não demonstra que os dois achados tenham a mesma causa, e executar testes não garante encontrar uma falha.
```

### en affected field ORIGINAL

```text
Review can find flaws without execution; execution exposes failures.
```

### en affected field OPTIONAL_CANDIDATE

```text
The review directly identifies a defect in the requirements. The incorrect displayed date is an observed failure whose cause requires further analysis. The scenario does not establish that the two findings share a cause, and executing tests does not guarantee finding a failure.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão2→3 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 2                | ['o1']      |
| 2026-10-27.9       | True               | 2                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-019 — ACCEPT_AS_IS

LO`FL-4.1.1`; K2; version2; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`87318d66d89b5640ca9aa15567d2d5d9520c80012c9117f22ff44eff058be100` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Externally specified behaviour is the stated derivation basis and code structure is excluded: black-box techniques. White-box requires structure; experience-based derives from tester experience rather than the supplied specification basis. Risk-based testing can influence selection/priorities alongside any technique family, but no risk criterion is given and it is not the requested family in this classification.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter4, §4.1; EN4.0.1pp.[38, 39]; PT4.0/v1.0pp.[41, 42]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** A origem dos testes é comportamento especificado externamente e a estrutura do código é excluída da derivação: caixa-preta. Caixa-branca baseia-se na estrutura; experiência baseia-se no conhecimento do testador. Risco pode orientar âmbito/prioridade de testes de qualquer família, mas não é a família pedida por esta base.

**EN:** Externally specified behaviour is the derivation basis and code structure is excluded: black-box. White-box uses structure; experience-based uses tester knowledge. Risk may guide scope/priority with any family but is not the family defined by the supplied basis.

## Comparação PT/EN / PT/EN comparison

**PT:** Externally specified/especificado externamente e without using/sem usar preservam a base e a exclusão. Não se diz que o testador está proibido de conhecer o código, apenas que não o usa para derivar estes testes. Caixa-preta/branca e experiência mantêm a classificação.

**EN:** Externally specified and without using preserve the basis/exclusion. This does not forbid tester knowledge of code; it excludes structure as the derivation basis for these tests. The family names remain equivalent.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Testadores podem usar experiência ao aplicar caixa-preta, e testes podem ser priorizados por risco. Essa combinação real não altera a classificação solicitada pela origem especificada. Ausência de estrutura, sozinha, não bastaria; o enunciado também fornece positivamente a especificação.

**EN:** Experience may inform black-box work and risk may prioritize tests. Those combinations do not change the requested classification by derivation basis. No code structure alone would be insufficient, but the statement also positively supplies the specification.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-4.1.1/K2: distinguir bases de três famílias, dificuldade baixa. A explicação curta é correta; as justificações de o2/o3/o4 já dão o contraste. Não é necessário inventar novos requisitos ou aplicar uma técnicaK3.

**EN:** FL-4.1.1/K2distinguishes the three families’ bases; low difficulty. The short summary is correct, supplemented by o2/o3/o4contrasts. No new requirement orK3technique derivation is necessary.

## Riscos de interpretação / Interpretation risks

**PT:** Risco baixo de ensinar famílias como atividades mutuamente exclusivas em todo o projeto; a pergunta classifica a base destes testes, não toda a estratégia.

**EN:** Low risk of treating families as mutually exclusive across an entire project; this item classifies these tests’ basis, not the whole strategy.

## Conceitos críticos / Critical concepts

| ENliteral                      | PTliteral                               | Avaliação / Assessment |
| ------------------------------ | --------------------------------------- | ---------------------- |
| externally specified behaviour | comportamento especificado externamente | EQUIVALENT_BASIS       |
| without using code structure   | sem usar a estrutura do código          | EQUIVALENT_RESTRICTION |
| Black-box techniques           | Técnicas de caixa-preta                 | EQUIVALENT             |
| Experience-based techniques    | Técnicas baseadas na experiência        | EQUIVALENT             |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: derivação do comportamento especificado sem estrutura.

**EN:** Correct: specification-based derivation without structural basis.

### o2 — distrator/distractor

**PT:** Estrutura interna seria necessária como base, mas está excluída.

**EN:** Internal structure would be the basis, but is excluded.

### o3 — distrator/distractor

**PT:** Conhecimento/experiência pode apoiar, mas não é a origem expressamente dada.

**EN:** Experience can support work but is not the expressly stated source.

### o4 — distrator/distractor

**PT:** Risco orienta decisões e pode combinar-se com caixa-preta; não substitui a família pedida.

**EN:** Risk guides decisions and can combine with black-box; it does not replace the requested family.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Testes derivados do comportamento especificado externamente, sem usar a estrutura do código, pertencem a que família?
```

### pt statement RETAINED_UNCHANGED

```text
Testes derivados do comportamento especificado externamente, sem usar a estrutura do código, pertencem a que família?
```

### en statement ORIGINAL

```text
Tests derived from externally specified behaviour, without using code structure, belong to which family?
```

### en statement RETAINED_UNCHANGED

```text
Tests derived from externally specified behaviour, without using code structure, belong to which family?
```

### o1 pt text ORIGINAL

```text
Técnicas de caixa-preta
```

### o1 pt text RETAINED_UNCHANGED

```text
Técnicas de caixa-preta
```

### o1 pt explanation ORIGINAL

```text
A origem é o comportamento especificado.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A origem é o comportamento especificado.
```

### o1 en text ORIGINAL

```text
Black-box techniques
```

### o1 en text RETAINED_UNCHANGED

```text
Black-box techniques
```

### o1 en explanation ORIGINAL

```text
The source is specified behaviour.
```

### o1 en explanation RETAINED_UNCHANGED

```text
The source is specified behaviour.
```

### o2 pt text ORIGINAL

```text
Técnicas de caixa-branca
```

### o2 pt text RETAINED_UNCHANGED

```text
Técnicas de caixa-branca
```

### o2 pt explanation ORIGINAL

```text
As técnicas de caixa-branca usam a estrutura interna.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
As técnicas de caixa-branca usam a estrutura interna.
```

### o2 en text ORIGINAL

```text
White-box techniques
```

### o2 en text RETAINED_UNCHANGED

```text
White-box techniques
```

### o2 en explanation ORIGINAL

```text
White-box techniques use internal structure.
```

### o2 en explanation RETAINED_UNCHANGED

```text
White-box techniques use internal structure.
```

### o3 pt text ORIGINAL

```text
Técnicas baseadas na experiência
```

### o3 pt text RETAINED_UNCHANGED

```text
Técnicas baseadas na experiência
```

### o3 pt explanation ORIGINAL

```text
As técnicas baseadas na experiência derivam testes dos conhecimentos e da experiência do testador. A base de derivação indicada é o comportamento especificado externamente, o que identifica técnicas de caixa-preta.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
As técnicas baseadas na experiência derivam testes dos conhecimentos e da experiência do testador. A base de derivação indicada é o comportamento especificado externamente, o que identifica técnicas de caixa-preta.
```

### o3 en text ORIGINAL

```text
Experience-based techniques
```

### o3 en text RETAINED_UNCHANGED

```text
Experience-based techniques
```

### o3 en explanation ORIGINAL

```text
Experience-based techniques derive tests from tester knowledge and experience. The stated derivation basis is externally specified behavior, which identifies black-box techniques.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Experience-based techniques derive tests from tester knowledge and experience. The stated derivation basis is externally specified behavior, which identifies black-box techniques.
```

### o4 pt text ORIGINAL

```text
Teste baseado no risco
```

### o4 pt text RETAINED_UNCHANGED

```text
Teste baseado no risco
```

### o4 pt explanation ORIGINAL

```text
O teste baseado no risco orienta o âmbito, a profundidade e a prioridade usando os riscos avaliados. Não é a família de técnicas CTFL identificada pela derivação de testes do comportamento especificado sem usar a estrutura do código.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
O teste baseado no risco orienta o âmbito, a profundidade e a prioridade usando os riscos avaliados. Não é a família de técnicas CTFL identificada pela derivação de testes do comportamento especificado sem usar a estrutura do código.
```

### o4 en text ORIGINAL

```text
Risk-based testing
```

### o4 en text RETAINED_UNCHANGED

```text
Risk-based testing
```

### o4 en explanation ORIGINAL

```text
Risk-based testing guides scope, depth and priority using assessed risks. It is not the CTFL technique family identified by deriving tests from specified behavior without code structure.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Risk-based testing guides scope, depth and priority using assessed risks. It is not the CTFL technique family identified by deriving tests from specified behavior without code structure.
```

### pt general explanation ORIGINAL

```text
A origem é o comportamento especificado.
```

### pt general explanation RETAINED_UNCHANGED

```text
A origem é o comportamento especificado.
```

### en general explanation ORIGINAL

```text
The source is specified behaviour.
```

### en general explanation RETAINED_UNCHANGED

```text
The source is specified behaviour.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A origem é o comportamento especificado.
```

### pt affected field OPTIONAL_CANDIDATE

```text
Estes testes derivam do comportamento especificado, independentemente da implementação: técnicas de caixa-preta. As técnicas de caixa-branca derivam testes da estrutura interna, enquanto as baseadas na experiência usam o conhecimento e a experiência do testador. A priorização baseada no risco pode combinar-se com estas famílias.
```

### en affected field ORIGINAL

```text
The source is specified behaviour.
```

### en affected field OPTIONAL_CANDIDATE

```text
These tests are derived from specified behaviour independently of the implementation: black-box techniques. White-box techniques derive tests from internal structure, while experience-based techniques use tester knowledge and experience. Risk-based prioritization can be combined with these families.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão2→3 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 1                | ['o1']      |
| 2026-10-27.3       | True               | 1                | ['o1']      |
| 2026-10-27.4       | True               | 1                | ['o1']      |
| 2026-10-27.5       | True               | 1                | ['o1']      |
| 2026-10-27.6       | True               | 1                | ['o1']      |
| 2026-10-27.7       | True               | 2                | ['o1']      |
| 2026-10-27.8       | True               | 2                | ['o1']      |
| 2026-10-27.9       | True               | 2                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.


# tl-023 — ACCEPT_AS_IS

LO`FL-4.4.2`; K2; version4; required=1; key`['o1']`; content revision2026-10-27.10.

Canonical SHA-256`3267bc5ef044af2ec3f37e73b285884f97f3b851c44931c4edea46a0b84849d8` — objeto completo / full object.

Revisão AI, não aprovação humana/SME. LOW anterior é proveniência, não decisão automática. / AI review only; previous LOW is provenance, not an automatic verdict.

## Solução independente / Independent pre-key solution

Learning while designing, executing and evaluating, in a timeboxed session guided by a charter, characterizes session-based exploratory testing. Unadapted predefined replay lacks the described adaptive design; error guessing can contribute experience-based ideas without defining this full process; a checklist alone does not characterize concurrent learning/design/execution. The scenario describes this structured variant, not a universal requirement that all exploratory testing must use timeboxes/charters.

Registada/recorded`2026-11-06T13:27:40.028021+00:00`; projeção sem chaves/justificações, opções ordenadas porSHA-256. Pistas do pedido conhecidas. / User hints known; no stored key/rationale consulted before recording.

## Fontes oficiais / Official references

Capítulo/chapter4, §4.4.2; EN4.0.1pp.[38, 44]; PT4.0/v1.0pp.[41, 48]. Referências complementares / supporting sections: []. Páginas físicas contando capa; fontes e limitações em ../sources.json. / Physical pages counting cover; source registry includes consultation limits.

## Raciocínio e unicidade / Reasoning and uniqueness

**PT:** Aprender enquanto concebe/executa/avalia, com duração delimitada e carta que orienta a sessão, caracteriza teste exploratório baseado em sessões. Não é mera repetição fixa nem derivação a partir de checklist; antecipação de erros pode ajudar sem substituir essa organização. Só o1 caracteriza a combinação dada.

**EN:** Learning while designing/executing/evaluating, within a timebox and guided by a charter, characterizes session-based exploratory testing. It is not fixed replay or checklist derivation; error guessing can contribute without replacing that organization. Onlyo1matches the combination.

## Comparação PT/EN / PT/EN comparison

**PT:** While/enquanto preserva simultaneidade; designing/concebe, executing/executa e evaluating/avalia preservam as três ações durante aprendizagem. Timeboxed session/sessão de duração definida e guided by a test charter/orientada por uma carta mantêm estrutura e objetivo. “Mais diretamente” evita exclusividade artificial.

**EN:** While preserves simultaneity, and designing/executing/evaluating retain all three actions during learning. Timeboxed session and charter guidance preserve structure. Most directly avoids artificial exclusivity.

## Evidência contrária e limites / Contrary evidence and limits

**PT:** Nem todo teste exploratório exige sessão formal, carta ou debrief. O cenário fornece uma variante baseada em sessões; não faltar menção a debrief não a invalida. “Duração definida” exprime uma delimitação de tempo aqui, não prescreve minutos universais nem duração fixa de todos os testes exploratórios.

**EN:** Not all exploration requires formal sessions/charters/debriefs. This scenario explicitly gives a session-based variant; absence of a debrief mention does not invalidate it. Defined duration here expresses a timebox, not universal minutes or fixed duration for all exploration.

## LO/K e suficiência pedagógica / LO/K and teaching sufficiency

**PT:** FL-4.4.2/K2: explicar a caracterização conjunta, dificuldade baixa/média. A explicação geral é correta, embora omita avaliação/carta/timebox que já estão no enunciado e nos distratores. Expandi-la favorece autonomia do aluno, sem correção obrigatória.

**EN:** FL-4.4.2/K2explains the combined characteristics; low/moderate difficulty. The general rationale is correct but omits evaluation/charter/timebox already explicit in the statement/rationales. Expansion aids learning without being a mandatory correction.

## Riscos de interpretação / Interpretation risks

**PT:** Risco pedagógico baixo de universalizar a variante por sessões ou confundir carta com checklist. As justificações existentes já distinguem os conceitos.

**EN:** Low teaching risk of universalizing sessions or confusing a charter with a checklist; existing rationales already distinguish them.

## Conceitos críticos / Critical concepts

| ENliteral                                 | PTliteral                          | Avaliação / Assessment  |
| ----------------------------------------- | ---------------------------------- | ----------------------- |
| while designing, executing and evaluating | enquanto concebe, executa e avalia | EQUIVALENT_SIMULTANEITY |
| timeboxed session                         | sessão de duração definida         | EQUIVALENT_TIMEBOX      |
| test charter                              | carta de testes                    | EQUIVALENT_GUIDANCE     |
| most directly                             | mais diretamente                   | EQUIVALENT_QUALIFIER    |

## Todas as alternativas / Every alternative

### o1 — correta/correct

**PT:** Correta: aprendizagem e desenho/execução/avaliação combinados, com sessão orientada.

**EN:** Correct: combined learning/design/execution/evaluation in a guided session.

### o2 — distrator/distractor

**PT:** Repetição sem adaptação não caracteriza descoberta e conceção durante aprendizagem.

**EN:** Unadapted replay does not characterize discovery/design during learning.

### o3 — distrator/distractor

**PT:** Pode apoiar ideias de teste, mas não define simultaneidade/sessão/carta descritas.

**EN:** Can supply test ideas but does not define the described concurrency/session/charter.

### o4 — distrator/distractor

**PT:** Carta fornece objetivos de sessão; não foi dada uma lista de condições da qual derivar testes.

**EN:** A charter gives session goals; no checklist condition derivation is supplied.

## Texto integral real antes/depois / Actual full original/retained content

Original eproposto real são idênticos. Candidato editorial opcional é separado e NÃO aplicado. / Actual objects are unchanged; optional candidate is separate and unapplied.

### pt statement ORIGINAL

```text
Um testador aprende sobre uma nova funcionalidade de pesquisa enquanto concebe, executa e avalia testes numa sessão de duração definida, orientada por uma carta de testes. Que técnica é mais diretamente caracterizada por estas atividades combinadas?
```

### pt statement RETAINED_UNCHANGED

```text
Um testador aprende sobre uma nova funcionalidade de pesquisa enquanto concebe, executa e avalia testes numa sessão de duração definida, orientada por uma carta de testes. Que técnica é mais diretamente caracterizada por estas atividades combinadas?
```

### en statement ORIGINAL

```text
A tester learns about a new search feature while designing, executing and evaluating tests in a timeboxed session guided by a test charter. Which technique is most directly characterized by these combined activities?
```

### en statement RETAINED_UNCHANGED

```text
A tester learns about a new search feature while designing, executing and evaluating tests in a timeboxed session guided by a test charter. Which technique is most directly characterized by these combined activities?
```

### o1 pt text ORIGINAL

```text
Teste exploratório baseado em sessões
```

### o1 pt text RETAINED_UNCHANGED

```text
Teste exploratório baseado em sessões
```

### o1 pt explanation ORIGINAL

```text
A aprendizagem, a conceção e a execução influenciam-se mutuamente.
```

### o1 pt explanation RETAINED_UNCHANGED

```text
A aprendizagem, a conceção e a execução influenciam-se mutuamente.
```

### o1 en text ORIGINAL

```text
Session-based exploratory testing
```

### o1 en text RETAINED_UNCHANGED

```text
Session-based exploratory testing
```

### o1 en explanation ORIGINAL

```text
Learning, design and execution inform each other.
```

### o1 en explanation RETAINED_UNCHANGED

```text
Learning, design and execution inform each other.
```

### o2 pt text ORIGINAL

```text
Repetição de scripts de teste predefinidos sem os adaptar
```

### o2 pt text RETAINED_UNCHANGED

```text
Repetição de scripts de teste predefinidos sem os adaptar
```

### o2 pt explanation ORIGINAL

```text
O testador concebe e adapta testes enquanto aprende. Uma repetição fixa não explica essa aprendizagem, conceção e execução em simultâneo.
```

### o2 pt explanation RETAINED_UNCHANGED

```text
O testador concebe e adapta testes enquanto aprende. Uma repetição fixa não explica essa aprendizagem, conceção e execução em simultâneo.
```

### o2 en text ORIGINAL

```text
Replay of predefined test scripts without adapting them
```

### o2 en text RETAINED_UNCHANGED

```text
Replay of predefined test scripts without adapting them
```

### o2 en explanation ORIGINAL

```text
The tester designs and adapts tests while learning. Fixed replay does not explain that simultaneous learning, design and execution.
```

### o2 en explanation RETAINED_UNCHANGED

```text
The tester designs and adapts tests while learning. Fixed replay does not explain that simultaneous learning, design and execution.
```

### o3 pt text ORIGINAL

```text
Antecipação de erros
```

### o3 pt text RETAINED_UNCHANGED

```text
Antecipação de erros
```

### o3 pt explanation ORIGINAL

```text
A antecipação de erros seleciona alvos prováveis de defeitos usando a experiência de erros e falhas. Aqui, o comportamento distintivo é a aprendizagem, a conceção e a execução simultâneas orientadas por uma carta de testes; a antecipação de erros pode apoiar, mas não substitui, essa abordagem exploratória.
```

### o3 pt explanation RETAINED_UNCHANGED

```text
A antecipação de erros seleciona alvos prováveis de defeitos usando a experiência de erros e falhas. Aqui, o comportamento distintivo é a aprendizagem, a conceção e a execução simultâneas orientadas por uma carta de testes; a antecipação de erros pode apoiar, mas não substitui, essa abordagem exploratória.
```

### o3 en text ORIGINAL

```text
Error guessing
```

### o3 en text RETAINED_UNCHANGED

```text
Error guessing
```

### o3 en explanation ORIGINAL

```text
Error guessing selects likely defect targets using experience of errors and failures. Here the defining behavior is simultaneous learning, design and execution guided by a charter; error guessing could support, but does not replace, that exploratory approach.
```

### o3 en explanation RETAINED_UNCHANGED

```text
Error guessing selects likely defect targets using experience of errors and failures. Here the defining behavior is simultaneous learning, design and execution guided by a charter; error guessing could support, but does not replace, that exploratory approach.
```

### o4 pt text ORIGINAL

```text
Teste baseado em checklists
```

### o4 pt text RETAINED_UNCHANGED

```text
Teste baseado em checklists
```

### o4 pt explanation ORIGINAL

```text
O teste baseado em checklists deriva testes de uma lista de condições de teste. Uma carta de testes define objetivos da sessão; o cenário descreve descobrir e adaptar testes durante a sessão, não derivá-los de entradas de uma checklist.
```

### o4 pt explanation RETAINED_UNCHANGED

```text
O teste baseado em checklists deriva testes de uma lista de condições de teste. Uma carta de testes define objetivos da sessão; o cenário descreve descobrir e adaptar testes durante a sessão, não derivá-los de entradas de uma checklist.
```

### o4 en text ORIGINAL

```text
Checklist-based testing
```

### o4 en text RETAINED_UNCHANGED

```text
Checklist-based testing
```

### o4 en explanation ORIGINAL

```text
Checklist-based testing derives tests from a list of test conditions. A charter sets session objectives; the scenario describes discovering and adapting tests during the session, not deriving them from checklist entries.
```

### o4 en explanation RETAINED_UNCHANGED

```text
Checklist-based testing derives tests from a list of test conditions. A charter sets session objectives; the scenario describes discovering and adapting tests during the session, not deriving them from checklist entries.
```

### pt general explanation ORIGINAL

```text
A aprendizagem, a conceção e a execução influenciam-se mutuamente.
```

### pt general explanation RETAINED_UNCHANGED

```text
A aprendizagem, a conceção e a execução influenciam-se mutuamente.
```

### en general explanation ORIGINAL

```text
Learning, design and execution inform each other.
```

### en general explanation RETAINED_UNCHANGED

```text
Learning, design and execution inform each other.
```

## Editorial opcional — não aplicado / Optional editorial — not applied

Campo/path: `['explanation']`. Problema confirmado: nenhum. Objetivo: clareza/apoio pedagógico. A redação proposta é do revisor, não citação oficial nem correção obrigatória. / No confirmed defect; reviewer wording for clarity, not an official quote or mandatory correction.

### pt affected field ORIGINAL

```text
A aprendizagem, a conceção e a execução influenciam-se mutuamente.
```

### pt affected field OPTIONAL_CANDIDATE

```text
No teste exploratório, a aprendizagem e a conceção, execução e avaliação de testes influenciam-se mutuamente. Aqui, uma duração delimitada e uma carta com objetivos de teste estruturam uma abordagem baseada em sessões. As sessões são uma forma de organizar o teste exploratório, não um requisito universal.
```

### en affected field ORIGINAL

```text
Learning, design and execution inform each other.
```

### en affected field OPTIONAL_CANDIDATE

```text
In exploratory testing, learning and test design, execution and evaluation inform one another. Here a timebox and a charter with test objectives structure a session-based approach. Sessions are one way to organize exploratory testing, not a universal requirement.
```

Objeto completo anterior/candidato, todas as alternativas/justificações e hashes em ../optional-candidates.json. Só o campo identificado difere; versões/chaves atuais não mudam. / Full original/candidate objects and hashes are provided; only the identified field differs.

Impacto se futuramente autorizado: versão4→5 apenas do item alterado; arquivar.10e introduzir revisão seguinte, preservando tentativas/backups antigos. Nada disto foi executado. / Future authorized change requires versioning and immutable history; no such work is done now.

Testes futuros: texto exato aprovadoPT/ENe campos não alterados;90IDs/chaves/LO/K; arquivos/sessões/scoring/backups por revisão; guards,unit,TypeScript/lint/build ePlaywrightdirecionado para renderização e troca de língua. / Future tests include exact fields, versioned history/persistence and targeted rendered language checks.

## Histórico / History

| Revisão / Revision | Presente / Present | Versão / Version | Chave / Key |
| ------------------ | ------------------ | ---------------- | ----------- |
| 2026-10-27.1       | True               | 1                | ['o1']      |
| 2026-10-27.2       | True               | 2                | ['o1']      |
| 2026-10-27.3       | True               | 2                | ['o1']      |
| 2026-10-27.4       | True               | 2                | ['o1']      |
| 2026-10-27.5       | True               | 3                | ['o1']      |
| 2026-10-27.6       | True               | 3                | ['o1']      |
| 2026-10-27.7       | True               | 4                | ['o1']      |
| 2026-10-27.8       | True               | 4                | ['o1']      |
| 2026-10-27.9       | True               | 4                | ['o1']      |

Hashes de cada revisão em decision-matrix.json. O objeto atual é idêntico ao da.9para este item e não é reescrito. Ausência antes da introdução é esperada. / Historical metadata/hashes are retained; no attempts are regraded.

## Decisão e pendências / Decision and pending gates

ACCEPT_AS_ISporAI; nenhum defeito obrigatório confirmado. Nenhuma alteração autorizada/aplicada ao banco, nenhum OWNER_ACCEPTED/HUMAN_APPROVED. Revisão humana independente e decisões do proprietário permanecem separadas e pendentes. Fase10Haberta; Lote9não iniciado. / AI recommendation only; no owner or human approval; stop afterBatch8.

