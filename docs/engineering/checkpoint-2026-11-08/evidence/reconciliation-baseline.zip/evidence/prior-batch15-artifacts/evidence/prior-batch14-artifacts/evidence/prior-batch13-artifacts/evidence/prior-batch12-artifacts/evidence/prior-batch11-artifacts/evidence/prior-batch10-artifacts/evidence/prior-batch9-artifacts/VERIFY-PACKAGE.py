"""Read-only portable Batch9 integrity/evidence verification, Python3.9+ standard library.
Inspect this file and BATCH9-RULES.py. No human/semantic certification is conferred.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Do not use Python -O; integrity assertions must remain enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,re,runpy
root=Path(__file__).resolve().parent
read=lambda n:json.loads((root/n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
folder='docs/academic/phase10h-batch9-2026-11-06'
m=read('MANIFEST.json');expected={e['relativePath'] for e in m['files']};actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert len(expected)==len(m['files']) and actual==expected|{'MANIFEST.json'}
for e in m['files']:
 n=e['relativePath'];pp=PurePosixPath(n);p=root/n;assert not pp.is_absolute() and '..' not in pp.parts and '\\' not in n and ':' not in n
 assert p.resolve().is_relative_to(root) and not p.is_symlink();b=p.read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256'],n
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json');inv=read('GIT-CHANGE-INVENTORY.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049'
assert pre['priorPackageSHA256']=='80c880ea17c3a3eead36801aa42d8ddab046d7a4a0b2b9431722b94bc9907f8a' and pre['priorManifestHashCount']==175 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical'] and proof['uniqueIDsAndKeysPreserved']==90
assert len(pre['existingFilesSHA256'])==proof['existingFilesByteIdentical']==285 and len(pre['existingUncommittedDocuments'])==proof['priorUncommittedDocumentsPreserved']==71
assert len(proof['priorBatchDocumentsSHA256'])==82 and proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha((root/n).read_bytes())==h==pre['existingFilesSHA256'][n]
assert inv['existingFilesChanged']==[] and len(inv['newBatch9Files'])==18 and len(inv['preservedPendingDocuments'])==71
for e in inv['newBatch9Files']:
 b=(root/e['relativePath']).read_bytes();assert sha(b)==e['sha256'] and len(b)==e['sizeBytes']
for e in m['files']:
 if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
required={'src/data/syllabus-questions.ts','src/data/variability-questions.ts','src/domain/blueprint.ts','tests/unit/academic-audit.test.ts','tests/unit/blueprint.test.ts','tests/unit/quality-maintenance.test.ts','tests/unit/variability.test.ts'}
assert set(proof['requiredComparisonFilesSHA256'])==required and proof['comparisonFilesMatchBatch8ZIP'] is True
for n in required:assert n in expected and sha((root/n).read_bytes())==proof['requiredComparisonFilesSHA256'][n]==pre['existingFilesSHA256'][n]
continuity=read('EXPORT-CONTINUITY.json');oldManifest=read(continuity['priorManifestPath']);oldEntries={e['relativePath']:e for e in oldManifest['files']}
assert continuity['previousPackageSHA256']==pre['priorPackageSHA256'] and continuity['previousFileCount']==176 and len(continuity['files'])==176
assert {e['previousRelativePath'] for e in continuity['files']}==set(oldEntries)|{'MANIFEST.json'}
assert sum(e['kind']=='preserved_repository_reference' for e in continuity['files'])==120
for e in continuity['files']:
 b=(root/e['currentRelativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
 if e['previousRelativePath']!='MANIFEST.json':
  old=oldEntries[e['previousRelativePath']];assert (len(b),sha(b))==(old['sizeBytes'],old['sha256'])
bank=read('review-data/current-bank.json');old=read('src/data/archive/questions-2026-10-27.9.json');pres=read('BANK-PRESERVATION.json')
assert len(bank)==len({q['id'] for q in bank})==90 and pres['contentRevision']=='2026-10-27.10'
assert [q['id'] for q in bank]==[q['id'] for q in old] and all(a['correct']==b['correct'] for a,b in zip(old,bank))
assert [a['id'] for a,b in zip(old,bank) if a!=b]==['tl-011','tl-090']
assert len(pres['questions'])==90
for r,q in zip(pres['questions'],bank):assert r['id']==q['id'] and r['beforeCanonicalSHA256']==r['afterCanonicalSHA256']==canonical(q) and r['beforeKey']==r['afterKey']==q['correct'] and r['beforeVersion']==r['afterVersion']==q['version']
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha((root/n).read_bytes())==h==pre['existingFilesSHA256'][n]
data=read(folder+'/decision-matrix.json');comparisons=read(folder+'/exact-comparisons.json');blind=read(folder+'/blind-solutions.json');projection=read(folder+'/blind-projection.json');sources=read(folder+'/sources.json');optionalAll=read(folder+'/optional-candidates.json')
assert blind==read('evidence/blind-solutions.json') and projection==read('evidence/blind-projection.json') and blind['projectionSHA256']==sha((root/'evidence/blind-projection.json').read_bytes())
rules=runpy.run_path(str(root/'BATCH9-RULES.py'));args=[bank,data,comparisons,blind,projection,sources,optionalAll];specific=rules['check'](*args);neg=rules['negative_checks'](*args)
logged=read('evidence/checks/batch9-specific-result.json');assert logged['result']=='PASS' and logged['exitCode']==0 and logged['questions']==specific['questions'] and logged['negativeChecks']==neg and neg['negativeCasesRejected']==12
blocks=[];pairCount=0;optionalCount=0
for row,c in zip(data['decisions'],comparisons):
 ident=row['questionId'];q=next(q for q in bank if q['id']==ident);assert q==next(q for q in old if q['id']==ident)
 for h in row['history']:
  aq=next((v for v in read('src/data/archive/questions-'+h['contentRevision']+'.json') if v['id']==ident),None);assert h['present']==(aq is not None)
  if aq is not None:assert (h['version'],h['key'],h['canonicalSHA256'])==(aq['version'],aq['correct'],canonical(aq))
 item=[]
 for lang in ['pt','en']:item.extend([q['text'][lang]]*2)
 for o in q['options']:
  for lang in ['pt','en']:
   for f in ['text','explanation']:item.extend([o[f][lang]]*2)
 for lang in ['pt','en']:item.extend([q['explanation'][lang]]*2)
 assert len(item)==40
 optional=row['optionalEditorialCandidate']
 if optional:
  optionalCount+=1
  for lang in ['pt','en']:item.extend([optional['originalText'][lang],optional['candidateText'][lang]])
 report=(root/folder/'reports'/(ident+'.md')).read_text(encoding='utf8');assert re.findall(r'```text\n([\s\S]*?)\n```',report)==item
 pairs=row['analysis']['criticalPairs'];first={p[0] for p in pairs};parsed=[]
 for line in report.splitlines():
  if line.startswith('|'):
   cells=[v.strip() for v in line.split('|')[1:-1]]
   if len(cells)==3 and cells[0] in first:parsed.append(cells)
 assert parsed==pairs;pairCount+=len(pairs);blocks.extend(item)
assert len(blocks)==336 and pairCount==36 and optionalCount==4
assert re.findall(r'```text\n([\s\S]*?)\n```',(root/'ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==blocks
for n in ['multiple-answer-scoring','legacy-academic-context','targeted-vitest','format-check','diff-check']:assert read('evidence/checks/'+n+'-result.json')['exitCode']==0
scoring=json.loads((root/'evidence/checks/multiple-answer-scoring.log').read_text(encoding='utf8'));assert scoring['result']=='PASS' and len(scoring['syntheticSelections'])==8 and all(c['expected']==c['actual'] for c in scoring['syntheticSelections']) and scoring['storageAccessed'] is False
assert 'NOT Batch9-specific' in read('evidence/checks/legacy-academic-context-result.json')['scopeNote']
assert read('docs/academic/phase10h-batch3-2026-11-06/record.json')['ownerDecision'] is None
for n in [4,5,6,7,8]:
 d=read('docs/academic/phase10h-batch'+str(n)+'-2026-11-06/decision-matrix.json');assert d['ownerAcceptedCount']==d['humanApprovedCount']==0
flat=read(folder+'/alternative-assessments.json')
assert len(flat)==len({(a['questionId'],a['optionId']) for a in flat})==32
for a in flat:
 row=next(r for r in data['decisions'] if r['questionId']==a['questionId']);q=next(q for q in bank if q['id']==a['questionId']);o=next(o for o in q['options'] if o['id']==a['optionId']);d=row['analysis']['options'][a['optionId']]
 assert a['text']==o['text'] and a['publishedRationale']==o['explanation'] and a['supportsIndependentAnswer']==d['supportsAnswer'] and a['reviewPT']==d['pt'] and a['reviewEN']==d['en']
q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(expected),'individualReports':8,'alternativesReviewed':32,'actualComparisonTextBlocks':320,'optionalComparisonTextBlocks':16,'criticalConceptPairs':pairCount,'optionalCandidatesUnapplied':4,'priorBatchDocumentsVerified':82,'previousPackageFilesAccountedFor':176,'IDsAndKeysPreserved':90,'historicalBanksVerified':9,'negativeCasesRejected':12,'syntheticScoringChecks':8,'newOwnerAcceptances':0,'newHumanApprovals':0,'semanticTruthAutomaticallyProven':False},indent=2))
