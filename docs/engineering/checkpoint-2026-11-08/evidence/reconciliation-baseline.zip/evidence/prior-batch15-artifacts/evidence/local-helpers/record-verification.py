from pathlib import Path
import json,hashlib,datetime,runpy,copy,sys,subprocess
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch15-2026-11-07/';f=root/folder
read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
pre=read(p/'preflight.json');matrix=read(f/'decision-matrix.json');g=runpy.run_path(str(p/'GLOBAL15-RULES.py'));rules=runpy.run_path(str(p/'BATCH15-RULES.py'));bank=read(p/'runtime-before.json')['bank'];reference=g['load_reference']((p/'reference-bank.json').read_bytes())
args=[bank,matrix,read(f/'exact-comparisons.json'),read(f/'blind-solutions.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidates.json'),{d['questionId']:(f/'reports'/(d['questionId']+'.md')).read_text(encoding='utf8') for d in matrix['decisions']},{f'2026-10-27.{i}':read(root/f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}]
def rejects(call):
    try:call()
    except AssertionError:return True
    return False
rules['check'](*args);g['check_bank'](bank,reference)
outside=copy.deepcopy(args);outside[0][1]['text']['en']='adulterated bank';assert outside[0][1]['id']=='tl-002' and outside[0][1]!=bank[1]
assert rules['check'](*outside)['result']=='PASS' and rejects(lambda:g['check_bank'](outside[0],reference)) and rejects(lambda:g['check_bank'](outside[0],outside[0]))
inside=copy.deepcopy(args);next(q for q in inside[0] if q['id']=='tl-069')['text']['en']='adulterated bank';assert rejects(lambda:rules['check'](*inside))
route={'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'intactControlsPassed':True,'tl002MutationInjectedIntoActualArgument':True,'tl002ScopedControlPassed':True,'tl002GlobalRejected':True,'tl069ScopedRejected':True,'poisonedReferenceRejected':True,'layerContract':'Scope8 evidence / immutable full90 object equality; out-of-scope edits intentionally delegated globally'}
(p/'layer-routing-result.json').write_text(json.dumps(route,indent=2)+'\n')
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
source=[]
for s in read(f/'sources.json')['sources']:
    b=(Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0')/s['fileName']).read_bytes();assert sha(b)==s['sha256']
    pdf=pymupdf.open(stream=b,filetype='pdf');assert len(pdf)==s['pageCount']
    checks=[]
    for d in matrix['decisions']:
        for section,pages in d['references'].items():
            text=''.join(pdf[n-1].get_text() for n in pages[s['language']]);assert section in text,(d['questionId'],section,s['language'])
            checks.append({'questionId':d['questionId'],'section':section,'physicalPages':pages[s['language']],'sectionFound':True})
        text=''.join(pdf[n-1].get_text() for n in d['LOPages'][s['language']]);assert d['learningObjective'] in text
    source.append({'language':s['language'],'edition':s['edition'],'sha256':sha(b),'pageCount':len(pdf),'sectionAndLOChecks':checks})
(p/'source-verification-result.json').write_text(json.dumps({'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':source,'webStatus':'EN accessible, PT timeout this execution; official local copies read and hashed; no remote raw-byte equality claim','fullPDFsOrPageTextsExported':False},ensure_ascii=False,indent=2)+'\n')
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
assert (f/'blind-projection.json').read_bytes()==(p/'blind-projection.json').read_bytes() and (f/'blind-solutions.json').read_bytes()==(p/'blind-solutions.json').read_bytes()
for x in f.rglob('*.json'):read(x)
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
inventory=read(f/'file-inventory.json');inventory.update(afterGitStatus=git('status','--untracked-files=all'),existingFilesChanged=[],recordedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),newDocumentPaths=sorted(x.relative_to(root).as_posix() for x in f.rglob('*') if x.is_file()),frozenBlindSHA256={n:sha((p/n).read_bytes()) for n in ['blind-projection.json','blind-solutions.json']})
(f/'file-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
metas={n:read(p/(n+'-result.json')) for n in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']};assert all(v['exitCode']==0 for v in metas.values())
text='''# Lote 15 — verificação técnica e limites

Execuções novas em 2026-11-07, horários UTC. Não se apresentam logs dos Lotes 1–14 como novas execuções. A revisão cega e os horários ficaram congelados antes da consulta dos gabaritos.

## Baseline e preservação

Preflight PASS: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10. ZIP do Lote 14 autenticado por SHA-256 47ad385f5cd7f7fe2761ff6bae56312779c71825c753d3f0bb04a46997894c04, CRC, 470 hashes, 471 membros e verificador portátil. As 226 referências do repositório coincidiram com os bytes atuais. Inventário inicial: 391 ficheiros, 177 não rastreados e 188 documentos académicos anteriores.

Integridade global nova: 90 objetos completos iguais à referência imutável do membro review-data/current-bank.json do ZIP autenticado. Preservados 364 alternativas, 64 objetivos, IDs, gabaritos, versões, explicações e revisão .10. Os nove arquivos .1–.9 coincidem byte a byte com o HEAD e com o inventário inicial. Nenhuma alteração aos 391 ficheiros anteriores, incluindo as evidências de interrupção e recuperação. Não há revisão .11 nem novo aceite de proprietário ou aprovação humana.

## Resultados realmente executados

| Gate | Resultado |
| --- | --- |
| Guard específico BATCH15 | PASS: oito objetos, 33 alternativas, 328 blocos literais, LO/K, versões, históricos, fontes e coerência das soluções |
| Casos negativos encaminhados | PASS: 18 rejeitados, sendo 17 específicos e um global; inclui chave, segunda resposta, falta de fundamentação, tradução, fonte, histórico, falsa aprovação, proposta aplicada e alteração a tl-069 |
| GLOBAL15 | PASS: 90 objetos completos iguais à referência fixa autenticada |
| Casos negativos globais | PASS: 96 rejeitados; texto em cada uma das 90 questões, chave, versão, explicação, ID ausente/duplicado e referência adulterada |
| Encaminhamento de mutações | PASS: o objeto adulterado tl-002 chega à proteção global, que o rejeita; o guard específico preserva o seu âmbito; tl-069 adulterada é rejeitada pelo específico |
| Vitest direcionado | PASS: 85 testes em seis ficheiros; sem skips |
| Seleção múltipla | PASS: 16 casos sintéticos: oito para tl-001 (o1 e o4) e oito para tl-083 (o2 e o4), sem aceitar parcial, excedente ou duplicado; sem LocalStorage |
| Fontes e JSON | PASS: hashes das duas cópias locais oficiais, número de páginas, secções e LO nas páginas citadas; JSON legível e coerente |
| Formato | PASS: Prettier nos 16 documentos novos sujeitos a estilo; os dois JSON da revisão cega permanecem byte a byte congelados, com sintaxe e conteúdo verificados separadamente |
| git diff --check | PASS; documentos não rastreados têm guard, JSON e formato próprios, pois este comando não os cobre |

Os seis ficheiros unitários são academic-audit, bank-history, backup, syllabus-coverage, quality-maintenance e blueprint. Comandos completos, datas e exit codes em evidence/checks. Os guards foram inspecionados antes de executar; expectativas vêm da referência autenticada e não foram alteradas para obter PASS. Não ocorreram falhas críticas nem foram removidos casos negativos nesta execução.

## Conferência dos metadados

Um rótulo do auxiliar de encaminhamento ainda dizia tl058ScopedRejected, herdado do lote anterior, embora a mutação real já fosse aplicada a tl-069. O nome foi corrigido para tl069ScopedRejected e os controlos de encaminhamento e fontes foram reexecutados sem alterar expectativas. O registo anterior e a explicação ficam em evidence/checks/superseded-routing-label.json; não foi uma falha de banco ou guard nem foi ocultado como resultado histórico diferente.

## Limitações e verificações não executadas

Não se executaram TypeScript, ESLint, build ou E2E completos: o âmbito é documentação académica e auxiliares externos, sem alteração de implementação, banco, pontuação ou persistência. O carregador runtime transpila os dados para comparação; não é typecheck completo. O guard legado --phase10h-batch2 não foi executado nem apresentado como validação linguística deste lote.

EN ficou acessível nesta execução e PT teve timeout; as cópias oficiais locais foram usadas; as referências precisas e hashes correspondem às cópias oficiais locais. Não se afirma que EN 4.0.1 e PT 4.0 tradução 1.0 sejam textualmente idênticos, nem igualdade remota dos bytes. Não foram incluídos PDFs integrais ou textos integrais de páginas protegidas. A análise de conceitos é interpretação académica por IA; automação valida consistência, não verdade ou aprovação humana independente.

A referência autenticada contém cinco alternativas em tl-083 e exige duas respostas; por isso foram revistas 33 alternativas, sem omitir a quinta ou alterar o banco. Os oito pareceres são ACCEPT_AS_IS; nenhuma correção obrigatória ou proposta editorial justificada foi identificada. Isso não aprova automaticamente outros itens. Nenhum OWNER_ACCEPTED ou HUMAN_APPROVED foi atribuído. A Fase 10H permanece aberta; não iniciar Lote 16.

## Exportação condicionada

Somente após os gates, a exportação deve comparar diretamente os 471 membros anteriores e criar o novo manifesto. CRC, extração limpa, verificador portátil e adulterações do pacote têm registo próprio em export-result.json externo e evidence/checks/package-negative-tests.json no pacote. Resultados destes passos não são antecipados neste registo.

## Metadados novos

```json
'''+json.dumps({'specific':read(p/'batch15-specific-execution.json'),'integrity':read(p/'integrity-execution.json'),'commands':metas,'layerRouting':route},ensure_ascii=False,indent=2)+'\n```\n'
(f/'verification.md').write_text(text,encoding='utf8')
print(json.dumps({'result':'PASS','sourceChecks':len(source),'layerRouting':route,'preservedFiles':391,'frozenBlindRecordsByteIdentical':True},indent=2))
