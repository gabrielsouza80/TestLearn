"""Read-only structural/evidence checks specific to Batch7; not a semantic theorem prover.
Expected answers are the previously recorded AI blind derivations, not machine-inferred linguistic truth.
"""
import hashlib,json,copy
IDS=['tl-022','tl-041']
EXPECTED={'tl-022':{'lo':'FL-4.4.1','level':'K2','version':3,'key':['o1'],'hash':'093dc2e2ddc74cfea383381171b9fcacd36f787bc3d66e04e61de85369a4932c'},'tl-041':{'lo':'FL-1.5.2','level':'K1','version':1,'key':['o2'],'hash':'bb2ef546b854b9c48951dfd3433466464e54eaf0b37f16c99811ecebe7be01b4'}}
canonical=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def alltext(q,lang):return '\n'.join([q['text'][lang],q['explanation'][lang],*[o[f][lang] for o in q['options'] for f in ['text','explanation']]])
def check(bank,matrix,comparisons,blind,projection,sources):
 assert matrix['scope']=='Phase 10H Batch 7 only' and matrix['humanApprovedCount']==matrix['ownerAcceptedCount']==matrix['contentChanges']==0
 assert [r['questionId'] for r in matrix['decisions']]==IDS and len(comparisons)==len(blind['solutions'])==len(projection)==2
 report=[]
 for row,c,p in zip(matrix['decisions'],comparisons,projection):
  ident=row['questionId'];q=next(q for q in bank if q['id']==ident);exp=EXPECTED[ident]
  assert canonical(q)==exp['hash'] and q['lo']==exp['lo'] and q['level']==exp['level'] and q['version']==exp['version'] and q['correct']==exp['key']
  assert row['decision']=='ACCEPT_AS_IS' and row['ownerDecision'] is None and row['humanApproval']==q['humanApproval']=='PENDING'
  assert row['linguisticAssessment']=='CONTEXTUALLY_EQUIVALENT_WITH_MINOR_LEXICAL_RISK' and row['residualRiskSeverity']=='LOW'
  assert row['confirmedProblems']==[] and row['contentChanged'] is False
  assert row['beforeCanonicalSHA256']==row['afterCanonicalSHA256']==canonical(q)
  assert row['existingKey']==row['proposedKey']==row['independentSolution']['answer']==exp['key']
  assert row['questionVersion']==exp['version'] and row['learningObjective']==exp['lo'] and row['cognitiveLevel']==exp['level']
  assert row['contentRevisionBefore']==row['contentRevisionAfter']=='2026-10-27.10'
  assert row['independentSolution']==next(s for s in blind['solutions'] if s['questionId']==ident)
  assert c['questionId']==ident and c['original']==c['proposed']==q and c['changed'] is False
  assert p['id']==ident and p['text']==q['text'] and p['lo']==q['lo'] and p['level']==q['level'] and not set(p)&{'correct','explanation'}
  assert p['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  a=row['analysis'];assert set(a['distractors'])=={o['id'] for o in q['options']} and len(a['distractors'])==4
  assert [o for o,n in a['distractors'].items() if n['supportsAnswer']]==exp['key']
  for d in a['distractors'].values():assert isinstance(d['supportsAnswer'],bool) and all(len(d[l])>20 for l in ['pt','en']) and d['concept']
  for en,pt,status,why in a['criticalPairs']:
   assert en in alltext(q,'en') and pt in alltext(q,'pt') and status in ['EQUIVALENT','CONTEXTUAL_EQUIVALENCE','MINOR_LEXICAL_RISK','OFFICIAL_LOAN_TERM_RETAINED'] and len(why)>20
  assert len(a['criticalPairs'])==(5 if ident=='tl-022' else 8)
  optional=row['optionalEditorialCandidate'];assert optional==c['optionalEditorialCandidate']
  assert optional['kind']=='OPTIONAL_EDITORIAL_NOT_CONFIRMED_DEFECT' and optional['applied'] is False and optional['requiresExplicitOwnerAuthorization'] is True
  assert optional['text']['en']==q['text']['en'] and optional['text']['pt']==a['optionalPT'] and optional['text']['pt']!=q['text']['pt']
  assert optional['answerKeyImpact']==optional['optionsAndExplanationsImpact']=='NONE' and len(optional['regressionPlanIfAuthorized'])==4
  for lang in ['EN','PT']:
   source=next(s for s in sources['sources'] if s['language']==lang);assert set(row['references'][lang])<=set(source['pagesConsulted'])
  if ident=='tl-022':
   assert '29 de fevereiro' in optional['text']['pt'] and 'o seu conhecimento' in optional['text']['pt'] and 'produtos semelhantes' in optional['text']['pt']
   assert a['distractors']['o3']['concept']=='EXPLORATORY_TESTING' and a['distractors']['o4']['concept']=='BOUNDARY_VALUE_ANALYSIS'
  else:
   assert 'equipa responsável pela entrega' in optional['text']['pt'] and 'whole team approach (abordagem de toda a equipa)' in optional['text']['pt']
   assert a['distractors']['o2']['concept']=='COLLABORATION_SHARED_QUALITY'
  report.append({'questionId':ident,'LO':q['lo'],'K':q['level'],'version':q['version'],'canonicalSHA256':canonical(q),'independentKey':exp['key'],'storedKeyMatchesBlind':True,'alternativesCovered':4,'criticalPairsAnchored':len(a['criticalPairs']),'semanticApproval':'NOT_PROVIDED_BY_AUTOMATION','optionalWordingApplied':False})
 return {'result':'PASS','scope':'Batch7 evidence consistency, identity, critical phrase anchors, option-review completeness, source pages and approval boundaries','questions':report,'newOwnerAcceptances':0,'newHumanApprovals':0}
def negative_checks(bank,matrix,comparisons,blind,projection,sources):
 check(bank,matrix,comparisons,blind,projection,sources)
 mutations=[
 ('wrong answer',lambda d:d['decisions'][0].update(proposedKey=['o2'])),
 ('invented human approval',lambda d:d['decisions'][0].update(humanApproval='HUMAN_APPROVED')),
 ('invented owner acceptance',lambda d:d['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),
 ('false exact-translation claim',lambda d:d['decisions'][0].update(linguisticAssessment='PERFECT_LITERAL_EQUIVALENCE')),
 ('unreviewed distractor',lambda d:d['decisions'][0]['analysis']['distractors'].pop('o4')),
 ('second supported answer',lambda d:d['decisions'][0]['analysis']['distractors']['o4'].update(supportsAnswer=True)),
 ('unauthorized optional application',lambda d:d['decisions'][0]['optionalEditorialCandidate'].update(applied=True)),
 ('invented source page',lambda d:d['decisions'][0]['references'].update(EN=[999]))]
 rejected=[]
 for name,mutate in mutations:
  d=copy.deepcopy(matrix);mutate(d)
  try:check(bank,d,comparisons,blind,projection,sources)
  except AssertionError:rejected.append(name)
  else:raise AssertionError('False positive accepted: '+name)
 # A model that leaked the key or explanations into the blind projection must not pass.
 p=copy.deepcopy(projection);p[0]['correct']=['o1']
 try:check(bank,matrix,comparisons,blind,p,sources)
 except AssertionError:rejected.append('key leaked into projection')
 else:raise AssertionError('Blind projection leakage not detected')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'semanticTruthAutomaticallyProven':False}
