"""Explicit-allowlist export only. No repository writes, Git changes or network."""
from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,sys,zipfile,tempfile,datetime,re
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch15-2026-11-07'
read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda q:sha(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
pre=read(p/'preflight.json');proof=read(p/'integrity-result.json')
def snapshot():
    names=[n for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0') if n]
    return {'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain=v1','-uall'),'files':{n:sha((root/n).read_bytes()) for n in names}}
before=snapshot();assert before['head']==pre['head'] and before['branch']=='develop'
assert all(before['files'][n]==h for n,h in pre['existingFilesSHA256'].items()) and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
new={n for n in before['files'] if n.startswith(folder+'/')};assert len(new)==18 and set(before['files'])==set(pre['existingFilesSHA256'])|new
assert proof['result']=='PASS' and read(p/'batch15-specific-result.json')['exitCode']==0 and read(p/'final-preservation-result.json')['result']=='PASS'
work=Path(tempfile.mkdtemp(prefix='TestLearn-Batch15-export-'));stage=work/'package';stage.mkdir();provenance={}
def safe(n):
    pp=PurePosixPath(n);assert n and not pp.is_absolute() and '..' not in pp.parts and '\\' not in n and ':' not in n and pp.as_posix()==n
    assert not set(pp.parts)&{'.git','node_modules','dist','test-results','__pycache__'} and not pp.name.startswith('.env')
    return n
def put(n,b,source):
    safe(n);assert n not in provenance;npath=stage/n;npath.parent.mkdir(parents=True,exist_ok=True);npath.write_bytes(b);assert npath.read_bytes()==b;provenance[n]=source
def jput(n,d,source):put(n,(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),source)
archive=Path('C:/Users/gabri/Downloads')/pre['priorPackageName'];assert sha(archive.read_bytes())==pre['priorPackageSHA256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==471
    oldManifestBytes=z.read('MANIFEST.json');oldManifest=json.loads(oldManifestBytes);assert len(oldManifest['files'])==470
    oldRefs={e['relativePath'] for e in oldManifest['files'] if e['provenance'].get('kind')=='exact repository bytes'};assert len(oldRefs)==226
    for e in oldManifest['files']:
        b=z.read(e['relativePath']);assert (len(b),sha(b))==(e['sizeBytes'],e['sha256'])
    selected=oldRefs|new
    for n in sorted(selected):
        safe(n);assert not (root/n).is_symlink();b=(root/n).read_bytes()
        if n in oldRefs:assert b==z.read(n)
        put(n,b,{'kind':'exact repository bytes','baseCommit':pre['head'],'newDuringBatch15':n in new,'preflightSHA256':pre['existingFilesSHA256'].get(n)})
    index={sha((stage/n).read_bytes()):n for n in sorted(provenance)};mapping=[]
    for n in z.namelist():
        safe(n);b=z.read(n);h=sha(b);dest=n if n in oldRefs else index.get(h)
        if dest is None:
            dest='evidence/prior-batch14-artifacts/'+n;put(dest,b,{'kind':'exact historical final Batch14 ZIP bytes, not a fresh Batch15 execution','previousRelativePath':n,'previousPackageSHA256':pre['priorPackageSHA256']});index[h]=dest
        assert (stage/dest).read_bytes()==b
        mapping.append({'previousRelativePath':n,'currentRelativePath':dest,'sizeBytes':len(b),'sha256':h,'kind':'preserved_repository_reference' if n in oldRefs else 'historical_content_mapped_by_hash'})
    assert (p/'reference-bank.json').read_bytes()==z.read('review-data/current-bank.json')
assert len(mapping)==471
jput('EXPORT-CONTINUITY.json',{'previousPackageName':pre['priorPackageName'],'previousPackageSHA256':pre['priorPackageSHA256'],'previousFileCount':471,'priorManifestPath':next(e['currentRelativePath'] for e in mapping if e['previousRelativePath']=='MANIFEST.json'),'priorManifestSHA256':sha(oldManifestBytes),'repositoryReferenceFilesPreserved':226,'omittedFiles':[],'files':mapping},{'kind':'All471 prior members compared directly to authenticated original ZIP bytes, not only declared new hashes; identical payloads mapped without needless duplication'})
for mode in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']:
    meta=read(p/(mode+'-result.json'));assert meta['exitCode']==0
    for suffix in ['.log','-result.json']:put('evidence/checks/'+mode+suffix,(p/(mode+suffix)).read_bytes(),{'kind':'fresh Batch15 scoped execution','command':meta['command'],'startedAt':meta['startedAt'],'completedAt':meta['completedAt'],'exitCode':0})
for name in ['batch15-specific-result.json','batch15-specific-execution.json','integrity-execution.json','final-preservation-result.json','layer-routing-result.json','source-verification-result.json','superseded-routing-label.json']:
    put('evidence/checks/'+name,(p/name).read_bytes(),{'kind':'fresh Batch15 verification metadata and checks'})
for name in ['preflight.json','integrity-result.json','blind-projection.json','blind-solutions.json','key-reveal.json']:
    put('evidence/'+name,(p/name).read_bytes(),{'kind':'fresh Batch15 integrity result' if name=='integrity-result.json' else 'preserved original baseline/pre-key evidence; timestamps not rewritten'})
for name in ['VERIFY-PACKAGE.py','BATCH15-RULES.py','GLOBAL15-RULES.py']:
    put(name,(p/name).read_bytes(),{'kind':'inspected portable read-only Python standard-library verifier; separate scoped/global contracts'})
for name in ['verify.py','check-multiple-answer.cjs','record-blind.py','record-verification.py','final-checks.py','export.py']:
    put('evidence/local-helpers/'+name,(p/name).read_bytes(),{'kind':'actual local execution helper; original checkout/PDF tools required, not portable entrypoint'})
put('reference-bank.json',(p/'reference-bank.json').read_bytes(),{'kind':'exact immutable review-data/current-bank.json from SHA-pinned Batch14 ZIP; NOT derived from candidate'})
bank=read(p/'runtime-before.json')['bank']
jput('review-data/current-bank.json',bank,{'kind':'complete90 question data; fresh integrity verified equality with live runtime; no student data'})
jput('BANK-PRESERVATION.json',{'contentRevision':'2026-10-27.10','baseCommit':pre['head'],'questions':[{'id':q['id'],'beforeCanonicalSHA256':canonical(q),'afterCanonicalSHA256':canonical(q),'beforeKey':q['correct'],'afterKey':q['correct'],'beforeVersion':q['version'],'afterVersion':q['version']} for q in bank]},{'kind':'Full90 object preservation; fresh runtime/global equality independently checked'})
jput('GIT-CHANGE-INVENTORY.json',{'branch':before['branch'],'head':before['head'],'initialStatus':pre['status'],'finalStatus':before['status'],'existingFilesChanged':[],'preservedPendingDocuments':pre['existingUncommittedDocuments'],'newFiles':[{'relativePath':n,'sizeBytes':(root/n).stat().st_size,'sha256':sha((root/n).read_bytes())} for n in sorted(new)],'stagedFiles':[],'commitsCreated':False,'remoteGitOperations':False,'newOwnerAccepted':0,'newHumanApproved':0},{'kind':'complete fresh Git inventory;391 pre-batch files preserved;18 new Batch15 documents only'})
summary=(root/folder/'README.md').read_text(encoding='utf8')+'\n\n'
for d in read(root/folder/'decision-matrix.json')['decisions']:summary+=(root/folder/'reports'/(d['questionId']+'.md')).read_text(encoding='utf8')+'\n\n'
put('ACADEMIC-REVIEW-SUMMARY.md',summary.encode(),{'kind':'current Batch15 summary plus all8 existing full bilingual academic reports; blind review not repeated'})
instructions=(root/folder/'README.md').read_text(encoding='utf8')+"""

## Verificação portátil

Inspecionar VERIFY-PACKAGE.py, BATCH15-RULES.py e GLOBAL15-RULES.py. Depois de extrair numa pasta limpa, executar `python -B VERIFY-PACKAGE.py` com Python 3.9+ standard library, sem -O. Os três ficheiros são somente leitura, sem rede nem subprocessos. Os auxiliares em evidence/local-helpers requerem o checkout original e não são entradas portáteis. Verificadores históricos são evidência e não pacotes autónomos.

EXPORT-CONTINUITY.json mapeia todos os 471 membros do ZIP autenticado do Lote 14, comparados diretamente byte a byte. As 226 referências anteriores do repositório mantêm caminhos relativos. Cargas históricas idênticas podem partilhar destino, sem omissões. MANIFEST.json cobre todas as cargas exceto ele próprio para evitar circularidade; o SHA-256 externo do ZIP cobre também o manifesto. Hashes mostram consistência, não certificação académica ou assinatura digital.

Os logs históricos de falha e recuperação dos Lotes 12 e 13 são preservados sem reescrita e não são apresentados como novos testes. Os resultados novos estão em evidence/checks. O dossiê é uma exportação de evidência, não um repositório executável completo. A Fase 10H permanece aberta; aprovação humana PENDING; sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Não iniciar Lote 16. Nenhuma publicação, commit ou operação Git remota.
"""
put('README.md',instructions.encode(),{'kind':'current package instructions, scoped status and explicit academic limits'})
for n in provenance:
    assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}',(stage/n).read_bytes()),n
def manifest():
    d={'schemaVersion':1,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Phase10H Batch15 only; prior evidence unchanged through mapping','baseCommit':pre['head'],'selfHash':'Manifest excluded from internal hashes; whole-ZIP SHA covers it','files':[{'relativePath':n,'sizeBytes':(stage/n).stat().st_size,'sha256':sha((stage/n).read_bytes()),'provenance':provenance[n]} for n in sorted(provenance)]}
    (stage/'MANIFEST.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def runverify(path):
    return subprocess.run([sys.executable,'-B',str(path/'VERIFY-PACKAGE.py')],capture_output=True,text=True,encoding='utf8')
def verify(path):
    r=runverify(path);assert r.returncode==0,r.stdout+r.stderr;return json.loads(r.stdout)
manifest();initial=verify(stage);probes=[]
def reject(name):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();r=runverify(stage)
    probes.append({'name':name,'command':[sys.executable,'-B',str(stage/'VERIFY-PACKAGE.py')],'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    assert r.returncode!=0,'False positive: '+name
# Synthetic disposable package copies only; restore each input exactly afterwards.
probe=stage/folder/'exact-comparisons.json';saved=probe.read_bytes();probe.write_bytes(saved+b' ');reject('payload hash tamper');probe.write_bytes(saved)
probe=stage/'evidence/checks/diff-check.log';saved=probe.read_bytes();probe.unlink();reject('missing payload');probe.write_bytes(saved)
probe=stage/'docs/academic/phase10h-batch14-2026-11-07/README.md';saved=probe.read_bytes();probe.unlink();reject('loss of prior batch evidence');probe.write_bytes(saved)
mp=stage/'MANIFEST.json';savedManifest=mp.read_bytes();bad=json.loads(savedManifest);bad['files'][0]['relativePath']='../unsafe';mp.write_text(json.dumps(bad));reject('unsafe manifest path');mp.write_bytes(savedManifest)
bad=json.loads(savedManifest);bad['files'][0]['sha256']='0'*64;mp.write_text(json.dumps(bad));reject('false declared SHA256');mp.write_bytes(savedManifest)
probe=stage/'review-data/current-bank.json';saved=probe.read_bytes();badBank=json.loads(saved);badBank[1]['text']['en']='synthetic unauthorized tl-002 change';probe.write_text(json.dumps(badBank),encoding='utf8')
# Update only the disposable outer manifest to prove the immutable global layer rejects it too.
bad=json.loads(savedManifest);entry=next(e for e in bad['files'] if e['relativePath']=='review-data/current-bank.json');entry.update(sizeBytes=probe.stat().st_size,sha256=sha(probe.read_bytes()));mp.write_text(json.dumps(bad));reject('bank edit with outer manifest recomputed');probe.write_bytes(saved);mp.write_bytes(savedManifest)
# Poison candidate and purported reference together, with matching outer hashes.
candidate=stage/'review-data/current-bank.json';reference=stage/'reference-bank.json';savedCandidate=candidate.read_bytes();savedReference=reference.read_bytes();poison=json.loads(savedCandidate);poison[1]['text']['en']='synthetic poisoned expected reference';raw=json.dumps(poison).encode();candidate.write_bytes(raw);reference.write_bytes(raw)
bad=json.loads(savedManifest)
for entry in bad['files']:
    if entry['relativePath'] in ['review-data/current-bank.json','reference-bank.json']:entry.update(sizeBytes=len(raw),sha256=sha(raw))
mp.write_text(json.dumps(bad));reject('poisoned reference and candidate with outer hashes recomputed');candidate.write_bytes(savedCandidate);reference.write_bytes(savedReference);mp.write_bytes(savedManifest)
assert verify(stage)==initial
jput('evidence/checks/package-negative-tests.json',{'result':'PASS','casesRejected':len(probes),'cases':probes,'scope':'Only disposable staging payloads mutated; all restored; no real repository/user data touched'},{'kind':'fresh actual negative executions against portable package; log includes deliberate nonzero rejection exits'})
manifest();ready=verify(stage)
downloads=Path('C:/Users/gabri/Downloads');base='TestLearn-Phase10H-Batch15-Academic-Review-20261107';zipPath=downloads/(base+'.zip');i=0
while zipPath.exists():
    i+=1;zipPath=downloads/(base+'-'+datetime.datetime.now().strftime('%H%M%S')+'-'+str(i)+'.zip')
expected=sorted(n.relative_to(stage).as_posix() for n in stage.rglob('*') if n.is_file())
with zipfile.ZipFile(zipPath,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n in expected:z.write(stage/n,n)
extracted=work/'extracted-clean'
with zipfile.ZipFile(zipPath) as z:
    assert z.testzip() is None and sorted(z.namelist())==expected and len(set(z.namelist()))==len({n.casefold() for n in z.namelist()})==len(expected)
    for n in z.namelist():safe(n);assert z.read(n)==(stage/n).read_bytes()
    z.extractall(extracted)
for n in expected:assert (extracted/n).read_bytes()==(stage/n).read_bytes()
final=verify(extracted);assert final==ready and snapshot()==before
result={'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':[sys.executable,str(p/'export.py')],'exitCode':0,'zipPath':str(zipPath),'sizeBytes':zipPath.stat().st_size,'fileCount':len(expected),'manifestHashes':len(provenance),'sha256':sha(zipPath.read_bytes()),'CRC':'PASS','cleanExtraction':'PASS','portableVerifier':final,'priorMembersComparedDirectlyAndPreserved':471,'packageNegativeCasesRejected':len(probes),'repositoryUnchangedByExport':True,'stagingLocation':str(stage),'cleanExtractionLocation':str(extracted),'missingFiles':[]}
(p/'export-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
