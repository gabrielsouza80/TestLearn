"""Evidence-only investigation. Does not change any verifier or repository file."""
from pathlib import Path
import json,hashlib,subprocess,datetime,copy,runpy,zipfile,sys
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');f=root/'docs/academic/phase10h-batch12-2026-11-06';out=p/'recovery-evidence';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();canon=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());read=lambda x:json.loads(Path(x).read_text(encoding='utf-8-sig'))
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
pre=read(p/'preflight.json');assert git('branch','--show-current').strip()=='develop' and git('rev-parse','HEAD').strip()==pre['head'] and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
paths=[n for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0') if n];assert len(paths)==350
zipPath=Path('C:/Users/gabri/Downloads/TestLearn-Phase10H-Batch11-Academic-Review-20261106.zip');assert sha(zipPath.read_bytes())=='57db2636f49d56402944f71f8b87d14b0235cc25cd2d47d5b01951b3730c6188'
with zipfile.ZipFile(zipPath) as z:
 assert z.testzip() is None and len(z.namelist())==299
 m=json.loads(z.read('MANIFEST.json'));assert len(m['files'])==298
 for e in m['files']:
  b=z.read(e['relativePath']);assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
 referenceBytes=z.read('review-data/current-bank.json');entry=next(e for e in m['files'] if e['relativePath']=='review-data/current-bank.json');assert sha(referenceBytes)==entry['sha256']
ref=json.loads(referenceBytes);baseline=read(p/'runtime-before.json');live=json.loads(subprocess.check_output(['node','C:/TestLearn/tmp/phase10h-batch6-20261106/current-bank.cjs',str(root)]));assert live==baseline and ref==live['bank']
rules=runpy.run_path(str(p/'BATCH12-RULES.py'));matrix=read(f/'decision-matrix.json');ids=[d['questionId'] for d in matrix['decisions']]
args=[live['bank'],matrix,read(f/'exact-comparisons.json'),read(f/'blind-solutions.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidates.json'),{i:(f/'reports'/(i+'.md')).read_text(encoding='utf8') for i in ids},{'2026-10-27.'+str(i):read(root/('src/data/archive/questions-2026-10-27.'+str(i)+'.json')) for i in range(1,10)}]
assert rules['check'](*args)['result']=='PASS'
altered=copy.deepcopy(args);originalHash=canon(altered[0][1]);assert altered[0][1]['id']=='tl-002';altered[0][1]['text']['en']='adulterated bank';assert canon(altered[0][1])!=originalHash
assert rules['check'](*altered)['result']=='PASS'
# The complete-equality condition used by original integrity() does reject that same injected bank.
globalOriginalRejected=altered[0]!=ref;assert globalOriginalRejected
scoped=copy.deepcopy(args);next(q for q in scoped[0] if q['id']=='tl-016')['text']['en']='adulterated bank'
try:rules['check'](*scoped)
except AssertionError:scopedRejected=True
else:raise AssertionError('Scoped mutation was not rejected')
started=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=[sys.executable,str(p/'verify.py'),'batch12-specific'];red=subprocess.run(cmd,cwd=root,capture_output=True,text=True);completed=datetime.datetime.now(datetime.timezone.utc).isoformat();assert red.returncode==1 and 'False positive: unauthorized bank edit' in red.stderr
snapshot={'capturedAt':completed,'branch':'develop','head':pre['head'],'status':git('status','--untracked-files=all'),'filesSHA256':{n:sha((root/n).read_bytes()) for n in paths},'protectedPreBatch12Count':332,'batch12ExistingFilesSHA256':{n:sha((root/n).read_bytes()) for n in paths if n.startswith('docs/academic/phase10h-batch12-')},'STOP_FAILURE_SHA256':sha((p/'STOP-FAILURE.json').read_bytes())}
original=out/'original';original.mkdir()
for name in ['BATCH12-RULES.py','verify.py','STOP-FAILURE.json','targeted-vitest.log','targeted-vitest-result.json','multiple-answer-scoring.log','multiple-answer-scoring-result.json','integrity-result.json','integrity-execution.json']:(original/name).write_bytes((p/name).read_bytes())
(original/'interruption-README.md').write_bytes((f/'README.md').read_bytes());(original/'interruption-verification.md').write_bytes((f/'verification.md').read_bytes())
(out/'red.log').write_text(red.stdout+red.stderr,encoding='utf8');(out/'red-result.json').write_text(json.dumps({'command':cmd,'startedAt':started,'completedAt':completed,'exitCode':red.returncode,'expectedOriginalFailureReproduced':True},indent=2)+'\n')
(out/'resume-snapshot.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(p/'reference-bank.json').write_bytes(referenceBytes)
result={'rootCause':'B: the out-of-scope mutation was tested against the wrong layer. Integrated negative verification lacked dispatch to the existing full-bank equality protection.','hypothesisA':'No global-protection defect demonstrated: original complete equality rejects the identical mutated bank. Scoped check only hashes eight reviewed items; its global counts are structural checks, not a promise of all90 content hashes. The combined test organization had a real coverage gap.','hypothesisB':'CONFIRMED','hypothesisC':'REJECTED: the changed deep-copy bank is passed directly as args[0] to check; mutation hash changes and original remains intact. It is not a discarded or unused copy.','changedQuestionId':'tl-002','beforeCanonicalSHA256':originalHash,'afterCanonicalSHA256':canon(altered[0][1]),'scopedAcceptsOutOfScopeMutation':True,'originalGlobalEqualityRejectsSameMutation':globalOriginalRejected,'scopedRejectsInScopeMutation':scopedRejected,'referenceBankFileSHA256':sha(referenceBytes),'referenceBankCanonicalSHA256':canon(ref),'baselineZIP_SHA256':sha(zipPath.read_bytes()),'priorBatch11MembersVerified':299,'preexistingRepositoryFiles':len(paths),'academicReviewRepeated':False,'firstCorrectionApplied':False,'originalFailureArchived':True}
(out/'diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
