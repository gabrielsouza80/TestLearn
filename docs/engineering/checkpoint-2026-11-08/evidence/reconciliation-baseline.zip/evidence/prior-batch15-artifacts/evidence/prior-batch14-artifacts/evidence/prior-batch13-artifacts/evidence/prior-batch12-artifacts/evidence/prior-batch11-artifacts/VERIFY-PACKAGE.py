"""Inspect before running. Python3.9+ standard library, read-only, no network/subprocess.
Hashes establish consistency, not authenticity, semantic truth or human approval.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Python -O is forbidden: integrity assertions must be enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,runpy,re,datetime
root=Path(__file__).resolve().parent
def safe(n):
 assert isinstance(n,str) and n and '\\' not in n and ':' not in n and '\x00' not in n
 pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and pp.as_posix()==n
 p=root/n;assert p.resolve().is_relative_to(root) and not any(a.is_symlink() for a in [p,*p.parents] if a.is_relative_to(root))
 return p
def read(n):return json.loads(safe(n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
m=read('MANIFEST.json');files=m['files'];names=[e['relativePath'] for e in files]
assert len(names)==len(set(names))==len({n.casefold() for n in names})
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};assert actual==set(names)|{'MANIFEST.json'}
for e in files:
 b=safe(e['relativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256'] and e['provenance'],e['relativePath']
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json');inv=read('GIT-CHANGE-INVENTORY.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049' and pre['contentRevision']=='2026-10-27.10'
assert pre['priorPackageName']=='TestLearn-Phase10H-Batch10-Academic-Review-20261106.zip' and pre['priorPackageSHA256']=='13f36441a07f61ec1f6a5a79fdcb06a5166a7eccc22118658af79ef7cd8ec716'
assert pre['priorManifestHashCount']==254 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical'] and proof['existingFilesByteIdentical']==len(pre['existingFilesSHA256'])==314 and proof['priorUncommittedDocumentsPreserved']==len(pre['existingUncommittedDocuments'])==100
assert len(proof['priorBatchDocumentsSHA256'])==111 and proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
assert inv['existingFilesChanged']==[] and len(inv['newFiles'])==18 and len(inv['preservedPendingDocuments'])==100
for e in inv['newFiles']:
 b=safe(e['relativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
for e in files:
 if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
continuity=read('EXPORT-CONTINUITY.json');oldManifest=read(continuity['priorManifestPath']);old={e['relativePath']:e for e in oldManifest['files']}
assert continuity['previousPackageSHA256']==pre['priorPackageSHA256'] and continuity['previousFileCount']==len(continuity['files'])==255
assert len({e['previousRelativePath'] for e in continuity['files']})==255 and {e['previousRelativePath'] for e in continuity['files']}==set(old)|{'MANIFEST.json'}
assert sum(e['kind']=='preserved_repository_reference' for e in continuity['files'])==149 and continuity['omittedFiles']==[]
for e in continuity['files']:
 b=safe(e['currentRelativePath']).read_bytes();assert len(b)==e['sizeBytes'] and sha(b)==e['sha256']
 if e['previousRelativePath']!='MANIFEST.json':assert (len(b),sha(b))==(old[e['previousRelativePath']]['sizeBytes'],old[e['previousRelativePath']]['sha256'])
bank=read('review-data/current-bank.json');pres=read('BANK-PRESERVATION.json')
assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64 and pres['contentRevision']=='2026-10-27.10'
assert len(pres['questions'])==90
for a,q in zip(pres['questions'],bank):assert a['id']==q['id'] and a['beforeCanonicalSHA256']==a['afterCanonicalSHA256']==canonical(q) and a['beforeKey']==a['afterKey']==q['correct'] and a['beforeVersion']==a['afterVersion']==q['version']
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
archive=read('src/data/archive/questions-2026-10-27.9.json');assert [q['id'] for q in archive]==[q['id'] for q in bank] and all(a['correct']==q['correct'] for a,q in zip(archive,bank))
assert [q['id'] for a,q in zip(archive,bank) if a!=q]==['tl-011','tl-090']
q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
folder='docs/academic/phase10h-batch11-2026-11-06/'
matrix=read(folder+'decision-matrix.json');comparisons=read(folder+'exact-comparisons.json');blind=read(folder+'blind-solutions.json');projections=read(folder+'blind-projection.json');options=read(folder+'alternative-assessments.json');sources=read(folder+'sources.json');optional=read(folder+'optional-candidates.json')
assert blind==read('evidence/blind-solutions.json') and projections==read('evidence/blind-projection.json') and blind['projectionSHA256']==sha(safe('evidence/blind-projection.json').read_bytes())
reveal=read('evidence/key-reveal.json');assert len(reveal['questions'])==8
for s,k in zip(blind['solutions'],reveal['questions']):assert s['questionId']==k['questionId'] and s['answer']==k['key']==k['independentAnswer'] and datetime.datetime.fromisoformat(s['recordedAt'])<datetime.datetime.fromisoformat(reveal['at'])
reports={d['questionId']:safe(folder+'reports/'+d['questionId']+'.md').read_text(encoding='utf8') for d in matrix['decisions']}
archives={'2026-10-27.'+str(i):read('src/data/archive/questions-2026-10-27.'+str(i)+'.json') for i in range(1,10)}
rules=runpy.run_path(str(safe('BATCH11-RULES.py')));args=[bank,matrix,comparisons,blind,projections,options,sources,optional,reports,archives];specific=rules['check'](*args);negative=rules['negative_checks'](*args)
logged=read('evidence/checks/batch11-specific-result.json');assert {k:logged[k] for k in specific}==specific and logged['negativeChecks']==negative and logged['exitCode']==0
allBlocks=[]
for d in matrix['decisions']:allBlocks.extend(re.findall(r'```text\n([\s\S]*?)\n```',reports[d['questionId']]))
assert len(allBlocks)==324 and re.findall(r'```text\n([\s\S]*?)\n```',safe('ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==allBlocks
for n in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']:
 a=read('evidence/checks/'+n+'-result.json');assert a['exitCode']==0 and a['startedAt'] and a['completedAt']
scoring=json.loads(safe('evidence/checks/multiple-answer-scoring.log').read_text());assert len(scoring['syntheticSelections'])==8 and all(c['expected']==c['actual'] for c in scoring['syntheticSelections']) and not scoring['storageAccessed']
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(files),'previousPackageFilesAccountedFor':255,'priorAcademicDocumentsVerified':111,'questionsPreserved':90,'alternativesPreserved':364,'learningObjectivesPreserved':64,'historicalArchivesVerified':9,'batch11ReviewedQuestions':8,'batch11AlternativesVerified':32,'actualComparisonBlocks':320,'optionalComparisonBlocks':4,'negativeEvidenceCasesRejected':negative['negativeCasesRejected'],'syntheticScoringChecks':8,'ownerAcceptedAdded':0,'humanApprovedAdded':0,'semanticTruthAutomaticallyProven':False},indent=2))
