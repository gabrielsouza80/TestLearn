# TestLearn — Fase 10H, Lote 14

Âmbito exclusivo: tl-058, tl-059, tl-060, tl-061, tl-065, tl-066, tl-067 e tl-068; 32 alternativas. Revisão por IA, não SME humano. Oito pareceres ACCEPT_AS_IS, fundamentados sem usar a triagem NONE como evidência. Não houve defeito obrigatório nem proposta editorial justificada; o banco permanece inalterado.

Soluções cegas foram registadas antes da revelação de chaves e explicações, com horário e SHA-256. Coincidência de respostas não prova correção. Os relatórios preservam os textos integrais PT/EN em blocos literais antes/depois idênticos, avaliam todos os distratores, as explicações, hipóteses alternativas, LO/K e nove revisões históricas.

Baseline: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos. ZIP do Lote 13 autenticado: 78162d4c4582d296e66f3bb6c57483988aec78214f366710c655d4f14b9f63d6; 432 ficheiros e 431 hashes. Inventário inicial: 373 ficheiros, 159 não rastreados, 170 documentos académicos anteriores. Todos são preservados; interrupções e recuperações dos Lotes 12 e 13 mantêm os resultados históricos.

Fontes: EN v4.0.1 e PT v4.0 tradução 1.0, com páginas físicas verificadas individualmente. Ambos os endpoints oficiais ficaram acessíveis nesta execução; cópias oficiais locais foram lidas e hashed. Não se afirma igualdade textual de edições ou igualdade remota dos bytes. Referências e limites em sources.json. Não foi necessária consulta separada do glossário.

Distinções essenciais: fatores de sucesso não são garantia; cobertura estrutural não prova requisitos completos; checklist de alto nível admite variabilidade; confirmação dos três C não é reteste de defeito; prioridade não é severidade; comunicação adapta-se ao público; aprovação salarial é premissa de negócio; análise antecipada não exige software executável.

Duas camadas: BATCH14-RULES verifica os oito objetos e a coerência do dossiê. GLOBAL14-RULES compara os 90 objetos completos com referência fixa extraída do ZIP autenticado anterior, nunca gerada a partir do candidato. A mutação fora do lote em tl-002 é responsabilidade global. Guardas e verificação de pacote comprovam consistência, não verdade académica automática.

Sem alteração a banco, históricos, código, testes, persistência, versões ou pontuação. tl-001 mantém exatamente as duas respostas o1 e o4. Sem OWNER_ACCEPTED ou HUMAN_APPROVED novo; aprovação humana PENDING. Propostas opcionais permanecem vazias e não aplicadas.

Exportar apenas após todos os gates, contabilizando por comparação direta os 432 membros anteriores. O pacote é um dossiê de evidência, não um repositório executável completo. Datas reais UTC são conservadas. Ver verification.md para execuções novas, limites e testes não executados.

Fase 10H aberta. Sem commit, push, merge, PR, deploy ou Production. Concluir só Lote 14 e aguardar auditoria; não iniciar Lote 15.


# tl-058 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-3.2.5 / K1; versão 2; revisão 2026-10-27.10; SHA-256 canónico `f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Objetivos claros, critérios de saída mensuráveis e tempo suficiente para preparação são fatores explícitos de sucesso. O guia de colocação em serviço é um produto de trabalho passível de revisão; não há motivo para retirar preparação ou impor um tipo único.

Raciocínio guardado antes da revelação:

Objetivos claros, critérios de saída mensuráveis e tempo de preparação permitem orientar e avaliar a revisão do guia. A dimensão do pacote e o tipo de revisão devem depender do contexto; sacrificar preparação não é um fator de sucesso.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 3.2.5: EN páginas [37]; PT páginas [40].
- Secção 3.2.4: EN páginas [36, 37]; PT páginas [39, 40].

- LO FL-3.2.5/K1: EN página 32; PT página 35.

EN v4.0.1, página 37, e PT v4.0 tradução 1.0, página 40, incluem objetivos, critérios mensuráveis e preparação. A ressalva de walkthrough consta de EN página 36 e PT página 40. Não se infere que todas as revisões imponham exatamente o mesmo processo ou pessoas distintas.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Deployment guide corresponde a guia de colocação em serviço de software, não à execução do deployment. Revised/atualizado mantém o documento revisto; measurable exit criteria/critérios de saída mensuráveis é o mesmo conceito. Instead/em vez de transferir todo o tempo e every/todos mantêm os qualificadores que enfraquecem os distratores.

| EN literal                | PT literal                                          |
| ------------------------- | --------------------------------------------------- |
| revised deployment guide  | guia atualizado de colocação em serviço de software |
| measurable exit criteria  | critérios de saída mensuráveis                      |
| adequate preparation time | tempo adequado para preparação                      |

## Contraevidência e outras respostas defensáveis

Num walkthrough a revisão individual prévia pode não ser obrigatória. Isso não torna falso reconhecer tempo adequado como fator de sucesso nem torna superior transferi-lo integralmente para a reunião. Um conjunto maior pode facilitar logística, mas juntar todos os manuais não é, por si, fator de eficácia. Não se promete que estes fatores garantam todos os defeitos detetados.

## LO, nível K, explicações e dificuldade

K1: reconhecer uma lista de fatores expressamente apresentada na secção 3.2.5. O cenário apenas contextualiza a recordação; não obriga a desenhar um processo K3. Os distratores contrastam preparação, dimensão do pacote e adaptação do tipo, sem exigir experiência específica de infraestruturas. As quatro explicações são suficientes para esta distinção.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um líder de revisão prepara uma revisão de um guia atualizado de colocação em serviço de software. Que medida é um fator reconhecido de sucesso das revisões?
```

Proposto atual — sem alteração

```text
Um líder de revisão prepara uma revisão de um guia atualizado de colocação em serviço de software. Que medida é um fator reconhecido de sucesso das revisões?
```

### Enunciado EN

Original

```text
A review leader is preparing a review of a revised deployment guide. Which arrangement is a recognised success factor for reviews?
```

Proposto atual — sem alteração

```text
A review leader is preparing a review of a revised deployment guide. Which arrangement is a recognised success factor for reviews?
```

### o1 — alternativa PT

Original

```text
Transferir o tempo de preparação para a reunião, para que todos contactem com o guia em conjunto.
```

Proposto atual — sem alteração

```text
Transferir o tempo de preparação para a reunião, para que todos contactem com o guia em conjunto.
```

### o1 — explicação PT

Original

```text
Uma preparação individual adequada apoia uma revisão eficaz; substituí-la por uma primeira leitura na reunião prejudica esse fator.
```

Proposto atual — sem alteração

```text
Uma preparação individual adequada apoia uma revisão eficaz; substituí-la por uma primeira leitura na reunião prejudica esse fator.
```

### o1 — alternativa EN

Original

```text
Allocate the preparation time to the meeting instead, so everyone encounters the guide together.
```

Proposto atual — sem alteração

```text
Allocate the preparation time to the meeting instead, so everyone encounters the guide together.
```

### o1 — explicação EN

Original

```text
Adequate individual preparation supports effective review; replacing it with a first reading in the meeting undermines that factor.
```

Proposto atual — sem alteração

```text
Adequate individual preparation supports effective review; replacing it with a first reading in the meeting undermines that factor.
```

### o2 — alternativa PT

Original

```text
Usar o mesmo tipo de revisão para todos os produtos de trabalho para evitar decisões dependentes do contexto.
```

Proposto atual — sem alteração

```text
Usar o mesmo tipo de revisão para todos os produtos de trabalho para evitar decisões dependentes do contexto.
```

### o2 — explicação PT

Original

```text
O tipo de revisão deve adequar-se aos objetivos, ao produto de trabalho, aos participantes e ao contexto.
```

Proposto atual — sem alteração

```text
O tipo de revisão deve adequar-se aos objetivos, ao produto de trabalho, aos participantes e ao contexto.
```

### o2 — alternativa EN

Original

```text
Use the same review type for every work product to avoid context-dependent decisions.
```

Proposto atual — sem alteração

```text
Use the same review type for every work product to avoid context-dependent decisions.
```

### o2 — explicação EN

Original

```text
The review type should suit objectives, the work product, participants and context.
```

Proposto atual — sem alteração

```text
The review type should suit objectives, the work product, participants and context.
```

### o3 — alternativa PT

Original

```text
Juntar todos os manuais relacionados num grande pacote de revisão para reduzir o número de sessões.
```

Proposto atual — sem alteração

```text
Juntar todos os manuais relacionados num grande pacote de revisão para reduzir o número de sessões.
```

### o3 — explicação PT

Original

```text
Partes pequenas ajudam os revisores a manter a concentração; minimizar o número de sessões não é o critério de sucesso predominante.
```

Proposto atual — sem alteração

```text
Partes pequenas ajudam os revisores a manter a concentração; minimizar o número de sessões não é o critério de sucesso predominante.
```

### o3 — alternativa EN

Original

```text
Combine all related manuals into one large review package to reduce the number of sessions.
```

Proposto atual — sem alteração

```text
Combine all related manuals into one large review package to reduce the number of sessions.
```

### o3 — explicação EN

Original

```text
Small chunks help reviewers maintain concentration; minimising session count is not the overriding success criterion.
```

Proposto atual — sem alteração

```text
Small chunks help reviewers maintain concentration; minimising session count is not the overriding success criterion.
```

### o4 — alternativa PT

Original

```text
Definir objetivos claros e critérios de saída mensuráveis e disponibilizar tempo adequado para preparação.
```

Proposto atual — sem alteração

```text
Definir objetivos claros e critérios de saída mensuráveis e disponibilizar tempo adequado para preparação.
```

### o4 — explicação PT

Original

```text
Objetivos claros, critérios de saída mensuráveis e preparação suficiente são fatores explícitos de sucesso das revisões.
```

Proposto atual — sem alteração

```text
Objetivos claros, critérios de saída mensuráveis e preparação suficiente são fatores explícitos de sucesso das revisões.
```

### o4 — alternativa EN

Original

```text
Define clear objectives and measurable exit criteria, and provide adequate preparation time.
```

Proposto atual — sem alteração

```text
Define clear objectives and measurable exit criteria, and provide adequate preparation time.
```

### o4 — explicação EN

Original

```text
Clear goals, measurable exit criteria and sufficient preparation are explicit review success factors.
```

Proposto atual — sem alteração

```text
Clear goals, measurable exit criteria and sufficient preparation are explicit review success factors.
```

### Explicação geral PT

Original

```text
As revisões precisam de âmbito adequado, preparação, apoio e objetivos claros. A eficiência não resulta de eliminar a preparação ou tornar o material revisto excessivamente extenso.
```

Proposto atual — sem alteração

```text
As revisões precisam de âmbito adequado, preparação, apoio e objetivos claros. A eficiência não resulta de eliminar a preparação ou tornar o material revisto excessivamente extenso.
```

### Explicação geral EN

Original

```text
Reviews need an appropriate scope, preparation, support and clear goals. Efficiency does not come from removing preparation or making the reviewed material excessively large.
```

Proposto atual — sem alteração

```text
Reviews need an appropriate scope, preparation, support and clear goals. Efficiency does not come from removing preparation or making the reviewed material excessively large.
```

## Avaliação das quatro alternativas

### o1 — distrator

Retirar a preparação individual e substituí-la por leitura na reunião prejudica o fator indicado; discutir em conjunto não torna essa substituição superior.

Allocating individual preparation time to the meeting removes the chance to inspect independently beforehand. Meeting together can help discussion, but replacing preparation is not the recognised success factor asked for.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Impor o mesmo tipo a todos os produtos elimina a adaptação a objetivos e contexto; a explicação publicada identifica corretamente os fatores de escolha.

Review type should suit the work product, objectives and context. Imposing a universal type specifically to avoid contextual decisions contradicts justified tailoring.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Reduzir sessões juntando todos os manuais não assegura concentração; o princípio de partes pequenas justifica a rejeição sem inventar um tamanho máximo.

Combining all manuals may reduce session count, but a large review package increases cognitive load and is not an established success factor. Smaller manageable work products support effective attention.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — correta

Objetivos claros, critérios mensuráveis e preparação adequada reproduzem os fatores do syllabus; a explicação está correta sem prometer sucesso garantido.

Clear objectives, measurable completion criteria and enough preparation time support purposeful, assessable reviews. They do not guarantee every defect is found, and remain appropriate for a deployment guide.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o4'] | a3ee4d986b3d4aab7364d154507e967fee2c3f8d63ce9f99f913571c31648e9c |
| 2026-10-27.5 | True     | 2      | ['o4'] | f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7 |
| 2026-10-27.6 | True     | 2      | ['o4'] | f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7 |
| 2026-10-27.7 | True     | 2      | ['o4'] | f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7 |
| 2026-10-27.8 | True     | 2      | ['o4'] | f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7 |
| 2026-10-27.9 | True     | 2      | ['o4'] | f1959bc4d961799a3ea2d40451f5dbe827179852ff11549ae2116950aa0e69c7 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-059 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-4.3.3 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc`.

Resposta pré-gabarito: `['o1']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o1']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

A estrutura implementada pode ser medida objetivamente mesmo com especificação incompleta; funcionalidades ausentes podem não gerar qualquer ramo ou instrução no denominador. Logo a cobertura completa dos ramos não prova cobertura completa de requisitos e pode não revelar a auditoria omitida.

Raciocínio guardado antes da revelação:

Os ramos medem a estrutura que existe no código, não o que falta implementar. Podem detetar defeitos de implementação apesar de uma especificação incompleta, mas cobertura estrutural completa não demonstra que o requisito omitido esteja satisfeito.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 4.3.3: EN páginas [43]; PT páginas [47].
- Secção 4.3.2: EN páginas [43]; PT páginas [46, 47].

- LO FL-4.3.3/K2: EN página 38; PT página 41.

EN secção 4.3.3 na página 43 e PT na página 47 descrevem explicitamente especificações incompletas e defeitos de omissão. EN secção 4.3.2 cabe na página 43; PT inicia na página 46 e continua na 47. O deslocamento de páginas foi verificado individualmente, sem presumir equivalência textual integral.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

May miss/pode não detetar preserva possibilidade, não obrigação de falhar. Every branch/todos os ramos e all required functions/todas as funções obrigatórias mantêm o alcance. Objective coverage/cobertura objetiva descreve medição estrutural, não prova de correção. Missing code/código ausente não entra artificialmente como instrução existente não coberta.

| EN literal         | PT literal         |
| ------------------ | ------------------ |
| may miss           | pode não detetar   |
| objective coverage | cobertura objetiva |
| every branch       | todos os ramos     |

## Contraevidência e outras respostas defensáveis

Um teste derivado do código pode observar um efeito que revele uma omissão; a opção correta diz pode não detetar, não nunca deteta. Uma exigência de auditoria pode ser conhecida noutro artefacto apesar da especificação incompleta. Não há contradição em saber que o requisito existe e não ter o implementado; cobertura mede o que está presente.

## LO, nível K, explicações e dificuldade

K2: explicar simultaneamente uma vantagem e uma limitação e distingui-las de métricas de requisitos. Não há cálculo ou aplicação K3. A explicação geral pede complemento baseado em requisitos, que exige esclarecer a especificação incompleta; não promete que bastará repetir a base incompleta para encontrar tudo. Cada distrator expõe uma confusão diferente.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
A especificação de um componente está incompleta. Testes derivados do código exercitam todos os ramos, mas uma função obrigatória de registo de auditoria não foi implementada. Que afirmação melhor descreve o valor e a limitação deste teste caixa-branca?
```

Proposto atual — sem alteração

```text
A especificação de um componente está incompleta. Testes derivados do código exercitam todos os ramos, mas uma função obrigatória de registo de auditoria não foi implementada. Que afirmação melhor descreve o valor e a limitação deste teste caixa-branca?
```

### Enunciado EN

Original

```text
A component's specification is incomplete. Tests derived from its code exercise every branch, but a required audit-recording function has not been implemented. Which statement best describes the value and limitation of this white-box testing?
```

Proposto atual — sem alteração

```text
A component's specification is incomplete. Tests derived from its code exercise every branch, but a required audit-recording function has not been implemented. Which statement best describes the value and limitation of this white-box testing?
```

### o1 — alternativa PT

Original

```text
Fornece cobertura objetiva da estrutura implementada, mas pode não detetar a omissão do requisito de auditoria.
```

Proposto atual — sem alteração

```text
Fornece cobertura objetiva da estrutura implementada, mas pode não detetar a omissão do requisito de auditoria.
```

### o1 — explicação PT

Original

```text
O teste caixa-branca usa a estrutura da implementação mesmo com uma especificação incompleta; uma funcionalidade ausente pode não ter estrutura a cobrir.
```

Proposto atual — sem alteração

```text
O teste caixa-branca usa a estrutura da implementação mesmo com uma especificação incompleta; uma funcionalidade ausente pode não ter estrutura a cobrir.
```

### o1 — alternativa EN

Original

```text
It provides objective coverage of implemented structure, but may miss the omitted audit requirement.
```

Proposto atual — sem alteração

```text
It provides objective coverage of implemented structure, but may miss the omitted audit requirement.
```

### o1 — explicação EN

Original

```text
White-box testing uses implementation structure even with an incomplete specification; absent functionality may have no structure to cover.
```

Proposto atual — sem alteração

```text
White-box testing uses implementation structure even with an incomplete specification; absent functionality may have no structure to cover.
```

### o2 — alternativa PT

Original

```text
A cobertura total de ramos demonstra que todas as funções obrigatórias estão presentes, incluindo o registo de auditoria.
```

Proposto atual — sem alteração

```text
A cobertura total de ramos demonstra que todas as funções obrigatórias estão presentes, incluindo o registo de auditoria.
```

### o2 — explicação PT

Original

```text
A cobertura refere-se aos ramos implementados, não à prova de que todos os requisitos foram implementados.
```

Proposto atual — sem alteração

```text
A cobertura refere-se aos ramos implementados, não à prova de que todos os requisitos foram implementados.
```

### o2 — alternativa EN

Original

```text
Full branch coverage demonstrates that all required functions are present, including audit recording.
```

Proposto atual — sem alteração

```text
Full branch coverage demonstrates that all required functions are present, including audit recording.
```

### o2 — explicação EN

Original

```text
Coverage refers to implemented branches, not proof that every requirement was implemented.
```

Proposto atual — sem alteração

```text
Coverage refers to implemented branches, not proof that every requirement was implemented.
```

### o3 — alternativa PT

Original

```text
Uma especificação incompleta torna os testes derivados do código inadequados para detetar defeitos de implementação.
```

Proposto atual — sem alteração

```text
Uma especificação incompleta torna os testes derivados do código inadequados para detetar defeitos de implementação.
```

### o3 — explicação PT

Original

```text
Usar a implementação é uma vantagem quando as especificações estão incompletas; isso não elimina a limitação distinta relativa a omissões.
```

Proposto atual — sem alteração

```text
Usar a implementação é uma vantagem quando as especificações estão incompletas; isso não elimina a limitação distinta relativa a omissões.
```

### o3 — alternativa EN

Original

```text
An incomplete specification makes code-derived tests unsuitable for detecting implementation defects.
```

Proposto atual — sem alteração

```text
An incomplete specification makes code-derived tests unsuitable for detecting implementation defects.
```

### o3 — explicação EN

Original

```text
Using the implementation is a strength when specifications are incomplete; this does not eliminate the separate omission limitation.
```

Proposto atual — sem alteração

```text
Using the implementation is a strength when specifications are incomplete; this does not eliminate the separate omission limitation.
```

### o4 — alternativa PT

Original

```text
Os resultados dos ramos medem a cobertura de requisitos, enquanto a função de auditoria ausente reduz a cobertura de instruções.
```

Proposto atual — sem alteração

```text
Os resultados dos ramos medem a cobertura de requisitos, enquanto a função de auditoria ausente reduz a cobertura de instruções.
```

### o4 — explicação PT

Original

```text
A cobertura de ramos e de instruções mede a estrutura do código existente; código ausente não é uma instrução não coberta dessa implementação.
```

Proposto atual — sem alteração

```text
A cobertura de ramos e de instruções mede a estrutura do código existente; código ausente não é uma instrução não coberta dessa implementação.
```

### o4 — alternativa EN

Original

```text
The branch results measure requirements coverage, while the missing audit function reduces statement coverage.
```

Proposto atual — sem alteração

```text
The branch results measure requirements coverage, while the missing audit function reduces statement coverage.
```

### o4 — explicação EN

Original

```text
Branch and statement coverage measure existing code structure; missing code is not an uncovered statement in that implementation.
```

Proposto atual — sem alteração

```text
Branch and statement coverage measure existing code structure; missing code is not an uncovered statement in that implementation.
```

### Explicação geral PT

Original

```text
A cobertura estrutural pode orientar testes adicionais e aumentar a confiança no código. Continuam a ser necessários testes baseados em requisitos para tratar omissões; cobertura total do código não é cobertura total de requisitos.
```

Proposto atual — sem alteração

```text
A cobertura estrutural pode orientar testes adicionais e aumentar a confiança no código. Continuam a ser necessários testes baseados em requisitos para tratar omissões; cobertura total do código não é cobertura total de requisitos.
```

### Explicação geral EN

Original

```text
Structural coverage can guide extra tests and increase confidence in code. Requirements-based testing is still needed to address omissions; full code coverage is not full requirements coverage.
```

Proposto atual — sem alteração

```text
Structural coverage can guide extra tests and increase confidence in code. Requirements-based testing is still needed to address omissions; full code coverage is not full requirements coverage.
```

## Avaliação das quatro alternativas

### o1 — correta

Correta: mede estrutura implementada sem garantir que deteta funcionalidade ausente; o qualificador pode é preservado na explicação dos dois idiomas.

Structural coverage objectively measures exercised implemented code. A function absent from that structure may remain invisible to code-derived tests; may miss is a possibility, not a universal claim of impossibility.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Cobertura total de ramos não demonstra implementação de todos os requisitos; a explicação separa corretamente estrutura existente de funcionalidade requerida.

All implemented branches can be exercised while required functionality is missing. Full structural coverage therefore cannot establish that every required function, including audit recording, exists.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Uma especificação incompleta não impede detetar defeitos no código existente; a limitação de omissões não elimina a utilidade estrutural descrita.

An incomplete specification does not make code-derived tests useless for implementation defects. Their limited view of omissions is different from inability to expose faults in code that is present.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Ramos não medem requisitos e código inexistente não é uma instrução implementada descoberta como não coberta; a explicação responde às duas partes falsas.

Branch coverage is not requirements coverage. Missing functionality adds no statements to the implemented-code denominator, so its omission does not necessarily reduce measured statement coverage.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |
| 2026-10-27.5 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |
| 2026-10-27.6 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |
| 2026-10-27.7 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |
| 2026-10-27.8 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |
| 2026-10-27.9 | True     | 1      | ['o1'] | 530c97e50a27b10a101d6427034146d9bcff50a5530d6ccc7988fd7897239fbc |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-060 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-4.4.3 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Checklists de alto nível dão condições comuns mas permitem exemplos e sequências distintos. Isso pode ampliar cobertura e reduzir repetibilidade. A análise do defeito novo deve informar atualização com condição separada e diretamente verificável, mantendo tamanho e relevância manejáveis.

Raciocínio guardado antes da revelação:

Uma checklist de alto nível orienta o que verificar sem fixar todos os passos ou dados, permitindo exploração distinta e menor repetibilidade. A nova falha deve informar uma condição verificável, sem abandonar o instrumento nem congelar uma lista incompleta.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 4.4.3: EN páginas [44, 45]; PT páginas [48, 49].

- LO FL-4.4.3/K2: EN página 38; PT página 41.

A definição começa em EN página 44 e PT página 48; verificabilidade, atualização e compromisso de repetibilidade continuam em EN página 45 e PT página 49. Ambos os textos sustentam as três dimensões. Restrições da fonte sobre itens excessivamente gerais ou adequados a outros instrumentos não são requisitos novos inventados para este cenário.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

High-level/alto nível, directly checkable/diretamente verificável e every future severe defect only/todos os futuros defeitos graves apenas mantêm grau de detalhe, verificabilidade e exclusividade. Repeatability trade-off/compromisso de repetibilidade é legível no contexto de variabilidade; não indica que nenhum teste concreto possa ser repetido.

| EN literal                   | PT literal                       |
| ---------------------------- | -------------------------------- |
| high-level checklist         | checklist de alto nível          |
| directly checkable condition | condição diretamente verificável |
| repeatability trade-off      | compromisso de repetibilidade    |

## Contraevidência e outras respostas defensáveis

Procedimentos idênticos podem aumentar repetibilidade quando essa é a necessidade, mas não são inerentes à orientação de alto nível e não resolvem a atualização. Cartas exploratórias são complementos defensáveis; congelar a lista e encaminhar todos os defeitos futuros apenas para outra técnica é o absoluto que torna o distrator incorreto.

## LO, nível K, explicações e dificuldade

K2: explicar a natureza da técnica e a relação entre consistência, variabilidade e manutenção da lista. Não se pede criar a condição concreta, pelo que não é aplicação K3. As explicações individuais e geral delimitam a possibilidade de exploração e a necessidade de aprender com defeitos sem transformar a checklist numa bateria prescritiva completa.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Dois testadores usam a mesma checklist de alto nível para um editor de documentos, mas escolhem exemplos e sequências de ações diferentes. É depois encontrado um novo defeito grave fora da checklist atual. Que resposta melhor reflete o teste baseado em checklists?
```

Proposto atual — sem alteração

```text
Dois testadores usam a mesma checklist de alto nível para um editor de documentos, mas escolhem exemplos e sequências de ações diferentes. É depois encontrado um novo defeito grave fora da checklist atual. Que resposta melhor reflete o teste baseado em checklists?
```

### Enunciado EN

Original

```text
Two testers use the same high-level checklist for a document editor but choose different examples and action sequences. A new severe defect is then found outside the current checklist. Which response best reflects checklist-based testing?
```

Proposto atual — sem alteração

```text
Two testers use the same high-level checklist for a document editor but choose different examples and action sequences. A new severe defect is then found outside the current checklist. Which response best reflects checklist-based testing?
```

### o1 — alternativa PT

Original

```text
Exigir passos de execução idênticos para cada item, continuando a descrever a checklist como orientação de alto nível.
```

Proposto atual — sem alteração

```text
Exigir passos de execução idênticos para cada item, continuando a descrever a checklist como orientação de alto nível.
```

### o1 — explicação PT

Original

```text
Procedimentos detalhados idênticos poderiam aumentar a repetibilidade, mas não são inerentes a uma checklist de alto nível nem tratam a atualização das suas condições.
```

Proposto atual — sem alteração

```text
Procedimentos detalhados idênticos poderiam aumentar a repetibilidade, mas não são inerentes a uma checklist de alto nível nem tratam a atualização das suas condições.
```

### o1 — alternativa EN

Original

```text
Require identical execution steps for every item while continuing to describe the checklist as high-level guidance.
```

Proposto atual — sem alteração

```text
Require identical execution steps for every item while continuing to describe the checklist as high-level guidance.
```

### o1 — explicação EN

Original

```text
Detailed identical procedures could increase repeatability, but are not inherent in a high-level checklist and do not address updating its conditions.
```

Proposto atual — sem alteração

```text
Detailed identical procedures could increase repeatability, but are not inherent in a high-level checklist and do not address updating its conditions.
```

### o2 — alternativa PT

Original

```text
Abandonar a checklist porque exemplos diferentes demonstram que não pode proporcionar consistência útil.
```

Proposto atual — sem alteração

```text
Abandonar a checklist porque exemplos diferentes demonstram que não pode proporcionar consistência útil.
```

### o2 — explicação PT

Original

```text
Checklists de alto nível podem orientar de forma consistente, permitindo variabilidade e uma cobertura potencialmente mais ampla.
```

Proposto atual — sem alteração

```text
Checklists de alto nível podem orientar de forma consistente, permitindo variabilidade e uma cobertura potencialmente mais ampla.
```

### o2 — alternativa EN

Original

```text
Discard the checklist because different examples demonstrate that it cannot provide useful consistency.
```

Proposto atual — sem alteração

```text
Discard the checklist because different examples demonstrate that it cannot provide useful consistency.
```

### o2 — explicação EN

Original

```text
High-level checklists can give consistent guidance while allowing variability and potentially broader coverage.
```

Proposto atual — sem alteração

```text
High-level checklists can give consistent guidance while allowing variability and potentially broader coverage.
```

### o3 — alternativa PT

Original

```text
Reconhecer o compromisso de repetibilidade e atualizar a checklist com uma condição diretamente verificável baseada no defeito.
```

Proposto atual — sem alteração

```text
Reconhecer o compromisso de repetibilidade e atualizar a checklist com uma condição diretamente verificável baseada no defeito.
```

### o3 — explicação PT

Original

```text
Itens de alto nível permitem variação; a análise de defeitos deve orientar atualizações regulares sem tornar a checklist excessivamente longa.
```

Proposto atual — sem alteração

```text
Itens de alto nível permitem variação; a análise de defeitos deve orientar atualizações regulares sem tornar a checklist excessivamente longa.
```

### o3 — alternativa EN

Original

```text
Recognise the repeatability trade-off and update the checklist with a directly checkable condition informed by the defect.
```

Proposto atual — sem alteração

```text
Recognise the repeatability trade-off and update the checklist with a directly checkable condition informed by the defect.
```

### o3 — explicação EN

Original

```text
High-level items permit variation; defect analysis should inform regular updates without making the checklist unmanageably long.
```

Proposto atual — sem alteração

```text
High-level items permit variation; defect analysis should inform regular updates without making the checklist unmanageably long.
```

### o4 — alternativa PT

Original

```text
Manter a checklist inalterada e tratar todos os futuros defeitos graves apenas através de uma carta de teste exploratório separada.
```

Proposto atual — sem alteração

```text
Manter a checklist inalterada e tratar todos os futuros defeitos graves apenas através de uma carta de teste exploratório separada.
```

### o4 — explicação PT

Original

```text
A exploração pode complementar a checklist, mas ignorar nova evidência de defeitos impede a sua evolução.
```

Proposto atual — sem alteração

```text
A exploração pode complementar a checklist, mas ignorar nova evidência de defeitos impede a sua evolução.
```

### o4 — alternativa EN

Original

```text
Keep the checklist unchanged and handle every future severe defect only through a separate exploratory charter.
```

Proposto atual — sem alteração

```text
Keep the checklist unchanged and handle every future severe defect only through a separate exploratory charter.
```

### o4 — explicação EN

Original

```text
Exploration may complement the checklist, but ignoring new defect evidence prevents the checklist from evolving.
```

Proposto atual — sem alteração

```text
Exploration may complement the checklist, but ignoring new defect evidence prevents the checklist from evolving.
```

### Explicação geral PT

Original

```text
O teste baseado em checklists cobre as condições listadas em vez de prescrever casos de teste detalhados idênticos. Deve manter itens relevantes e verificáveis individualmente, usando experiência e evidência de defeitos.
```

Proposto atual — sem alteração

```text
O teste baseado em checklists cobre as condições listadas em vez de prescrever casos de teste detalhados idênticos. Deve manter itens relevantes e verificáveis individualmente, usando experiência e evidência de defeitos.
```

### Explicação geral EN

Original

```text
Checklist-based testing covers listed conditions rather than prescribing identical detailed test cases. Maintain relevant, independently checkable items using experience and defect evidence.
```

Proposto atual — sem alteração

```text
Checklist-based testing covers listed conditions rather than prescribing identical detailed test cases. Maintain relevant, independently checkable items using experience and defect evidence.
```

## Avaliação das quatro alternativas

### o1 — distrator

Passos detalhados idênticos poderiam servir outro objetivo, mas contradizem a orientação de alto nível indicada e não incorporam a evidência do defeito novo.

Identical execution steps can support scripted repeatability, but imposing them on every item changes the high-level guidance being described. It also does not explicitly incorporate the newly found severe defect.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Exemplos diferentes não eliminam consistência ao nível das condições comuns; a explicação corretamente admite cobertura potencialmente mais ampla.

Different examples do not make a high-level checklist incapable of useful consistency. Shared conditions can guide both testers even when their concrete data and sequences differ.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — correta

Correta: reconhece menor repetibilidade e atualiza uma condição verificável com base no defeito; não exige inventar o texto ou automatizar todos os itens.

High-level checklists permit variation at the cost of exact repeatability. Adding a directly checkable condition informed by the new defect improves future coverage without pretending the technique prescribes identical scripts.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Exploração pode complementar a checklist, mas mantê-la congelada e usar apenas outro instrumento para todos os defeitos futuros impede a sua evolução.

Exploratory charters may complement a checklist, but freezing it and relegating every future severe defect exclusively elsewhere prevents learning from the newly observed omission.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |
| 2026-10-27.5 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |
| 2026-10-27.6 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |
| 2026-10-27.7 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |
| 2026-10-27.8 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |
| 2026-10-27.9 | True     | 1      | ['o3'] | fe780efeb1775fe9ef0f838aedfd789eb9b617f731f628c347796b568a741bba |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-061 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-4.5.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Faltam finalidade e regras de alteração da etiqueta. A conversação entre negócio, desenvolvimento e testes deve esclarecer valor, exemplos positivos e negativos e critérios testáveis antes de implementar. A confirmação dos três C refere-se a critérios de aceitação, não a repetir testes após corrigir um defeito.

Raciocínio guardado antes da revelação:

A story carece de condições de utilização e do propósito da alteração. A colaboração entre negócio, desenvolvimento e teste deve clarificar objetivo, valor, exemplos positivos e negativos e critérios testáveis antes da implementação, sem decidir regras de negócio unilateralmente.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 4.5.1: EN páginas [45]; PT páginas [49].
- Secção 4.5.2: EN páginas [45, 46]; PT páginas [49, 50].
- Secção 2.2.3: EN páginas [30]; PT páginas [33].

- LO FL-4.5.1/K2: EN página 38; PT página 41.

As secções 4.5.1 e 4.5.2 estão em EN páginas 45–46 e PT páginas 49–50. Ambas relacionam os três C com critérios testáveis e cenários positivos/negativos. EN página 30 e PT página 33 definem teste de confirmação de defeito corrigido; esta referência de apoio impede confundir usos da palavra confirmação.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Before implementation/antes da implementação mantém o momento. Permitted and forbidden examples/exemplos permitidos e proibidos preserva ambas as polaridades. Amendment rule/regra de alteração significa alterar etiquetas, não alterar critérios arbitrariamente. Confirmation/confirmação na explicação usa os três C; teste de confirmação pós-correção é conceito distinto.

| EN literal                       | PT literal                       |
| -------------------------------- | -------------------------------- |
| before implementation            | antes da implementação           |
| permitted and forbidden examples | exemplos permitidos e proibidos  |
| testable acceptance criteria     | critérios de aceitação testáveis |

## Contraevidência e outras respostas defensáveis

Um representante pode redigir o cartão sozinho, mas a opção proíbe discussão posterior e perde as perspetivas pedidas. Tarefas técnicas podem ser úteis depois de clarificar o comportamento; não substituem o acordo sobre quando a alteração é permitida. Critérios podem evoluir, mas adiá-los deliberadamente neste cenário deixa a omissão por resolver.

## LO, nível K, explicações e dificuldade

K2: explicar colaboração para obter entendimento e testabilidade, sem exigir derivar casos ATDD em K3. A opção correta cobre quem, para quê e em que condições; as explicações contrapõem conveniência técnica, autoria isolada e adiamento. A referência aos três C esclarece o termo confirmação e é pedagogicamente adequada, sem precisar modificar o banco.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma user story inicial indica que os trabalhadores de um laboratório precisam de alterar a etiqueta de uma amostra, mas não explica quando são permitidas alterações nem por que são importantes. O que devem fazer em conjunto os representantes do negócio, os programadores e os testadores antes da implementação?
```

Proposto atual — sem alteração

```text
Uma user story inicial indica que os trabalhadores de um laboratório precisam de alterar a etiqueta de uma amostra, mas não explica quando são permitidas alterações nem por que são importantes. O que devem fazer em conjunto os representantes do negócio, os programadores e os testadores antes da implementação?
```

### Enunciado EN

Original

```text
A draft story says that laboratory staff need to amend a sample label, but does not explain when changes are allowed or why they matter. What should business representatives, developers and testers do together before implementation?
```

Proposto atual — sem alteração

```text
A draft story says that laboratory staff need to amend a sample label, but does not explain when changes are allowed or why they matter. What should business representatives, developers and testers do together before implementation?
```

### o1 — alternativa PT

Original

```text
Deixar os programadores escolher a regra de alteração mais simples e pedir aos testadores que a documentem como resultado esperado.
```

Proposto atual — sem alteração

```text
Deixar os programadores escolher a regra de alteração mais simples e pedir aos testadores que a documentem como resultado esperado.
```

### o1 — explicação PT

Original

```text
A conveniência de implementação, por si só, não estabelece valor de negócio nem acordo partilhado sobre o comportamento permitido.
```

Proposto atual — sem alteração

```text
A conveniência de implementação, por si só, não estabelece valor de negócio nem acordo partilhado sobre o comportamento permitido.
```

### o1 — alternativa EN

Original

```text
Let developers select the simplest amendment rule and ask testers to document it as the expected result.
```

Proposto atual — sem alteração

```text
Let developers select the simplest amendment rule and ask testers to document it as the expected result.
```

### o1 — explicação EN

Original

```text
Implementation convenience alone does not establish business value or shared agreement on permitted behaviour.
```

Proposto atual — sem alteração

```text
Implementation convenience alone does not establish business value or shared agreement on permitted behaviour.
```

### o2 — alternativa PT

Original

```text
Discutir o objetivo do utilizador e o valor de negócio, explorar exemplos permitidos e proibidos e acordar critérios de aceitação testáveis.
```

Proposto atual — sem alteração

```text
Discutir o objetivo do utilizador e o valor de negócio, explorar exemplos permitidos e proibidos e acordar critérios de aceitação testáveis.
```

### o2 — explicação PT

Original

```text
A conversação entre as três perspetivas constrói uma story partilhada e critérios de confirmação, ajudando a revelar regras pouco claras ou em falta.
```

Proposto atual — sem alteração

```text
A conversação entre as três perspetivas constrói uma story partilhada e critérios de confirmação, ajudando a revelar regras pouco claras ou em falta.
```

### o2 — alternativa EN

Original

```text
Discuss the user goal and business value, explore permitted and forbidden examples, and agree testable acceptance criteria.
```

Proposto atual — sem alteração

```text
Discuss the user goal and business value, explore permitted and forbidden examples, and agree testable acceptance criteria.
```

### o2 — explicação EN

Original

```text
Conversation across the three perspectives builds a shared story and confirmation criteria, helping expose unclear or missing rules.
```

Proposto atual — sem alteração

```text
Conversation across the three perspectives builds a shared story and confirmation criteria, helping expose unclear or missing rules.
```

### o3 — alternativa PT

Original

```text
Pedir ao representante do negócio que conclua a story sozinho e depois estimá-la sem mais discussão.
```

Proposto atual — sem alteração

```text
Pedir ao representante do negócio que conclua a story sozinho e depois estimá-la sem mais discussão.
```

### o3 — explicação PT

Original

```text
O contributo do negócio é essencial, mas a autoria colaborativa inclui as perspetivas de desenvolvimento e teste para estabelecer entendimento partilhado e testabilidade.
```

Proposto atual — sem alteração

```text
O contributo do negócio é essencial, mas a autoria colaborativa inclui as perspetivas de desenvolvimento e teste para estabelecer entendimento partilhado e testabilidade.
```

### o3 — alternativa EN

Original

```text
Ask the business representative to complete the story alone, then estimate it without further discussion.
```

Proposto atual — sem alteração

```text
Ask the business representative to complete the story alone, then estimate it without further discussion.
```

### o3 — explicação EN

Original

```text
Business input is essential, but collaborative authorship includes development and testing perspectives to establish shared understanding and testability.
```

Proposto atual — sem alteração

```text
Business input is essential, but collaborative authorship includes development and testing perspectives to establish shared understanding and testability.
```

### o4 — alternativa PT

Original

```text
Converter o rascunho numa lista detalhada de tarefas de implementação e adiar os critérios de aceitação até à primeira demonstração.
```

Proposto atual — sem alteração

```text
Converter o rascunho numa lista detalhada de tarefas de implementação e adiar os critérios de aceitação até à primeira demonstração.
```

### o4 — explicação PT

Original

```text
Uma lista de tarefas não resolve as regras de negócio em falta; a confirmação deve orientar a implementação em vez de esperar por ela.
```

Proposto atual — sem alteração

```text
Uma lista de tarefas não resolve as regras de negócio em falta; a confirmação deve orientar a implementação em vez de esperar por ela.
```

### o4 — alternativa EN

Original

```text
Convert the draft into a detailed implementation task list and defer acceptance criteria until the first demonstration.
```

Proposto atual — sem alteração

```text
Convert the draft into a detailed implementation task list and defer acceptance criteria until the first demonstration.
```

### o4 — explicação EN

Original

```text
A task list does not resolve the missing business rules; confirmation should inform implementation rather than wait for it.
```

Proposto atual — sem alteração

```text
A task list does not resolve the missing business rules; confirmation should inform implementation rather than wait for it.
```

### Explicação geral PT

Original

```text
A escrita colaborativa de user stories combina as perspetivas de negócio, desenvolvimento e teste. O cartão é apoiado pela conversação e confirmação; uma lista de tarefas técnicas, por si só, é insuficiente.
```

Proposto atual — sem alteração

```text
A escrita colaborativa de user stories combina as perspetivas de negócio, desenvolvimento e teste. O cartão é apoiado pela conversação e confirmação; uma lista de tarefas técnicas, por si só, é insuficiente.
```

### Explicação geral EN

Original

```text
Collaborative story writing combines business, development and testing perspectives. The card is supported by conversation and confirmation; a technical task list alone is insufficient.
```

Proposto atual — sem alteração

```text
Collaborative story writing combines business, development and testing perspectives. The card is supported by conversation and confirmation; a technical task list alone is insufficient.
```

## Avaliação das quatro alternativas

### o1 — distrator

Conveniência da implementação não estabelece intenção de negócio; usar a regra técnica como oráculo sem acordo partilhado não resolve a ambiguidade.

Developer convenience does not determine the intended business rule. Recording the simplest chosen implementation as the expected result creates a self-confirming oracle without agreeing user needs.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: reúne as três perspetivas para esclarecer valor e condições testáveis; confirmação refere-se aos critérios dos três C, não ao reteste de defeito.

Discussing the user goal and business value with permitted and forbidden examples builds shared understanding. Agreeing testable acceptance criteria addresses the missing boundaries before implementation.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

O negócio aporta conhecimento essencial, mas concluir sozinho e impedir nova discussão não satisfaz a colaboração explícita pedida no enunciado.

Business representatives supply essential domain knowledge, but completing the story alone and prohibiting further discussion loses the combined perspectives requested in the scenario.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Uma lista de tarefas não esclarece regras de negócio e adiar critérios até à demonstração mantém a ambiguidade durante a implementação inicial.

Implementation tasks describe how to build rather than why or when label changes are acceptable. Deferring acceptance criteria until demonstration leaves the identified ambiguity unresolved during implementation.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |
| 2026-10-27.5 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |
| 2026-10-27.6 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |
| 2026-10-27.7 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |
| 2026-10-27.8 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |
| 2026-10-27.9 | True     | 1      | ['o2'] | 76e5a5163149d97dd8272b46b1e90f4a9b94fe8b0ca2c4a95c37639944cba271 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-065 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.3.1 / K1; versão 1; revisão 2026-10-27.10; SHA-256 canónico `04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Tempo de resposta é exemplo explícito de métrica de qualidade do produto. Quantidade de casos executados mede progresso, defeitos abertos por prioridade mede defeitos e requisitos cobertos mede cobertura. A classificação pedida não equivale a dizer que outras métricas nunca informam decisões de qualidade.

Raciocínio guardado antes da revelação:

O tempo de resposta medido descreve um atributo de qualidade do produto. Casos executados indicam progresso; defeitos abertos agrupados por prioridade são métricas de defeitos; requisitos cobertos indicam cobertura, não uma medição direta de desempenho.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 5.3.1: EN páginas [54]; PT páginas [60].

- LO FL-5.3.1/K1: EN página 47; PT página 52.

EN página 54 e PT página 60 apresentam tempo de resposta entre métricas da qualidade do produto e prioridades de defeitos entre métricas de defeitos. As traduções de categorias são congruentes neste item. Não se extrapola que uma métrica isolada permita aprovar a qualidade ou a publicação.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Measured/medido preserva que existe observação, sem inventar unidades, valor, limiar ou carga. High-priority/prioridade elevada é fiel e distinto de severidade. Planned cases executed/casos planeados executados e specified requirements covered/requisitos especificados cobertos mantêm numerador e objeto, sem transformar cobertura em correção garantida.

| EN literal             | PT literal                     |
| ---------------------- | ------------------------------ |
| Measured response time | Tempo de resposta medido       |
| high-priority defects  | defeitos de prioridade elevada |
| coverage metric        | métrica de cobertura           |

## Contraevidência e outras respostas defensáveis

Defeitos e cobertura podem ser usados como indicadores indiretos de qualidade, mas o enunciado pede a categoria segundo a taxonomia. O qualificador em vez de separa essas categorias. Um tempo medido sem contexto ou limiar não prova conformidade, e prioridade elevada não deve ser rebatizada como severidade elevada.

## LO, nível K, explicações e dificuldade

K1: recordar categorias e exemplos de métricas da secção 5.3.1. O dashboard de biblioteca só contextualiza, sem cálculo de desempenho. A justificação breve de progresso em o1 é suficiente para esta classificação e complementada pela explicação geral; não exige uma extensão editorial sem defeito demonstrado.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um dashboard de um serviço de empréstimos de uma biblioteca contém várias métricas de teste. Que métrica é classificada como métrica de qualidade do produto, em vez de métrica de progresso do teste, de defeitos ou de cobertura?
```

Proposto atual — sem alteração

```text
Um dashboard de um serviço de empréstimos de uma biblioteca contém várias métricas de teste. Que métrica é classificada como métrica de qualidade do produto, em vez de métrica de progresso do teste, de defeitos ou de cobertura?
```

### Enunciado EN

Original

```text
A dashboard for a library lending service contains several test metrics. Which metric is classified as a product quality metric rather than a test progress, defect or coverage metric?
```

Proposto atual — sem alteração

```text
A dashboard for a library lending service contains several test metrics. Which metric is classified as a product quality metric rather than a test progress, defect or coverage metric?
```

### o1 — alternativa PT

Original

```text
Número de casos de teste planeados que foram executados.
```

Proposto atual — sem alteração

```text
Número de casos de teste planeados que foram executados.
```

### o1 — explicação PT

Original

```text
Esta é uma métrica de progresso do teste.
```

Proposto atual — sem alteração

```text
Esta é uma métrica de progresso do teste.
```

### o1 — alternativa EN

Original

```text
Number of planned test cases that have been executed.
```

Proposto atual — sem alteração

```text
Number of planned test cases that have been executed.
```

### o1 — explicação EN

Original

```text
This is a test progress metric.
```

Proposto atual — sem alteração

```text
This is a test progress metric.
```

### o2 — alternativa PT

Original

```text
Tempo de resposta medido do serviço de empréstimos.
```

Proposto atual — sem alteração

```text
Tempo de resposta medido do serviço de empréstimos.
```

### o2 — explicação PT

Original

```text
O tempo de resposta mede uma característica de qualidade não funcional do produto.
```

Proposto atual — sem alteração

```text
O tempo de resposta mede uma característica de qualidade não funcional do produto.
```

### o2 — alternativa EN

Original

```text
Measured response time of the lending service.
```

Proposto atual — sem alteração

```text
Measured response time of the lending service.
```

### o2 — explicação EN

Original

```text
Response time measures a non-functional quality characteristic of the product.
```

Proposto atual — sem alteração

```text
Response time measures a non-functional quality characteristic of the product.
```

### o3 — alternativa PT

Original

```text
Número de defeitos de prioridade elevada que permanecem abertos.
```

Proposto atual — sem alteração

```text
Número de defeitos de prioridade elevada que permanecem abertos.
```

### o3 — explicação PT

Original

```text
Esta é uma métrica de defeitos; pode apoiar decisões sobre qualidade, mas não é a métrica de qualidade do produto pedida nesta classificação.
```

Proposto atual — sem alteração

```text
Esta é uma métrica de defeitos; pode apoiar decisões sobre qualidade, mas não é a métrica de qualidade do produto pedida nesta classificação.
```

### o3 — alternativa EN

Original

```text
Number of high-priority defects that remain open.
```

Proposto atual — sem alteração

```text
Number of high-priority defects that remain open.
```

### o3 — explicação EN

Original

```text
This is a defect metric; it can inform quality decisions but is not the product quality metric requested in this classification.
```

Proposto atual — sem alteração

```text
This is a defect metric; it can inform quality decisions but is not the product quality metric requested in this classification.
```

### o4 — alternativa PT

Original

```text
Percentagem de requisitos de empréstimo especificados cobertos por testes.
```

Proposto atual — sem alteração

```text
Percentagem de requisitos de empréstimo especificados cobertos por testes.
```

### o4 — explicação PT

Original

```text
Esta é uma métrica de cobertura, não uma medição direta de uma característica de qualidade do produto.
```

Proposto atual — sem alteração

```text
Esta é uma métrica de cobertura, não uma medição direta de uma característica de qualidade do produto.
```

### o4 — alternativa EN

Original

```text
Percentage of specified lending requirements covered by tests.
```

Proposto atual — sem alteração

```text
Percentage of specified lending requirements covered by tests.
```

### o4 — explicação EN

Original

```text
This is a coverage metric, not a direct measurement of a product quality characteristic.
```

Proposto atual — sem alteração

```text
This is a coverage metric, not a direct measurement of a product quality characteristic.
```

### Explicação geral PT

Original

```text
O syllabus distingue categorias de métricas. As métricas de progresso, defeitos e cobertura são úteis, mas o tempo de resposta mede diretamente uma característica de qualidade do produto.
```

Proposto atual — sem alteração

```text
O syllabus distingue categorias de métricas. As métricas de progresso, defeitos e cobertura são úteis, mas o tempo de resposta mede diretamente uma característica de qualidade do produto.
```

### Explicação geral EN

Original

```text
The syllabus distinguishes categories of metrics. Progress, defect and coverage metrics are valuable, but response time directly measures a product quality characteristic.
```

Proposto atual — sem alteração

```text
The syllabus distinguishes categories of metrics. Progress, defect and coverage metrics are valuable, but response time directly measures a product quality characteristic.
```

## Avaliação das quatro alternativas

### o1 — distrator

O número de casos planeados executados é progresso de execução; a justificação curta identifica a categoria correta sem alegar uma medição de qualidade.

Executed planned test cases describe test execution progress. Their count alone is not a direct measurement of a product quality characteristic such as response time.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: o tempo de resposta observado mede desempenho do produto, sem concluir que cumpre algum limiar ou que o produto está aprovado.

Measured service response time quantifies performance of the product and is a product quality metric. No threshold compliance or quality guarantee is implied by merely reporting the measured value.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Defeitos abertos de prioridade elevada continuam métricas de defeitos; podem informar qualidade, mas prioridade não se confunde com severidade.

Open high-priority defects are classified as defect metrics. Priority concerns urgency of addressing them and must not silently be substituted with severity or measured performance.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Requisitos especificados cobertos são uma métrica de cobertura; a justificação não confunde a existência de testes com satisfazer esses requisitos.

The proportion of specified requirements covered by tests is a coverage metric. Coverage provides useful evidence but does not directly measure the product response time or guarantee satisfaction.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |
| 2026-10-27.5 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |
| 2026-10-27.6 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |
| 2026-10-27.7 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |
| 2026-10-27.8 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |
| 2026-10-27.9 | True     | 1      | ['o2'] | 04d5337e7a0c9cbda71d8fad168ff53d7e5a5f11259545d65ead77703093a0b1 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-066 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.3.3 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Há duas necessidades explícitas: visibilidade rápida de bloqueios em fusos diferentes e síntese semanal de riscos para direção. Dashboard atualizado com notificações assíncronas e resumo adaptado satisfaz ambas. A ausência de regulamento impondo um formato deixa escolher canais segundo público e contexto.

Raciocínio guardado antes da revelação:

Os públicos têm necessidades e cadências diferentes. O dashboard atualizado e os alertas assíncronos disponibilizam bloqueios entre fusos horários; o resumo semanal sintetiza riscos para a direção. A ausência de um formato imposto permite adaptar os canais.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 5.3.3: EN páginas [55]; PT páginas [61].
- Secção 5.3.2: EN páginas [54, 55]; PT páginas [60, 61].

- LO FL-5.3.3/K2: EN página 47; PT página 52.

EN secção 5.3.3 e PT correspondente estão nas páginas 55 e 61. Na secção de apoio 5.3.2, EN refere a equipa de teste e PT o gestor na produção de relatórios; essa diferença de edição não determina a opção aqui, que trata público e canais, não exclusividade de um papel.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Rapid/rápida não é instantânea. Across time zones/em diferentes fusos horários, weekly/semanal e sole/único mantêm cadência, distribuição e exclusividade. Up-to-date/atualizado é premissa necessária para o dashboard funcionar. Release risks/riscos da entrega é coerente no contexto de gestão, sem tornar todas as comunicações necessariamente formais.

| EN literal                         | PT literal                            |
| ---------------------------------- | ------------------------------------- |
| across time zones                  | em diferentes fusos horários          |
| weekly summary                     | resumo semanal                        |
| asynchronous blocker notifications | notificações assíncronas de bloqueios |

## Contraevidência e outras respostas defensáveis

Chamadas podem complementar canais assíncronos, mas como único registo sem informação retida não respondem ao cenário. Um log bruto pode ajudar analistas, mas não fornece por si a síntese pedida. Notificações assíncronas não garantem leitura instantânea; o cenário pede melhor adequação, não um SLA absoluto inventado.

## LO, nível K, explicações e dificuldade

K2: exemplificar adaptação de canais e detalhe a stakeholders distintos e contrastar velocidade operacional com cadência de gestão. Não é preciso conhecer uma ferramenta específica. As quatro justificações e a explicação geral deixam claro que canais se podem combinar e que dashboard não substitui síntese de riscos para o destinatário.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa distribuída precisa de visibilidade rápida dos testes bloqueados em diferentes fusos horários. Um grupo de direção precisa de um resumo semanal dos riscos da entrega. Nenhum regulamento impõe um único formato de comunicação. Que organização da comunicação melhor satisfaz estas necessidades?
```

Proposto atual — sem alteração

```text
Uma equipa distribuída precisa de visibilidade rápida dos testes bloqueados em diferentes fusos horários. Um grupo de direção precisa de um resumo semanal dos riscos da entrega. Nenhum regulamento impõe um único formato de comunicação. Que organização da comunicação melhor satisfaz estas necessidades?
```

### Enunciado EN

Original

```text
A distributed team needs rapid visibility of blocked tests across time zones. A steering group needs a weekly summary of release risks. No regulation mandates a single communication format. Which communication arrangement best suits these needs?
```

Proposto atual — sem alteração

```text
A distributed team needs rapid visibility of blocked tests across time zones. A steering group needs a weekly summary of release risks. No regulation mandates a single communication format. Which communication arrangement best suits these needs?
```

### o1 — alternativa PT

Original

```text
Enviar o resumo semanal da direção a todos e usá-lo como única notificação de bloqueios da equipa.
```

Proposto atual — sem alteração

```text
Enviar o resumo semanal da direção a todos e usá-lo como única notificação de bloqueios da equipa.
```

### o1 — explicação PT

Original

```text
Um resumo semanal é demasiado pouco frequente para a necessidade indicada de visibilidade rápida dos bloqueios da equipa.
```

Proposto atual — sem alteração

```text
Um resumo semanal é demasiado pouco frequente para a necessidade indicada de visibilidade rápida dos bloqueios da equipa.
```

### o1 — alternativa EN

Original

```text
Send the weekly steering summary to everyone and use it as the team's only blocker notification.
```

Proposto atual — sem alteração

```text
Send the weekly steering summary to everyone and use it as the team's only blocker notification.
```

### o1 — explicação EN

Original

```text
A weekly summary is too infrequent for the team's stated need for rapid visibility of blockers.
```

Proposto atual — sem alteração

```text
A weekly summary is too infrequent for the team's stated need for rapid visibility of blockers.
```

### o2 — alternativa PT

Original

```text
Usar uma chamada diária em direto como único registo para ambos os públicos, sem conservar informação de estado.
```

Proposto atual — sem alteração

```text
Usar uma chamada diária em direto como único registo para ambos os públicos, sem conservar informação de estado.
```

### o2 — explicação PT

Original

```text
Um único canal em direto não responde às necessidades indicadas de fusos horários nem fornece o resumo semanal de riscos adaptado ao público.
```

Proposto atual — sem alteração

```text
Um único canal em direto não responde às necessidades indicadas de fusos horários nem fornece o resumo semanal de riscos adaptado ao público.
```

### o2 — alternativa EN

Original

```text
Use a daily live call as the sole record for both audiences, without retaining status information.
```

Proposto atual — sem alteração

```text
Use a daily live call as the sole record for both audiences, without retaining status information.
```

### o2 — explicação EN

Original

```text
A sole live channel does not accommodate the stated time-zone needs or provide the tailored weekly risk summary.
```

Proposto atual — sem alteração

```text
A sole live channel does not accommodate the stated time-zone needs or provide the tailored weekly risk summary.
```

### o3 — alternativa PT

Original

```text
Fornecer ao grupo de direção o registo de execução sem tratamento e pedir-lhe que derive os riscos da entrega de forma independente.
```

Proposto atual — sem alteração

```text
Fornecer ao grupo de direção o registo de execução sem tratamento e pedir-lhe que derive os riscos da entrega de forma independente.
```

### o3 — explicação PT

Original

```text
Um registo técnico sem tratamento não fornece o resumo de riscos pedido e adequado ao público.
```

Proposto atual — sem alteração

```text
Um registo técnico sem tratamento não fornece o resumo de riscos pedido e adequado ao público.
```

### o3 — alternativa EN

Original

```text
Give the steering group the unfiltered execution log and ask it to derive release risks independently.
```

Proposto atual — sem alteração

```text
Give the steering group the unfiltered execution log and ask it to derive release risks independently.
```

### o3 — explicação EN

Original

```text
An unfiltered technical log does not provide the requested audience-appropriate risk summary.
```

Proposto atual — sem alteração

```text
An unfiltered technical log does not provide the requested audience-appropriate risk summary.
```

### o4 — alternativa PT

Original

```text
Manter um dashboard partilhado atualizado com notificações assíncronas de bloqueios e fornecer um resumo semanal conciso de riscos ao grupo de direção.
```

Proposto atual — sem alteração

```text
Manter um dashboard partilhado atualizado com notificações assíncronas de bloqueios e fornecer um resumo semanal conciso de riscos ao grupo de direção.
```

### o4 — explicação PT

Original

```text
Stakeholders diferentes precisam de detalhe e frequência diferentes. Combinar canais apoia o trabalho distribuído e as decisões de gestão.
```

Proposto atual — sem alteração

```text
Stakeholders diferentes precisam de detalhe e frequência diferentes. Combinar canais apoia o trabalho distribuído e as decisões de gestão.
```

### o4 — alternativa EN

Original

```text
Maintain an up-to-date shared dashboard with asynchronous blocker notifications, and provide a concise weekly risk summary for the steering group.
```

Proposto atual — sem alteração

```text
Maintain an up-to-date shared dashboard with asynchronous blocker notifications, and provide a concise weekly risk summary for the steering group.
```

### o4 — explicação EN

Original

```text
Different stakeholders need different detail and frequency. Combining channels supports distributed teamwork and management decisions.
```

Proposto atual — sem alteração

```text
Different stakeholders need different detail and frequency. Combining channels supports distributed teamwork and management decisions.
```

### Explicação geral PT

Original

```text
A comunicação do estado do teste deve adequar-se ao público, à frequência e ao contexto organizacional. Pode usar-se mais de um canal; um dashboard não elimina a necessidade de um resumo adaptado à gestão.
```

Proposto atual — sem alteração

```text
A comunicação do estado do teste deve adequar-se ao público, à frequência e ao contexto organizacional. Pode usar-se mais de um canal; um dashboard não elimina a necessidade de um resumo adaptado à gestão.
```

### Explicação geral EN

Original

```text
Test status communication should fit the audience, timing and organizational context. More than one channel may be used; a dashboard does not remove the need for a tailored management summary.
```

Proposto atual — sem alteração

```text
Test status communication should fit the audience, timing and organizational context. More than one channel may be used; a dashboard does not remove the need for a tailored management summary.
```

## Avaliação das quatro alternativas

### o1 — distrator

O resumo semanal satisfaz a direção, mas como única notificação da equipa atrasa a visibilidade rápida dos bloqueios explicitamente necessária.

A weekly management summary may suit the steering group, but using it as the sole blocker notification delays the rapid operational visibility explicitly required by the distributed team.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Uma chamada pode ajudar, mas sendo único registo sem informação persistida não adapta acesso assíncrono nem síntese semanal entre fusos horários.

A daily live call can supplement communication, but as the sole record without retained status it is unsuitable for asynchronous access across time zones and for weekly management synthesis.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

O registo bruto não é o resumo conciso e adequado ao público de direção; exigir que esse público derive todos os riscos não satisfaz o pedido.

An unfiltered execution log does not provide the concise risk interpretation requested by the steering group. Delegating all synthesis to that audience fails to tailor the information.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — correta

Correta: combina visibilidade partilhada atualizada e notificações assíncronas com resumo semanal adaptado; não impõe um canal universal ou leitura instantânea.

A current shared dashboard and asynchronous notifications support timely cross-time-zone access, while a concise weekly risk summary targets the steering group. The combination follows the distinct needs without requiring one universal channel.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |
| 2026-10-27.5 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |
| 2026-10-27.6 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |
| 2026-10-27.7 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |
| 2026-10-27.8 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |
| 2026-10-27.9 | True     | 1      | ['o4'] | 828b81c10e4a580455535fcddd9a8e92b67df153dc5b1fc137832f7fca68cf5f |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-067 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.3.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

O cenário ilustra a falácia da ausência de defeitos: verificar os cálculos especificados não assegura que o fluxo necessário aos utilizadores esteja completo. Validar o fecho com eles e rever os requisitos acordados enfrenta a aprovação de negócio omitida. Não se infere causa raiz humana ou intenção que o enunciado não fornece.

Raciocínio guardado antes da revelação:

Cumprir todos os cálculos especificados não torna o produto útil quando o fluxo necessário aos utilizadores está incompleto. Validar o fecho mensal com eles e rever requisitos acordados responde à ausência de erros como falácia; as outras práticas não resolvem a omissão.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 1.3: EN páginas [17, 18]; PT páginas [19].

- LO FL-1.3.1/K2: EN página 14; PT página 15.

EN introduz os princípios na página 17 e descreve a falácia na página 18. PT apresenta os sete princípios na página 19. Ambos distinguem verificação de validação das necessidades; a formulação e paginação são diferentes, não assumidas idênticas. A aprovação omitida é premissa do exemplo, não uma regra salarial oficial inventada.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Every specified calculation/todos os cálculos especificados limita o sucesso ao que foi especificado, não a todas as necessidades. Necessary approval step/uma aprovação necessária é uma etapa do fluxo salarial, não aceite académico. Revise the agreed requirements/rever os requisitos acordados conserva a necessidade de clarificação partilhada.

| EN literal                     | PT literal                      |
| ------------------------------ | ------------------------------- |
| every specified calculation    | todos os cálculos especificados |
| necessary approval step        | uma aprovação necessária        |
| revise the agreed requirements | rever os requisitos acordados   |

## Contraevidência e outras respostas defensáveis

Regressão, priorização por agrupamento e dados novos são práticas legítimas noutros contextos, mas não resolvem a necessidade de aprovação ausente neste. Rever requisitos acordados implica colaboração e autorizações de negócio aplicáveis; não é permissão para modificar unilateralmente o sistema ou dispensar aprovação necessária.

## LO, nível K, explicações e dificuldade

K2: explicar qual princípio é evidenciado por cálculos corretos mas workflow inadequado, e distinguir alternativas ligadas a regressão, concentração e desgaste dos testes. As explicações não negam utilidade dessas práticas; apenas mostram por que não atacam o problema documentado. Não são precisos conhecimentos de legislação salarial.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma aplicação de substituição de processamento salarial passa os testes de todos os cálculos especificados. Num piloto, os trabalhadores não conseguem concluir o fecho mensal porque uma aprovação necessária não foi especificada. Que resposta melhor aplica o princípio de teste ilustrado?
```

Proposto atual — sem alteração

```text
Uma aplicação de substituição de processamento salarial passa os testes de todos os cálculos especificados. Num piloto, os trabalhadores não conseguem concluir o fecho mensal porque uma aprovação necessária não foi especificada. Que resposta melhor aplica o princípio de teste ilustrado?
```

### Enunciado EN

Original

```text
A payroll replacement passes the tests for every specified calculation. During a pilot, clerks cannot complete the month-end workflow because a necessary approval step was not specified. Which response best addresses the testing principle illustrated?
```

Proposto atual — sem alteração

```text
A payroll replacement passes the tests for every specified calculation. During a pilot, clerks cannot complete the month-end workflow because a necessary approval step was not specified. Which response best addresses the testing principle illustrated?
```

### o1 — alternativa PT

Original

```text
Expandir a regressão dos cálculos para aumentar a confiança nas regras já especificadas.
```

Proposto atual — sem alteração

```text
Expandir a regressão dos cálculos para aumentar a confiança nas regras já especificadas.
```

### o1 — explicação PT

Original

```text
Isto reforça a verificação, mas não trata o fluxo de utilização em falta.
```

Proposto atual — sem alteração

```text
Isto reforça a verificação, mas não trata o fluxo de utilização em falta.
```

### o1 — alternativa EN

Original

```text
Expand calculation regression tests to increase confidence in the already specified rules.
```

Proposto atual — sem alteração

```text
Expand calculation regression tests to increase confidence in the already specified rules.
```

### o1 — explicação EN

Original

```text
This strengthens verification but does not address the missing user workflow.
```

Proposto atual — sem alteração

```text
This strengthens verification but does not address the missing user workflow.
```

### o2 — alternativa PT

Original

```text
Validar o fluxo completo de fecho mensal com os utilizadores e rever os requisitos acordados.
```

Proposto atual — sem alteração

```text
Validar o fluxo completo de fecho mensal com os utilizadores e rever os requisitos acordados.
```

### o2 — explicação PT

Original

```text
A falácia da ausência de defeitos diz respeito a cumprir especificações sem satisfazer as necessidades reais dos utilizadores.
```

Proposto atual — sem alteração

```text
A falácia da ausência de defeitos diz respeito a cumprir especificações sem satisfazer as necessidades reais dos utilizadores.
```

### o2 — alternativa EN

Original

```text
Validate the complete month-end workflow with users and revise the agreed requirements.
```

Proposto atual — sem alteração

```text
Validate the complete month-end workflow with users and revise the agreed requirements.
```

### o2 — explicação EN

Original

```text
The absence-of-defects fallacy concerns satisfying specifications without satisfying actual user needs.
```

Proposto atual — sem alteração

```text
The absence-of-defects fallacy concerns satisfying specifications without satisfying actual user needs.
```

### o3 — alternativa PT

Original

```text
Concentrar os testes nos módulos de cálculo com mais defeitos históricos.
```

Proposto atual — sem alteração

```text
Concentrar os testes nos módulos de cálculo com mais defeitos históricos.
```

### o3 — explicação PT

Original

```text
A concentração de defeitos pode orientar o esforço, mas o problema observado é comportamento de negócio em falta.
```

Proposto atual — sem alteração

```text
A concentração de defeitos pode orientar o esforço, mas o problema observado é comportamento de negócio em falta.
```

### o3 — alternativa EN

Original

```text
Concentrate testing on the calculation modules with the most historical defects.
```

Proposto atual — sem alteração

```text
Concentrate testing on the calculation modules with the most historical defects.
```

### o3 — explicação EN

Original

```text
Defect clustering can guide effort, but the observed problem is missing business behaviour.
```

Proposto atual — sem alteração

```text
Defect clustering can guide effort, but the observed problem is missing business behaviour.
```

### o4 — alternativa PT

Original

```text
Renovar os dados de teste dos cálculos para contrariar a menor eficácia de testes repetidos.
```

Proposto atual — sem alteração

```text
Renovar os dados de teste dos cálculos para contrariar a menor eficácia de testes repetidos.
```

### o4 — explicação PT

Original

```text
O desgaste dos testes é um princípio diferente; mudar os dados dos cálculos não estabelece a adequação do fluxo.
```

Proposto atual — sem alteração

```text
O desgaste dos testes é um princípio diferente; mudar os dados dos cálculos não estabelece a adequação do fluxo.
```

### o4 — alternativa EN

Original

```text
Refresh the calculation test data to counter the declining effectiveness of repeated tests.
```

Proposto atual — sem alteração

```text
Refresh the calculation test data to counter the declining effectiveness of repeated tests.
```

### o4 — explicação EN

Original

```text
Tests wearing out is a different principle; changing calculation data does not establish workflow suitability.
```

Proposto atual — sem alteração

```text
Tests wearing out is a different principle; changing calculation data does not establish workflow suitability.
```

### Explicação geral PT

Original

```text
A verificação de regras especificadas precisa de validação complementar dos objetivos dos utilizadores. Um piloto bem-sucedido exige compreender a aprovação em falta, não apenas mais verificações de cálculos aprovadas.
```

Proposto atual — sem alteração

```text
A verificação de regras especificadas precisa de validação complementar dos objetivos dos utilizadores. Um piloto bem-sucedido exige compreender a aprovação em falta, não apenas mais verificações de cálculos aprovadas.
```

### Explicação geral EN

Original

```text
Verification of specified rules needs complementary validation of users' goals. A successful pilot requires the missing approval need to be understood, not merely more passing calculation checks.
```

Proposto atual — sem alteração

```text
Verification of specified rules needs complementary validation of users' goals. A successful pilot requires the missing approval need to be understood, not merely more passing calculation checks.
```

## Avaliação das quatro alternativas

### o1 — distrator

Mais regressão dos cálculos pode apoiar verificação, mas não descobre nem acorda a etapa de aprovação necessária ao fluxo de fecho mensal.

More calculation regression can increase confidence in already specified arithmetic, but it does not discover or agree the missing approval step that prevents the month-end workflow.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: validar o fluxo com os utilizadores e rever requisitos trata a necessidade omitida; não autoriza ignorar a aprovação de negócio necessária.

End-to-end validation with users tests whether the product meets actual needs, and revising agreed requirements addresses the omitted approval. Passing specified calculations alone is insufficient for usefulness.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

A concentração de defeitos pode orientar esforço, mas o problema descrito é comportamento de negócio em falta e não maior incidência histórica nos cálculos.

Focusing on defect-prone modules is a reasonable defect-clustering strategy in other circumstances, but historic calculation defect counts do not address the omitted workflow requirement described.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Dados renovados podem combater desgaste de testes, mas aqui não foi demonstrado desgaste: o impedimento resulta da etapa necessária não especificada.

Refreshing test data can address declining effectiveness of repetitive tests, but the demonstrated cause is a missing required workflow step, not evidence that old calculation data have worn out.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o2'] | b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd |
| 2026-10-27.7 | True     | 1      | ['o2'] | b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd |
| 2026-10-27.8 | True     | 1      | ['o2'] | b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd |
| 2026-10-27.9 | True     | 1      | ['o2'] | b863e4bc774a4f8b5c67071744ef6c1d12852b539ffab602cd902b33cd2efcdd |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


# tl-068 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.2 / K1; versão 1; revisão 2026-10-27.10; SHA-256 canónico `40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24`.

Resposta pré-gabarito: `['o1']`; registada em `2026-11-07T23:11:48.676374+00:00`. Chave consultada depois: `['o1']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Iniciar análise quando está disponível o produto de trabalho correspondente e participar na revisão dos esboços são boas práticas transversais aos modelos. A especificação inicial permite análise e revisão sem esperar código executável. A correspondência entre atividades não torna iguais os objetivos dos níveis de teste.

Raciocínio guardado antes da revelação:

A análise pode começar quando a versão inicial do produto de trabalho está disponível, sem esperar pela conclusão do código. Esta prática aplica-se a diferentes modelos, com adaptação do momento concreto; níveis distintos mantêm objetivos próprios.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 2.1.2: EN páginas [25, 26]; PT páginas [27, 28].

- LO FL-2.1.2/K1: EN página 24; PT página 26.

A secção 2.1.2 começa em EN página 25 e continua na página 26; em PT começa na página 27 e desenvolve a lista na página 28. Em ambas estão análise/conceção na fase correspondente e envolvimento em esboços. A localização foi conferida por página, sem aplicar um deslocamento uniforme ao PDF.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web; referências e páginas conferidas nas cópias oficiais locais identificadas. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Early draft/versão inicial e becomes available/estiver disponível mantêm disponibilidade de material ainda incompleto. Across software development lifecycles/a diferentes ciclos de vida expressa aplicabilidade transversal, sem restringir a um modelo. Corresponding/correspondente não significa que cada teste dinâmico possa executar sem código nem que objetivos de componentes e aceitação coincidam.

| EN literal                             | PT literal                                            |
| -------------------------------------- | ----------------------------------------------------- |
| early draft                            | versão inicial                                        |
| becomes available                      | estiver disponível                                    |
| corresponding development work product | produto de trabalho de desenvolvimento correspondente |

## Contraevidência e outras respostas defensáveis

Pode haver condicionantes que limitem recursos ou datas concretas; o item pergunta uma boa prática aplicável, não garante início imediato ao segundo. A sequência de testes dinâmicos pode influenciar execução, mas não obriga a adiar revisão estática. Objetivos específicos podem partilhar preocupações sem serem idênticos.

## LO, nível K, explicações e dificuldade

K1: reconhecer as boas práticas enumeradas na secção 2.1.2. A situação de um esboço de interface contextualiza a recordação, sem exigir desenho de uma estratégia K3. As explicações distinguem disponibilidade de produto de trabalho, análise antecipada, execução dinâmica e objetivos próprios de cada nível.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa escolhe práticas para rever uma versão inicial de uma nova especificação de interface. Que prática é aplicável a diferentes ciclos de vida de desenvolvimento de software?
```

Proposto atual — sem alteração

```text
Uma equipa escolhe práticas para rever uma versão inicial de uma nova especificação de interface. Que prática é aplicável a diferentes ciclos de vida de desenvolvimento de software?
```

### Enunciado EN

Original

```text
A team is selecting practices for reviewing an early draft of a new interface specification. Which practice is applicable across software development lifecycles?
```

Proposto atual — sem alteração

```text
A team is selecting practices for reviewing an early draft of a new interface specification. Which practice is applicable across software development lifecycles?
```

### o1 — alternativa PT

Original

```text
Iniciar a análise de teste quando o produto de trabalho de desenvolvimento correspondente estiver disponível.
```

Proposto atual — sem alteração

```text
Iniciar a análise de teste quando o produto de trabalho de desenvolvimento correspondente estiver disponível.
```

### o1 — explicação PT

Original

```text
A análise antecipada e a participação nas versões iniciais dos produtos de trabalho são boas práticas independentes do modelo de ciclo de vida.
```

Proposto atual — sem alteração

```text
A análise antecipada e a participação nas versões iniciais dos produtos de trabalho são boas práticas independentes do modelo de ciclo de vida.
```

### o1 — alternativa EN

Original

```text
Start test analysis when the corresponding development work product becomes available.
```

Proposto atual — sem alteração

```text
Start test analysis when the corresponding development work product becomes available.
```

### o1 — explicação EN

Original

```text
Early analysis and involvement in draft work products are good practices independent of the lifecycle model.
```

Proposto atual — sem alteração

```text
Early analysis and involvement in draft work products are good practices independent of the lifecycle model.
```

### o2 — alternativa PT

Original

```text
Usar os mesmos objetivos no teste de componentes e no teste de aceitação.
```

Proposto atual — sem alteração

```text
Usar os mesmos objetivos no teste de componentes e no teste de aceitação.
```

### o2 — explicação PT

Original

```text
Os níveis de teste diferentes têm objetivos específicos, ajudando a evitar atividades redundantes.
```

Proposto atual — sem alteração

```text
Os níveis de teste diferentes têm objetivos específicos, ajudando a evitar atividades redundantes.
```

### o2 — alternativa EN

Original

```text
Use the same test objectives for component testing and acceptance testing.
```

Proposto atual — sem alteração

```text
Use the same test objectives for component testing and acceptance testing.
```

### o2 — explicação EN

Original

```text
Different test levels have specific objectives, helping avoid redundant activities.
```

Proposto atual — sem alteração

```text
Different test levels have specific objectives, helping avoid redundant activities.
```

### o3 — alternativa PT

Original

```text
Basear a calendarização da revisão na conclusão do código em vez da disponibilidade da versão inicial.
```

Proposto atual — sem alteração

```text
Basear a calendarização da revisão na conclusão do código em vez da disponibilidade da versão inicial.
```

### o3 — explicação PT

Original

```text
Esperar pela conclusão do código perde a vantagem de rever a especificação quando fica disponível.
```

Proposto atual — sem alteração

```text
Esperar pela conclusão do código perde a vantagem de rever a especificação quando fica disponível.
```

### o3 — alternativa EN

Original

```text
Base review timing on completion of coding rather than availability of the draft.
```

Proposto atual — sem alteração

```text
Base review timing on completion of coding rather than availability of the draft.
```

### o3 — explicação EN

Original

```text
Waiting for coding loses the benefit of reviewing the specification when it is first available.
```

Proposto atual — sem alteração

```text
Waiting for coding loses the benefit of reviewing the specification when it is first available.
```

### o4 — alternativa PT

Original

```text
Aplicar a sequência de testes dinâmicos do ciclo de vida como calendário das revisões da especificação.
```

Proposto atual — sem alteração

```text
Aplicar a sequência de testes dinâmicos do ciclo de vida como calendário das revisões da especificação.
```

### o4 — explicação PT

Original

```text
As revisões estáticas podem começar com versões iniciais; a sua calendarização não precisa de seguir a disponibilidade de software executável.
```

Proposto atual — sem alteração

```text
As revisões estáticas podem começar com versões iniciais; a sua calendarização não precisa de seguir a disponibilidade de software executável.
```

### o4 — alternativa EN

Original

```text
Apply the lifecycle's dynamic test sequence as the schedule for specification reviews.
```

Proposto atual — sem alteração

```text
Apply the lifecycle's dynamic test sequence as the schedule for specification reviews.
```

### o4 — explicação EN

Original

```text
Static reviews can begin with drafts; their timing need not follow availability of executable software.
```

Proposto atual — sem alteração

```text
Static reviews can begin with drafts; their timing need not follow availability of executable software.
```

### Explicação geral PT

Original

```text
Uma atividade de teste correspondente apoia cada atividade de desenvolvimento. A análise antecipada e a revisão de versões iniciais aplicam-se a diferentes ciclos de vida, mantendo cada nível os seus objetivos.
```

Proposto atual — sem alteração

```text
Uma atividade de teste correspondente apoia cada atividade de desenvolvimento. A análise antecipada e a revisão de versões iniciais aplicam-se a diferentes ciclos de vida, mantendo cada nível os seus objetivos.
```

### Explicação geral EN

Original

```text
A corresponding test activity supports each development activity. Early analysis and review of drafts apply across lifecycles while each test level retains its own objectives.
```

Proposto atual — sem alteração

```text
A corresponding test activity supports each development activity. Early analysis and review of drafts apply across lifecycles while each test level retains its own objectives.
```

## Avaliação das quatro alternativas

### o1 — correta

Correta: a disponibilidade da versão inicial permite análise e revisão antecipadas, sem depender da conclusão de código executável ou de um modelo único.

Starting analysis when the corresponding development work product is available supports early feedback across lifecycles. A draft specification is enough to start relevant analysis without waiting for executable code.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Os níveis de componentes e aceitação têm objetivos específicos e distintos; partilhar algumas preocupações não torna apropriado usar objetivos idênticos.

Component and acceptance testing address different objectives. Reusing identical objectives across these levels is not a general good practice, regardless of lifecycle.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Esperar pela conclusão do código perde a oportunidade de feedback sobre a especificação disponível; não é condição para revisão estática inicial.

Waiting for coding completion unnecessarily postpones analysis and review of a draft that is already available. Dynamic test readiness is not a prerequisite for analysing the specification.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

O calendário da execução dinâmica não determina o início de revisões de especificações; estas podem analisar esboços sem software executável.

The sequence of dynamic test execution does not determine when specification reviews should occur. Static analysis and reviews can use the available draft before executable components exist.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão      | Presente | Versão | Chave  | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —      | —                                                                |
| 2026-10-27.2 | False    | —      | —      | —                                                                |
| 2026-10-27.3 | False    | —      | —      | —                                                                |
| 2026-10-27.4 | False    | —      | —      | —                                                                |
| 2026-10-27.5 | False    | —      | —      | —                                                                |
| 2026-10-27.6 | True     | 1      | ['o1'] | 40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24 |
| 2026-10-27.7 | True     | 1      | ['o1'] | 40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24 |
| 2026-10-27.8 | True     | 1      | ['o1'] | 40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24 |
| 2026-10-27.9 | True     | 1      | ['o1'] | 40e52ec609896625603d9d5c38ee2b6209bf71634816e531033192d9207cee24 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 14; aguardar auditoria antes de Lote 15.


