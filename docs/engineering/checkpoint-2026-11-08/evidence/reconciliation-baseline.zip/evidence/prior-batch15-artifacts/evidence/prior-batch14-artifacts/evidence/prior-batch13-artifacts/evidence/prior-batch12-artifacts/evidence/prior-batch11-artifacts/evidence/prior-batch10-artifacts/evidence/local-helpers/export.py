"""Explicit allowlist export; no repository writes, no Git mutations or network."""
from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,sys,zipfile,tempfile,datetime,re
p=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch10-2026-11-06'
read=lambda n:json.loads(Path(n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda q:sha(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode()
pre=read(p/'preflight.json');proof=read(p/'integrity-result.json');bank=read(p/'runtime-before.json')['bank']
def snapshot():
 names=[n for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0') if n]
 return {'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain=v1','-uall'),'files':{n:sha((root/n).read_bytes()) for n in names}}
before=snapshot();assert before['head']==pre['head'] and before['branch']=='develop' and all(before['files'][n]==h for n,h in pre['existingFilesSHA256'].items())
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
new={n for n in before['files'] if n.startswith(folder+'/')};assert len(new)==11 and set(before['files'])==set(pre['existingFilesSHA256'])|new
assert proof['existingFilesByteIdentical']==303 and proof['result']=='PASS'
work=Path(tempfile.mkdtemp(prefix='TestLearn-Batch10-review-'));stage=work/'package';stage.mkdir();provenance={}
def safe(n):
 a=PurePosixPath(n);assert not a.is_absolute() and '..' not in a.parts and '\\' not in n and ':' not in n and a.as_posix()==n
 assert not set(a.parts)&{'.git','node_modules','dist','test-results','__pycache__'} and not a.name.startswith('.env')
 return n
def put(n,b,source):
 safe(n);target=stage/n;assert n not in provenance;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);assert target.read_bytes()==b;provenance[n]=source
def jput(n,d,source):put(n,(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),source)
archive=Path('C:/Users/gabri/Downloads')/pre['priorPackageName'];assert sha(archive.read_bytes())==pre['priorPackageSHA256']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 manifest=readme=None;manifest=json.loads(z.read('MANIFEST.json'));oldRefs={e['relativePath'] for e in manifest['files'] if e['provenance'].get('kind')=='exact repository bytes'};assert len(oldRefs)==138
 selected=oldRefs|new
 for n in sorted(selected):
  safe(n);assert not (root/n).is_symlink();b=(root/n).read_bytes()
  if n in oldRefs:assert b==z.read(n)
  put(n,b,{'kind':'exact repository bytes','baseCommit':pre['head'],'newDuringBatch10':n in new,'preflightSHA256':pre['existingFilesSHA256'].get(n)})
 index={sha((stage/n).read_bytes()):n for n in sorted(provenance)};mapping=[]
 for n in z.namelist():
  safe(n);b=z.read(n);h=sha(b);destination=n if n in oldRefs else index.get(h)
  if destination is None:
   destination='evidence/prior-batch9-artifacts/'+n;put(destination,b,{'kind':'exact historical final Batch9 ZIP bytes, not a fresh Batch10 execution','previousRelativePath':n,'previousPackageSHA256':pre['priorPackageSHA256']});index[h]=destination
  assert (stage/destination).read_bytes()==b
  mapping.append({'previousRelativePath':n,'currentRelativePath':destination,'sizeBytes':len(b),'sha256':h,'kind':'preserved_repository_reference' if n in oldRefs else 'historical_content_mapped_by_hash'})
assert len(mapping)==219
jput('EXPORT-CONTINUITY.json',{'previousPackageName':pre['priorPackageName'],'previousPackageSHA256':pre['priorPackageSHA256'],'previousFileCount':219,'priorManifestPath':next(e['currentRelativePath'] for e in mapping if e['previousRelativePath']=='MANIFEST.json'),'repositoryReferenceFilesPreserved':138,'omittedFiles':[],'files':mapping},{'kind':'all219 previous members mapped with exact bytes; identical historical payloads shared without unnecessary copies'})
for mode in ['targeted-vitest','multiple-answer-scoring','format-check','diff-check']:
 meta=read(p/(mode+'-result.json'));assert meta['exitCode']==0
 for suffix in ['.log','-result.json']:put('evidence/checks/'+mode+suffix,(p/(mode+suffix)).read_bytes(),{'kind':'fresh Batch10 check','command':meta['command'],'startedAt':meta['startedAt'],'completedAt':meta['completedAt'],'exitCode':0})
for name in ['batch10-specific-result.json','batch10-specific-execution.json','integrity-execution.json']:put('evidence/checks/'+name,(p/name).read_bytes(),{'kind':'fresh Batch10 execution metadata and evidence checks'})
for name in ['preflight.json','integrity-result.json','blind-projection.json','blind-solution.json','key-reveal.json','helper-observations.json']:put('evidence/'+name,(p/name).read_bytes(),{'kind':'fresh Batch10 evidence; full baseline, timing and explicit limitations'})
for name in ['VERIFY-PACKAGE.py','BATCH10-RULES.py']:put(name,(p/name).read_bytes(),{'kind':'inspected portable read-only Python standard-library verifier'})
for name in ['verify.py','record-blind.py','check-multiple-answer.cjs','read-evidence.py','focus-evidence.py','export.py']:put('evidence/local-helpers/'+name,(p/name).read_bytes(),{'kind':'actual local execution helper; requires original workspace/PDF tools, not portable entrypoint'})
jput('review-data/current-bank.json',bank,{'kind':'actual complete90 question bank, no student data; preflight snapshot re-evaluated equal by fresh check'})
jput('BANK-PRESERVATION.json',{'contentRevision':'2026-10-27.10','baseCommit':pre['head'],'questions':[{'id':q['id'],'beforeCanonicalSHA256':canonical(q),'afterCanonicalSHA256':canonical(q),'beforeKey':q['correct'],'afterKey':q['correct'],'beforeVersion':q['version'],'afterVersion':q['version']} for q in bank]},{'kind':'all90 objects equality established by fresh runtime comparison'})
jput('GIT-CHANGE-INVENTORY.json',{'branch':before['branch'],'head':before['head'],'initialStatus':pre['status'],'fullInitialStatus':pre['fullGitStatus'],'finalStatus':before['status'],'existingFilesChanged':[],'preservedPendingDocuments':pre['existingUncommittedDocuments'],'newFiles':[{'relativePath':n,'sizeBytes':(root/n).stat().st_size,'sha256':sha((root/n).read_bytes())} for n in sorted(new)],'stagedFiles':[],'commitsCreated':False,'remoteGitOperations':False,'newOwnerAcceptances':0,'newHumanApprovals':0},{'kind':'fresh complete Git inventory with303 prior files,89 pending and11 new documents'})
summary=(root/folder/'README.md').read_text(encoding='utf8')+'\n\n'+(root/folder/'tl-062.md').read_text(encoding='utf8')
put('ACADEMIC-REVIEW-SUMMARY.md',summary.encode(),{'kind':'executive README and complete verbatim bilingual report;40 actual unchanged and2 optional text blocks'})
instructions=(root/folder/'README.md').read_text(encoding='utf8')+'''

## Portable read-only verification

Inspect top-level VERIFY-PACKAGE.py and BATCH10-RULES.py, then run `python -B VERIFY-PACKAGE.py` after clean extraction using Python 3.9+ standard library. Do not use -O. No network or writes are performed by those two portable files. Historical verifier copies are evidence only, not standalone nested packages. Local helpers under evidence require the original full checkout; do not treat them as portable entrypoints.

EXPORT-CONTINUITY.json maps all 219 members of the final Batch 9 package. Identical byte payloads may share a destination. All 138 prior repository-reference files remain at repository-relative paths. MANIFEST.json records all other files with size, SHA-256 and provenance, excluding itself to avoid recursion. The external whole-ZIP SHA covers the manifest. Hashes establish consistency, not authenticity signatures or academic truth. No full copyrighted syllabus PDFs or real student data are included.

Fresh commands and exit codes are under evidence/checks. Legacy --phase10h-batch2 was not executed in Batch 10. Only documentation was added; full build/typecheck/lint/E2E were not repeated. The current-runtime exact-set check is not a full TypeScript check. This scoped evidence archive is not a complete executable repository. Phase 10H remains OPEN; no new owner acceptance or human approval, no Batch 11.
'''
put('README.md',instructions.encode(),{'kind':'portable package instructions, scope and explicit limits'})
for n in provenance:
 b=(stage/n).read_bytes();assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}',b),n
manifest={'schemaVersion':1,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Phase10H Batch10 only with exact historical continuity','baseCommit':pre['head'],'manifestSelfHash':'Self excluded to avoid circular hash; external ZIP hash covers manifest','files':[{'relativePath':n,'sizeBytes':(stage/n).stat().st_size,'sha256':sha((stage/n).read_bytes()),'provenance':provenance[n]} for n in sorted(provenance)]}
(stage/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def verify(path):
 r=subprocess.run([sys.executable,'-B',str(path/'VERIFY-PACKAGE.py')],capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;return json.loads(r.stdout)
initial=verify(stage)
probe=stage/folder/'exact-comparisons.json';saved=probe.read_bytes();probe.write_bytes(saved+b' ')
r=subprocess.run([sys.executable,'-B',str(stage/'VERIFY-PACKAGE.py')],capture_output=True,text=True);assert r.returncode!=0;probe.write_bytes(saved)
missing=stage/'evidence/checks/diff-check.log';saved=missing.read_bytes();missing.unlink()
r=subprocess.run([sys.executable,'-B',str(stage/'VERIFY-PACKAGE.py')],capture_output=True,text=True);assert r.returncode!=0;missing.write_bytes(saved)
mp=stage/'MANIFEST.json';saved=mp.read_bytes();bad=json.loads(saved);bad['files'][0]['relativePath']='../unsafe';mp.write_text(json.dumps(bad))
r=subprocess.run([sys.executable,'-B',str(stage/'VERIFY-PACKAGE.py')],capture_output=True,text=True);assert r.returncode!=0;mp.write_bytes(saved)
# Also reject a false hash; all probes touch only disposable package copies.
bad=json.loads(saved);bad['files'][0]['sha256']='0'*64;mp.write_text(json.dumps(bad));r=subprocess.run([sys.executable,'-B',str(stage/'VERIFY-PACKAGE.py')],capture_output=True,text=True);assert r.returncode!=0;mp.write_bytes(saved)
assert verify(stage)==initial
downloads=Path('C:/Users/gabri/Downloads');base='TestLearn-Phase10H-Batch10-Academic-Review-20261106';zipPath=downloads/(base+'.zip');i=0
while zipPath.exists():i+=1;zipPath=downloads/(base+'-'+datetime.datetime.now().strftime('%H%M%S')+'-'+str(i)+'.zip')
expected=sorted(a.relative_to(stage).as_posix() for a in stage.rglob('*') if a.is_file())
with zipfile.ZipFile(zipPath,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in expected:z.write(stage/n,n)
extracted=work/'extracted-clean'
with zipfile.ZipFile(zipPath) as z:
 assert z.testzip() is None and sorted(z.namelist())==expected and len(set(z.namelist()))==len(expected)
 for n in z.namelist():safe(n);assert z.read(n)==(stage/n).read_bytes()
 z.extractall(extracted)
for n in expected:assert (extracted/n).read_bytes()==(stage/n).read_bytes()
final=verify(extracted);assert final==initial and snapshot()==before
result={'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':[sys.executable,str(p/'export.py')],'exitCode':0,'zipPath':str(zipPath),'sizeBytes':zipPath.stat().st_size,'fileCount':len(expected),'repositoryFiles':len(selected),'sha256':sha(zipPath.read_bytes()),'manifestHashes':'PASS','ZIPCRCIntegrity':'PASS','cleanExtraction':'PASS','portableVerifier':final,'tamperedPayloadRejected':True,'missingPayloadRejected':True,'unsafePathRejected':True,'falseHashRejected':True,'repositoryUnchangedByExport':True,'missingFiles':[],'stagingLocation':str(stage)}
(p/'export-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
