# Lote 13 — recuperação da falha de legibilidade

Estado atual: recuperação demonstrada. A falha histórica continua FAIL em STOP-FAILURE.json e verification.md. Estes documentos não foram reescritos.

## Diagnóstico e correção mínima

Causa A: erro de espaçamento no relatório novo tl-049. A expressão regular também é ampla: encontrou `ão1` dentro de `secção1.4.2`, mas o trecho realmente precisava de espaço. Existia igualmente `na20` no mesmo parágrafo. A falha foi reproduzida antes da correção com exit code 1; não era alteração ao banco.

Foram inseridos exatamente dois espaços: `continua na20;` → `continua na 20;` e `secção1.4.2 na p.21.` → `secção 1.4.2 na p.21.`. Secção e páginas foram mantidas e reconferidas nas cópias oficiais locais: EN v4.0.1, páginas físicas 19–20; PT v4.0 tradução 1.0, página física 21. Não houve alteração académica nem regeneração dos relatórios.

SHA-256 original: `e695590874cacf04c43fb70540374da4ebe29c3a0c4f994aa68e847a7b162a98`.

SHA-256 corrigido: `e91fd56b5237eddcc4ab62ba5966784ff248ba0b3776a95a9af73b52c05a4eb5`.

O relatório original está preservado em evidence/recovery/original/tl-049.md no pacote; o diff exato está em evidence/recovery/report-only.diff. Os 18 outros documentos iniciais do lote permanecem byte a byte idênticos. Os 352 ficheiros anteriores ao lote, incluindo 149 documentos académicos anteriores, permanecem preservados. Não se alega que todos os 19 documentos iniciais sejam idênticos.

## Demonstração e limites

O guard original e o global não foram modificados. O relatório preservado continua a falhar no guard completo; o corrigido passa e a remoção sintética do espaço em `secção 1.4.2` volta a falhar. Blocos literais do banco, soluções pré-gabarito, horários, decisões e expectativas não mudaram.

A alteração em tl-002 chega à proteção global: o guard do lote aceita esse controlo fora do seu âmbito e o global rejeita o banco adulterado. O guard específico rejeita a alteração em tl-048. Uma referência global igualmente adulterada é rejeitada. Resultados e hashes em evidence/recovery/red-green-routing.json.

Os oito pareceres académicos anteriores permanecem ACCEPT_AS_IS; a revisão cega não foi repetida. Não há OWNER_ACCEPTED ou HUMAN_APPROVED novo. Integridade técnica não é verdade académica nem revisão humana independente. A Fase 10H permanece aberta; não iniciar Lote 14.


# tl-048 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.2.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

O teste fornece evidência sobre qualidade e consequências possíveis da cobrança duplicada para apoiar a decisão dos stakeholders. Os outros resultados favoráveis só se aplicam às viagens testadas e não anulam esse risco. Não se pede que o testador decida disponibilizar ou reparar a lógica.

Raciocínio guardado antes da revelação:

Os testes dão evidência delimitada sobre qualidade e o risco de cobrança dupla para informar stakeholders. Não decidem automaticamente a disponibilização nem provam ausência de defeitos nas viagens não testadas. Transfers num operador de transportes são transbordos, não transferências bancárias.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 1.2.1: EN páginas [16]; PT páginas [17, 18].
- Secção 1.1.2: EN páginas [16]; PT páginas [17].

- LO FL-1.2.1/K2: EN página 14; PT página 15.

EN p.16 e PT pp.17–18 ligam deteção, avaliação direta de qualidade e decisões do SDLC. A distinção de debugging em EN p.16/PT p.17 apoia o contraste de o4. A tradução do exemplo de transporte é análise contextual do revisor, não um termo de bilhética citado do syllabus.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Valid transfers/transbordos válidos é coerente no domínio explícito de transportes e bilhética: não são transferências bancárias. Some/alguns e other tested journeys/restantes viagens testadas mantêm quantificadores e âmbito; não se generaliza a todas as viagens. Charged twice/cobrados duas vezes e before release/antes da disponibilização mantêm consequência e momento.

| EN literal | PT literal |
| --- | --- |
| valid transfers | transbordos válidos |
| other tested journeys | restantes viagens testadas |
| charged twice | cobrados duas vezes |

## Contraevidência e outras respostas defensáveis

Uma política de entrega pode usar métricas e critérios automáticos; contudo, a proporção isolada e o desprezo pelo impacto em o3 não são justificados. Cumprimento processual pode ser relevante, mas não é evidência suficiente por si face ao problema observado. Um profissional pode testar e corrigir, mas a correção é outra atividade, não contribuição direta da execução de teste.

## LO, nível K, explicações e dificuldade

K2: exemplificar a contribuição dos testes num cenário de decisão e distinguir avaliação direta de melhoria indireta. A cobrança concreta dá significado ao risco e os distratores confrontam processo, estatística sem impacto e debugging. A explicação não promete ausência de defeitos nem infere automaticamente uma decisão de publicação.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um operador de transportes tem de decidir se disponibiliza um novo serviço de bilhetes. Os testes revelam que alguns transbordos válidos são cobrados duas vezes, enquanto as restantes viagens testadas cumprem os critérios de aceitação. Como contribuem os testes mais diretamente para esta decisão?
```

Proposto atual — sem alteração

```text
Um operador de transportes tem de decidir se disponibiliza um novo serviço de bilhetes. Os testes revelam que alguns transbordos válidos são cobrados duas vezes, enquanto as restantes viagens testadas cumprem os critérios de aceitação. Como contribuem os testes mais diretamente para esta decisão?
```

### Enunciado EN

Original

```text
A transport operator must decide whether to release a new ticketing service. Tests reveal that some valid transfers are charged twice, while the other tested journeys meet their acceptance criteria. How does testing contribute most directly to this decision?
```

Proposto atual — sem alteração

```text
A transport operator must decide whether to release a new ticketing service. Tests reveal that some valid transfers are charged twice, while the other tested journeys meet their acceptance criteria. How does testing contribute most directly to this decision?
```

### o1 — alternativa PT

Original

```text
Demonstram que o processo documentado foi seguido, o que é evidência suficiente para disponibilizar o serviço.
```

Proposto atual — sem alteração

```text
Demonstram que o processo documentado foi seguido, o que é evidência suficiente para disponibilizar o serviço.
```

### o1 — explicação PT

Original

```text
O cumprimento do processo, por si só, não demonstra qualidade aceitável do produto; o problema de cobrança observado continua a ser relevante.
```

Proposto atual — sem alteração

```text
O cumprimento do processo, por si só, não demonstra qualidade aceitável do produto; o problema de cobrança observado continua a ser relevante.
```

### o1 — alternativa EN

Original

```text
They establish that the documented process was followed, which is sufficient evidence to release.
```

Proposto atual — sem alteração

```text
They establish that the documented process was followed, which is sufficient evidence to release.
```

### o1 — explicação EN

Original

```text
Process adherence alone does not establish acceptable product quality; the observed charging problem remains relevant.
```

Proposto atual — sem alteração

```text
Process adherence alone does not establish acceptable product quality; the observed charging problem remains relevant.
```

### o2 — alternativa PT

Original

```text
Fornecem evidência sobre a qualidade do produto e um risco concreto que os stakeholders devem considerar antes da disponibilização.
```

Proposto atual — sem alteração

```text
Fornecem evidência sobre a qualidade do produto e um risco concreto que os stakeholders devem considerar antes da disponibilização.
```

### o2 — explicação PT

Original

```text
Os resultados dos testes apoiam decisões de disponibilização ao revelar defeitos e avaliar a qualidade no âmbito testado.
```

Proposto atual — sem alteração

```text
Os resultados dos testes apoiam decisões de disponibilização ao revelar defeitos e avaliar a qualidade no âmbito testado.
```

### o2 — alternativa EN

Original

```text
They provide evidence about product quality and a concrete risk for stakeholders to consider before release.
```

Proposto atual — sem alteração

```text
They provide evidence about product quality and a concrete risk for stakeholders to consider before release.
```

### o2 — explicação EN

Original

```text
Test results inform release decisions by exposing defects and evaluating quality within the tested scope.
```

Proposto atual — sem alteração

```text
Test results inform release decisions by exposing defects and evaluating quality within the tested scope.
```

### o3 — alternativa PT

Original

```text
Determinam a decisão de disponibilização pela proporção de viagens aprovadas, independentemente do impacto no negócio.
```

Proposto atual — sem alteração

```text
Determinam a decisão de disponibilização pela proporção de viagens aprovadas, independentemente do impacto no negócio.
```

### o3 — explicação PT

Original

```text
Uma proporção de aprovações, por si só, não considera as consequências da cobrança duplicada nem os critérios de disponibilização acordados.
```

Proposto atual — sem alteração

```text
Uma proporção de aprovações, por si só, não considera as consequências da cobrança duplicada nem os critérios de disponibilização acordados.
```

### o3 — alternativa EN

Original

```text
They determine the release decision from the proportion of journeys that passed, regardless of the business impact.
```

Proposto atual — sem alteração

```text
They determine the release decision from the proportion of journeys that passed, regardless of the business impact.
```

### o3 — explicação EN

Original

```text
A pass proportion alone does not account for the consequences of double charging or the agreed release criteria.
```

Proposto atual — sem alteração

```text
A pass proportion alone does not account for the consequences of double charging or the agreed release criteria.
```

### o4 — alternativa PT

Original

```text
Melhoram diretamente o serviço ao corrigir a lógica de cobrança como parte da execução de teste.
```

Proposto atual — sem alteração

```text
Melhoram diretamente o serviço ao corrigir a lógica de cobrança como parte da execução de teste.
```

### o4 — explicação PT

Original

```text
Os testes identificam o problema; corrigir a lógica é debugging. A melhoria da qualidade através da remoção é uma contribuição indireta dos testes.
```

Proposto atual — sem alteração

```text
Os testes identificam o problema; corrigir a lógica é debugging. A melhoria da qualidade através da remoção é uma contribuição indireta dos testes.
```

### o4 — alternativa EN

Original

```text
They improve the service directly by correcting the charging logic as part of test execution.
```

Proposto atual — sem alteração

```text
They improve the service directly by correcting the charging logic as part of test execution.
```

### o4 — explicação EN

Original

```text
Testing identifies the problem; correcting the logic is debugging. Quality improvement through removal is an indirect contribution of testing.
```

Proposto atual — sem alteração

```text
Testing identifies the problem; correcting the logic is debugging. Quality improvement through removal is an indirect contribution of testing.
```

### Explicação geral PT

Original

```text
Os testes fornecem evidência para a decisão; não tomam automaticamente a decisão de negócio nem removem o defeito. A aprovação dos outros testes não anula o risco revelado.
```

Proposto atual — sem alteração

```text
Os testes fornecem evidência para a decisão; não tomam automaticamente a decisão de negócio nem removem o defeito. A aprovação dos outros testes não anula o risco revelado.
```

### Explicação geral EN

Original

```text
Testing supplies decision evidence; it neither makes the business decision automatically nor removes the defect. Passing other tests does not cancel the risk revealed.
```

Proposto atual — sem alteração

```text
Testing supplies decision evidence; it neither makes the business decision automatically nor removes the defect. Passing other tests does not cancel the risk revealed.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: seguir processo não prova qualidade aceitável nem resolve o problema de cobrança observado.

Following a documented process can support confidence, but these product test results do not establish process compliance as sufficient release evidence.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: evidência de qualidade e risco no âmbito testado permite uma decisão informada pelos stakeholders.

The observed double charge and successful tested journeys supply product-quality and concrete risk evidence for stakeholder judgment, within the tested scope.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: proporção de aprovações sem impacto não substitui critérios de entrega e julgamento de risco.

A passing proportion alone ignores the significance of charging defects; testing informs rather than mechanically dictates the business release decision.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta: corrigir lógica pertence a debugging/desenvolvimento, embora a mesma pessoa possa testar e corrigir.

Revealing a charging failure is testing; repairing faulty charging logic is debugging/development, not the direct contribution of test execution described.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |
| 2026-10-27.5 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |
| 2026-10-27.6 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |
| 2026-10-27.7 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |
| 2026-10-27.8 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |
| 2026-10-27.9 | True | 1 | ['o2'] | 0a0fd473714e1f0e8dc341512bef9367a37665fe9fd206fd41f4ec9362f62769 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-049 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.4.2 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

O serviço de emergência tem necessidades de disponibilidade e conservação de evidência distintas. Adaptar testes, cobertura e detalhe retido aos riscos e obrigações responde ao contexto; reutilização não dispensa análise dessas diferenças. Não se presume que um processo seja adequado por usar a mesma tecnologia.

Raciocínio guardado antes da revelação:

A abordagem deve adaptar disponibilidade, cobertura e conservação das evidências às obrigações e riscos do serviço de emergência. Não basta manter o método por a linguagem ser igual, só aumentar exemplos funcionais ou escolher formalidade máxima sem análise do contexto.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 1.4.2: EN páginas [19, 20]; PT páginas [21].

- LO FL-1.4.2/K2: EN página 14; PT página 15.

A lista EN de fatores começa na p.19 e continua na 20; PT concentra a secção 1.4.2 na p.21. Domínio, necessidades e restrições influenciam técnicas, cobertura e detalhe de testware em ambos. A aplicação à conservação para auditoria vem da obrigação expressa no cenário, não de uma regra legal acrescentada.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Emergency dispatch/coordenação de meios de emergência preserva a finalidade operacional do serviço no contexto. Availability/disponibilidade não é apenas velocidade. Retain evidence/conservação de evidências mantém retenção para auditoria, não só produzir logs transitórios. Only/apenas e before assessing/antes de avaliar conservam as restrições que enfraquecem os distratores.

| EN literal | PT literal |
| --- | --- |
| emergency dispatch service | serviço de coordenação de meios de emergência |
| strict availability obligations | obrigações rigorosas de disponibilidade |
| retain evidence | conservação de evidências |

## Contraevidência e outras respostas defensáveis

Se uma análise demonstrasse que metas e evidências existentes já eram suficientes, algum material poderia ser mantido. Mas o1 propõe apenas mais exemplos funcionais sem avaliar disponibilidade/auditoria. Um processo formal pode ser apropriado, mas selecionar o máximo antes de avaliar obrigações, como em o4, não é adaptação fundamentada. Não se inventam níveis de cobertura ou prazos legais de conservação.

## LO, nível K, explicações e dificuldade

K2: explicar impacto de contexto relacionando domínio, criticidade, riscos e necessidades de evidência. Não exige conhecimento de normas de emergência ou leis específicas; as obrigações são premissas do exercício. Os distratores são plausíveis atalhos de reutilização e formalismo, sem depender de marcas de ferramentas.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa reutiliza a abordagem de teste de uma aplicação interna de salas de reunião num serviço de coordenação de meios de emergência. Este último tem obrigações rigorosas de disponibilidade e uma exigência de auditoria de conservação de evidências. Que adaptação melhor reflete o novo contexto?
```

Proposto atual — sem alteração

```text
Uma equipa reutiliza a abordagem de teste de uma aplicação interna de salas de reunião num serviço de coordenação de meios de emergência. Este último tem obrigações rigorosas de disponibilidade e uma exigência de auditoria de conservação de evidências. Que adaptação melhor reflete o novo contexto?
```

### Enunciado EN

Original

```text
A team reuses a test approach from an internal meeting-room application for an emergency dispatch service. The latter has strict availability obligations and an audit requirement to retain evidence. What adaptation best reflects the new context?
```

Proposto atual — sem alteração

```text
A team reuses a test approach from an internal meeting-room application for an emergency dispatch service. The latter has strict availability obligations and an audit requirement to retain evidence. What adaptation best reflects the new context?
```

### o1 — alternativa PT

Original

```text
Manter as metas de cobertura e o detalhe das evidências, aumentando apenas o número de exemplos funcionais.
```

Proposto atual — sem alteração

```text
Manter as metas de cobertura e o detalhe das evidências, aumentando apenas o número de exemplos funcionais.
```

### o1 — explicação PT

Original

```text
Mais exemplos funcionais, por si só, não respondem ao risco de disponibilidade nem aos requisitos de evidência para auditoria.
```

Proposto atual — sem alteração

```text
Mais exemplos funcionais, por si só, não respondem ao risco de disponibilidade nem aos requisitos de evidência para auditoria.
```

### o1 — alternativa EN

Original

```text
Retain the coverage targets and evidence detail, increasing only the number of functional examples.
```

Proposto atual — sem alteração

```text
Retain the coverage targets and evidence detail, increasing only the number of functional examples.
```

### o1 — explicação EN

Original

```text
More functional examples alone do not address the availability risk or audit evidence requirements.
```

Proposto atual — sem alteração

```text
More functional examples alone do not address the availability risk or audit evidence requirements.
```

### o2 — alternativa PT

Original

```text
Usar os mesmos produtos de trabalho de teste porque a linguagem de implementação não mudou.
```

Proposto atual — sem alteração

```text
Usar os mesmos produtos de trabalho de teste porque a linguagem de implementação não mudou.
```

### o2 — explicação PT

Original

```text
A tecnologia é apenas um fator contextual; a criticidade do domínio e as obrigações dos stakeholders também afetam os produtos de trabalho e a cobertura.
```

Proposto atual — sem alteração

```text
A tecnologia é apenas um fator contextual; a criticidade do domínio e as obrigações dos stakeholders também afetam os produtos de trabalho e a cobertura.
```

### o2 — alternativa EN

Original

```text
Use the same testware because the implementation language has not changed.
```

Proposto atual — sem alteração

```text
Use the same testware because the implementation language has not changed.
```

### o2 — explicação EN

Original

```text
Technology is only one contextual factor; domain criticality and stakeholder obligations also affect testware and coverage.
```

Proposto atual — sem alteração

```text
Technology is only one contextual factor; domain criticality and stakeholder obligations also affect testware and coverage.
```

### o3 — alternativa PT

Original

```text
Adaptar os testes de disponibilidade, as metas de cobertura e as evidências conservadas aos riscos e às obrigações do serviço.
```

Proposto atual — sem alteração

```text
Adaptar os testes de disponibilidade, as metas de cobertura e as evidências conservadas aos riscos e às obrigações do serviço.
```

### o3 — explicação PT

Original

```text
O domínio de negócio, os riscos de produto e as necessidades regulamentares ou de auditoria influenciam as técnicas, a cobertura e o detalhe dos produtos de trabalho de teste.
```

Proposto atual — sem alteração

```text
O domínio de negócio, os riscos de produto e as necessidades regulamentares ou de auditoria influenciam as técnicas, a cobertura e o detalhe dos produtos de trabalho de teste.
```

### o3 — alternativa EN

Original

```text
Tailor availability testing, coverage targets and retained evidence to the service risks and obligations.
```

Proposto atual — sem alteração

```text
Tailor availability testing, coverage targets and retained evidence to the service risks and obligations.
```

### o3 — explicação EN

Original

```text
Business domain, product risks and regulatory or audit needs influence techniques, coverage and testware detail.
```

Proposto atual — sem alteração

```text
Business domain, product risks and regulatory or audit needs influence techniques, coverage and testware detail.
```

### o4 — alternativa PT

Original

```text
Adotar o processo de teste mais formal disponível antes de avaliar as obrigações aplicáveis.
```

Proposto atual — sem alteração

```text
Adotar o processo de teste mais formal disponível antes de avaliar as obrigações aplicáveis.
```

### o4 — explicação PT

Original

```text
O contexto exige uma adaptação justificada, não a escolha da máxima formalidade sem analisar as necessidades reais.
```

Proposto atual — sem alteração

```text
O contexto exige uma adaptação justificada, não a escolha da máxima formalidade sem analisar as necessidades reais.
```

### o4 — alternativa EN

Original

```text
Adopt the most formal test process available before assessing which obligations apply.
```

Proposto atual — sem alteração

```text
Adopt the most formal test process available before assessing which obligations apply.
```

### o4 — explicação EN

Original

```text
Context calls for justified tailoring, not selecting maximum formality without analysing the actual needs.
```

Proposto atual — sem alteração

```text
Context calls for justified tailoring, not selecting maximum formality without analysing the actual needs.
```

### Explicação geral PT

Original

```text
O processo de teste depende das necessidades dos stakeholders, da criticidade, dos riscos e das restrições, além da tecnologia. A reutilização é útil quando a abordagem é adaptada a essas diferenças.
```

Proposto atual — sem alteração

```text
O processo de teste depende das necessidades dos stakeholders, da criticidade, dos riscos e das restrições, além da tecnologia. A reutilização é útil quando a abordagem é adaptada a essas diferenças.
```

### Explicação geral EN

Original

```text
The test process depends on stakeholder needs, criticality, risks and constraints as well as technology. Reuse is useful when the approach is adapted to those differences.
```

Proposto atual — sem alteração

```text
The test process depends on stakeholder needs, criticality, risks and constraints as well as technology. Reuse is useful when the approach is adapted to those differences.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: aumentar apenas exemplos funcionais não adapta disponibilidade nem a evidência retida exigida.

More functional examples alone do not address strict availability or the evidence-retention audit obligation; the existing targets and detail cannot be assumed adequate.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Incorreta: linguagem comum não determina os riscos, obrigações nem detalhe adequado do testware.

A common implementation language does not fix the domain risks, availability obligations, regulatory context or appropriate testware detail.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — correta

Correta: adapta simultaneamente disponibilidade, cobertura e evidências aos riscos e obrigações descritos.

Tailoring availability testing, coverage and retained evidence addresses the service-specific risk and obligations together.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta: formalidade máxima antes da análise substitui justificação contextual por uma regra automática.

Maximum formality selected before assessing obligations substitutes a blanket rule for contextual tailoring. Formality may ultimately be appropriate, but must be justified.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |
| 2026-10-27.5 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |
| 2026-10-27.6 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |
| 2026-10-27.7 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |
| 2026-10-27.8 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |
| 2026-10-27.9 | True | 1 | ['o3'] | 5b9ad367653a5bf0cabb3c37033e85c309b97b82fa60b3d69a718bdf717d33fa |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-050 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.4.5 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

A revisão do calendário por um atraso é gestão/controlo de testes; derivar casos a partir de condições é conceção, principalmente função técnica de teste. A mesma pessoa pode desempenhar ambas. O elemento discriminante é a responsabilidade da tarefa, não o cargo nem o tamanho da equipa.

Raciocínio guardado antes da revelação:

Rever o calendário após atraso é controlo/gestão de testes; derivar casos de condições é conceção técnica de testes. A mesma pessoa pode acumular funções. A classificação depende da tarefa predominante, não do título profissional ou exclusividade.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 1.4.5: EN páginas [21]; PT páginas [23].
- Secção 1.4.1: EN páginas [19]; PT páginas [20, 21].

- LO FL-1.4.5/K2: EN página 14; PT página 15.

EN p.21 e PT p.23 permitem a mesma pessoa nas funções de teste e gestão e distribuem tarefas principalmente por responsabilidade. A descrição de atividades em EN p.19/PT pp.20–21 apoia controlo e conceção. Não há conflito de tradução que mude a classificação.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Mainly/principalmente é um qualificador decisivo, presente nas duas partes de o4 e nas explicações. One person may/uma pessoa pode conserva possibilidade, ao contrário de must/têm de em o3. Schedule/calendário e prioritised conditions/condições priorizadas mantêm as tarefas. Joana é personagem sintética, não autoridade ou qualificação humana.

| EN literal | PT literal |
| --- | --- |
| mainly test management | principalmente gestão de testes |
| One person may perform both | Uma pessoa pode desempenhar ambas |
| separate people must perform them | têm de ser executadas por pessoas diferentes |

## Contraevidência e outras respostas defensáveis

Conceção também exige decisões, mas isso não torna toda decisão uma tarefa de gestão. Equipas ágeis podem partilhar gestão e um gestor designado pode executar testes. O3 classifica as tarefas corretamente e falha só ao impor pessoas distintas; o4 mantém a distinção e a acumulação possível, sem a tornar obrigatória em todos os contextos.

## LO, nível K, explicações e dificuldade

K2: comparar duas responsabilidades num cenário aplicado, incluindo o distrator quase correto o3. Não se trata de decorar um título profissional; a explicação geral e as quatro justificações evitam exclusividade. O contexto pequeno torna plausível a acumulação sem impor um organigrama.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Numa equipa pequena, Joana revê o calendário de testes após um atraso no ambiente e depois deriva casos de teste a partir de condições priorizadas. Que afirmação compara corretamente as suas funções nestas duas tarefas?
```

Proposto atual — sem alteração

```text
Numa equipa pequena, Joana revê o calendário de testes após um atraso no ambiente e depois deriva casos de teste a partir de condições priorizadas. Que afirmação compara corretamente as suas funções nestas duas tarefas?
```

### Enunciado EN

Original

```text
In a small team, Joana revises the test schedule after an environment delay and then derives test cases from prioritised conditions. Which statement correctly compares her roles in these two tasks?
```

Proposto atual — sem alteração

```text
In a small team, Joana revises the test schedule after an environment delay and then derives test cases from prioritised conditions. Which statement correctly compares her roles in these two tasks?
```

### o1 — alternativa PT

Original

```text
Ambas as tarefas são de gestão de testes porque envolvem decidir que trabalho a equipa vai executar.
```

Proposto atual — sem alteração

```text
Ambas as tarefas são de gestão de testes porque envolvem decidir que trabalho a equipa vai executar.
```

### o1 — explicação PT

Original

```text
Derivar casos de teste é conceção de teste, uma atividade técnica principalmente associada à função de teste.
```

Proposto atual — sem alteração

```text
Derivar casos de teste é conceção de teste, uma atividade técnica principalmente associada à função de teste.
```

### o1 — alternativa EN

Original

```text
Both tasks are test management because they involve deciding what work the team will perform.
```

Proposto atual — sem alteração

```text
Both tasks are test management because they involve deciding what work the team will perform.
```

### o1 — explicação EN

Original

```text
Deriving test cases is test design, an engineering activity primarily associated with the testing role.
```

Proposto atual — sem alteração

```text
Deriving test cases is test design, an engineering activity primarily associated with the testing role.
```

### o2 — alternativa PT

Original

```text
Ambas as tarefas são da função de teste porque são executadas por um membro da equipa e não por um gestor designado.
```

Proposto atual — sem alteração

```text
Ambas as tarefas são da função de teste porque são executadas por um membro da equipa e não por um gestor designado.
```

### o2 — explicação PT

Original

```text
As funções distinguem-se pelas responsabilidades, não pelo cargo da pessoa que executa a tarefa.
```

Proposto atual — sem alteração

```text
As funções distinguem-se pelas responsabilidades, não pelo cargo da pessoa que executa a tarefa.
```

### o2 — alternativa EN

Original

```text
Both tasks are testing because a team member rather than a designated manager performs them.
```

Proposto atual — sem alteração

```text
Both tasks are testing because a team member rather than a designated manager performs them.
```

### o2 — explicação EN

Original

```text
Roles are distinguished by responsibilities, not by the job title of the person performing the task.
```

Proposto atual — sem alteração

```text
Roles are distinguished by responsibilities, not by the job title of the person performing the task.
```

### o3 — alternativa PT

Original

```text
A revisão do calendário é gestão de testes e a derivação de casos é teste, pelo que têm de ser executadas por pessoas diferentes.
```

Proposto atual — sem alteração

```text
A revisão do calendário é gestão de testes e a derivação de casos é teste, pelo que têm de ser executadas por pessoas diferentes.
```

### o3 — explicação PT

Original

```text
A classificação das tarefas está correta, mas uma pessoa pode desempenhar ambas as funções num contexto adequado.
```

Proposto atual — sem alteração

```text
A classificação das tarefas está correta, mas uma pessoa pode desempenhar ambas as funções num contexto adequado.
```

### o3 — alternativa EN

Original

```text
Schedule revision is test management and test case derivation is testing, so separate people must perform them.
```

Proposto atual — sem alteração

```text
Schedule revision is test management and test case derivation is testing, so separate people must perform them.
```

### o3 — explicação EN

Original

```text
The task classification is right, but one person may perform both roles in an appropriate context.
```

Proposto atual — sem alteração

```text
The task classification is right, but one person may perform both roles in an appropriate context.
```

### o4 — alternativa PT

Original

```text
A revisão do calendário é principalmente gestão de testes; derivar os casos pertence principalmente à função de teste. Uma pessoa pode desempenhar ambas.
```

Proposto atual — sem alteração

```text
A revisão do calendário é principalmente gestão de testes; derivar os casos pertence principalmente à função de teste. Uma pessoa pode desempenhar ambas.
```

### o4 — explicação PT

Original

```text
O planeamento e o controlo pertencem principalmente à gestão de testes; a análise, a conceção, a implementação e a execução pertencem principalmente à função de teste.
```

Proposto atual — sem alteração

```text
O planeamento e o controlo pertencem principalmente à gestão de testes; a análise, a conceção, a implementação e a execução pertencem principalmente à função de teste.
```

### o4 — alternativa EN

Original

```text
Schedule revision is mainly test management; deriving the cases is mainly the testing role. One person may perform both.
```

Proposto atual — sem alteração

```text
Schedule revision is mainly test management; deriving the cases is mainly the testing role. One person may perform both.
```

### o4 — explicação EN

Original

```text
Planning and control belong mainly to test management; analysis, design, implementation and execution belong mainly to the testing role.
```

Proposto atual — sem alteração

```text
Planning and control belong mainly to test management; analysis, design, implementation and execution belong mainly to the testing role.
```

### Explicação geral PT

Original

```text
As responsabilidades distinguem as funções. O syllabus permite que uma pessoa assuma ambas e que tarefas de gestão sejam partilhadas em equipas ágeis.
```

Proposto atual — sem alteração

```text
As responsabilidades distinguem as funções. O syllabus permite que uma pessoa assuma ambas e que tarefas de gestão sejam partilhadas em equipas ágeis.
```

### Explicação geral EN

Original

```text
Responsibilities distinguish the roles. The syllabus permits one person to take both roles and permits management tasks to be shared in agile teams.
```

Proposto atual — sem alteração

```text
Responsibilities distinguish the roles. The syllabus permits one person to take both roles and permits management tasks to be shared in agile teams.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: decidir pormenores técnicos de casos não transforma a conceção em gestão global do teste.

Both tasks involve decisions, but that does not classify technical case derivation as test management; the nature of each task matters.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Incorreta: ser membro da equipa não altera a natureza da tarefa de controlo do calendário.

Being a team member rather than a designated manager does not turn schedule control into the technical testing role.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: a distinção das tarefas está correta, mas exigir pessoas diferentes é uma inferência indevida.

The task distinction is largely right, but the inference that different people must perform them is unsupported and contrary to possible role combination.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — correta

Correta: distingue responsabilidades predominantes e admite a mesma pessoa em ambas as funções.

Schedule control is mainly management and deriving cases is mainly technical testing; a single person may perform both roles in context.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |
| 2026-10-27.5 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |
| 2026-10-27.6 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |
| 2026-10-27.7 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |
| 2026-10-27.8 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |
| 2026-10-27.9 | True | 1 | ['o4'] | 67fa25c4381a3088a94f0bc896cdc3dd7ba8591d104fb213baae70689bc0129b |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-051 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-1.5.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320`.

Resposta pré-gabarito: `['o1']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o1']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Escuta ativa, compreensão do domínio e pensamento analítico apoiam esclarecer o significado de reembolsado com uma regra e um exemplo concreto. A comunicação construtiva é a melhor primeira resposta. Uma falha reportada não é automaticamente um defeito confirmado; a divergência do resultado esperado precisa de ser analisada.

Raciocínio guardado antes da revelação:

É necessário ouvir a regra prevista, esclarecer o significado de negócio com um exemplo e discutir evidência construtivamente. A classificação reportada não prova defeito confirmado. Mais reproduções ou relatórios não resolvem por si a divergência semântica; atribuir unilateralmente o negócio ao programador não garante resolução.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 1.5.1: EN páginas [21, 22]; PT páginas [23, 24].

- LO FL-1.5.1/K2: EN página 14; PT página 15.

EN pp.21–22 e PT pp.23–24 incluem comunicação, escuta, pensamento analítico e conhecimento de domínio, e recomendam comunicar construtivamente. O exercício particulariza essas competências; não é uma definição normativa do estado financeiro de um reembolso nem aconselhamento sobre pagamentos.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Intended/previsto exprime intenção ou expectativa, não erro confirmado ou estatística de previsão. Refunded/reembolsado conserva o estado de negócio em disputa; aspas EN versus guillemets PT não mudam o termo. Reported failure/falha reportada é classificação reportada, sujeita a esclarecimento. Constructively/de forma construtiva conserva o modo de discutir evidência.

| EN literal | PT literal |
| --- | --- |
| intended behaviour | comportamento previsto |
| refunded | reembolsado |
| reported refund failure | falha de reembolso reportada |
| constructively | de forma construtiva |

## Contraevidência e outras respostas defensáveis

Mais execuções podem apoiar reprodução e uma escalada pode tornar-se necessária se não houver acordo. Nem contagens nem repetição resolvem por si a semântica. O programador pode conhecer profundamente o domínio, mas não recebe autoridade unilateral sobre o negócio por usar termos da implementação. Se o significado ainda não estiver acordado, deve ser clarificado com stakeholders relevantes; a opção o1 remete para essa base acordada, não inventa que já se provou um defeito.

## LO, nível K, explicações e dificuldade

K2: exemplificar competências gerais na resolução de um desacordo é adequado. A alternativa correta combina ações concretas, não uma lista abstrata de traços. Os distratores preservam ações potencialmente úteis noutro momento, mas insuficientes quando usadas para adiar significado ou afirmar autoridade. Explicações não garantem que todo desacordo se resolva numa conversa.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um programador afirma que uma falha de reembolso reportada é o comportamento previsto. O testador e o programador usam significados diferentes para «reembolsado». Que resposta melhor demonstra as competências gerais necessárias para resolver o desacordo?
```

Proposto atual — sem alteração

```text
Um programador afirma que uma falha de reembolso reportada é o comportamento previsto. O testador e o programador usam significados diferentes para «reembolsado». Que resposta melhor demonstra as competências gerais necessárias para resolver o desacordo?
```

### Enunciado EN

Original

```text
A developer says a reported refund failure is intended behaviour. The tester and developer use different meanings for "refunded". Which response best demonstrates the generic skills needed to resolve this disagreement?
```

Proposto atual — sem alteração

```text
A developer says a reported refund failure is intended behaviour. The tester and developer use different meanings for "refunded". Which response best demonstrates the generic skills needed to resolve this disagreement?
```

### o1 — alternativa PT

Original

```text
Pedir ao programador que explique a regra prevista, comparar um exemplo concreto com o significado de negócio acordado e discutir a evidência de forma construtiva.
```

Proposto atual — sem alteração

```text
Pedir ao programador que explique a regra prevista, comparar um exemplo concreto com o significado de negócio acordado e discutir a evidência de forma construtiva.
```

### o1 — explicação PT

Original

```text
A escuta ativa, o conhecimento do domínio e o pensamento analítico ajudam a estabelecer um significado comum sem críticas pessoais.
```

Proposto atual — sem alteração

```text
A escuta ativa, o conhecimento do domínio e o pensamento analítico ajudam a estabelecer um significado comum sem críticas pessoais.
```

### o1 — alternativa EN

Original

```text
Ask the developer to explain the intended rule, compare a concrete example with the agreed business meaning, and discuss the evidence constructively.
```

Proposto atual — sem alteração

```text
Ask the developer to explain the intended rule, compare a concrete example with the agreed business meaning, and discuss the evidence constructively.
```

### o1 — explicação EN

Original

```text
Active listening, domain understanding and analytical thinking help establish shared meaning without personal criticism.
```

Proposto atual — sem alteração

```text
Active listening, domain understanding and analytical thinking help establish shared meaning without personal criticism.
```

### o2 — alternativa PT

Original

```text
Repetir a mesma falha com mais dados antes de discutir o significado do termo de negócio.
```

Proposto atual — sem alteração

```text
Repetir a mesma falha com mais dados antes de discutir o significado do termo de negócio.
```

### o2 — explicação PT

Original

```text
Execuções adicionais podem confirmar a reprodução, mas não resolvem as interpretações diferentes do resultado esperado.
```

Proposto atual — sem alteração

```text
Execuções adicionais podem confirmar a reprodução, mas não resolvem as interpretações diferentes do resultado esperado.
```

### o2 — alternativa EN

Original

```text
Repeat the same failure with more data before discussing what the business term means.
```

Proposto atual — sem alteração

```text
Repeat the same failure with more data before discussing what the business term means.
```

### o2 — explicação EN

Original

```text
Additional runs may confirm reproducibility but do not resolve the differing interpretations of the expected result.
```

Proposto atual — sem alteração

```text
Additional runs may confirm reproducibility but do not resolve the differing interpretations of the expected result.
```

### o3 — alternativa PT

Original

```text
Reescrever o relatório com terminologia da implementação para que o programador decida o significado de negócio.
```

Proposto atual — sem alteração

```text
Reescrever o relatório com terminologia da implementação para que o programador decida o significado de negócio.
```

### o3 — explicação PT

Original

```text
O vocabulário técnico, por si só, não estabelece a regra de negócio acordada nem substitui a colaboração com os stakeholders relevantes.
```

Proposto atual — sem alteração

```text
O vocabulário técnico, por si só, não estabelece a regra de negócio acordada nem substitui a colaboração com os stakeholders relevantes.
```

### o3 — alternativa EN

Original

```text
Rewrite the report using implementation terminology so that the developer can decide the business meaning.
```

Proposto atual — sem alteração

```text
Rewrite the report using implementation terminology so that the developer can decide the business meaning.
```

### o3 — explicação EN

Original

```text
Technical vocabulary alone does not establish the agreed business rule or replace collaboration with the relevant stakeholders.
```

Proposto atual — sem alteração

```text
Technical vocabulary alone does not establish the agreed business rule or replace collaboration with the relevant stakeholders.
```

### o4 — alternativa PT

Original

```text
Escalar imediatamente a classificação em disputa, usando o número de relatórios semelhantes para apoiar a interpretação do testador.
```

Proposto atual — sem alteração

```text
Escalar imediatamente a classificação em disputa, usando o número de relatórios semelhantes para apoiar a interpretação do testador.
```

### o4 — explicação PT

Original

```text
A escalada pode ser necessária em alguns casos, mas contar relatórios não esclarece o termo; neste caso, discutir construtivamente a evidência é a melhor primeira resposta.
```

Proposto atual — sem alteração

```text
A escalada pode ser necessária em alguns casos, mas contar relatórios não esclarece o termo; neste caso, discutir construtivamente a evidência é a melhor primeira resposta.
```

### o4 — alternativa EN

Original

```text
Escalate the disputed classification immediately, using the number of similar reports to support the tester's interpretation.
```

Proposto atual — sem alteração

```text
Escalate the disputed classification immediately, using the number of similar reports to support the tester's interpretation.
```

### o4 — explicação EN

Original

```text
Escalation may sometimes be necessary, but counting reports does not clarify the term; constructive discussion of evidence is the better first response here.
```

Proposto atual — sem alteração

```text
Escalation may sometimes be necessary, but counting reports does not clarify the term; constructive discussion of evidence is the better first response here.
```

### Explicação geral PT

Original

```text
Os testes exigem comunicação e escuta ativa, além de competências técnicas. Deve esclarecer-se o comportamento esperado com conhecimento do domínio e evidência antes de tratar o desacordo como um problema pessoal ou de autoridade.
```

Proposto atual — sem alteração

```text
Os testes exigem comunicação e escuta ativa, além de competências técnicas. Deve esclarecer-se o comportamento esperado com conhecimento do domínio e evidência antes de tratar o desacordo como um problema pessoal ou de autoridade.
```

### Explicação geral EN

Original

```text
Testing needs communication and active listening as well as technical skills. Clarify the expected behaviour using domain knowledge and evidence before treating the disagreement as a personal or authority issue.
```

Proposto atual — sem alteração

```text
Testing needs communication and active listening as well as technical skills. Clarify the expected behaviour using domain knowledge and evidence before treating the disagreement as a personal or authority issue.
```

## Avaliação das quatro alternativas

### o1 — correta

Correta: ouvir, comparar com significado de negócio e discutir evidência clarifica a divergência sem crítica pessoal.

Listening, concrete comparison against agreed business meaning and constructive evidence discussion address the semantic disagreement without declaring either participant automatically right.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Incorreta como melhor primeira resposta: mais dados podem reproduzir comportamento, mas adiar o significado mantém a ambiguidade.

More data may help reproduce behaviour, but deferring discussion of the disputed business term does not resolve the interpretation problem.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: terminologia técnica não estabelece por si a regra de negócio nem substitui colaboração.

Implementation terminology can aid communication, but delegating the business meaning solely to the developer does not establish the agreed business rule.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta como primeira medida: escalada imediata e quantidade de relatos não demonstram qual interpretação é correta.

Escalation can become appropriate if discussion fails; immediate escalation based on counts of similar reports does not establish the correctness of the tester interpretation.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |
| 2026-10-27.5 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |
| 2026-10-27.6 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |
| 2026-10-27.7 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |
| 2026-10-27.8 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |
| 2026-10-27.9 | True | 1 | ['o1'] | 1d38455b9ce7bac2dc8231c6062909cac6cfaad3135d4a008f0ae19f8185b320 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-052 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.1 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470`.

Resposta pré-gabarito: `['o3']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o3']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

A mudança para incrementos utilizáveis frequentes requer feedback sobre comportamento novo e existente ao longo da evolução. Combinar testes estáticos e dinâmicos dentro dos incrementos, com regressão, responde às entregas e à possibilidade de alteração de requisitos. Não basta rever cedo e deixar toda validação dinâmica para o fim.

Raciocínio guardado antes da revelação:

Incrementos utilizáveis frequentes com requisitos mutáveis pedem teste estático e dinâmico dentro dos incrementos, feedback rápido e regressão ao longo da evolução. Adiar toda regressão ou teste dinâmico de sistema ao fim perde feedback; planos detalhados imutáveis ignoram mudança.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 2.1.1: EN páginas [25]; PT páginas [27].

- LO FL-2.1.1/K2: EN página 24; PT página 26.

EN p.25 e PT p.27 descrevem testes estáticos e dinâmicos em iterações, feedback rápido e regressão em entregas frequentes. A modalidade podem a todos os níveis não foi convertida numa obrigação de executar toda a suite a cada incremento.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Usable increments/incrementos utilizáveis conserva que há produto útil e não só documentos parciais. Can change/podem mudar exprime possibilidade, não obrigação de mudança em toda iteração. Within increments/nos incrementos e as the product grows/à medida que o produto cresce mantêm repetição durante desenvolvimento, sem trocar por uma única campanha final.

| EN literal | PT literal |
| --- | --- |
| usable increments | incrementos utilizáveis |
| Requirements can change | Os requisitos podem mudar |
| within increments | nos incrementos |

## Contraevidência e outras respostas defensáveis

Planeamento antecipado e testes de aceitação novos são úteis; falham nas opções porque impõem desenho imutável ou adiam regressão. Alguns testes podem precisar de ambiente ou sistema mais completo. O3 não exige todos os níveis/tipos, a bateria completa ou a mesma intensidade em cada quinzena; mantém a adaptação ao incremento e ao risco. Cada duas semanas é premissa local, não definição universal de desenvolvimento incremental.

## LO, nível K, explicações e dificuldade

K2: explicar a alteração do teste em resposta ao SDLC. O cenário fornece contexto suficiente sem exigir um framework ágil específico. O4 oferece aceitação, mas a reserva de regressão ao fim é o erro relevante; isso ajuda a avaliar razão e não só uma palavra-chave. A explicação não garante deteção de todas as regressões.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa passa de uma única entrega no fim do projeto para incrementos utilizáveis a cada duas semanas. Os requisitos podem mudar entre incrementos. Que alteração aos testes melhor responde a este ciclo de vida?
```

Proposto atual — sem alteração

```text
Uma equipa passa de uma única entrega no fim do projeto para incrementos utilizáveis a cada duas semanas. Os requisitos podem mudar entre incrementos. Que alteração aos testes melhor responde a este ciclo de vida?
```

### Enunciado EN

Original

```text
A team moves from a single end-of-project delivery to usable increments every two weeks. Requirements can change between increments. Which change to testing best addresses this lifecycle?
```

Proposto atual — sem alteração

```text
A team moves from a single end-of-project delivery to usable increments every two weeks. Requirements can change between increments. Which change to testing best addresses this lifecycle?
```

### o1 — alternativa PT

Original

```text
Manter o teste dinâmico de sistema para o último incremento, revendo os requisitos de cada incremento anterior.
```

Proposto atual — sem alteração

```text
Manter o teste dinâmico de sistema para o último incremento, revendo os requisitos de cada incremento anterior.
```

### o1 — explicação PT

Original

```text
Cada incremento utilizável precisa de feedback dinâmico atempado; adiá-lo prejudica a entrega frequente.
```

Proposto atual — sem alteração

```text
Cada incremento utilizável precisa de feedback dinâmico atempado; adiá-lo prejudica a entrega frequente.
```

### o1 — alternativa EN

Original

```text
Keep dynamic system testing for the final increment, while reviewing each earlier increment's requirements.
```

Proposto atual — sem alteração

```text
Keep dynamic system testing for the final increment, while reviewing each earlier increment's requirements.
```

### o1 — explicação EN

Original

```text
Each usable increment needs timely dynamic feedback; deferring it undermines frequent delivery.
```

Proposto atual — sem alteração

```text
Each usable increment needs timely dynamic feedback; deferring it undermines frequent delivery.
```

### o2 — alternativa PT

Original

```text
Concluir conceções de teste detalhadas para todos os incrementos antes da primeira iteração e mantê-las inalteradas.
```

Proposto atual — sem alteração

```text
Concluir conceções de teste detalhadas para todos os incrementos antes da primeira iteração e mantê-las inalteradas.
```

### o2 — explicação PT

Original

```text
Requisitos em mudança exigem adaptação; uma conceção detalhada fixa para todos os incrementos contraria o contexto apresentado.
```

Proposto atual — sem alteração

```text
Requisitos em mudança exigem adaptação; uma conceção detalhada fixa para todos os incrementos contraria o contexto apresentado.
```

### o2 — alternativa EN

Original

```text
Complete detailed test designs for all increments before the first iteration, then retain them unchanged.
```

Proposto atual — sem alteração

```text
Complete detailed test designs for all increments before the first iteration, then retain them unchanged.
```

### o2 — explicação EN

Original

```text
Changing requirements require adaptation; a frozen detailed design for all increments conflicts with the stated context.
```

Proposto atual — sem alteração

```text
Changing requirements require adaptation; a frozen detailed design for all increments conflicts with the stated context.
```

### o3 — alternativa PT

Original

```text
Realizar testes estáticos e dinâmicos nos incrementos, com feedback rápido e testes de regressão à medida que o produto cresce.
```

Proposto atual — sem alteração

```text
Realizar testes estáticos e dinâmicos nos incrementos, com feedback rápido e testes de regressão à medida que o produto cresce.
```

### o3 — explicação PT

Original

```text
Incrementos funcionais e alterações frequentes criam a necessidade de testes repetidos e de feedback de regressão ao longo do desenvolvimento.
```

Proposto atual — sem alteração

```text
Incrementos funcionais e alterações frequentes criam a necessidade de testes repetidos e de feedback de regressão ao longo do desenvolvimento.
```

### o3 — alternativa EN

Original

```text
Perform static and dynamic testing within increments, with fast feedback and regression testing as the product grows.
```

Proposto atual — sem alteração

```text
Perform static and dynamic testing within increments, with fast feedback and regression testing as the product grows.
```

### o3 — explicação EN

Original

```text
Working increments and frequent changes create a need for repeated testing and regression feedback throughout development.
```

Proposto atual — sem alteração

```text
Working increments and frequent changes create a need for repeated testing and regression feedback throughout development.
```

### o4 — alternativa PT

Original

```text
Concentrar cada iteração nos novos testes de aceitação e reservar os testes de regressão para a entrega final.
```

Proposto atual — sem alteração

```text
Concentrar cada iteração nos novos testes de aceitação e reservar os testes de regressão para a entrega final.
```

### o4 — explicação PT

Original

```text
Os novos incrementos podem afetar negativamente o comportamento existente, pelo que o feedback de regressão é necessário antes da entrega final.
```

Proposto atual — sem alteração

```text
Os novos incrementos podem afetar negativamente o comportamento existente, pelo que o feedback de regressão é necessário antes da entrega final.
```

### o4 — alternativa EN

Original

```text
Concentrate each iteration on new acceptance tests and reserve regression testing for the final release.
```

Proposto atual — sem alteração

```text
Concentrate each iteration on new acceptance tests and reserve regression testing for the final release.
```

### o4 — explicação EN

Original

```text
New increments can adversely affect existing behaviour, so regression feedback is needed before the final release.
```

Proposto atual — sem alteração

```text
New increments can adversely affect existing behaviour, so regression feedback is needed before the final release.
```

### Explicação geral PT

Original

```text
O SDLC afeta a calendarização, a documentação, as técnicas e a automação. A entrega incremental exige feedback sobre o comportamento novo e o existente em cada incremento.
```

Proposto atual — sem alteração

```text
O SDLC afeta a calendarização, a documentação, as técnicas e a automação. A entrega incremental exige feedback sobre o comportamento novo e o existente em cada incremento.
```

### Explicação geral EN

Original

```text
The SDLC affects timing, documentation, techniques and automation. Incremental delivery calls for feedback on both new and existing behaviour in each increment.
```

Proposto atual — sem alteração

```text
The SDLC affects timing, documentation, techniques and automation. Incremental delivery calls for feedback on both new and existing behaviour in each increment.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: revisões precoces são úteis, mas adiar teste dinâmico de sistema ao último incremento prejudica feedback utilizável.

Reviewing requirements early is useful, but deferring dynamic system testing until the final increment fails to support usable intermediate increments adequately.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Incorreta: desenho detalhado totalmente fixo contraria a possibilidade explícita de requisitos mudarem.

Early planning is helpful, but designing every detail upfront and freezing it ignores the explicit possibility of requirement changes between increments.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — correta

Correta: estático, dinâmico, feedback rápido e regressão acompanham crescimento e alterações do produto.

Static and dynamic checks within increments, rapid feedback and evolving regression address both incremental delivery and change risk.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta: novos testes de aceitação não substituem regressão sobre efeitos no comportamento existente.

New acceptance tests alone omit effects on existing behaviour; deferring regression until final release gives late feedback on accumulating changes.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |
| 2026-10-27.5 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |
| 2026-10-27.6 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |
| 2026-10-27.7 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |
| 2026-10-27.8 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |
| 2026-10-27.9 | True | 1 | ['o3'] | be1c2ab791f4907429459e98d3ddcd798b3f7d33ffcc61c2b8ac2d550ce0e470 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-053 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.1.4 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

O pipeline pode acelerar feedback e reduzir repetição manual, mas precisa de preparação e manutenção; investigação manual centrada nos utilizadores continua relevante no cenário. DevOps aproxima desenvolvimento, testes e operações, sem transferir toda responsabilidade para depois da disponibilização.

Raciocínio guardado antes da revelação:

Automação pode reduzir repetição e acelerar feedback, mas requer preparação/manutenção e não elimina investigação manual centrada no utilizador no cenário. DevOps promove colaboração; não transfere simplesmente os testes para operações após publicação.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 2.1.4: EN páginas [26, 27]; PT páginas [28, 29].

- LO FL-2.1.4/K2: EN página 24; PT página 26.

EN pp.26–27 e PT pp.28–29 distinguem feedback/repetição de custos e limites da automação e mantêm teste manual na perspetiva do utilizador. Não se fez consulta nova de ferramentas ou recomendação comercial; a análise é do conceito CTFL.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Can/pode em o2 conserva benefício potencial, não promessa. Remain necessary/continuando a ser necessárias refere manutenção e teste manual no cenário. Mainly/principalmente em o3 não torna correto o conceito de passagem tardia de responsabilidade. Suite/suite automatizada é empréstimo para bateria, compreensível no contexto e sem impacto na resposta; preferência estilística por bateria não exige alteração.

| EN literal | PT literal |
| --- | --- |
| can accelerate feedback | pode acelerar o feedback |
| reduce repetitive manual work | reduzir trabalho manual repetitivo |
| after deployment | após a disponibilização |

## Contraevidência e outras respostas defensáveis

Ferramentas podem apoiar sessões exploratórias e algumas verificações encontradas nelas podem ser automatizadas depois. Isso não significa que exploração deva tornar-se exclusivamente checks repetíveis. DevOps não garante velocidade ou cobertura completa só pela aquisição de ferramentas. Não se quantifica aqui manutenção nem se universaliza o mesmo equilíbrio de testes para todo produto; os fluxos de utilizador e sessões planeadas são premissas.

## LO, nível K, explicações e dificuldade

K2: resumir benefícios e desafios do DevOps sem confundir automação com totalidade dos testes. O4 parte de vantagem real e acrescenta inferência incorreta sobre manutenção, criando distrator plausível. Explicações explicitam colaboração e recursos; não prometem que automação elimina defeitos ou testes humanos.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Uma equipa introduz um pipeline de entrega DevOps com testes automatizados de componentes e de regressão em cada alteração. Planeia também sessões exploratórias para novos fluxos de utilização. Que avaliação melhor descreve o impacto nos testes?
```

Proposto atual — sem alteração

```text
Uma equipa introduz um pipeline de entrega DevOps com testes automatizados de componentes e de regressão em cada alteração. Planeia também sessões exploratórias para novos fluxos de utilização. Que avaliação melhor descreve o impacto nos testes?
```

### Enunciado EN

Original

```text
A team introduces a DevOps delivery pipeline with automated component and regression tests on each change. It also plans exploratory sessions for new user workflows. Which assessment best describes the testing impact?
```

Proposto atual — sem alteração

```text
A team introduces a DevOps delivery pipeline with automated component and regression tests on each change. It also plans exploratory sessions for new user workflows. Which assessment best describes the testing impact?
```

### o1 — alternativa PT

Original

```text
As sessões exploratórias devem passar para o pipeline porque os testes em DevOps têm de produzir verificações automatizadas repetíveis.
```

Proposto atual — sem alteração

```text
As sessões exploratórias devem passar para o pipeline porque os testes em DevOps têm de produzir verificações automatizadas repetíveis.
```

### o1 — explicação PT

Original

```text
A automação reduz o trabalho repetitivo, mas não substitui o teste manual, sobretudo na perspetiva do utilizador.
```

Proposto atual — sem alteração

```text
A automação reduz o trabalho repetitivo, mas não substitui o teste manual, sobretudo na perspetiva do utilizador.
```

### o1 — alternativa EN

Original

```text
The exploratory sessions should move into the pipeline because DevOps testing must produce repeatable automated checks.
```

Proposto atual — sem alteração

```text
The exploratory sessions should move into the pipeline because DevOps testing must produce repeatable automated checks.
```

### o1 — explicação EN

Original

```text
Automation reduces repetitive work but does not replace manual testing, particularly testing from the user perspective.
```

Proposto atual — sem alteração

```text
Automation reduces repetitive work but does not replace manual testing, particularly testing from the user perspective.
```

### o2 — alternativa PT

Original

```text
O pipeline pode acelerar o feedback e reduzir trabalho manual repetitivo, continuando a ser necessárias a manutenção da automação e o teste manual centrado no utilizador.
```

Proposto atual — sem alteração

```text
O pipeline pode acelerar o feedback e reduzir trabalho manual repetitivo, continuando a ser necessárias a manutenção da automação e o teste manual centrado no utilizador.
```

### o2 — explicação PT

Original

```text
O DevOps promove a colaboração e feedback automatizado rápido, com custos de preparação e manutenção e uma necessidade continuada de teste manual.
```

Proposto atual — sem alteração

```text
O DevOps promove a colaboração e feedback automatizado rápido, com custos de preparação e manutenção e uma necessidade continuada de teste manual.
```

### o2 — alternativa EN

Original

```text
The pipeline can accelerate feedback and reduce repetitive manual work, while automation maintenance and user-focused manual testing remain necessary.
```

Proposto atual — sem alteração

```text
The pipeline can accelerate feedback and reduce repetitive manual work, while automation maintenance and user-focused manual testing remain necessary.
```

### o2 — explicação EN

Original

```text
DevOps promotes collaboration and fast automated feedback, with setup and maintenance costs and a continuing need for manual testing.
```

Proposto atual — sem alteração

```text
DevOps promotes collaboration and fast automated feedback, with setup and maintenance costs and a continuing need for manual testing.
```

### o3 — alternativa PT

Original

```text
O pipeline transfere principalmente a responsabilidade pelos testes do desenvolvimento para as operações após a disponibilização.
```

Proposto atual — sem alteração

```text
O pipeline transfere principalmente a responsabilidade pelos testes do desenvolvimento para as operações após a disponibilização.
```

### o3 — explicação PT

Original

```text
O DevOps procura a colaboração entre o desenvolvimento, incluindo testes, e as operações, em vez de uma passagem tardia de responsabilidade.
```

Proposto atual — sem alteração

```text
O DevOps procura a colaboração entre o desenvolvimento, incluindo testes, e as operações, em vez de uma passagem tardia de responsabilidade.
```

### o3 — alternativa EN

Original

```text
The pipeline mainly transfers responsibility for testing from development to operations after deployment.
```

Proposto atual — sem alteração

```text
The pipeline mainly transfers responsibility for testing from development to operations after deployment.
```

### o3 — explicação EN

Original

```text
DevOps seeks collaboration between development, including testing, and operations rather than a delayed responsibility handover.
```

Proposto atual — sem alteração

```text
DevOps seeks collaboration between development, including testing, and operations rather than a delayed responsibility handover.
```

### o4 — alternativa PT

Original

```text
A suite automatizada acelera o feedback de regressão, pelo que a sua manutenção pode esperar por uma regressão em produção.
```

Proposto atual — sem alteração

```text
A suite automatizada acelera o feedback de regressão, pelo que a sua manutenção pode esperar por uma regressão em produção.
```

### o4 — explicação PT

Original

```text
Um pipeline fiável exige manutenção continuada dos testes e das ferramentas; esperar por uma falha em produção prejudica esse feedback.
```

Proposto atual — sem alteração

```text
Um pipeline fiável exige manutenção continuada dos testes e das ferramentas; esperar por uma falha em produção prejudica esse feedback.
```

### o4 — alternativa EN

Original

```text
The automated suite makes regression feedback faster, so its maintenance can wait until a production regression occurs.
```

Proposto atual — sem alteração

```text
The automated suite makes regression feedback faster, so its maintenance can wait until a production regression occurs.
```

### o4 — explicação EN

Original

```text
A reliable pipeline requires continuing test and tool maintenance; waiting for a production failure undermines that feedback.
```

Proposto atual — sem alteração

```text
A reliable pipeline requires continuing test and tool maintenance; waiting for a production failure undermines that feedback.
```

### Explicação geral PT

Original

```text
O feedback rápido é uma vantagem, não uma garantia de testes completos. A infraestrutura do pipeline e os testes exigem recursos, e o teste manual continua a contribuir.
```

Proposto atual — sem alteração

```text
O feedback rápido é uma vantagem, não uma garantia de testes completos. A infraestrutura do pipeline e os testes exigem recursos, e o teste manual continua a contribuir.
```

### Explicação geral EN

Original

```text
Fast feedback is a benefit, not a guarantee of complete testing. Pipeline infrastructure and tests require resources, and manual testing still contributes.
```

Proposto atual — sem alteração

```text
Fast feedback is a benefit, not a guarantee of complete testing. Pipeline infrastructure and tests require resources, and manual testing still contributes.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: exploração pode usar ferramentas, mas DevOps não exige transformar toda investigação em checks automatizados repetíveis.

DevOps does not require every testing activity to be a repeatable automated check; exploratory user-focused investigation is not eliminated by the pipeline.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: benefício potencial de feedback com manutenção e contribuição manual reconhecidas.

Faster feedback and reduced repetitive work are potential benefits, while maintaining automation and human user-focused testing remain relevant in this scenario.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: a colaboração DevOps não equivale à transferência tardia do teste para operações.

A collaborative delivery pipeline does not mainly move testing ownership to operations after deployment; this is a siloed misunderstanding.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta: acelerar feedback não autoriza esperar por uma regressão em produção para manter a suite.

Faster execution does not justify deferring maintenance until a production regression; stale or unreliable checks undermine useful feedback.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |
| 2026-10-27.5 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |
| 2026-10-27.6 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |
| 2026-10-27.7 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |
| 2026-10-27.8 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |
| 2026-10-27.9 | True | 1 | ['o2'] | 643542b1442a9287d7874b5a720e8a01fb55664d7ddb389819e08d6ef9e3e807 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-054 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.2.2 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae`.

Resposta pré-gabarito: `['o4']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Os objetivos principais são verificar o que a pesquisa devolve e quão rapidamente responde numa carga acordada: funcional e não funcional. Ambos os testes estão explicitamente no nível de sistema. Usar a mesma operação não torna os objetivos iguais, nem dá base para inferir caixa-branca.

Raciocínio guardado antes da revelação:

Verificar os registos devolvidos é objetivo funcional; medir tempo de resposta com carga acordada é não funcional. Ambos estão no nível de sistema e podem executar a mesma função; a classificação pede objetivo principal, não nível nem inferência de caixa-branca.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 2.2.2: EN páginas [29, 30]; PT páginas [32, 33].

- LO FL-2.2.2/K2: EN página 24; PT página 26.

EN pp.29–30 e PT pp.32–33 distinguem funcional/não funcional e permitem reaproveitar cenários funcionais para restrições como tempo. A lista EN4.0.1 e PT4.0 de características não é textualmente idêntica, mas desempenho/tempo mantém o mesmo enquadramento nesta pergunta.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Primary objectives/objetivos principais é o qualificador que permite classificar sem negar sobreposição. Specified records/registos especificados, response time/tempo de resposta e agreed workload/carga acordada mantêm característica e condição. At system test level/no nível de teste de sistema conserva o nível de ambos.

| EN literal | PT literal |
| --- | --- |
| primary objectives | objetivos principais |
| agreed workload | carga acordada |
| response time | tempo de resposta |
| At system test level | No nível de teste de sistema |

## Contraevidência e outras respostas defensáveis

Um mesmo caso pode verificar simultaneamente resultados e tempos, e ambos podem ser derivados de especificações. O enunciado pede objetivo principal de cada um, não categorias mutuamente exclusivas em toda execução. A primeira verificação não inclui evidência de uso de estrutura interna; não se conclui universalmente que pesquisas nunca usam caixa-branca. Carga acordada define o contexto da medição, não um teste de nível diferente.

## LO, nível K, explicações e dificuldade

K2: comparar dimensões de tipo e nível através de dois objetivos de teste concretos. O1 é plausível para quem classifica só pela função executada; o2 confunde dimensão e contradiz a premissa; o3 não tem evidência de estrutura. A explicação de o3 deve ser lida no âmbito dado, não como conhecimento de toda a implementação ausente do cenário.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
No nível de teste de sistema, um teste verifica se uma pesquisa de documentos devolve os registos especificados. Outro executa a mesma pesquisa com uma carga acordada para verificar o tempo de resposta. Como devem ser classificados os seus objetivos principais?
```

Proposto atual — sem alteração

```text
No nível de teste de sistema, um teste verifica se uma pesquisa de documentos devolve os registos especificados. Outro executa a mesma pesquisa com uma carga acordada para verificar o tempo de resposta. Como devem ser classificados os seus objetivos principais?
```

### Enunciado EN

Original

```text
At system test level, one test checks whether a document search returns the specified records. Another runs the same search under an agreed workload to check its response time. How should their primary objectives be classified?
```

Proposto atual — sem alteração

```text
At system test level, one test checks whether a document search returns the specified records. Another runs the same search under an agreed workload to check its response time. How should their primary objectives be classified?
```

### o1 — alternativa PT

Original

```text
Ambos são funcionais porque executam a mesma função de pesquisa.
```

Proposto atual — sem alteração

```text
Ambos são funcionais porque executam a mesma função de pesquisa.
```

### o1 — explicação PT

Original

```text
A função executada pode ser a mesma e a característica avaliada ser diferente; o tempo de resposta é não funcional.
```

Proposto atual — sem alteração

```text
A função executada pode ser a mesma e a característica avaliada ser diferente; o tempo de resposta é não funcional.
```

### o1 — alternativa EN

Original

```text
Both are functional because they execute the same search function.
```

Proposto atual — sem alteração

```text
Both are functional because they execute the same search function.
```

### o1 — explicação EN

Original

```text
The executed function can be the same while the evaluated characteristic differs; response time is non-functional.
```

Proposto atual — sem alteração

```text
The executed function can be the same while the evaluated characteristic differs; response time is non-functional.
```

### o2 — alternativa PT

Original

```text
O primeiro é teste de componentes; o segundo é teste de sistema.
```

Proposto atual — sem alteração

```text
O primeiro é teste de componentes; o segundo é teste de sistema.
```

### o2 — explicação PT

Original

```text
Estes são níveis, não os tipos pedidos, e o cenário coloca explicitamente ambos no nível de sistema.
```

Proposto atual — sem alteração

```text
Estes são níveis, não os tipos pedidos, e o cenário coloca explicitamente ambos no nível de sistema.
```

### o2 — alternativa EN

Original

```text
The first is component testing; the second is system testing.
```

Proposto atual — sem alteração

```text
The first is component testing; the second is system testing.
```

### o2 — explicação EN

Original

```text
These are levels, not the requested types, and the scenario explicitly places both at system level.
```

Proposto atual — sem alteração

```text
These are levels, not the requested types, and the scenario explicitly places both at system level.
```

### o3 — alternativa PT

Original

```text
O primeiro é teste caixa-branca; o segundo é teste caixa-preta.
```

Proposto atual — sem alteração

```text
O primeiro é teste caixa-branca; o segundo é teste caixa-preta.
```

### o3 — explicação PT

Original

```text
Não é usada estrutura interna para derivar o primeiro teste. A distinção descrita é correção funcional versus desempenho.
```

Proposto atual — sem alteração

```text
Não é usada estrutura interna para derivar o primeiro teste. A distinção descrita é correção funcional versus desempenho.
```

### o3 — alternativa EN

Original

```text
The first is white-box testing; the second is black-box testing.
```

Proposto atual — sem alteração

```text
The first is white-box testing; the second is black-box testing.
```

### o3 — explicação EN

Original

```text
No internal structure is used to derive the first test. The distinction described is functional correctness versus performance.
```

Proposto atual — sem alteração

```text
No internal structure is used to derive the first test. The distinction described is functional correctness versus performance.
```

### o4 — alternativa PT

Original

```text
O primeiro é teste funcional; o segundo é teste não funcional.
```

Proposto atual — sem alteração

```text
O primeiro é teste funcional; o segundo é teste não funcional.
```

### o4 — explicação PT

Original

```text
Devolver os registos especificados diz respeito ao que o sistema faz; o tempo de resposta sob carga diz respeito a quão bem o faz.
```

Proposto atual — sem alteração

```text
Devolver os registos especificados diz respeito ao que o sistema faz; o tempo de resposta sob carga diz respeito a quão bem o faz.
```

### o4 — alternativa EN

Original

```text
The first is functional testing; the second is non-functional testing.
```

Proposto atual — sem alteração

```text
The first is functional testing; the second is non-functional testing.
```

### o4 — explicação EN

Original

```text
Returning the specified records concerns what the system does; response time under load concerns how well it performs.
```

Proposto atual — sem alteração

```text
Returning the specified records concerns what the system does; response time under load concerns how well it performs.
```

### Explicação geral PT

Original

```text
Os tipos e os níveis de teste são dimensões diferentes. Um cenário funcional também pode ser usado para avaliar uma restrição não funcional no mesmo nível de teste.
```

Proposto atual — sem alteração

```text
Os tipos e os níveis de teste são dimensões diferentes. Um cenário funcional também pode ser usado para avaliar uma restrição não funcional no mesmo nível de teste.
```

### Explicação geral EN

Original

```text
Test types and test levels are different dimensions. A functional scenario can also be used to assess a non-functional constraint at the same test level.
```

Proposto atual — sem alteração

```text
Test types and test levels are different dimensions. A functional scenario can also be used to assess a non-functional constraint at the same test level.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: a operação executada pode ser a mesma, mas a característica avaliada é diferente.

Executing the same search does not make every objective functional; response-time behaviour under workload is a non-functional quality concern.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — distrator

Incorreta: ambos foram colocados no nível de sistema e a resposta confunde nível com o tipo pedido.

The statement fixes both at system-test level; it gives no basis for reclassifying the first as component testing.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: não foi descrita derivação por estrutura interna; o contraste apresentado é correção versus desempenho.

Nothing about using implementation structure versus external specifications is given; white-box/black-box is not the stated objective contrast.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — correta

Correta: registos esperados correspondem a função; tempo de resposta sob carga é uma restrição não funcional.

Specified records test what the function does, while response time under agreed workload tests how well it performs; functional versus non-functional is the best objective classification.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |
| 2026-10-27.5 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |
| 2026-10-27.6 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |
| 2026-10-27.7 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |
| 2026-10-27.8 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |
| 2026-10-27.9 | True | 1 | ['o4'] | 940623405d80906e6e6be3bdc84781114fc8033bf5ad5a5b96b45dbbc7e874ae |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


# tl-057 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-3.2.2 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd`.

Resposta pré-gabarito: `['o2']`; registada em `2026-11-07T01:22:27.943027+00:00`. Chave consultada depois: `['o2']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

## Resolução independente e fundamento

Os revisores já identificaram anomalias individualmente; agora analisam-nas em conjunto, decidem estado, responsáveis, ações e seguimento. Isso é comunicação e análise. Uma anomalia pode ser defeito, questão ou outra observação; não deve ser automaticamente tratada como defeito confirmado.

Raciocínio guardado antes da revelação:

Após registo individual, discutir e analisar anomalias para determinar defeitos, responsáveis, ações e seguimento é comunicação e análise. Não é início, revisão individual já feita nem correção/elaboração de relatórios ainda não descrita.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.
- Secção 3.2.2: EN páginas [35, 36]; PT páginas [38, 39].

- LO FL-3.2.2/K2: EN página 32; PT página 35.

EN pp.35–36 e PT pp.38–39 descrevem a análise de anomalias, decisões sobre estado/responsabilidade/ações e seguimento. A passagem entre páginas foi verificada individualmente. A redação dos rótulos em PT corresponde às atividades, sem se inventar uma etapa de correção já executada.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN acessível via web; PT consultado pela cópia oficial local após timeout. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Individually logged/registaram individualmente e now/agora separam atividades concluída e atual. Which anomalies are defects/quais são defeitos conserva a triagem, sem equiparar todos os registos a defeitos. Owners/responsáveis significa responsabilidade por tratar ações, não propriedade literal nem culpabilização. Follow-up/acompanhamento preserva decisão sobre seguimento.

| EN literal | PT literal |
| --- | --- |
| individually logged anomalies | registaram individualmente anomalias |
| which anomalies are defects | quais são defeitos |
| agree owners and actions | acordar responsáveis e ações |

## Contraevidência e outras respostas defensáveis

Numa reunião podem ocorrer várias atividades e algumas correções pequenas podem ser feitas de imediato. Contudo, o cenário descreve decidir o tratamento e avaliar seguimento, sem afirmar que o produto já foi corrigido ou os resultados finais relatados. A atividade atual não se torna revisão individual só porque usa os seus registos. O processo genérico pode ser adaptado e iterado; a classificação não exige sequência rígida universal.

## LO, nível K, explicações e dificuldade

K2: resumir a atividade do processo pelos seus resultados e diferenciá-la de início, análise individual e correção/relato. O cenário é suficientemente específico, embora o vocabulário aproxime a descrição do syllabus e torne a pergunta relativamente fácil. Explicações mantêm a distinção anomalia/defeito e não exigem um documento separado para toda observação não confirmada.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Os revisores registaram individualmente anomalias numa especificação de API. Reúnem-se agora para decidir quais são defeitos, acordar responsáveis e ações e avaliar a necessidade de acompanhamento. Que atividade de revisão está a decorrer?
```

Proposto atual — sem alteração

```text
Os revisores registaram individualmente anomalias numa especificação de API. Reúnem-se agora para decidir quais são defeitos, acordar responsáveis e ações e avaliar a necessidade de acompanhamento. Que atividade de revisão está a decorrer?
```

### Enunciado EN

Original

```text
Reviewers have individually logged anomalies in an API specification. They now meet to decide which anomalies are defects, agree owners and actions, and assess whether follow-up is needed. Which review activity is taking place?
```

Proposto atual — sem alteração

```text
Reviewers have individually logged anomalies in an API specification. They now meet to decide which anomalies are defects, agree owners and actions, and assess whether follow-up is needed. Which review activity is taking place?
```

### o1 — alternativa PT

Original

```text
Início da revisão.
```

Proposto atual — sem alteração

```text
Início da revisão.
```

### o1 — explicação PT

Original

```text
O início assegura o acesso, a preparação e o entendimento das funções antes da revisão, não a decisão sobre anomalias registadas.
```

Proposto atual — sem alteração

```text
O início assegura o acesso, a preparação e o entendimento das funções antes da revisão, não a decisão sobre anomalias registadas.
```

### o1 — alternativa EN

Original

```text
Review initiation.
```

Proposto atual — sem alteração

```text
Review initiation.
```

### o1 — explicação EN

Original

```text
Initiation ensures access, preparation and understanding of roles before the review, not the disposition of logged anomalies.
```

Proposto atual — sem alteração

```text
Initiation ensures access, preparation and understanding of roles before the review, not the disposition of logged anomalies.
```

### o2 — alternativa PT

Original

```text
Comunicação e análise.
```

Proposto atual — sem alteração

```text
Comunicação e análise.
```

### o2 — explicação PT

Original

```text
Esta atividade analisa as anomalias registadas e acorda o seu estado, responsáveis e ações necessárias.
```

Proposto atual — sem alteração

```text
Esta atividade analisa as anomalias registadas e acorda o seu estado, responsáveis e ações necessárias.
```

### o2 — alternativa EN

Original

```text
Communication and analysis.
```

Proposto atual — sem alteração

```text
Communication and analysis.
```

### o2 — explicação EN

Original

```text
This activity analyses logged anomalies and agrees their status, ownership and required actions.
```

Proposto atual — sem alteração

```text
This activity analyses logged anomalies and agrees their status, ownership and required actions.
```

### o3 — alternativa PT

Original

```text
Revisão individual.
```

Proposto atual — sem alteração

```text
Revisão individual.
```

### o3 — explicação PT

Original

```text
A revisão individual identifica e regista anomalias; o cenário descreve explicitamente a análise conjunta posterior.
```

Proposto atual — sem alteração

```text
A revisão individual identifica e regista anomalias; o cenário descreve explicitamente a análise conjunta posterior.
```

### o3 — alternativa EN

Original

```text
Individual review.
```

Proposto atual — sem alteração

```text
Individual review.
```

### o3 — explicação EN

Original

```text
Individual review identifies and logs anomalies; the scenario explicitly describes the subsequent joint analysis.
```

Proposto atual — sem alteração

```text
Individual review identifies and logs anomalies; the scenario explicitly describes the subsequent joint analysis.
```

### o4 — alternativa PT

Original

```text
Correção e elaboração de relatórios.
```

Proposto atual — sem alteração

```text
Correção e elaboração de relatórios.
```

### o4 — explicação PT

Original

```text
Essa atividade inclui corrigir defeitos confirmados, acompanhar ações e reportar resultados; aqui a equipa ainda decide o tratamento das anomalias.
```

Proposto atual — sem alteração

```text
Essa atividade inclui corrigir defeitos confirmados, acompanhar ações e reportar resultados; aqui a equipa ainda decide o tratamento das anomalias.
```

### o4 — alternativa EN

Original

```text
Fixing and reporting.
```

Proposto atual — sem alteração

```text
Fixing and reporting.
```

### o4 — explicação EN

Original

```text
That activity includes correcting confirmed defects, tracking actions and reporting results; here the team is still deciding the anomalies' disposition.
```

Proposto atual — sem alteração

```text
That activity includes correcting confirmed defects, tracking actions and reporting results; here the team is still deciding the anomalies' disposition.
```

### Explicação geral PT

Original

```text
Uma anomalia não é automaticamente um defeito confirmado. A comunicação e análise estabelece o seu tratamento antes do trabalho adequado de correção e elaboração de relatórios.
```

Proposto atual — sem alteração

```text
Uma anomalia não é automaticamente um defeito confirmado. A comunicação e análise estabelece o seu tratamento antes do trabalho adequado de correção e elaboração de relatórios.
```

### Explicação geral EN

Original

```text
An anomaly is not automatically a confirmed defect. Communication and analysis establishes its disposition before the appropriate correction and reporting work.
```

Proposto atual — sem alteração

```text
An anomaly is not automatically a confirmed defect. Communication and analysis establishes its disposition before the appropriate correction and reporting work.
```

## Avaliação das quatro alternativas

### o1 — distrator

Incorreta: início prepara acesso, funções e participantes; a análise de registos já está a decorrer.

Review initiation prepares participants, access and roles before review work; the scenario is already analysing individually logged anomalies.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o2 — correta

Correta: análise conjunta e decisões sobre estado, responsáveis, ações e seguimento são comunicação e análise.

Determining anomaly status, ownership, required actions and possible follow-up in discussion matches communication and analysis.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o3 — distrator

Incorreta: o registo individual já ocorreu; a atividade agora é a discussão conjunta posterior.

Individual anomaly identification has already occurred; the current joint status/action discussion is a different activity.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

### o4 — distrator

Incorreta: decidir tratamento não equivale ainda a corrigir defeitos confirmados ou relatar a conclusão.

Fixing defects and reporting results follow decisions; agreeing actions and classifying anomalies does not itself mean the product has been corrected or the review reported.

Justificação publicada coerente com a alternativa neste cenário; as ressalvas e contraexemplos do relatório delimitam a leitura. Não se transforma possibilidade em garantia nem responsabilidade predominante em exclusividade.

## Histórico de versões

| Revisão | Presente | Versão | Chave | SHA-256 canónico |
| --- | --- | --- | --- | --- |
| 2026-10-27.1 | False | — | — | — |
| 2026-10-27.2 | False | — | — | — |
| 2026-10-27.3 | False | — | — | — |
| 2026-10-27.4 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |
| 2026-10-27.5 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |
| 2026-10-27.6 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |
| 2026-10-27.7 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |
| 2026-10-27.8 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |
| 2026-10-27.9 | True | 1 | ['o2'] | 9f7f8f2563d79f5009d6199fb2822641b7326c13730f27ec516ccd3a215f67fd |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 13; aguardar auditoria antes de Lote 14.


