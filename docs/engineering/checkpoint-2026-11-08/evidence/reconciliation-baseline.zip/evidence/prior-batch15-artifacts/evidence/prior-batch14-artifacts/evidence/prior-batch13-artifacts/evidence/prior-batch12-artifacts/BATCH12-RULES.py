"""Read-only consistency/identity checks. Not automated semantic or human approval."""
import copy,hashlib,json,re,datetime
IDS=['tl-016', 'tl-018', 'tl-031', 'tl-034', 'tl-039', 'tl-042', 'tl-043', 'tl-045']
EXPECTED={'tl-016': ('FL-3.2.3', 'K1', 3, '8b262220a636b7ce047fa7127c111fa231496642e4409759e3a7c5b17a908b7c'), 'tl-018': ('FL-3.2.4', 'K2', 3, '9444c9830675b08a4435e5b969ea682d63039bf116249bf5300a9f51e5c397b9'), 'tl-031': ('FL-5.1.1', 'K2', 3, '0def0fa4d9038c8059cd8ad5d0f5d7b3c43ba08bcfbb23f345f6adf682b9c1e0'), 'tl-034': ('FL-5.2.3', 'K2', 2, '176b0c0fd90712ddaf00158b871ce4ed8a4b769d54cf1f86607539a81d713ca7'), 'tl-039': ('FL-6.1.1', 'K2', 2, '593a5bd756107b0387eb6803ca9e06a2fa38d9a4f47014c969f5381dbfe4692f'), 'tl-042': ('FL-1.4.3', 'K2', 1, '3537a79a65e62ee0c5c7d80eb17eaa751ce4a063548d877b778f9ddadbe0f735'), 'tl-043': ('FL-2.1.6', 'K2', 1, '70ecf4448366086f5c0ec828623f9044d477ab94a922bb40135d9e9af2c9b2d8'), 'tl-045': ('FL-5.3.2', 'K2', 1, 'ca486bd1028c0b64f5f84de119c1c1bc935b3798eae827fafd70bc6c6bc88f79')}
REFS={'tl-016': {'3.2.3': {'EN': [36], 'PT': [39]}, '3.2.4': {'EN': [36, 37], 'PT': [39, 40]}}, 'tl-018': {'3.2.4': {'EN': [36, 37], 'PT': [39, 40]}, '3.2.2': {'EN': [35, 36], 'PT': [38, 39]}}, 'tl-031': {'5.1.1': {'EN': [48], 'PT': [53]}, '1.4.3': {'EN': [20], 'PT': [22]}}, 'tl-034': {'5.2.3': {'EN': [52, 53], 'PT': [58, 59]}, '5.2.1': {'EN': [52], 'PT': [57]}}, 'tl-039': {'6.1': {'EN': [59], 'PT': [65]}}, 'tl-042': {'1.4.3': {'EN': [20], 'PT': [22]}}, 'tl-043': {'2.1.6': {'EN': [28], 'PT': [30]}}, 'tl-045': {'5.3.2': {'EN': [54, 55], 'PT': [60, 61]}, '5.3': {'EN': [53, 54], 'PT': [59]}}}
KEYS={'tl-016': ['o1'], 'tl-018': ['o1'], 'tl-031': ['o1'], 'tl-034': ['o1'], 'tl-039': ['o1'], 'tl-042': ['o1'], 'tl-043': ['o3'], 'tl-045': ['o3']}
LOPAGES={1: {'EN': [14], 'PT': [15]}, 2: {'EN': [24], 'PT': [26]}, 3: {'EN': [32], 'PT': [35]}, 5: {'EN': [47], 'PT': [52]}, 6: {'EN': [58], 'PT': [64]}}
def canonical(q):return hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(bank,matrix,comparisons,blind,projections,alternatives,sources,optional,reports,archives):
 assert matrix['scope']=='Phase 10H Batch 12 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert [d['questionId'] for d in matrix['decisions']]==IDS and len(comparisons)==len(projections)==len(blind['solutions'])==8
 assert len(alternatives)==len({(a['questionId'],a['optionId']) for a in alternatives})==32 and set(reports)==set(IDS)
 assert blind['reviewerType']=='AI' and not blind['publishedKeysConsultedBeforeRecording'] and not blind['publishedExplanationsConsultedBeforeRecording'] and not blind['ownerAccepted'] and not blind['humanApproved']
 assert set(archives)=={f'2026-10-27.{i}' for i in range(1,10)}
 assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64
 for s in sources['sources']:
  assert s['sha256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 checks=[]
 for d,c,projection,s in zip(matrix['decisions'],comparisons,projections,blind['solutions']):
  ident=d['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],canonical(q))==(lo,k,v,h) and q['correct']==KEYS[ident] and q['required']==1
  assert d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None and d['unresolvedMandatoryIssues']==[]
  assert d['existingKey']==d['proposedKey']==d['independentAnswer']==s['answer']==KEYS[ident] and s['questionId']==ident and d['keyComparison']=='MATCH'
  assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged'] and not d['priorNONEUsedAsEvidence']
  assert (d['learningObjective'],d['cognitiveLevel'],d['questionVersion'],d['requiredAnswers'])==(lo,k,v,1)
  assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==h and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
  assert c=={'questionId':ident,'original':q,'proposed':q,'changed':False}
  assert set(projection)=={'id','lo','level','text','options'} and projection['id']==ident and projection['text']==q['text'] and (projection['lo'],projection['level'])==(lo,k)
  assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  assert s['shuffledOrder']==[o['id'] for o in projection['options']] and len(s['reasonPT'])>100 and set(s['optionAssessmentsEN'])=={'o1','o2','o3','o4'}
  assert datetime.datetime.fromisoformat(s['recordedAt']).tzinfo
  for field in ['assessmentPT','counterEvidencePT','translationAssessmentPT','pedagogyAssessmentPT','editionDifferencePT']:assert len(d[field])>100
  assert d['references']==REFS[ident] and d['LOPages']==LOPAGES[q['chapter']]
  for refs in d['references'].values():
   for lang,pages in refs.items():assert set(pages)<=set(next(x['pagesConsulted'] for x in sources['sources'] if x['language']==lang))
  for a in [a for a in alternatives if a['questionId']==ident]:
   o=next(o for o in q['options'] if o['id']==a['optionId']);assert a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsAnswer']==(o['id'] in KEYS[ident])
   assert len(a['reviewPT'])>50 and a['reviewEN']==s['optionAssessmentsEN'][o['id']] and len(a['reviewEN'])>50 and a['references']==REFS[ident]
  assert len([a for a in alternatives if a['questionId']==ident])==4
  for pair in d['criticalPairs']:assert pair['en'] in json.dumps(q,ensure_ascii=False) and pair['pt'] in json.dumps(q,ensure_ascii=False)
  assert len(d['history'])==9
  for entry in d['history']:
   a=next((a for a in archives[entry['contentRevision']] if a['id']==ident),None);assert entry['present']==(a is not None)
   if a is not None:assert (entry['version'],entry['key'],entry['canonicalSHA256'],entry['equalCurrent'])==(a['version'],a['correct'],canonical(a),a==q)
  blocks=[]
  for lang in ['pt','en']:blocks.extend([q['text'][lang]]*2)
  for o in q['options']:
   for lang in ['pt','en']:
    for field in ['text','explanation']:blocks.extend([o[field][lang]]*2)
  for lang in ['pt','en']:blocks.extend([q['explanation'][lang]]*2)
  actualBlocks=40
  assert optional==[], 'No bank proposal is authorized or necessary in Batch12'
  assert re.findall(r'```text\n([\s\S]*?)\n```',reports[ident])==blocks
  prose=re.sub(r'```[\s\S]*?```','',reports[ident]);assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
  assert 'não aprovação humana' in prose and str(s['recordedAt']) in prose
  checks.append({'questionId':ident,'canonicalSHA256':h,'independentKey':KEYS[ident],'publishedKey':KEYS[ident],'alternativesVerified':4,'actualComparisonBlocks':actualBlocks,'optionalComparisonBlocks':len(blocks)-40,'priorNONEUsedAsEvidence':False})
 q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
 return {'result':'PASS','questions':checks,'reviewedQuestions':8,'reviewedAlternatives':32,'actualComparisonBlocks':320,'optionalComparisonBlocks':0,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args, global_check, reference_bank):
 check(*args)
 cases=[('wrong key',1,lambda a:a['decisions'][0].update(existingKey=['o2'])),('second answer accepted',5,lambda a:a[1].update(supportsAnswer=True)),('missing option assessment',5,lambda a:a.pop()),('PT text incompatible with source',5,lambda a:a[0]['text'].update(pt='adulterado')),('missing published explanation',5,lambda a:a[0]['publishedExplanation'].update(pt='')),('missing reasoning',3,lambda a:a['solutions'][0].update(reasonPT='')),('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank')),('false human approval',1,lambda a:a['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda a:a['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('invalid source pages',1,lambda a:a['decisions'][0]['references']['3.2.3'].update(EN=[999])),('corrupted historical question',9,lambda a:a['2026-10-27.9'][15]['explanation'].update(pt='adulterado')),('NONE reused as approval',1,lambda a:a['decisions'][0].update(priorNONEUsedAsEvidence=True)),('key leaked into blind projection',4,lambda a:a[0].update(correct=['o1'])),('unauthorized proposal added or applied',7,lambda a:a.append({'questionId':'tl-016','applied':True})),('missing counterevidence',1,lambda a:a['decisions'][1].update(counterEvidencePT=''))]
 rejected=[]
 for name,i,mutate in cases:
  a=copy.deepcopy(list(args));mutate(a[i])
  # Preserve the exact original tl-002 mutation and rejection expectation.
  # It belongs to full-bank protection; all review-evidence cases stay scoped.
  try:
   if name=='unauthorized bank edit':global_check(a[0],reference_bank)
   else:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 scoped=copy.deepcopy(list(args));next(q for q in scoped[0] if q['id']=='tl-016')['text']['en']='adulterated bank'
 try:check(*scoped)
 except AssertionError:rejected.append('reviewed question tl-016 edit rejected by scoped guard')
 else:raise AssertionError('Scoped false positive for tl-016')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'originalTl002CasePreserved':True,'globalCases':['unauthorized bank edit'],'scopedCases':len(rejected)-1,'claimLimit':'Combined dispatch preserves separate scoped and global contracts; not automatic semantic proof.'}
