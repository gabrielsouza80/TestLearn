"""Pure full-bank equality protection extracted from Batch12 integrity().
Reference is pinned to the already authenticated Batch11 ZIP, never to candidate data.
No filesystem/network/subprocess operations; safe for portable read-only verification.
"""
import copy,hashlib,json
BASELINE_ZIP_SHA256='57db2636f49d56402944f71f8b87d14b0235cc25cd2d47d5b01951b3730c6188'
REFERENCE_FILE_SHA256='9a6bc09d6ab5a512cb53ea26dc7a1da5ae465167bf5e2b6ba8c9c9b34f332615'
REFERENCE_CANONICAL_SHA256='3b1faffe3e89031fac6a76ee30e8f82e5a81d3ebea58f1857d0f36391bf9320a'
def canonical(bank):return hashlib.sha256(json.dumps(bank,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load_reference(raw):
 assert hashlib.sha256(raw).hexdigest()==REFERENCE_FILE_SHA256,'Reference bytes differ from authenticated Batch11 member'
 bank=json.loads(raw);assert canonical(bank)==REFERENCE_CANONICAL_SHA256,'Reference semantic hash mismatch'
 return bank
def check_bank(current,reference):
 assert canonical(reference)==REFERENCE_CANONICAL_SHA256,'Reference was changed or derived from altered candidate'
 assert current==reference,'Unauthorized bank edit: full90 objects differ from authenticated Batch11 baseline'
 assert len(current)==len({q['id'] for q in current})==90
 assert sum(len(q['options']) for q in current)==364 and len({q['lo'] for q in current})==64
 q=next(q for q in current if q['id']=='tl-001');assert q['correct']==['o1','o4'] and q['required']==2
 return {'result':'PASS','scope':'All90 complete objects: text, explanations, keys, versions, LO/K and metadata','questions':90,'alternatives':364,'learningObjectives':64,'baselineCanonicalSHA256':REFERENCE_CANONICAL_SHA256}
def negative_checks(reference):
 check_bank(reference,reference);rejected=[]
 def expect_rejection(name,current,expected):
  try:check_bank(current,expected)
  except AssertionError:rejected.append(name)
  else:raise AssertionError('Global false positive: '+name)
 for item in reference:
  bank=copy.deepcopy(reference);next(q for q in bank if q['id']==item['id'])['text']['en']='adulterated bank'
  expect_rejection('text mutation '+item['id'],bank,reference)
 for name,mutate in [('key',lambda b:b[1].update(correct=['o4'])),('version',lambda b:b[1].update(version=999)),('explanation',lambda b:b[1]['explanation'].update(pt='adulterado')),('missing ID',lambda b:b.pop()),('duplicate ID',lambda b:b[1].update(id=b[0]['id']))]:
  bank=copy.deepcopy(reference);mutate(bank);expect_rejection(name,bank,reference)
 altered=copy.deepcopy(reference);altered[1]['text']['en']='adulterated bank';expect_rejection('poisoned expected reference',altered,altered)
 return {'result':'PASS','negativeCasesRejected':len(rejected),'perQuestionMutations':90,'cases':rejected,'referenceNeverUpdatedFromCandidate':True}
