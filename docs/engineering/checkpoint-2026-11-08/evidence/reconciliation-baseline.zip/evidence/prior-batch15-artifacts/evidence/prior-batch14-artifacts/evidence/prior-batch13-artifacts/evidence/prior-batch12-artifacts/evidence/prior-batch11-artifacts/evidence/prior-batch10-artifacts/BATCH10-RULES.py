"""Read-only standard-library evidence checks, not automatic academic approval."""
import copy,hashlib,json,re,datetime
def canonical(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
HASH='387ffd2ae2e1b9c1e9c7f95dc420c930a4b165ceb3c1f2f1cef68ff7e4726a9a'
def check(bank,matrix,comparison,blind,projection,alternatives,sources,optional,report):
 assert matrix['scope']=='Phase 10H Batch 10 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert len(matrix['decisions'])==1;d=matrix['decisions'][0];q=next(q for q in bank if q['id']=='tl-062')
 assert (q['lo'],q['level'],q['version'],q['correct'],q['required'])==('FL-5.1.2','K1',1,['o4'],1) and canonical(q)==HASH
 assert d['questionId']=='tl-062' and d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None
 assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged']
 assert d['existingKey']==d['proposedKey']==d['independentAnswer']==blind['answer']==['o4']
 assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==HASH and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
 assert d['learningObjective']==q['lo'] and d['cognitiveLevel']==q['level'] and d['questionVersion']==1 and d['requiredAnswers']==1
 assert comparison['questionId']=='tl-062' and comparison['original']==comparison['proposed']==q and comparison['changed'] is False
 assert set(projection)=={'id','lo','level','text','options'} and projection['id']==q['id'] and projection['text']==q['text'] and projection['lo']==q['lo'] and projection['level']==q['level']
 assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((q['id']+o['id']).encode()).hexdigest())
 assert blind['questionId']=='tl-062' and blind['reviewerType']=='AI' and not blind['alternativeKeyConsultedBeforeRecording'] and not blind['storedExplanationsConsultedBeforeRecording'] and not blind['humanApproved'] and not blind['ownerAccepted']
 assert datetime.datetime.fromisoformat(blind['recordedAt']).tzinfo is not None and set(blind['distractors'])=={'o1','o2','o3'} and len(blind['reasonPT'])>100 and len(blind['reasonEN'])>100
 assert len(alternatives)==4 and {a['optionId'] for a in alternatives}=={'o1','o2','o3','o4'}
 for a in alternatives:
  o=next(o for o in q['options'] if o['id']==a['optionId'])
  assert a['questionId']=='tl-062' and a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsIndependentAnswer']==(o['id']=='o4')
  assert all(len(a['review'][l])>60 for l in ['en','pt']) and len(a['counterexampleBoundaryEN'])>100
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 for s in sources['sources']:
  assert s['sections']['5.1.2']==([48,49] if s['language']=='EN' else [53,54]) and s['sections']['FL-5.1.2']==([47] if s['language']=='EN' else [52])
  assert s['localSHA256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert len(d['criticalPairs'])==8
 for en,pt,status in d['criticalPairs']:
  assert en in json.dumps(q,ensure_ascii=False) and pt in json.dumps(q,ensure_ascii=False) and len(status)>15
 for k in ['reasonPT','reasonEN','KlevelAssessment','contraryEvidence','explanationQuality']:assert len(d[k])>100
 assert optional['kind']=='OPTIONAL_EDITORIAL_NOT_CONFIRMED_DEFECT' and not optional['applied'] and optional['requiresExplicitOwnerAuthorization']
 assert optional['path']==['explanation'] and optional['original']==q and optional['currentText']==q['explanation'] and optional['keyImpact']=='NONE'
 candidate=copy.deepcopy(q);candidate['explanation']=optional['suggestedText'];assert candidate==optional['candidate'] and canonical(candidate)==optional['candidateCanonicalSHA256'] and candidate!=q
 assert len(optional['testsIfAuthorized'])==4
 blocks=[]
 for l in ['pt','en']:blocks.extend([q['text'][l]]*2)
 for o in q['options']:
  for l in ['pt','en']:
   for k in ['text','explanation']:blocks.extend([o[k][l]]*2)
 for l in ['pt','en']:blocks.extend([q['explanation'][l]]*2)
 for l in ['pt','en']:blocks.append(optional['suggestedText'][l])
 assert len(blocks)==42 and re.findall(r'```text\n([\s\S]*?)\n```',report)==blocks
 # Reject identifier collisions in prose only; do not rewrite exact source blocks, hashes, paths or JSON.
 prose=re.sub(r'```[\s\S]*?```','',report)
 assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
 assert 'não aprovação humana' in report
 return {'result':'PASS','questionId':'tl-062','canonicalSHA256':HASH,'independentKey':['o4'],'publishedKey':['o4'],'alternativesVerified':4,'actualComparisonBlocks':40,'optionalCandidateBlocks':2,'criticalPairs':8,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args):
 check(*args);tests=[('wrong key',1,lambda x:x['decisions'][0].update(existingKey=['o1'])),('false human approval',1,lambda x:x['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda x:x['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('missing distractor',5,lambda x:x.pop()),('altered PT option',5,lambda x:x[0]['text'].update(pt='adulterado')),('two supported answers',5,lambda x:x[0].update(supportsIndependentAnswer=True)),('key leakage',4,lambda x:x.update(correct=['o4'])),('missing blind rationale',3,lambda x:x.update(reasonPT='')),('invented source page',6,lambda x:x['sources'][0]['sections'].update({'5.1.2':[999]})),('optional applied',7,lambda x:x.update(applied=True)),('changed published comparison',2,lambda x:x.update(changed=True)),('missing contrary evidence',1,lambda x:x['decisions'][0].update(contraryEvidence=''))]
 rejected=[]
 for name,i,mutate in tests:
  a=copy.deepcopy(list(args));mutate(a[i])
  try:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('Negative case not rejected: '+name)
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected}
