from pathlib import Path
import json,subprocess,sys,hashlib,datetime,copy,runpy,re,zipfile,tempfile
out=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');f=root/'docs/academic/phase10h-batch13-2026-11-06';rec=out/'recovery-evidence'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
pre=read(out/'preflight.json');resume=read(rec/'resume-snapshot.json');spacing=read(rec/'spacing-result.json')
assert read(out/'batch13-specific-result.json')['exitCode']==0
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools');import pymupdf
sourceEvidence=[]
for s in read(f/'sources.json')['sources']:
    b=(Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0')/s['fileName']).read_bytes();assert sha(b)==s['sha256']
    d=pymupdf.open(stream=b,filetype='pdf');assert len(d)==s['pageCount']
    pages=[19,20] if s['language']=='EN' else [21]
    texts=[d[n-1].get_text() for n in pages]
    assert '1.4.2' in ''.join(texts)
    sourceEvidence.append({'language':s['language'],'fileName':s['fileName'],'sha256':sha(b),'pagesRead':pages,'section':'1.4.2','meaning':'Context influences process, techniques, coverage and testware detail; page and section numbers unchanged by two inserted spaces.'})
(rec/'source-reference-check.json').write_text(json.dumps({'result':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sourceEvidence},indent=2)+'\n')
# Reauthenticate prior complete package and run the already inspected historical verifier.
zpath=Path('C:/Users/gabri/Downloads')/pre['priorPackageName'];assert sha(zpath.read_bytes())==pre['priorPackageSHA256']
temp=Path(tempfile.mkdtemp(prefix='TestLearn-B13-prior-clean-'))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==366
    for n in z.namelist():
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n and ':' not in n
    z.extractall(temp)
    oldm=json.loads(z.read('MANIFEST.json'));assert len(oldm['files'])==365
    for e in oldm['files']:
        b=z.read(e['relativePath']);assert (len(b),sha(b))==(e['sizeBytes'],e['sha256'])
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run([sys.executable,'-B',str(temp/'VERIFY-PACKAGE.py')],capture_output=True,text=True,encoding='utf8')
(rec/'prior-package-recheck.log').write_text(p.stdout+p.stderr,encoding='utf8');assert p.returncode==0,p.stderr
(rec/'prior-package-recheck.json').write_text(json.dumps({'command':[sys.executable,'-B',str(temp/'VERIFY-PACKAGE.py')],'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'sha256':sha(zpath.read_bytes()),'CRC':'PASS','files':366,'hashes':365,'verifier':json.loads(p.stdout)},indent=2)+'\n')
g=runpy.run_path(str(out/'GLOBAL13-RULES.py'));rules=runpy.run_path(str(out/'BATCH13-RULES.py'));bank=read(out/'runtime-before.json')['bank'];reference=g['load_reference']((out/'reference-bank.json').read_bytes());matrix=read(f/'decision-matrix.json')
args=[bank,matrix,read(f/'exact-comparisons.json'),read(f/'blind-solutions.json'),read(f/'blind-projection.json'),read(f/'alternative-assessments.json'),read(f/'sources.json'),read(f/'optional-candidates.json'),{d['questionId']:(f/'reports'/(d['questionId']+'.md')).read_text(encoding='utf8') for d in matrix['decisions']},{f'2026-10-27.{i}':read(root/f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}]
rules['check'](*args);g['check_bank'](bank,reference)
def rejected(call):
    try:call()
    except AssertionError:return True
    return False
oldargs=copy.deepcopy(args);oldargs[8]['tl-049']=(rec/'original/tl-049.md').read_text(encoding='utf8')
assert rejected(lambda:rules['check'](*oldargs))
mut=copy.deepcopy(args);mut[8]['tl-049']=mut[8]['tl-049'].replace('secção 1.4.2','secção1.4.2');assert rejected(lambda:rules['check'](*mut))
outside=copy.deepcopy(args);outside[0][1]['text']['en']='adulterated bank';assert outside[0][1]['id']=='tl-002' and outside[0][1]!=args[0][1]
assert rules['check'](*outside)['result']=='PASS' and rejected(lambda:g['check_bank'](outside[0],reference))
inside=copy.deepcopy(args);next(q for q in inside[0] if q['id']=='tl-048')['text']['en']='adulterated bank';assert rejected(lambda:rules['check'](*inside))
assert rejected(lambda:g['check_bank'](outside[0],outside[0]))
route={'result':'PASS','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalFullGuardStillRED':True,'correctedFullGuardGREEN':True,'syntheticSpacingRegressionRejected':True,'tl002MutationActuallyInjected':True,'tl002ScopedControlPassed':True,'tl002GlobalRejected':True,'tl048ScopedRejected':True,'poisonedReferenceRejected':True,'guardsSHA256':{n:sha((out/n).read_bytes()) for n in ['BATCH13-RULES.py','GLOBAL13-RULES.py']}}
(rec/'red-green-routing.json').write_text(json.dumps(route,indent=2)+'\n')
for n,h in resume['batch13FilesSHA256'].items():assert sha((root/n).read_bytes())==(spacing['correctedSHA256'] if n.endswith('/reports/tl-049.md') else h)
for name in route['guardsSHA256']:assert route['guardsSHA256'][name]==resume['auxFilesSHA256'][name]
recovery=f'''# Lote 13 — recuperação da falha de legibilidade

Estado atual: recuperação demonstrada. A falha histórica continua FAIL em STOP-FAILURE.json e verification.md. Estes documentos não foram reescritos.

## Diagnóstico e correção mínima

Causa A: erro de espaçamento no relatório novo tl-049. A expressão regular também é ampla: encontrou `ão1` dentro de `secção1.4.2`, mas o trecho realmente precisava de espaço. Existia igualmente `na20` no mesmo parágrafo. A falha foi reproduzida antes da correção com exit code 1; não era alteração ao banco.

Foram inseridos exatamente dois espaços: `continua na20;` → `continua na 20;` e `secção1.4.2 na p.21.` → `secção 1.4.2 na p.21.`. Secção e páginas foram mantidas e reconferidas nas cópias oficiais locais: EN v4.0.1, páginas físicas 19–20; PT v4.0 tradução 1.0, página física 21. Não houve alteração académica nem regeneração dos relatórios.

SHA-256 original: `{spacing['originalSHA256']}`.

SHA-256 corrigido: `{spacing['correctedSHA256']}`.

O relatório original está preservado em evidence/recovery/original/tl-049.md no pacote; o diff exato está em evidence/recovery/report-only.diff. Os 18 outros documentos iniciais do lote permanecem byte a byte idênticos. Os 352 ficheiros anteriores ao lote, incluindo 149 documentos académicos anteriores, permanecem preservados. Não se alega que todos os 19 documentos iniciais sejam idênticos.

## Demonstração e limites

O guard original e o global não foram modificados. O relatório preservado continua a falhar no guard completo; o corrigido passa e a remoção sintética do espaço em `secção 1.4.2` volta a falhar. Blocos literais do banco, soluções pré-gabarito, horários, decisões e expectativas não mudaram.

A alteração em tl-002 chega à proteção global: o guard do lote aceita esse controlo fora do seu âmbito e o global rejeita o banco adulterado. O guard específico rejeita a alteração em tl-048. Uma referência global igualmente adulterada é rejeitada. Resultados e hashes em evidence/recovery/red-green-routing.json.

Os oito pareceres académicos anteriores permanecem ACCEPT_AS_IS; a revisão cega não foi repetida. Não há OWNER_ACCEPTED ou HUMAN_APPROVED novo. Integridade técnica não é verdade académica nem revisão humana independente. A Fase 10H permanece aberta; não iniciar Lote 14.
'''
with (f/'recovery.md').open('x',encoding='utf8') as h:h.write(recovery)
result=read(out/'batch13-specific-result.json')
executions={name:read(out/(name+'-result.json')) for name in ['targeted-vitest','multiple-answer-scoring','diff-check']}
assert all(x['exitCode']==0 for x in executions.values())
text='''# Lote 13 — revalidação após recuperação

Execuções novas de 2026-11-07, horários UTC. As execuções anteriores e a interrupção foram preservadas separadamente; os resultados abaixo não são herdados.

| Verificação nova | Resultado |
| --- | --- |
| Guard específico completo | PASS: oito questões, 32 alternativas e 320 blocos literais antes/depois |
| Casos negativos encaminhados | PASS: 16 rejeitados; 15 específicos e um global, sem atribuir tl-002 ao âmbito específico |
| Proteção global | PASS: 90 objetos completos iguais à referência imutável autenticada |
| Negativos globais | PASS: 96 rejeitados, incluindo texto em cada questão, chave, versão, explicação, ID ausente/duplicado e referência adulterada |
| Testes unitários direcionados | PASS: 85 testes em seis ficheiros |
| Seleção múltipla tl-001 | PASS: oito casos sintéticos; conjunto correto o1 e o4, sem aceitar seleção parcial; sem LocalStorage |
| Integridade e histórico | PASS: 90 IDs/chaves, 364 alternativas, 64 objetivos, revisão .10 e nove arquivos; 352 ficheiros anteriores preservados |
| git diff --check | PASS; não inspeciona documentos não rastreados, que têm validação própria |

Os testes de auditoria académica, histórico, backup, cobertura do syllabus, manutenção de qualidade e blueprint foram realmente reexecutados. Não houve skips nestes 85 testes. Comandos completos, horários, exit codes e logs ficam em evidence/checks.

JSON e referências do dossiê são verificados pelo guard e pelo verificador portátil. Apenas os dois documentos novos de recuperação são formatados com Prettier; os 19 documentos iniciais ficam congelados, com a única exceção autorizada dos dois espaços em tl-049. Os blocos textuais originais são comparados literalmente pelo guard, em vez de reformatados. Não se alega um PASS global de Prettier sobre documentos preservados.

TypeScript, ESLint, build e E2E completos não foram repetidos: esta recuperação não altera banco, código funcional, testes do projeto, pontuação ou persistência. Os guards não comprovam equivalência semântica automaticamente. A cópia oficial local PT foi usada; mantém-se a limitação histórica do endpoint PT com timeout.

README.md, verification.md e STOP-FAILURE.json iniciais permanecem como evidência histórica da interrupção. Este documento e recovery.md descrevem a recuperação. A exportação só é permitida após os restantes gates de formato, inventário e pacote passarem; os resultados de CRC, extração e adulterações do pacote serão apresentados pelo export-result.json externo e pela execução do verificador portátil.

## Metadados novos

```json
'''+json.dumps({'specific':read(out/'batch13-specific-execution.json'),'integrity':read(out/'integrity-execution.json'),'commands':executions,'redGreenRouting':route},ensure_ascii=False,indent=2)+'\n```\n'
with (f/'revalidation.md').open('x',encoding='utf8') as h:h.write(text)
print(json.dumps({'result':'PASS','routing':route,'priorPackageReauthenticated':True,'newRecoveryDocuments':2},indent=2))
