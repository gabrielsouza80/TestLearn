from pathlib import Path
import json,datetime,subprocess,hashlib
out=Path(__file__).parent;root=Path('C:/TestLearn/tmp/develop-workspace');folder='docs/academic/phase10h-batch13-2026-11-06/'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
args=['node','node_modules/prettier/bin/prettier.cjs','--check',folder+'recovery.md',folder+'revalidation.md']
started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=root,capture_output=True,text=True,encoding='utf8')
(out/'format-check.log').write_text(p.stdout+p.stderr,encoding='utf8')
(out/'format-check-result.json').write_text(json.dumps({'command':args,'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'scope':'Only two newly added recovery documents; original19 frozen except two authorized spaces. No global Prettier claim.'},indent=2)+'\n')
assert p.returncode==0,p.stdout+p.stderr
pre=read(out/'preflight.json');resume=read(out/'recovery-evidence/resume-snapshot.json');spacing=read(out/'recovery-evidence/spacing-result.json')
for n,h in pre['existingFilesSHA256'].items():assert sha((root/n).read_bytes())==h,n
for n,h in resume['batch13FilesSHA256'].items():assert sha((root/n).read_bytes())==(spacing['correctedSHA256'] if n==folder+'reports/tl-049.md' else h),n
for n in ['BATCH13-RULES.py','GLOBAL13-RULES.py']:assert sha((out/n).read_bytes())==resume['auxFilesSHA256'][n]
new=[p for p in (root/folder).rglob('*') if p.is_file()];assert len(new)==21
for p in new:
    t=p.read_text(encoding='utf8');assert '\x00' not in t and t.endswith('\n'),str(p)
    if p.suffix=='.json':json.loads(t)
    assert not any(line.rstrip()!=line for line in t.splitlines()),'Trailing whitespace '+str(p)
result={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'existing352Preserved':True,'initialBatch13DocumentsUnchanged':18,'authorizedReportChange':{'relativePath':folder+'reports/tl-049.md','beforeSHA256':spacing['originalSHA256'],'afterSHA256':spacing['correctedSHA256'],'insertedSpaces':2},'newRecoveryDocuments':2,'validJSON':True,'newFilesUTF8AndWhitespaceChecks':21,'guardsUnchanged':True,'blindEvidenceUnchanged':True,'newOwnerAccepted':0,'newHumanApproved':0}
(out/'final-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));print(p.stdout if hasattr(p,'stdout') else 'Prettier check PASS')
