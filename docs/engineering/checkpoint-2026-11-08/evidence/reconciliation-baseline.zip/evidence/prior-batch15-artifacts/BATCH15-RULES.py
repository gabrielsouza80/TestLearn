"""Read-only consistency/identity checks. Not automated semantic or human approval."""
import copy,hashlib,json,re,datetime
IDS=['tl-069', 'tl-070', 'tl-075', 'tl-079', 'tl-080', 'tl-081', 'tl-082', 'tl-083']
EXPECTED={'tl-069': ('FL-2.1.3', 'K1', 2, '5ceb5524a517d84ee85d867b65e8a77343dc9f263c251630ae0cfe0c0044bf88'), 'tl-070': ('FL-4.1.1', 'K2', 1, '568f18f9033d037ac35d0a341a482505c60ffce44446c8ccff8b53ff9ec986e8'), 'tl-075': ('FL-5.4.1', 'K2', 1, 'e3573db6fb3c6e18cfacf71d6f34df8f7caf4a5648212039e7db869a0681f723'), 'tl-079': ('FL-6.1.1', 'K2', 1, '3d281fff792051c8ea68d1fc2fef2701b2c93c95e14ce5a97b41889bb608fc29'), 'tl-080': ('FL-6.2.1', 'K1', 1, 'a8c56669c1259bbd90abb7bc6caef7c99ef82cd728adfc697df2c1b0b0ade32b'), 'tl-081': ('FL-1.5.2', 'K1', 1, '7f524a77ae865771fe94ed90d343caf777ec06bd1ac38b2c2a6542e9c6f35a43'), 'tl-082': ('FL-5.1.7', 'K2', 1, '6db583fcdba368ec8ddb760a64796f2c27ad1229099909ff214bef8c7ebcf1af'), 'tl-083': ('FL-3.2.4', 'K2', 1, 'f31d575236f2c92922a162f519a70646956cff3d2057c8a2628276d9b5af521d')}
KEYS={'tl-069': ['o3'], 'tl-070': ['o4'], 'tl-075': ['o3'], 'tl-079': ['o4'], 'tl-080': ['o2'], 'tl-081': ['o3'], 'tl-082': ['o1'], 'tl-083': ['o2', 'o4']}
FORMAT={'tl-069': (4, 1), 'tl-070': (4, 1), 'tl-075': (4, 1), 'tl-079': (4, 1), 'tl-080': (4, 1), 'tl-081': (4, 1), 'tl-082': (4, 1), 'tl-083': (5, 2)}
REFS={'tl-069': {'2.1.3': {'EN': [26], 'PT': [28]}}, 'tl-070': {'4.1': {'EN': [39], 'PT': [42]}}, 'tl-075': {'5.4': {'EN': [56], 'PT': [62]}}, 'tl-079': {'6.1': {'EN': [59], 'PT': [65]}, '4.3.2': {'EN': [43], 'PT': [46, 47]}}, 'tl-080': {'6.2': {'EN': [59, 60], 'PT': [65, 66]}}, 'tl-081': {'1.5.2': {'EN': [22], 'PT': [24]}}, 'tl-082': {'5.1.7': {'EN': [51], 'PT': [56, 57]}}, 'tl-083': {'3.2.4': {'EN': [36, 37], 'PT': [39, 40]}}}
LOPAGES={1: {'EN': [14], 'PT': [15]}, 2: {'EN': [24], 'PT': [26]}, 3: {'EN': [32], 'PT': [35]}, 4: {'EN': [38], 'PT': [41]}, 5: {'EN': [47], 'PT': [52]}, 6: {'EN': [58], 'PT': [64]}}
def canonical(q):return hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(bank,matrix,comparisons,blind,projections,alternatives,sources,optional,reports,archives):
 assert matrix['scope']=='Phase 10H Batch 15 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert [d['questionId'] for d in matrix['decisions']]==IDS and len(comparisons)==len(projections)==len(blind['solutions'])==8
 assert len(alternatives)==len({(a['questionId'],a['optionId']) for a in alternatives})==33 and set(reports)==set(IDS)
 assert blind['reviewerType']=='AI' and not blind['publishedKeysConsultedBeforeRecording'] and not blind['publishedExplanationsConsultedBeforeRecording'] and not blind['ownerAccepted'] and not blind['humanApproved']
 assert set(archives)=={f'2026-10-27.{i}' for i in range(1,10)}
 assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64
 for s in sources['sources']:
  assert s['sha256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 checks=[]
 for d,c,projection,s in zip(matrix['decisions'],comparisons,projections,blind['solutions']):
  ident=d['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],canonical(q))==(lo,k,v,h) and q['correct']==KEYS[ident] and q['required']==FORMAT[ident][1] and len(q['options'])==FORMAT[ident][0]
  assert d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None and d['unresolvedMandatoryIssues']==[]
  assert d['existingKey']==d['proposedKey']==d['independentAnswer']==s['answer']==KEYS[ident] and s['questionId']==ident and d['keyComparison']=='MATCH'
  assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged'] and not d['priorNONEUsedAsEvidence']
  assert (d['learningObjective'],d['cognitiveLevel'],d['questionVersion'],d['requiredAnswers'])==(lo,k,v,FORMAT[ident][1])
  assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==h and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
  assert c=={'questionId':ident,'original':q,'proposed':q,'changed':False}
  assert set(projection)=={'id','lo','level','text','options'} and projection['id']==ident and projection['text']==q['text'] and (projection['lo'],projection['level'])==(lo,k)
  assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  assert s['shuffledOrder']==[o['id'] for o in projection['options']] and len(s['reasonPT'])>100 and set(s['optionAssessmentsEN'])=={o['id'] for o in q['options']}
  assert datetime.datetime.fromisoformat(s['recordedAt']).tzinfo
  for field in ['assessmentPT','counterEvidencePT','translationAssessmentPT','pedagogyAssessmentPT','editionDifferencePT']:assert len(d[field])>100
  assert d['references']==REFS[ident] and d['LOPages']==LOPAGES[q['chapter']]
  for refs in d['references'].values():
   for lang,pages in refs.items():assert set(pages)<=set(next(x['pagesConsulted'] for x in sources['sources'] if x['language']==lang))
  for a in [a for a in alternatives if a['questionId']==ident]:
   o=next(o for o in q['options'] if o['id']==a['optionId']);assert a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsAnswer']==(o['id'] in KEYS[ident])
   assert len(a['reviewPT'])>50 and a['reviewEN']==s['optionAssessmentsEN'][o['id']] and len(a['reviewEN'])>50 and a['references']==REFS[ident]
  assert len([a for a in alternatives if a['questionId']==ident])==FORMAT[ident][0]
  for pair in d['criticalPairs']:assert pair['en'] in json.dumps(q,ensure_ascii=False) and pair['pt'] in json.dumps(q,ensure_ascii=False)
  assert len(d['history'])==9
  for entry in d['history']:
   a=next((a for a in archives[entry['contentRevision']] if a['id']==ident),None);assert entry['present']==(a is not None)
   if a is not None:assert (entry['version'],entry['key'],entry['canonicalSHA256'],entry['equalCurrent'])==(a['version'],a['correct'],canonical(a),a==q)
  blocks=[]
  for lang in ['pt','en']:blocks.extend([q['text'][lang]]*2)
  for o in q['options']:
   for lang in ['pt','en']:
    for field in ['text','explanation']:blocks.extend([o[field][lang]]*2)
  for lang in ['pt','en']:blocks.extend([q['explanation'][lang]]*2)
  actualBlocks=8+8*FORMAT[ident][0]
  assert optional==[], 'No bank proposal is authorized or necessary in Batch15'
  assert re.findall(r'```text\n([\s\S]*?)\n```',reports[ident])==blocks
  prose=re.sub(r'```[\s\S]*?```','',reports[ident]);assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
  assert 'não aprovação humana' in prose and str(s['recordedAt']) in prose
  checks.append({'questionId':ident,'canonicalSHA256':h,'independentKey':KEYS[ident],'publishedKey':KEYS[ident],'alternativesVerified':FORMAT[ident][0],'actualComparisonBlocks':actualBlocks,'optionalComparisonBlocks':len(blocks)-actualBlocks,'priorNONEUsedAsEvidence':False})
 q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
 return {'result':'PASS','questions':checks,'reviewedQuestions':8,'reviewedAlternatives':33,'actualComparisonBlocks':328,'optionalComparisonBlocks':0,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args, global_check, reference_bank):
 check(*args)
 cases=[('wrong key',1,lambda a:a['decisions'][0].update(existingKey=['o1'])),('second answer accepted',5,lambda a:a[0].update(supportsAnswer=True)),('missing option assessment',5,lambda a:a.pop()),('PT text incompatible with source',5,lambda a:a[0]['text'].update(pt='adulterado')),('missing published explanation',5,lambda a:a[0]['publishedExplanation'].update(pt='')),('missing reasoning',3,lambda a:a['solutions'][0].update(reasonPT='')),('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank')),('false human approval',1,lambda a:a['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda a:a['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('invalid source pages',1,lambda a:a['decisions'][0]['references']['2.1.3'].update(EN=[999])),('corrupted historical question',9,lambda a:next(q for q in a['2026-10-27.9'] if q['id']=='tl-069')['explanation'].update(pt='adulterado')),('NONE reused as approval',1,lambda a:a['decisions'][0].update(priorNONEUsedAsEvidence=True)),('key leaked into blind projection',4,lambda a:a[0].update(correct=['o1'])),('unauthorized proposal added or applied',7,lambda a:a.append({'questionId':'tl-069','applied':True})),('missing counterevidence',1,lambda a:a['decisions'][1].update(counterEvidencePT='')),('partial tl-083 key',1,lambda a:a['decisions'][-1].update(existingKey=['o2'])),('extra tl-083 key',1,lambda a:a['decisions'][-1].update(existingKey=['o2','o4','o5']))]
 rejected=[]
 for name,i,mutate in cases:
  a=copy.deepcopy(list(args));mutate(a[i])
  # Preserve the exact original tl-002 mutation and rejection expectation.
  # It belongs to full-bank protection; all review-evidence cases stay scoped.
  try:
   if name=='unauthorized bank edit':global_check(a[0],reference_bank)
   else:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 scoped=copy.deepcopy(list(args));next(q for q in scoped[0] if q['id']=='tl-069')['text']['en']='adulterated bank'
 try:check(*scoped)
 except AssertionError:rejected.append('reviewed question tl-069 edit rejected by scoped guard')
 else:raise AssertionError('Scoped false positive for tl-069')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'originalTl002CasePreserved':True,'globalCases':['unauthorized bank edit'],'scopedCases':len(rejected)-1,'claimLimit':'Combined dispatch preserves separate scoped and global contracts; not automatic semantic proof.'}
