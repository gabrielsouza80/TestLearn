"""Inspect before execution. Python 3.9+ standard library; read-only, no network.
Consistency is not academic truth or a human approval. External ZIP SHA authenticates delivery.
"""
import sys
sys.dont_write_bytecode=True
if not __debug__:raise SystemExit('Do not use Python -O: assertions must remain enabled.')
from pathlib import Path,PurePosixPath
import json,hashlib,runpy,re,datetime,copy
root=Path(__file__).resolve().parent
def safe(n):
    assert isinstance(n,str) and n and '\\' not in n and ':' not in n and '\x00' not in n
    pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts and '.' not in pp.parts and pp.as_posix()==n
    p=root/n;assert p.resolve().is_relative_to(root) and not any(a.is_symlink() for a in [p,*p.parents] if a.is_relative_to(root))
    return p
read=lambda n:json.loads(safe(n).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
m=read('MANIFEST.json');entries=m['files'];names=[e['relativePath'] for e in entries]
assert len(names)==len(set(names))==len({n.casefold() for n in names})
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert actual==set(names)|{'MANIFEST.json'},'Missing or unexpected payload'
for e in entries:
    b=safe(e['relativePath']).read_bytes();assert (len(b),sha(b))==(e['sizeBytes'],e['sha256']) and e['provenance'],e['relativePath']
pre=read('evidence/preflight.json');proof=read('evidence/integrity-result.json')
assert pre['branch']=='develop' and pre['head']=='3fd0a85d95ecb79539515833ee3cbe7869c58049' and pre['contentRevision']=='2026-10-27.10'
assert pre['priorPackageSHA256']=='47ad385f5cd7f7fe2761ff6bae56312779c71825c753d3f0bb04a46997894c04' and pre['priorManifestHashCount']==470 and pre['priorPackageVerifier']['result']=='PASS'
assert proof['result']=='PASS' and proof['exitCode']==0 and proof['questionBankIdentical'] and proof['existingFilesByteIdentical']==len(pre['existingFilesSHA256'])==391
assert len(proof['priorBatchDocumentsSHA256'])==188 and proof['priorUncommittedDocumentsPreserved']==177
for n,h in proof['priorBatchDocumentsSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
for e in entries:
    if e['provenance'].get('kind')=='exact repository bytes' and e['relativePath'] in pre['existingFilesSHA256']:assert e['sha256']==pre['existingFilesSHA256'][e['relativePath']]
continuity=read('EXPORT-CONTINUITY.json');oldBytes=safe(continuity['priorManifestPath']).read_bytes()
assert sha(oldBytes)==continuity['priorManifestSHA256']
old=json.loads(oldBytes);oldFiles={e['relativePath']:e for e in old['files']}
assert len(oldFiles)==470 and continuity['previousPackageSHA256']==pre['priorPackageSHA256'] and continuity['previousFileCount']==len(continuity['files'])==471 and continuity['omittedFiles']==[]
assert len({e['previousRelativePath'] for e in continuity['files']})==471 and {e['previousRelativePath'] for e in continuity['files']}==set(oldFiles)|{'MANIFEST.json'}
assert sum(e['kind']=='preserved_repository_reference' for e in continuity['files'])==226
oldMap={e['previousRelativePath']:e['currentRelativePath'] for e in continuity['files']}
for e in continuity['files']:
    b=safe(e['currentRelativePath']).read_bytes();assert (len(b),sha(b))==(e['sizeBytes'],e['sha256'])
    if e['previousRelativePath']!='MANIFEST.json':assert (len(b),sha(b))==(oldFiles[e['previousRelativePath']]['sizeBytes'],oldFiles[e['previousRelativePath']]['sha256'])
bank=read('review-data/current-bank.json');g=runpy.run_path(str(safe('GLOBAL15-RULES.py')))
reference=g['load_reference'](safe('reference-bank.json').read_bytes())
assert safe('reference-bank.json').read_bytes()==safe(oldMap['review-data/current-bank.json']).read_bytes()
globalResult=g['check_bank'](bank,reference);globalNegative=g['negative_checks'](reference)
assert len(proof['historicalSHA256'])==9
for n,h in proof['historicalSHA256'].items():assert sha(safe(n).read_bytes())==h==pre['existingFilesSHA256'][n]
pres=read('BANK-PRESERVATION.json');assert pres['contentRevision']=='2026-10-27.10' and len(pres['questions'])==90
for a,q in zip(pres['questions'],bank):assert a['id']==q['id'] and a['beforeCanonicalSHA256']==a['afterCanonicalSHA256']==canonical(q) and a['beforeKey']==a['afterKey']==q['correct'] and a['beforeVersion']==a['afterVersion']==q['version']
folder='docs/academic/phase10h-batch15-2026-11-07/'
matrix=read(folder+'decision-matrix.json');blind=read(folder+'blind-solutions.json');projection=read(folder+'blind-projection.json')
assert blind==read('evidence/blind-solutions.json') and projection==read('evidence/blind-projection.json') and blind['projectionSHA256']==sha(safe('evidence/blind-projection.json').read_bytes())
reveal=read('evidence/key-reveal.json');assert len(reveal['questions'])==8
for s,k in zip(blind['solutions'],reveal['questions']):assert s['questionId']==k['questionId'] and s['answer']==k['key']==k['independentAnswer'] and datetime.datetime.fromisoformat(s['recordedAt'])<datetime.datetime.fromisoformat(reveal['at'])
reports={d['questionId']:safe(folder+'reports/'+d['questionId']+'.md').read_text(encoding='utf8') for d in matrix['decisions']}
archives={f'2026-10-27.{i}':read(f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}
args=[bank,matrix,read(folder+'exact-comparisons.json'),blind,projection,read(folder+'alternative-assessments.json'),read(folder+'sources.json'),read(folder+'optional-candidates.json'),reports,archives]
rules=runpy.run_path(str(safe('BATCH15-RULES.py')));specific=rules['check'](*args)
negative=rules['negative_checks'](*args,global_check=g['check_bank'],reference_bank=reference)
logged=read('evidence/checks/batch15-specific-result.json')
assert {k:logged[k] for k in specific}==specific and logged['negativeChecks']==negative and logged['globalBankCheck']==globalResult and logged['globalNegativeChecks']==globalNegative and logged['exitCode']==0
blocks=[b for d in matrix['decisions'] for b in re.findall(r'```text\n([\s\S]*?)\n```',reports[d['questionId']])]
assert len(blocks)==328 and re.findall(r'```text\n([\s\S]*?)\n```',safe('ACADEMIC-REVIEW-SUMMARY.md').read_text(encoding='utf8'))==blocks

assert safe(folder+'blind-projection.json').read_bytes()==safe('evidence/blind-projection.json').read_bytes() and safe(folder+'blind-solutions.json').read_bytes()==safe('evidence/blind-solutions.json').read_bytes()
def rejects(call):
    try:call()
    except AssertionError:return True
    return False
outside=copy.deepcopy(args);outside[0][1]['text']['en']='adulterated bank';assert outside[0][1]['id']=='tl-002' and outside[0][1]!=bank[1]
assert rules['check'](*outside)['result']=='PASS' and rejects(lambda:g['check_bank'](outside[0],reference)) and rejects(lambda:g['check_bank'](outside[0],outside[0]))
inside=copy.deepcopy(args);next(q for q in inside[0] if q['id']=='tl-069')['text']['en']='adulterated bank';assert rejects(lambda:rules['check'](*inside))
route=read('evidence/checks/layer-routing-result.json');assert route['result']=='PASS' and all(route[k] for k in ['intactControlsPassed','tl002MutationInjectedIntoActualArgument','tl002ScopedControlPassed','tl002GlobalRejected','tl069ScopedRejected','poisonedReferenceRejected'])
source=read('evidence/checks/source-verification-result.json');assert source['result']=='PASS' and len(source['sources'])==2
for src in source['sources']:
    expected=next(x for x in args[6]['sources'] if x['language']==src['language']);assert src['sha256']==expected['sha256'] and src['pageCount']==expected['pageCount']
    assert {c['questionId'] for c in src['sectionAndLOChecks']}==set(reports)
    for check in src['sectionAndLOChecks']:
        d=next(d for d in matrix['decisions'] if d['questionId']==check['questionId']);assert check['sectionFound'] and check['physicalPages']==d['references'][check['section']][src['language']]
for mode in ['targeted-vitest','multiple-answer-scoring','diff-check','format-check']:
    meta=read('evidence/checks/'+mode+'-result.json');assert meta['exitCode']==0 and meta['startedAt'] and meta['completedAt']
score=json.loads(safe('evidence/checks/multiple-answer-scoring.log').read_text());assert score['syntheticCases']==16 and len(score['questionChecks'])==2 and {q['questionId'] for q in score['questionChecks']}=={'tl-001','tl-083'} and all(len(q['syntheticSelections'])==8 and all(c['expected']==c['actual'] for c in q['syntheticSelections']) for q in score['questionChecks']) and not score['storageAccessed']
inventory=read('GIT-CHANGE-INVENTORY.json');assert inventory['existingFilesChanged']==[] and len(inventory['newFiles'])==18 and len(inventory['preservedPendingDocuments'])==177
for e in inventory['newFiles']:assert sha(safe(e['relativePath']).read_bytes())==e['sha256'] and safe(e['relativePath']).stat().st_size==e['sizeBytes']
assert proof['newOwnerAcceptances']==proof['newHumanApprovals']==0
print(json.dumps({'result':'PASS','filesIncludingManifest':len(actual),'payloadHashes':len(entries),'priorMembersPreserved':471,'priorAcademicDocumentsPreserved':188,'questions':90,'alternatives':364,'learningObjectives':64,'historicalArchives':9,'reviewedQuestions':8,'reviewedAlternatives':33,'combinedNegativeCasesRejected':negative['negativeCasesRejected'],'globalNegativeCasesRejected':globalNegative['negativeCasesRejected'],'scopedAndGlobalContractsDemonstrated':True,'frozenBlindRecordsByteIdentical':True,'syntheticScoringChecks':16,'newOwnerAccepted':0,'newHumanApproved':0,'semanticTruthAutomaticallyProven':False},indent=2))
