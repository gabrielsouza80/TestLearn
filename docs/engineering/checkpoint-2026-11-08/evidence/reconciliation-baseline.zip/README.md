# TestLearn — Fase 10H, Lote 16

Âmbito fechado: tl-084 (FL-2.2.2/K2) e tl-085 (FL-5.2.4/K2), cinco alternativas e duas respostas cada: duas questões, dez alternativas e 96 blocos literais antes/depois. Soluções cegas guardadas antes de revelar chaves e explicações, com data UTC e hash. Dois pareceres ACCEPT_AS_IS por IA, sem usar NONE ou coincidência de chave como prova académica.

Preflight em 2026-11-07; dossiê criado em 2026-11-08. Os horários reais são preservados quando a execução atravessa a meia-noite. Baseline: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos e nove arquivos históricos. Pacote do Lote 15 autenticado: 387a3e01f6c6b87bd3ad5229477fe7286f6a2c955bf4a82e114d0d980b4df68e, 518 membros e 517 hashes. Inventário inicial: 409 ficheiros rastreados/não ignorados, 195 não rastreados e 206 documentos académicos anteriores, todos preservados.

tl-084: resultado funcional versus qualidade de desempenho, limite inclusivo p95 ≤ 300 ms e condição de 200 utilizadores concorrentes. Percentil 95 não significa máximo individual. A regra matemática é interpretação do requisito, não uma definição estatística atribuída ao syllabus. API não prova caixa-branca nem carga prova nível de integração de sistemas. O método amostral de percentil não está especificado e não é necessário para classificar os tipos de teste.

tl-085: executar mitigação e acompanhar eficácia/adaptar resposta a riscos emergentes são controlo; identificação, classificação e categorização repetidas são análise inicial neste cenário. Não se proíbe reanálise futura. Testes de mudança da hora são exemplo contextual, sem inventar regras tarifárias.

As fontes oficiais EN v4.0.1 e PT v4.0 tradução 1.0 foram consultadas por secção e página física; ambos os endpoints remotos acessíveis e cópias locais identificadas por hash. Não se afirma identidade textual ou igualdade remota dos bytes. Não se exportam PDFs integrais ou dados reais. A interpretação e contraevidência do revisor estão separadas dos textos literais publicados.

Guard específico protege dois objetos completos e a evidência. Guard global compara os 90 objetos completos com referência fixa extraída do ZIP autenticado do Lote 15. Não deriva a referência do candidato. Casos negativos só alteram cópias isoladas e respeitam os dois âmbitos. Controlos anteriores são preservados; os novos auxiliares não os substituem nem enfraquecem.

Sem alteração a banco, gabaritos, explicações, versões, objetivos, pontuação, persistência, aplicação, testes ou guards anteriores. Sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Revisão por IA não é revisão académica humana independente. Nenhuma correção obrigatória ou proposta editorial justificada foi identificada; optional-candidates.json vazio.

Exportar apenas depois dos gates, com continuidade exata dos 518 membros anteriores, incluindo metadados e manifesto histórico. Este é dossiê de evidência, não repositório executável completo. Ver verification.md para execuções novas, limites e verificações não executadas. Fase 10H permanece aberta: reconciliação global e revisão humana são etapas separadas, não iniciadas automaticamente. Sem Git remoto, commit, branch, PR, merge, push ou deploy.


## Verificação portátil

Inspecionar VERIFY-PACKAGE.py, BATCH16-RULES.py e GLOBAL16-RULES.py. Depois de extrair numa pasta limpa, executar `python -B VERIFY-PACKAGE.py` com Python 3.9+ standard library, sem -O. Os três ficheiros são somente leitura, sem rede nem subprocessos. Os auxiliares em evidence/local-helpers requerem o checkout original e não são entradas portáteis. Verificadores históricos são evidência e não pacotes autónomos.

EXPORT-CONTINUITY.json mapeia todos os 518 membros do ZIP autenticado do Lote 15, comparados diretamente byte a byte. As 244 referências anteriores do repositório mantêm caminhos relativos. Cargas históricas idênticas podem partilhar destino, sem omissões. MANIFEST.json cobre todas as cargas exceto ele próprio para evitar circularidade; o SHA-256 externo do ZIP cobre também o manifesto. Hashes mostram consistência, não certificação académica ou assinatura digital.

Os logs históricos de falha e recuperação dos Lotes 12 e 13 são preservados sem reescrita e não são apresentados como novos testes. Os resultados novos estão em evidence/checks. O dossiê é uma exportação de evidência, não um repositório executável completo. A Fase 10H permanece aberta; aprovação humana PENDING; sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Não iniciar outra fase automaticamente. Nenhuma publicação, commit ou operação Git remota.
