import json, pathlib, hashlib, re, sys
ROOT=pathlib.Path('C:/TestLearn/tmp/develop-workspace')
OUT=pathlib.Path(__file__).parent
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def canonical(v): return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
bank=load(OUT/'reference-bank.json'); by={q['id']:q for q in bank}
allrows=[]; details=[]; issues=[]
for n in range(1,17):
 d=next((ROOT/'docs/academic').glob(f'phase10h-batch{n}-*'))
 f=d/('records.json' if n<3 else 'record.json' if n==3 else 'decision-matrix.json')
 raw=load(f)
 rows=raw['corrections'] if n==1 else [raw] if n==3 else raw['decisions']
 for r in rows:
  q=by[r['questionId']]; decision=r.get('decision',r.get('status'))
  answer=r.get('independentAnswer',r.get('independentSolution',{}).get('answer'))
  if n==1: answer=None
  elif answer is None: answer=r.get('independentSolution',{}).get('selected')
  for field,expected in [('learningObjective',q['lo']),('cognitiveLevel',q['level'])]:
   if r.get(field)!=expected: issues.append([q['id'],field,r.get(field),expected])
  h=r.get('afterCanonicalSHA256',r.get('afterSHA256',r.get('correctedSHA256')))
  if h!=canonical(q): issues.append([q['id'],'hash',h,canonical(q)])
  if answer is not None and set(answer)!=set(q['correct']): issues.append([q['id'],'blind answer',answer,q['correct']])
  allrows.append({'batch':n,'source':f.relative_to(ROOT).as_posix(),'record':r,'answer':answer,'decision':decision})
 details.append({'batch':n,'files':len(list(d.rglob('*'))),'rows':len(rows),'decisions':[(r['questionId'],r.get('decision',r.get('status'))) for r in rows]})
sys.path=[p for p in sys.path if pathlib.Path(p or '.').resolve()!=OUT.resolve()]
sys.path.insert(0,'C:/TestLearn/tmp/pdf-tools')
import pymupdf
pdfdir=pathlib.Path('C:/TestLearn/docs/Certified Tester Foundation Level (CTFL) v4.0')
sources=[]
for name in ['ISTQB_CTFL_Syllabus_v4.0.1.pdf','ISTQB_CTFL_Syllabus-v4.0-PT_v1.0 (1).pdf']:
 p=pdfdir/name; doc=pymupdf.open(p); los={}
 for i,page in enumerate(doc):
  for m in re.finditer(r'(FL-\d+\.\d+\.\d+)\s*\((K[123])\)',page.get_text()):
   los.setdefault(m[1],{'level':m[2],'page':i+1})
 mismatch=[(q['id'],q['lo'],q['level'],los.get(q['lo'])) for q in bank if los.get(q['lo'],{}).get('level')!=q['level']]
 sources.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pages':len(doc),'objectives':los,'mismatches':mismatch})
result={'rows':allrows,'batches':details,'issues':issues,'sources':sources}
(OUT/'inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
from collections import Counter
print(json.dumps({'counts':dict(Counter(x['decision'] for x in allrows)),'rows':len(allrows),'unique':len({r['record']['questionId'] for r in allrows}),'issues':issues,'missingBlind':[(r['batch'],r['record']['questionId']) for r in allrows if r['answer'] is None],'syllabus':[(s['file'],len(s['objectives']),s['mismatches']) for s in sources]},ensure_ascii=False,indent=2))
