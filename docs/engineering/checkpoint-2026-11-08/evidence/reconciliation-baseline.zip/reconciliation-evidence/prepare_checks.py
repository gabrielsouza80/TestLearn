import pathlib,json,hashlib,zipfile,subprocess,datetime,importlib.util,sys
W=pathlib.Path(__file__).parent; R=pathlib.Path('C:/TestLearn/tmp/develop-workspace'); D=R/'docs/academic/phase10h-reconciliation-2026-11-08'
Z=pathlib.Path('C:/Users/gabri/Downloads/TestLearn-Phase10H-Batch16-Academic-Review-20261108-000938-1.zip')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read(p):return json.loads(p.read_bytes())
pre=read(W/'preflight.json'); matrix=read(D/'global-matrix.json'); approval=read(D/'approval-reconciliation.json')
assert sha(Z.read_bytes())==pre['priorPackageSHA256']
z=zipfile.ZipFile(Z); assert z.testzip() is None
data={n:z.read(n) for n in z.namelist()}
required={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in D.iterdir() if p.is_file()}
protected={p:h for p,h in pre['existingFilesSHA256'].items() if p.startswith('docs/academic/phase10h-batch') or p.startswith('src/data/archive/')}
for p,h in protected.items():assert sha(data[p])==h,p
contract={'baselineSHA256':pre['priorPackageSHA256'],'protectedEvidence':protected,'owners':{r['questionId']:r['ownerAcceptance'] for r in matrix['rows'] if r['ownerAcceptance']['state']=='OWNER_ACCEPTED'},'records':{r['questionId']:{'batch':r['batch'],'record':r['historicalReviewRecord'],'decision':r['academicVerdict'],'answer':r['independentAnswer'],'evidence':r['evidence'],'sourcesAndPages':r['sourcesAndPages'],'sourceCatalogue':r['sourceCatalogue'],'history':r['history']} for r in matrix['rows']},'corrections':read(D/'correction-comparisons.json'),'approvalReconciliation':approval,'requiredNewEvidence':required}
# Contract is created once, before tests. Its inputs are checked against authenticated original evidence.
assert not (W/'RECONCILIATION-CONTRACT.json').exists()
dump(W/'RECONCILIATION-CONTRACT.json',contract)
guard=W/'RECONCILIATION-RULES.py'; text=guard.read_text(encoding='utf-8');assert text.count('TO_BE_PINNED_BEFORE_FIRST_EXECUTION')==1
guard.write_text(text.replace('TO_BE_PINNED_BEFORE_FIRST_EXECUTION',sha((W/'RECONCILIATION-CONTRACT.json').read_bytes())),encoding='utf-8')
# Independent source extraction: confirm matrix records against original source JSON, not generated summaries.
for r in matrix['rows']:
 raw=json.loads(data[r['evidence']['path']]); batch=r['batch']
 candidates=raw['corrections'] if batch==1 else [raw] if batch==3 else raw['decisions']
 assert next(x for x in candidates if x['questionId']==r['questionId'])==r['historicalReviewRecord']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
runtime=subprocess.run(['node','C:/TestLearn/tmp/phase10h-batch6-20261106/current-bank.cjs',str(R)],capture_output=True,text=True,check=True)
live=json.loads(runtime.stdout); bank=live['bank'];assert live['revision']=='2026-10-27.10'
data['reconciliation/current-bank.json']=json.dumps(bank,ensure_ascii=False,indent=2).encode()
(W/'current-bank.json').write_bytes(data['reconciliation/current-bank.json'])
for p in D.iterdir():
 if p.is_file():data[p.relative_to(R).as_posix()]=p.read_bytes()
data['RECONCILIATION-CONTRACT.json']=(W/'RECONCILIATION-CONTRACT.json').read_bytes()
spec=importlib.util.spec_from_file_location('reconciliation_rules',guard); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
positive=module.check(data); negatives=module.negatives(data)
preserved=[]
for p,h in pre['existingFilesSHA256'].items():
 assert sha((R/p).read_bytes())==h,p
 preserved.append(p)
head=subprocess.run(['git','rev-parse','HEAD'],cwd=R,capture_output=True,text=True,check=True).stdout.strip();assert head==pre['head']
assert subprocess.run(['git','branch','--show-current'],cwd=R,capture_output=True,text=True,check=True).stdout.strip()=='develop'
diff=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True,text=True);assert diff.returncode==0,diff.stdout+diff.stderr
assert not subprocess.run(['git','diff','--name-only'],cwd=R,capture_output=True,text=True,check=True).stdout
assert not subprocess.run(['git','diff','--cached','--name-only'],cwd=R,capture_output=True,text=True,check=True).stdout
status=subprocess.run(['git','status','--untracked-files=all'],cwd=R,capture_output=True,text=True,check=True)
result={'startedUTC':start,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'rtk proxy python C:/TestLearn/tmp/phase10h-reconciliation-20261108/prepare_checks.py','exitCode':0,'positiveControl':positive,'negativeTests':negatives,'negativeCount':len(negatives),'priorFilesByteIdentical':len(preserved),'gitDiffCheck':{'command':'git diff --check','exitCode':diff.returncode,'stdout':diff.stdout,'stderr':diff.stderr},'head':head,'bankCanonicalSHA256':module.canonical(bank),'newFunctionalTestsExecuted':0,'sourceLOChecks':'64 unique objectives and all90 LO/K pairs equal both official local editions; inspection.json contains exact physical LO pages','historyFiles':9,'unexpectedOldFileChanges':[]}
dump(W/'checks.json',result);(W/'git-status-after.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['negativeTests']},ensure_ascii=False,indent=2))
