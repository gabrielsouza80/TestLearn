"""Create only the new reconciliation dossier; never rewrite prior project evidence."""
import json,pathlib,hashlib,datetime,collections,subprocess,re,sys
ROOT=pathlib.Path('C:/TestLearn/tmp/develop-workspace'); WORK=pathlib.Path(__file__).parent
DEST=ROOT/'docs/academic/phase10h-reconciliation-2026-11-08'
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(b): return hashlib.sha256(b).hexdigest()
def canon(v): return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def write(name,v):
 p=DEST/name
 if p.exists(): raise RuntimeError('Refusing overwrite: '+str(p))
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n' if not isinstance(v,str) else v,encoding='utf-8')
I=load(WORK/'inspection.json'); P=load(WORK/'preflight.json'); bank=load(WORK/'reference-bank.json'); by={q['id']:q for q in bank}
assert not I['issues']; assert not DEST.exists() or not list(DEST.iterdir())
for path,h in P['existingFilesSHA256'].items(): assert sha((ROOT/path).read_bytes())==h,path
DEST.mkdir(exist_ok=True)
hist={str(i):load(ROOT/f'src/data/archive/questions-2026-10-27.{i}.json') for i in range(1,10)}
archives={f'src/data/archive/questions-2026-10-27.{i}.json':sha((ROOT/f'src/data/archive/questions-2026-10-27.{i}.json').read_bytes()) for i in range(1,10)}
owners={}; ownerSources=[]
for n in (1,2):
 d=next((ROOT/'docs/academic').glob(f'phase10h-batch{n}-*')); f=next(d.glob('owner-acceptance-*.json')); o=load(f)
 ownerSources.append({'path':f.relative_to(ROOT).as_posix(),'sha256':sha(f.read_bytes()),'originalRecord':o})
 for v in o['questions']:
  q=by[v['questionId']]
  assert v['acceptedCanonicalSHA256']==canon(q)
  accepted_key=v['acceptedAnswerKey'] if n==1 else v['acceptedKey']
  assert v['acceptedVersion']==q['version'] and set(accepted_key)==set(q['correct'])
  owners[q['id']]={'state':'OWNER_ACCEPTED','record':v,'source':f.relative_to(ROOT).as_posix(),'sourceSHA256':sha(f.read_bytes()),'recordedOn':o['recordedOn'],'independentAcademicApproval':'PENDING'}
assert len(owners)==10
batches=[]; rows=[]; refs={}; fullReading={}
for n in range(1,17):
 d=next((ROOT/'docs/academic').glob(f'phase10h-batch{n}-*')); files=[]
 for f in sorted(d.rglob('*')):
  if not f.is_file(): continue
  data=f.read_bytes(); files.append({'path':f.relative_to(ROOT).as_posix(),'sizeBytes':len(data),'sha256':sha(data)})
  # All original textual documents are decoded and inventoried, without rewriting them.
  fullReading[f.relative_to(ROOT).as_posix()]=data.decode('utf-8-sig')
  if f.suffix=='.json': json.loads(data)
 sf=d/('sources-verified.json' if n==1 else 'sources.json'); src=load(sf)
 refs[n]={'path':sf.relative_to(ROOT).as_posix(),'sha256':sha(sf.read_bytes()),'original':src}
 batches.append({'batch':n,'directory':d.relative_to(ROOT).as_posix(),'files':files,'fileCount':len(files),'reviewedIds':[r['record']['questionId'] for r in I['rows'] if r['batch']==n], 'schema':'corrections + append-only acceptance' if n==1 else 'decisions + append-only acceptance' if n==2 else 'single record' if n==3 else 'decision-matrix.decisions'})
for r in I['rows']:
 q=by[r['record']['questionId']]; old=r['record']; n=r['batch']; f=ROOT/r['source']
 history=[]
 for i,questions in hist.items():
  previous=next((x for x in questions if x['id']==q['id']),None)
  history.append({'revision':'2026-10-27.'+i,'present':previous is not None,**({'version':previous['version'],'key':previous['correct'],'canonicalSHA256':canon(previous)} if previous else {})})
 references=old.get('references')
 if references is None:
  references={'section':'2.2.3' if q['id']=='tl-011' else '5.5','EN':[24,30,31] if q['id']=='tl-011' else [47,56,57],'PT':[26,33] if q['id']=='tl-011' else [52,62,63]} if n==1 else refs[n]['original']
 row={'questionId':q['id'],'batch':n,'learningObjective':q['lo'],'cognitiveLevel':q['level'],'version':q['version'],'contentRevision':'2026-10-27.10','canonicalSHA256':canon(q),'optionCount':len(q['options']),'requiredAnswers':q['required'],'independentAnswer':r['answer'],'blindEvidenceStatus':'NO_SEPARATE_PRE_KEY_RECORD_FOUND' if n==1 else 'HISTORICAL_AI_RECORD_NOT_NEW_HUMAN_REVIEW','publishedKey':q['correct'],'academicVerdict':r['decision'],'ownerAcceptance':owners.get(q['id'],{'state':'NOT_RECORDED'}),'humanAcademicApproval':'PENDING','bankHumanApproval':q['humanApproval'],'historicalReviewRecord':old,'history':history,'sourcesAndPages':references,'sourceCatalogue':{'path':refs[n]['path'],'sha256':refs[n]['sha256']},'evidence':{'path':r['source'],'sha256':sha(f.read_bytes()),'recordPointer':'/corrections' if n==1 else '/' if n==3 else '/decisions','questionId':q['id']}}
 rows.append(row)
rows.sort(key=lambda r:r['questionId'])
counts=dict(collections.Counter(r['academicVerdict'] for r in rows))
write('global-matrix.json',{'scope':'Historical reconciliation of 16 AI batches; no new academic approvals','baselineSHA256':P['priorPackageSHA256'],'counts':counts,'rows':rows})
write('batch-evidence-inventory.json',{'batches':batches,'academicFiles':sum(b['fileCount'] for b in batches),'allPriorWorkspaceFiles':P['existingFilesSHA256'],'pendingGitStatusBefore':P['status'],'fullGitStatusBefore':P['fullGitStatus'],'priorDocumentsAreNotReformatted':True})
write('approval-reconciliation.json',{'ownerAcceptedCount':len(owners),'humanApprovedCount':0,'bankPendingCount':sum(q['humanApproval']=='PENDING' for q in bank),'acceptedIds':sorted(owners),'originalAppendOnlyRecords':ownerSources,'scope':'Exact versions, complete canonical object hashes and existing keys only; no release authorization; no independent human SME evidence verified','historicalNullOwnerDecision':'Original review snapshots predate append-only owner decisions; null does not revoke later exact-scope acceptance'})
changed=[]; old9={q['id']:q for q in hist['9']}
for q in bank:
 if q!=old9[q['id']]: changed.append(q['id'])
assert changed==['tl-011','tl-090'],changed
corrections=[]
for id in changed:
 q=by[id]; old=old9[id]; rec=next(r['record'] for r in I['rows'] if r['record']['questionId']==id)
 assert canon(old)==rec['previousSHA256'] and canon(q)==rec['correctedSHA256']
 corrections.append({'questionId':id,'previousRevision':'2026-10-27.9','currentRevision':'2026-10-27.10','before':old,'after':q,'changedFields':[k for k in q if q[k]!=old.get(k)],'beforeCanonicalSHA256':canon(old),'afterCanonicalSHA256':canon(q),'originalDecision':rec,'ownerAcceptance':owners[id],'authorizationBoundary':'User authorized controlled Batch1 corrections then explicitly accepted these exact versions; not production authorization','humanAcademicApproval':'PENDING'})
write('correction-comparisons.json',corrections)
write('version-hash-reconciliation.json',{'currentBankRawSHA256':sha((WORK/'reference-bank.json').read_bytes()),'currentBankCanonicalSHA256':canon(bank),'contentRevision':'2026-10-27.10','historicalArchives':archives,'deltaFromRevision9':changed,'explanation':'Only the two documented Batch1 corrections differ from revision9. Earlier archive metadata/key/content changes remain historical; no retroactive authorization asserted. Absence before an item was introduced is recorded, not treated as loss.','items':[{'questionId':r['questionId'],'version':r['version'],'sha256':r['canonicalSHA256'],'history':r['history']} for r in rows]})
write('answer-key-reconciliation.json',{'all90CurrentKeysEqualRevision9':all(q['correct']==old9[q['id']]['correct'] for q in bank),'allDocumentedIndependentAnswersMatch':all(r['independentAnswer'] is None or set(r['independentAnswer'])==set(r['publishedKey']) for r in rows),'notRecordedBlindIds':['tl-011','tl-090'],'keys':[{'questionId':q['id'],'required':q['required'],'key':q['correct'],'history':next(r['history'] for r in rows if r['questionId']==q['id'])} for q in bank],'multipleSelection':[{'questionId':q['id'],'required':q['required'],'key':q['correct'],'options':len(q['options'])} for q in bank if q['required']>1],'scoringBoundary':'No scoring implementation changed or functional execution claimed; exact sets remain required, not partial selections.'})
exceptions=[
 {'id':'R-01','type':'HISTORICAL_EVIDENCE_LIMITATION','items':['tl-011','tl-090'],'finding':'Batch1 correction records contain keys and rationale, but no standalone pre-key blind solution/timestamp artifact. Independent answers remain null; no reconstructed timestamp or new blind review invented.','action':'Human review of exact accepted correction versions; not a bank integrity failure.'},
 {'id':'R-02','type':'COGNITIVE_CALIBRATION_PENDING','items':['tl-038','tl-078'],'finding':'Batch2 blocks tl-038 for possible recognition rather than K3 application; Batch3 accepts tl-078 with limited scenario-based application and official multiple-choice comparisons. These judgments require consistent human calibration, not automatic transfer of either verdict.','action':'Keep tl-038 BLOCKED_HUMAN_DECISION and all others historical states; see dedicated assessment.'},
 {'id':'R-03','type':'APPROVAL_SNAPSHOT_CHRONOLOGY','items':sorted(owners),'finding':'Original matrices contain null owner decisions; subsequent append-only owner records accept exact hashes. This is chronology, not general human academic approval.','action':'Expose both original record and separately scoped acceptance.'},
 {'id':'R-04','type':'SOURCE_EDITION_LIMITATION','finding':'EN4.0.1 and PT4.0 translation1.0 differ; page offsets are not universal. All64LO/K pairs match both local editions. Existing per-question source/page records are retained; no assertion that every historical citation was visually verified now.','action':'Use exact edition and physical pages; human reviewer checks semantic interpretations.'},
 {'id':'R-05','type':'CURRENT_HELPER_FAILURE_RESOLVED','finding':'First exploratory helper named inspect.py shadowed Python standard-library inspect during PyMuPDF import; exit1 AttributeError. No guard, bank or continuity failure. Removed helper directory from import search before loading external PDF library; rerun exit0. No project/old helper modified.','action':'Record both outcomes; portable verifier uses only standard library and no PDF import.'},
 {'id':'R-06','type':'NEW_PREFLIGHT_METADATA_TYPING_CORRECTION','evidence':P.get('metadataTypingCorrection'),'finding':'New audit metadata initially contained a manually mistyped HEAD; actual Git assertion had used correct expected HEAD and passed. Corrected only the new metadata, preserving original string in correction record.','action':'Use actual verified Git HEAD; no Git state normalized.'},
 {'id':'R-07','type':'HISTORICAL_RECOVERY_PRESERVED','finding':'Batch12 false-positive routing failure and Batch13 readability failure, STOP records and recovery evidence remain unchanged. Successful recovery does not erase original FAIL.','action':'Prior package members preserved byte-for-byte.'},
 {'id':'R-08','type':'CURRENT_EXPORT_BUILDER_SCHEMA_ERROR','finding':'First dossier generation exited1 with KeyError acceptedAnswerKey before any dossier file was written. Batch1 acceptance uses acceptedAnswerKey; Batch2 uses acceptedKey. Added explicit per-batch schema handling, without changing source records or expectations.','action':'Preserve execution history; this was a generator error, not a bank integrity rejection.'}
]
write('exceptions-conflicts.json',exceptions)
# Official local texts: identify every LO and validate all historical numeric page references against actual PDF sizes.
sources=[]
for language,s in zip(('EN','PT'),I['sources']):
 sources.append({**s,'language':language,'edition':'EN CTFL4.0.1 2024-09-15' if language=='EN' else 'PT CTFL4.0 translation1.0 21-04-2023','url':'https://istqb.org/wp-content/uploads/2024/11/ISTQB_CTFL_Syllabus_v4.0.1.pdf' if language=='EN' else 'https://pstqb.pt/wp-content/uploads/2024/05/ISTQB_CTFL_Syllabus-v4.0-PT_v1.0.pdf','consultation':'Local exact bytes read and all64 LO/K pairs extracted in this execution; official endpoint opened successfully with web tool. No fresh remote-byte equality asserted.','deepReviewPhysicalPages':[47,56,57,64] if language=='EN' else [52,62,63,70]})
write('sources.json',{'primary':sources,'historicalSourceCatalogues':[{'batch':n,**refs[n]} for n in refs],'officialSampleComparisons':[{'set':'B','version':'1.7','question':38,'questionPage':20,'answerPage':36,'objective':'FL-5.5.1','level':'K3','questionURL':'https://tbok.istqb.org/api/exam-pdf/10/questions','answerURL':'https://tbok.istqb.org/api/exam-pdf/10/answers','interpretation':'Selecting useful failure summary from execution evidence; pattern synthesis exceeds direct fact copying.'},{'set':'D','version':'1.5','question':38,'questionPage':19,'answerPage':33,'objective':'FL-5.5.1','level':'K3','questionURL':'https://tbok.istqb.org/api/exam-pdf/12/questions','answerURL':'https://tbok.istqb.org/api/exam-pdf/12/answers','interpretation':'Selecting missing information best enabling reproduction of reported failure; selection can require contextual application.'}],'limitations':'Official sample PDFs accessed through web text; no raw file hash asserted or screenshots claimed. Sample comparisons are analogies, not psychometric equivalence. Complete copyrighted PDFs not bundled. Automatic extraction validates LO labels and page ranges, not truth of translations or reviewer interpretations.'})
write('tl-038-assessment.md', '''# tl-038 — parecer de reconciliação, sem alteração de estado

Estado histórico: **BLOCKED_HUMAN_DECISION**. LO FL-5.5.1 / K3, versão 3, chave o1. A aceitação de Gabriel é OWNER_ACCEPTED para o hash exato documentado; não desbloqueia a decisão académica nem constitui revisão SME independente.

## Evidência e norma

CTFL EN v4.0.1, §5.5, páginas físicas 56–57; LO na página 47. PT v4.0, tradução 1.0, §5.5, páginas 62–63; LO na página 52. Ambos incluem ambiente, contexto, passos, resultados esperados/obtidos e evidências num relatório. O apêndice A EN página 64 / PT página 70 caracteriza K3 pela execução ou seleção e aplicação de um procedimento num contexto, incluindo preparar relatórios de defeitos. Isto não impõe redação livre como único formato possível.

## Argumentos a favor de adequação K3

O candidato pode aplicar critérios de reprodução e de rigor factual: conservar QA/build 82, utilizador autorizado, INV-7/25, Save, esperado 201 com ID, observado 500 sem fatura e r17. Precisa distinguir resultado esperado de observado e rejeitar diagnóstico não sustentado. o2 inverte resultados; o3 altera ambiente/build; o4 acrescenta deadlock confirmado sem evidência. A chave é factualmente única entre as opções, em PT e EN. Não se deve exigir título, severidade ou outros campos não fornecidos quando se pede o registo da evidência disponível.

O formato de escolha múltipla pode exigir aplicação: exame oficial B v1.7, questão 38, página 20, resposta/LO/K na página 36; exame D v1.5, questão 38, página 19, resposta/LO/K na página 33. Ambos são FL-5.5.1/K3, mas a semelhança do formato não demonstra igual exigência cognitiva.

## Argumentos contra / limite da tarefa concreta

o1 transcreve quase literalmente todos os factos do enunciado. As outras opções contêm contradições ostensivas ou uma causa expressamente não demonstrada. Um candidato pode acertar por correspondência lexical sem organizar informação, escolher dados em falta ou executar um procedimento de elaboração. Reconhecer uma transcrição fiel não demonstra, por si, capacidade autónoma de preparar um relatório; dificuldade baixa e nível K são dimensões diferentes. Os exemplos oficiais exigem inferir padrão de falha ou selecionar informação necessária à reprodução, operações potencialmente mais exigentes.

## Relação com outros lotes e impacto pedagógico

tl-078 foi aceite pela IA como aplicação limitada num cenário, com referência aos mesmos exames oficiais. Existe uma tensão de calibração entre esse parecer e o bloqueio de tl-038; não há erro demonstrado na chave de nenhum deles. Não se deve alterar retroativamente um parecer para obter uniformidade artificial. O risco é sobrestimar preparação autónoma K3 se este reconhecimento simples for apresentado como prova suficiente.

## Recomendação para especialista humano

Manter o bloqueio até decisão explícita sobre a operação cognitiva. Opções independentes: (1) manter como exercício introdutório K3, com justificação contextual e limite de dificuldade; (2) manter como treino de reconhecimento e desenvolver futuramente outro exercício K3; (3) autorizar uma reformulação que exija selecionar/organizar evidência ou completar dados relevantes, com revisão bilingue e regressão própria. Não há fundamento para mudar agora a chave o1, inventar campos, reduzir LO/K ou propor texto obrigatório apenas para aumentar dificuldade. Nenhuma reformulação foi aplicada.

## Qualificação do proprietário preservada literalmente

"The published answer is academically defensible and aligns with the ISTQB CTFL FL-5.5.1/K3 multiple-choice examination approach. Its difficulty is relatively low for K3, so a more demanding alternative may be developed later."

Esta análise é assistida por IA. Não atribui aprovação humana, certificação ou autorização de publicação. Textos integrais e justificações originais encontram-se na referência do banco e no registo original do Lote 2, conservados no pacote.
''')
write('tl-011-tl-090-verification.md', '''# Reconciliação das duas correções do Lote 1

`correction-comparisons.json` contém os dois objetos completos antes (.9) e depois (.10), incluindo PT/EN, todas as alternativas e justificações, hashes, versões, chaves e aceites originais. Não se parafraseiam esses blocos como comparação literal.

tl-011: versão 2 → 3; chave o1 preservada; FL-2.2.3/K2. O enunciado EN anterior qualificava os fluxos como unaffected, afirmação mais forte que implementação inalterada em PT. A correção remove essa garantia indevida e clarifica confirmação/regressão nas explicações, sem limitar regressão apenas ao código não modificado. EN §2.2.3 páginas 30–31, LO 24; PT página 33, LO 26.

tl-090: versão 1 → 2; chave o2 preservada; FL-5.5.1/K3. T-91 é identificador de transferência, não caso de teste inventado. A evidência do cenário exige que T-91 não exista previamente. A correção torna essa pré-condição explícita nas quatro opções apresentadas como passos completos e ajusta a explicação. Não inventa diagnóstico de causa. EN §5.5 páginas 56–57, LO 47; PT páginas 62–63, LO 52. Separar futuramente pré-condições e passos é melhoria opcional aceite como possibilidade, não aplicada.

Os hashes anteriores coincidem com os objetos do arquivo .9; os hashes corrigidos coincidem simultaneamente com o banco .10, os records originais e os dez aceites de âmbito exato. Somente estes dois objetos diferem entre .9 e .10; todos os 90 gabaritos são iguais. As correções foram solicitadas no âmbito de desenvolvimento do Lote 1 e posteriormente aceites pelo proprietário; isto não autoriza publicação. O histórico mais antigo permanece intacto, incluindo ausência de tl-090 antes de .9.

Ambas permanecem AI_CORRECTED_PENDING_HUMAN; humanApproval PENDING. Não existe artefacto separado de solução pré-gabarito no Lote 1: esta ausência é explicitada, não preenchida por uma resposta inventada. O aceite do proprietário corresponde às versões 3 e 2 e aos hashes documentados, não a toda revisão futura.
''')
write('pending-human-decisions.json',{'phase':'PHASE10H_OPEN','humanApprovedCount':0,'priorities':[{'priority':1,'ids':['tl-038'],'decisionRequired':'Adjudicate K3 application adequacy; retain historical blocked state until explicit specialist decision'},{'priority':2,'ids':['tl-011','tl-090'],'decisionRequired':'Independent academic review of exact corrected/owner-accepted versions, historical deltas and rationale'},{'priority':3,'ids':['tl-078','tl-025','tl-026','tl-028','tl-029','tl-046','tl-047','tl-071','tl-072','tl-073','tl-076','tl-077','tl-086','tl-087','tl-088','tl-089'],'decisionRequired':'Calibrate K3 demand, boundary conventions, explicit scenario policies and mathematical premises'},{'priority':4,'ids':['tl-001','tl-083','tl-084','tl-085','tl-022','tl-041'],'decisionRequired':'Validate multiple-answer uniqueness, qualifiers, bilingual terminology and pedagogy'},{'priority':5,'ids':[q['id'] for q in bank],'decisionRequired':'Complete remaining independent human academic review; avoid duplicating already reviewed items within this prioritized plan'}],'noNewOwnerOrHumanApproval':True})
write('human-review-plan.md','''# Plano de revisão humana priorizado

1. Especialista humano decide tl-038, comparando a operação exigida com o apêndice A e os exemplos oficiais; registar argumentos e contraevidência, sem equiparar escolha múltipla a K2.
2. Rever individualmente tl-011 e tl-090, com os blocos completos .9/.10 e hashes aceites. Confirmar escopo e semântica, sem reabrir automaticamente chaves.
3. Calibrar os cenários K3 em grupos de 4–6: convenções de fronteira e domínio; tabelas de decisão e regras indiferentes; transições com paragem específica; estimativa de esforço versus calendário; prioridades locais. Não generalizar premissas locais.
4. Rever seleção múltipla e pares linguísticos: quantidade de respostas, limite inclusivo/percentil, risco e controlo, toda a equipa e antecipação de erros. Coincidência com chave não substitui análise dos distratores.
5. Completar todos os restantes IDs em grupos temáticos de 6–8, usando a matriz para evitar omissões e duplicação. Validar explicações, qualificadores e as fontes da edição indicada.

Cada decisão humana deve identificar revisor real, âmbito, versão/hash, fonte e fundamento. OWNER_ACCEPTED é outra decisão e mantém âmbito próprio. Propostas ficam isoladas até autorização; qualquer aplicação exige preservação histórica e regressão proporcional. Nenhum destes passos é executado ou aprovado por este plano.
''')
write('global-consistency.md','''# Consistência global: evidência e interpretação

A matriz agrega os 90 registos originais, as análises PT/EN, distratores, riscos, fontes e nove revisões por item. Os formatos dos Lotes 1–3 foram tratados explicitamente, sem excluir os dez aceites apensos. Os 90 LO/K correspondem aos 64 objetivos identificados em ambas as edições oficiais. Os 90 objetos completos coincidem com a baseline autenticada; isto inclui traduções, alternativas e explicações, não apenas IDs/chaves.

Não se encontrou divergência entre as 88 respostas independentes registadas e os gabaritos atuais. As duas correções do Lote 1 têm chaves preservadas e ausência de artefacto cego autónomo, assinalada. Os pareceres não são substituídos pela triagem antiga NONE nem pelos campos academicReview PASS do banco, que são AI_REVIEWED e coexistem com humanApproval PENDING.

Os quatro itens de seleção múltipla são tratados como conjuntos completos: tl-001 o1/o4; tl-083 o2/o4; tl-084 o1/o4; tl-085 o2/o5. Não se infere correção de seleção parcial. A reconciliação não altera nem reexecuta a implementação de pontuação.

Os argumentos históricos distinguem três partições de combinações; limites válidos de fronteiras de partições rejeitadas; domínio discreto de cêntimos; convenção BVA específica de regra universal; esforço de duração; percentil de máximo individual; condicionais de garantias; anomalia de defeito e evidência de causa. Estes limites são preservados nos registos integrais de cada item. Melhorias editoriais opcionais não são convertidas em defeitos obrigatórios nem em alterações aplicadas.

A tensão principal é a calibração cognitiva de tl-038 versus outros exercícios K3 com alternativas já preparadas. A aceitação qualificada do proprietário não resolve a avaliação independente. Há também nuances PT/EN opcionais em tl-022/tl-041 e termos decisivos como may/can, mainly, at most e TWO. A documentação anterior avalia essas nuances; a reconciliação confirma rastreabilidade e coerência de registos, mas não substitui uma nova resolução humana de todos os itens.

Cobertura de 64 objetivos significa cobertura nominal, não equivalência psicométrica, equilíbrio de dificuldade ou prova de prontidão para certificação. Não se declara ausência universal de defeitos. Os especialistas devem prioritizar os casos identificados e completar os restantes.
''')
write('integrity-and-limitations.md','''# Integridade e limites

Baseline: ZIP final autenticado do Lote 16, SHA-256 401988f6ed12b19f3d6a36e7e35a39e265524568dec9fe6dc2a1ab2225b846c7, 564 membros/563 hashes. A primeira exportação do Lote 16 não foi usada. CRC, manifesto e verificador portátil foram executados numa extração limpa; 256 referências de repositório coincidem byte a byte. O inventário inicial contém 421 ficheiros rastreados ou não ignorados, 207 pendentes; não inclui node_modules, .git, caches, segredos nem ficheiros ignorados privados.

Os nove arquivos históricos são comparados com a baseline e com HEAD. Os documentos anteriores e os 90 objetos completos são protegidos por hashes fixos autenticados. A revisão continua .10; não existe alteração funcional, de Git, de aprovação ou de publicação. Os 564 membros anteriores serão mapeados com bytes e metadados preservados; verificação final condiciona exportação válida.

Os testes desta execução são os registados em verification.md. Testes funcionais, unitários da aplicação e E2E anteriores são históricos, não execuções novas. Nada funcional foi alterado, pelo que a sua repetição ampla não demonstra benefício proporcional nesta reconciliação.

A correspondência automática de LO/K, chaves e hashes prova consistência da evidência, não verdade académica, equivalência semântica universal ou revisão humana. A consulta oficial foi textual/local; não se inventa inspeção visual de todas as páginas, identidade textual entre edições ou hashes de PDFs de exames não descarregados. As fontes locais completas não são exportadas por razões de âmbito; hashes, origem, páginas e limitações são incluídos.

Falhas históricas e recuperações permanecem preservadas. A execução exploratória atual que falhou por import shadowing e a correção de metadados de preflight são documentadas separadamente; não são testes de integridade aprovados retroativamente. Nenhuma aceitação nova nem autorização de produção resulta deste dossiê.
''')
write('README.md',f'''# Fase 10H — Reconciliação global dos 16 lotes

Data: 2026-11-08. Não é Lote 17. Revisão assistida por IA; não aprovação académica humana.

## Resultado reconstruído

90/90 IDs únicos; 364 alternativas; 64 objetivos; nove arquivos históricos. Pareceres históricos: {counts}. Dez aceites do proprietário de âmbito exato, zero aprovações humanas independentes verificadas; 90 humanApproval PENDING no banco. Branch develop, HEAD {P['head']}, revisão .10.

A matriz global preserva os registos completos e as referências por item. tl-038 mantém BLOCKED_HUMAN_DECISION, mesmo com aceite qualificado do proprietário. tl-011 e tl-090 mantêm AI_CORRECTED_PENDING_HUMAN e correspondem exatamente às versões e hashes aceites. Não há novo parecer por lote nem nova aceitação.

## Navegação

- global-matrix.json: 90 linhas, LO/K, versão, respostas, parecer, aceitação, fontes, hashes e história.
- batch-evidence-inventory.json: todos os documentos dos 16 lotes e inventário Git inicial.
- exceptions-conflicts.json e global-consistency.md: limites, cronologia e tensões de avaliação.
- correction-comparisons.json: objetos completos antes/depois das duas correções.
- tl-038-assessment.md: decisão pendente de calibração K3.
- approval-reconciliation.json: dez aceites explícitos e escopo preservado.
- sources.json, pending-human-decisions.json e human-review-plan.md: consulta e próximas decisões.
- verification.md: execuções novas; integridade técnica não implica verdade académica.

Estado de conclusão técnica condicionado aos guards e exportação: RECONCILIATION_TECHNICALLY_VERIFIED — HUMAN_ACADEMIC_REVIEW_PENDING — PHASE10H_OPEN. Não constitui autorização de publicação.
''')
write('file-inventory.json',{'createdDirectory':DEST.relative_to(ROOT).as_posix(),'existingFilesBefore':P['existingFilesSHA256'],'newFilesAtGeneration':sorted(p.relative_to(ROOT).as_posix() for p in DEST.rglob('*') if p.is_file()),'allowedAdditions':'Only this new reconciliation dossier plus external read-only audit/export helpers and evidence; final manifest inventories later verification files','existingFilesModified':[]})
print(json.dumps({'created':str(DEST),'rows':len(rows),'counts':counts,'owners':len(owners),'humanPending':90,'priorAcademicDocuments':sum(b['fileCount'] for b in batches),'priorFilesPreserved':len(P['existingFilesSHA256'])}))
