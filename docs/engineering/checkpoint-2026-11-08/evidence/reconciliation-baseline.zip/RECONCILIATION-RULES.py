"""Read-only, network-free reconciliation checks. Integrity is not academic approval."""
import json,hashlib,copy,collections,pathlib
BANK_SHA='9a6bc09d6ab5a512cb53ea26dc7a1da5ae465167bf5e2b6ba8c9c9b34f332615'
BASELINE_SHA='401988f6ed12b19f3d6a36e7e35a39e265524568dec9fe6dc2a1ab2225b846c7'
CONTRACT_SHA='0ea03645d9b544a99a6e8a5668f9c17db5e5810372bdc64ad2cab7580013cbf4'
DOC='docs/academic/phase10h-reconciliation-2026-11-08/'
def digest(data): return hashlib.sha256(data).hexdigest()
def canonical(v): return digest(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def require(ok,why):
 if not ok: raise ValueError(why)
def check(data):
 contract_bytes=data['RECONCILIATION-CONTRACT.json']; require(digest(contract_bytes)==CONTRACT_SHA,'immutable contract changed')
 c=json.loads(contract_bytes)
 require(c['baselineSHA256']==BASELINE_SHA,'baseline identity')
 refbytes=data['review-data/current-bank.json']; require(digest(refbytes)==BANK_SHA,'immutable bank reference changed')
 ref=json.loads(refbytes); bank=json.loads(data['reconciliation/current-bank.json'])
 require(bank==ref,'unauthorized full-bank change')
 require(len(bank)==90 and len({q['id'] for q in bank})==90,'90 unique objects')
 require(sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64,'bank counts')
 require(all(q['humanApproval']=='PENDING' for q in bank),'bank human approval')
 for p,h in c['protectedEvidence'].items():
  require(p in data,'missing historical evidence: '+p)
  require(digest(data[p])==h,'historical evidence changed: '+p)
 matrix=json.loads(data[DOC+'global-matrix.json']); rows=matrix['rows']
 require(len(rows)==90 and len({r['questionId'] for r in rows})==90,'omission or duplicate')
 by={q['id']:q for q in ref}; allowed=set(c['owners'])
 require(set(r['questionId'] for r in rows)==set(by),'missing or extra IDs')
 for r in rows:
  id=r['questionId']; q=by[id]; e=c['records'][id]
  require(r['batch']==e['batch'] and r['evidence']==e['evidence'],'historical provenance')
  require(r['historicalReviewRecord']==e['record'],'historical verdict/record changed')
  require(r['academicVerdict']==e['decision'],'historical verdict removed or approved')
  require(r['learningObjective']==q['lo'] and r['cognitiveLevel']==q['level'],'LO/K changed')
  require(r['version']==q['version'] and r['contentRevision']=='2026-10-27.10','version/revision')
  require(r['canonicalSHA256']==canonical(q),'full object hash')
  require(r['publishedKey']==q['correct'],'key changed')
  require(r['requiredAnswers']==q['required'] and r['optionCount']==len(q['options']),'cardinality')
  require(r['independentAnswer']==e['answer'],'independent answer changed')
  require(r['humanAcademicApproval']=='PENDING' and r['bankHumanApproval']=='PENDING','false human approval')
  require(r['ownerAcceptance']==c['owners'].get(id,{'state':'NOT_RECORDED'}),'owner acceptance outside authorized scope')
  require(r['sourcesAndPages']==e['sourcesAndPages'] and r['sourceCatalogue']==e['sourceCatalogue'],'source missing or changed')
  require(r['history']==e['history'],'history reconciliation changed')
  require(bool(r['historicalReviewRecord']),'missing rationale')
 require(dict(collections.Counter(r['academicVerdict'] for r in rows))=={'ACCEPT_AS_IS':87,'AI_CORRECTED_PENDING_HUMAN':2,'BLOCKED_HUMAN_DECISION':1},'verdict distribution')
 require(matrix['counts']==dict(collections.Counter(r['academicVerdict'] for r in rows)),'summary counts')
 corrections=json.loads(data[DOC+'correction-comparisons.json'])
 require(corrections==c['corrections'],'unauthorized historical correction')
 approvals=json.loads(data[DOC+'approval-reconciliation.json'])
 require(approvals==c['approvalReconciliation'],'approval record changed')
 for p,h in c['requiredNewEvidence'].items():
  require(p in data and digest(data[p])==h,'missing/changed reconciliation evidence: '+p)
 return {'questions':90,'alternatives':364,'objectives':64,'archives':9,'historicalVerdicts':{'ACCEPT_AS_IS':87,'AI_CORRECTED_PENDING_HUMAN':2,'BLOCKED_HUMAN_DECISION':1},'ownerAccepted':10,'humanApproved':0,'historicalEvidenceFiles':len(c['protectedEvidence']),'academicTruthProven':False}
def negatives(original):
 """Each mutator modifies the actual input passed to check; no unused copies."""
 results=[]
 def trial(name,mutate):
  d=dict(original); mutate(d)
  try: check(d)
  except (ValueError,KeyError,json.JSONDecodeError) as err: results.append({'case':name,'result':'REJECTED','reason':str(err)}); return
  raise AssertionError('False positive: '+name)
 def change(d,path,fn):
  x=json.loads(d[path]); fn(x); d[path]=json.dumps(x,ensure_ascii=False).encode()
 def matrix(d,fn): change(d,DOC+'global-matrix.json',lambda x:fn(x['rows']))
 trial('omitted question',lambda d:matrix(d,lambda r:r.pop()))
 trial('duplicate ID',lambda d:matrix(d,lambda r:r.__setitem__(1,copy.deepcopy(r[0]))))
 trial('key adulterated',lambda d:matrix(d,lambda r:r[0].__setitem__('publishedKey',['o2'])))
 trial('LO/K altered',lambda d:matrix(d,lambda r:r[0].__setitem__('cognitiveLevel','K3')))
 trial('historical verdict removed',lambda d:matrix(d,lambda r:r[0].__setitem__('historicalReviewRecord',{})))
 trial('tl038 approved',lambda d:matrix(d,lambda r:next(x for x in r if x['questionId']=='tl-038').__setitem__('academicVerdict','HUMAN_APPROVED')))
 trial('false human approval',lambda d:matrix(d,lambda r:r[0].__setitem__('humanAcademicApproval','HUMAN_APPROVED')))
 trial('owner scope widened',lambda d:matrix(d,lambda r:r[0].__setitem__('ownerAcceptance',{'state':'OWNER_ACCEPTED'})))
 trial('unauthorized historical correction',lambda d:change(d,DOC+'correction-comparisons.json',lambda x:x[0]['after'].__setitem__('version',999)))
 trial('historical archive tampered',lambda d:d.__setitem__('src/data/archive/questions-2026-10-27.1.json',b'[]'))
 trial('source missing',lambda d:d.pop('docs/academic/phase10h-batch1-2026-11-05/sources-verified.json'))
 trial('prior verdict evidence removed',lambda d:d.pop('docs/academic/phase10h-batch2-2026-11-05/records.json'))
 trial('new human assessment evidence missing',lambda d:d.pop(DOC+'tl-038-assessment.md'))
 trial('source reference altered',lambda d:matrix(d,lambda r:r[0].__setitem__('sourcesAndPages',{})))
 trial('historical key changed',lambda d:matrix(d,lambda r:r[0]['history'][-1].__setitem__('key',['o9'])))
 trial('immutable reference altered',lambda d:d.__setitem__('review-data/current-bank.json',b'[]'))
 trial('contract rederived from candidate',lambda d:d.__setitem__('RECONCILIATION-CONTRACT.json',b'{}'))
 for index in range(90):
  trial('full object text mutation '+str(index+1),lambda d,i=index:change(d,'reconciliation/current-bank.json',lambda q:q[i]['text'].__setitem__('pt',q[i]['text']['pt']+' adulterado')))
 for name,fn in [('bank key',lambda b:b[1].__setitem__('correct',['o9'])),('bank version',lambda b:b[1].__setitem__('version',99)),('bank explanation',lambda b:b[1]['explanation'].__setitem__('en','altered')),('bank removed',lambda b:b.pop()),('bank duplicated',lambda b:b.__setitem__(1,copy.deepcopy(b[0]))),('false bank approval',lambda b:b[1].__setitem__('humanApproval','HUMAN_APPROVED'))]:
  trial(name,lambda d,f=fn:change(d,'reconciliation/current-bank.json',f))
 return results
