"""Read-only consistency/identity checks. Not automated semantic or human approval."""
import copy,hashlib,json,re,datetime
IDS=['tl-084', 'tl-085']
EXPECTED={'tl-084': ('FL-2.2.2', 'K2', 1, 'bd143f481130dccaa80bd6ac8c6ceb42e1566409aa8e10ed50063d884df76f39'), 'tl-085': ('FL-5.2.4', 'K2', 1, '7e58e2424021b96398caee8e0b489767e952131b97e642a63edbd1d8d8f2c161')}
KEYS={'tl-084': ['o1', 'o4'], 'tl-085': ['o2', 'o5']}
FORMAT={'tl-084': (5, 2), 'tl-085': (5, 2)}
REFS={'tl-084': {'2.2.2': {'EN': [29, 30], 'PT': [32, 33]}, '2.2.1': {'EN': [29], 'PT': [31, 32]}}, 'tl-085': {'5.2.4': {'EN': [53], 'PT': [59]}, '5.2.3': {'EN': [52, 53], 'PT': [58, 59]}}}
LOPAGES={2: {'EN': [24], 'PT': [26]}, 5: {'EN': [47], 'PT': [52]}}
BLIND_CANONICAL='58b2c7d1705b7ed973bcc8b5e1623f2084bee8a289e1f79b0408ac5a31c36e5d'
PROJECTION_CANONICAL='2737436f64666caedbadaf9c6819ed7696d4ffebdfb5d85d268b6ba85b6b24bc'
def canonical(q):return hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(bank,matrix,comparisons,blind,projections,alternatives,sources,optional,reports,archives):
 assert canonical(blind)==BLIND_CANONICAL and canonical(projections)==PROJECTION_CANONICAL
 assert matrix['scope']=='Phase 10H Batch 16 only' and matrix['ownerAcceptedCount']==matrix['humanApprovedCount']==matrix['contentChanges']==0
 assert [d['questionId'] for d in matrix['decisions']]==IDS and len(comparisons)==len(projections)==len(blind['solutions'])==2
 assert len(alternatives)==len({(a['questionId'],a['optionId']) for a in alternatives})==10 and set(reports)==set(IDS)
 assert blind['reviewerType']=='AI' and not blind['publishedKeysConsultedBeforeRecording'] and not blind['publishedExplanationsConsultedBeforeRecording'] and not blind['ownerAccepted'] and not blind['humanApproved']
 assert set(archives)=={f'2026-10-27.{i}' for i in range(1,10)}
 assert len(bank)==len({q['id'] for q in bank})==90 and sum(len(q['options']) for q in bank)==364 and len({q['lo'] for q in bank})==64
 for s in sources['sources']:
  assert s['sha256']==('3b072f81db5c7671aadacc42553e726faa93913a969cc7a89e9dc28c2318d1f1' if s['language']=='EN' else 'ee82959e813673016a4872ad805b883b74e702224a307b728c807c24a269a496')
 assert {s['language'] for s in sources['sources']}=={'EN','PT'}
 checks=[]
 for d,c,projection,s in zip(matrix['decisions'],comparisons,projections,blind['solutions']):
  ident=d['questionId'];q=next(q for q in bank if q['id']==ident);lo,k,v,h=EXPECTED[ident]
  assert (q['lo'],q['level'],q['version'],canonical(q))==(lo,k,v,h) and q['correct']==KEYS[ident] and q['required']==FORMAT[ident][1] and len(q['options'])==FORMAT[ident][0]
  assert d['decision']=='ACCEPT_AS_IS' and d['confirmedProblems']==[] and d['confirmedProblemSeverity'] is None and d['unresolvedMandatoryIssues']==[]
  assert d['existingKey']==d['proposedKey']==d['independentAnswer']==s['answer']==KEYS[ident] and s['questionId']==ident and d['keyComparison']=='MATCH'
  assert d['ownerDecision'] is None and d['humanApproval']==q['humanApproval']=='PENDING' and not d['contentChanged'] and not d['priorNONEUsedAsEvidence']
  assert (d['learningObjective'],d['cognitiveLevel'],d['questionVersion'],d['requiredAnswers'])==(lo,k,v,FORMAT[ident][1])
  assert d['beforeCanonicalSHA256']==d['afterCanonicalSHA256']==h and d['contentRevisionBefore']==d['contentRevisionAfter']=='2026-10-27.10'
  assert c=={'questionId':ident,'original':q,'proposed':q,'changed':False}
  assert set(projection)=={'id','lo','level','required','text','options'} and projection['required']==2 and projection['id']==ident and projection['text']==q['text'] and (projection['lo'],projection['level'])==(lo,k)
  assert projection['options']==sorted([{'id':o['id'],'text':o['text']} for o in q['options']],key=lambda o:hashlib.sha256((ident+o['id']).encode()).hexdigest())
  assert s['shuffledOrder']==[o['id'] for o in projection['options']] and len(s['reasonPT'])>100 and set(s['optionAssessmentsEN'])=={o['id'] for o in q['options']}
  assert datetime.datetime.fromisoformat(s['recordedAt']).tzinfo
  for field in ['assessmentPT','counterEvidencePT','translationAssessmentPT','pedagogyAssessmentPT','editionDifferencePT']:assert len(d[field])>100
  assert d['references']==REFS[ident] and d['LOPages']==LOPAGES[q['chapter']]
  for refs in d['references'].values():
   for lang,pages in refs.items():assert set(pages)<=set(next(x['pagesConsulted'] for x in sources['sources'] if x['language']==lang))
  for a in [a for a in alternatives if a['questionId']==ident]:
   o=next(o for o in q['options'] if o['id']==a['optionId']);assert a['text']==o['text'] and a['publishedExplanation']==o['explanation'] and a['supportsAnswer']==(o['id'] in KEYS[ident])
   assert len(a['reviewPT'])>50 and a['reviewEN']==s['optionAssessmentsEN'][o['id']] and len(a['reviewEN'])>50 and a['references']==REFS[ident]
  assert len([a for a in alternatives if a['questionId']==ident])==FORMAT[ident][0]
  for pair in d['criticalPairs']:assert pair['en'] in json.dumps(q,ensure_ascii=False) and pair['pt'] in json.dumps(q,ensure_ascii=False)
  assert len(d['history'])==9
  for entry in d['history']:
   a=next((a for a in archives[entry['contentRevision']] if a['id']==ident),None);assert entry['present']==(a is not None)
   if a is not None:assert (entry['version'],entry['key'],entry['canonicalSHA256'],entry['equalCurrent'])==(a['version'],a['correct'],canonical(a),a==q)
  blocks=[]
  for lang in ['pt','en']:blocks.extend([q['text'][lang]]*2)
  for o in q['options']:
   for lang in ['pt','en']:
    for field in ['text','explanation']:blocks.extend([o[field][lang]]*2)
  for lang in ['pt','en']:blocks.extend([q['explanation'][lang]]*2)
  actualBlocks=8+8*FORMAT[ident][0]
  assert optional==[], 'No bank proposal is authorized or necessary in Batch16'
  assert re.findall(r'```text\n([\s\S]*?)\n```',reports[ident])==blocks
  prose=re.sub(r'```[\s\S]*?```','',reports[ident]);assert not re.search(r'(?:[A-Za-zÀ-ÿ](?:o[1-4]|E2E)|(?:o[1-4]|E2E)[A-Za-zÀ-ÿ])',prose)
  side=reports[ident].split('## Comparação literal lado a lado')[1]
  actualRows=[tuple(cell.strip() for cell in line.strip().strip('|').split('|')) for line in side.splitlines() if line.startswith('|')][2:]
  expectedRows=[]
  for lang in ['pt','en']:
   values=[('Enunciado',q['text'][lang]),*[(o['id']+' '+field,o[field][lang]) for o in q['options'] for field in ['text','explanation']],('Explicação geral',q['explanation'][lang])]
   expectedRows.extend((lang.upper()+' '+label,text,text) for label,text in values)
  assert actualRows==expectedRows and d['optionCount']==5
  assert 'não aprovação humana' in prose and str(s['recordedAt']) in prose
  checks.append({'questionId':ident,'canonicalSHA256':h,'independentKey':KEYS[ident],'publishedKey':KEYS[ident],'alternativesVerified':FORMAT[ident][0],'actualComparisonBlocks':actualBlocks,'optionalComparisonBlocks':len(blocks)-actualBlocks,'priorNONEUsedAsEvidence':False})
 q001=next(q for q in bank if q['id']=='tl-001');assert q001['correct']==['o1','o4'] and q001['required']==2
 return {'result':'PASS','questions':checks,'reviewedQuestions':2,'reviewedAlternatives':10,'actualComparisonBlocks':96,'optionalComparisonBlocks':0,'semanticTruthAutomaticallyProven':False}
def negative_checks(*args, global_check, reference_bank):
 check(*args)
 cases=[('wrong key',1,lambda a:a['decisions'][0].update(existingKey=['o3'])),('second answer accepted',5,lambda a:a[1].update(supportsAnswer=True)),('missing option assessment',5,lambda a:a.pop()),('PT text incompatible with source',5,lambda a:a[0]['text'].update(pt='adulterado')),('missing published explanation',5,lambda a:a[0]['publishedExplanation'].update(pt='')),('missing reasoning',3,lambda a:a['solutions'][0].update(reasonPT='')),('unauthorized bank edit',0,lambda a:a[1]['text'].update(en='adulterated bank')),('false human approval',1,lambda a:a['decisions'][0].update(humanApproval='HUMAN_APPROVED')),('false owner acceptance',1,lambda a:a['decisions'][0].update(ownerDecision='OWNER_ACCEPTED')),('invalid source pages',1,lambda a:a['decisions'][0]['references']['2.2.2'].update(EN=[999])),('corrupted historical question',9,lambda a:next(q for q in a['2026-10-27.9'] if q['id']=='tl-084')['explanation'].update(pt='adulterado')),('NONE reused as approval',1,lambda a:a['decisions'][0].update(priorNONEUsedAsEvidence=True)),('key leaked into blind projection',4,lambda a:a[0].update(correct=['o1'])),('unauthorized proposal added or applied',7,lambda a:a.append({'questionId':'tl-084','applied':True})),('missing counterevidence',1,lambda a:a['decisions'][1].update(counterEvidencePT='')),('partial tl-085 key',1,lambda a:a['decisions'][-1].update(existingKey=['o2'])),('extra tl-085 key',1,lambda a:a['decisions'][-1].update(existingKey=['o2','o4','o5'])),('missing required report',8,lambda a:a.pop('tl-084')),('bank alternative removed',0,lambda a:next(q for q in a if q['id']=='tl-084')['options'].pop()),('bank version changed',0,lambda a:next(q for q in a if q['id']=='tl-084').update(version=999)),('content revision changed',1,lambda a:a['decisions'][0].update(contentRevisionAfter='2026-10-27.11')),('required cardinality changed',0,lambda a:next(q for q in a if q['id']=='tl-084').update(required=1)),('bank explanation changed',0,lambda a:next(q for q in a if q['id']=='tl-084')['explanation'].update(pt='adulterado')),('EN option changed',5,lambda a:a[0]['text'].update(en='tampered')),('blind timestamp changed',3,lambda a:a['solutions'][0].update(recordedAt='2000-01-01T00:00:00+00:00'))]
 rejected=[]
 for name,i,mutate in cases:
  a=copy.deepcopy(list(args));mutate(a[i])
  # Preserve the exact original tl-002 mutation and rejection expectation.
  # It belongs to full-bank protection; all review-evidence cases stay scoped.
  try:
   if name=='unauthorized bank edit':global_check(a[0],reference_bank)
   else:check(*a)
  except (AssertionError,KeyError):rejected.append(name)
  else:raise AssertionError('False positive: '+name)
 scoped=copy.deepcopy(list(args));next(q for q in scoped[0] if q['id']=='tl-084')['text']['en']='adulterated bank'
 try:check(*scoped)
 except AssertionError:rejected.append('reviewed question tl-084 edit rejected by scoped guard')
 else:raise AssertionError('Scoped false positive for tl-084')
 return {'result':'PASS','negativeCasesRejected':len(rejected),'cases':rejected,'originalTl002CasePreserved':True,'globalCases':['unauthorized bank edit'],'scopedCases':len(rejected)-1,'claimLimit':'Combined dispatch preserves separate scoped and global contracts; not automatic semantic proof.'}
