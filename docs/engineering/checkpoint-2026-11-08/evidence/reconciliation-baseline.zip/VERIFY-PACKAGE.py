"""Offline, standard-library, read-only verifier; no academic truth certification."""
import pathlib,sys,json,hashlib,importlib.util
sys.dont_write_bytecode=True
GUARD_SHA='71e9a909d8dd0c16df7ddc39b1256d2f71e2a462b72c4f2e7d31a0df1ec24c2a'
CONTINUITY_SHA='2fdc596fb9051ffafaa57bb6cd253dc6a78085d562f8ccdcf9a52f4a642c336e'
def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok: raise ValueError(message)
def safe(name):
 p=pathlib.PurePosixPath(name)
 return bool(name) and not p.is_absolute() and all(x not in ('','..','.') for x in name.split('/')) and '\\' not in name and ':' not in name
def verify(root):
 root=pathlib.Path(root).resolve(); manifest=json.loads((root/'MANIFEST.json').read_bytes()); entries=manifest['files']
 names=[e['relativePath'] for e in entries]
 need(len(names)==len(set(names)),'duplicate manifest paths')
 data={}
 for e in entries:
  name=e['relativePath'];need(safe(name),'unsafe manifest path')
  p=root/name;need(p.is_file() and not p.is_symlink(),'missing file or symlink: '+name)
  need(p.resolve().is_relative_to(root),'path escape')
  b=p.read_bytes();need(len(b)==e['sizeBytes'] and sha(b)==e['sha256'],'size/hash mismatch: '+name);data[name]=b
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 need(actual==set(names)|{'MANIFEST.json'},'unexpected or missing members')
 need(sha(data['EXPORT-CONTINUITY.json'])==CONTINUITY_SHA,'continuity index changed')
 continuity=json.loads(data['EXPORT-CONTINUITY.json']);need(len(continuity['members'])==564,'prior member count')
 need(len({x['sourcePath'] for x in continuity['members']})==564,'prior duplicates')
 for m in continuity['members']:
  need(safe(m['destinationPath']),'unsafe continuity path')
  b=data[m['destinationPath']];need(len(b)==m['sizeBytes'] and sha(b)==m['sha256'],'prior member changed')
 need(sha(data['RECONCILIATION-RULES.py'])==GUARD_SHA,'guard code changed')
 spec=importlib.util.spec_from_file_location('reconciliation_guard',root/'RECONCILIATION-RULES.py'); guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
 result=guard.check(data); negative=guard.negatives(data)
 return {'result':'PASS','filesIncludingManifest':len(names)+1,'payloadHashes':len(names),'priorMembersPreserved':564,'negativeCasesRejected':len(negative),'reconciliation':result,'limit':'Integrity and consistency only, not human academic approval or truth'}
if __name__=='__main__':
 try: print(json.dumps(verify(sys.argv[1] if len(sys.argv)>1 else pathlib.Path(__file__).parent),ensure_ascii=False,indent=2))
 except Exception as error: print(type(error).__name__+': '+str(error),file=sys.stderr);sys.exit(1)
