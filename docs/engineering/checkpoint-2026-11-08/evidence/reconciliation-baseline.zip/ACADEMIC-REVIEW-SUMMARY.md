# TestLearn — Fase 10H, Lote 16

Âmbito fechado: tl-084 (FL-2.2.2/K2) e tl-085 (FL-5.2.4/K2), cinco alternativas e duas respostas cada: duas questões, dez alternativas e 96 blocos literais antes/depois. Soluções cegas guardadas antes de revelar chaves e explicações, com data UTC e hash. Dois pareceres ACCEPT_AS_IS por IA, sem usar NONE ou coincidência de chave como prova académica.

Preflight em 2026-11-07; dossiê criado em 2026-11-08. Os horários reais são preservados quando a execução atravessa a meia-noite. Baseline: develop, HEAD 3fd0a85d95ecb79539515833ee3cbe7869c58049, revisão 2026-10-27.10; 90 questões, 364 alternativas, 64 objetivos e nove arquivos históricos. Pacote do Lote 15 autenticado: 387a3e01f6c6b87bd3ad5229477fe7286f6a2c955bf4a82e114d0d980b4df68e, 518 membros e 517 hashes. Inventário inicial: 409 ficheiros rastreados/não ignorados, 195 não rastreados e 206 documentos académicos anteriores, todos preservados.

tl-084: resultado funcional versus qualidade de desempenho, limite inclusivo p95 ≤ 300 ms e condição de 200 utilizadores concorrentes. Percentil 95 não significa máximo individual. A regra matemática é interpretação do requisito, não uma definição estatística atribuída ao syllabus. API não prova caixa-branca nem carga prova nível de integração de sistemas. O método amostral de percentil não está especificado e não é necessário para classificar os tipos de teste.

tl-085: executar mitigação e acompanhar eficácia/adaptar resposta a riscos emergentes são controlo; identificação, classificação e categorização repetidas são análise inicial neste cenário. Não se proíbe reanálise futura. Testes de mudança da hora são exemplo contextual, sem inventar regras tarifárias.

As fontes oficiais EN v4.0.1 e PT v4.0 tradução 1.0 foram consultadas por secção e página física; ambos os endpoints remotos acessíveis e cópias locais identificadas por hash. Não se afirma identidade textual ou igualdade remota dos bytes. Não se exportam PDFs integrais ou dados reais. A interpretação e contraevidência do revisor estão separadas dos textos literais publicados.

Guard específico protege dois objetos completos e a evidência. Guard global compara os 90 objetos completos com referência fixa extraída do ZIP autenticado do Lote 15. Não deriva a referência do candidato. Casos negativos só alteram cópias isoladas e respeitam os dois âmbitos. Controlos anteriores são preservados; os novos auxiliares não os substituem nem enfraquecem.

Sem alteração a banco, gabaritos, explicações, versões, objetivos, pontuação, persistência, aplicação, testes ou guards anteriores. Sem OWNER_ACCEPTED ou HUMAN_APPROVED novo. Revisão por IA não é revisão académica humana independente. Nenhuma correção obrigatória ou proposta editorial justificada foi identificada; optional-candidates.json vazio.

Exportar apenas depois dos gates, com continuidade exata dos 518 membros anteriores, incluindo metadados e manifesto histórico. Este é dossiê de evidência, não repositório executável completo. Ver verification.md para execuções novas, limites e verificações não executadas. Fase 10H permanece aberta: reconciliação global e revisão humana são etapas separadas, não iniciadas automaticamente. Sem Git remoto, commit, branch, PR, merge, push ou deploy.


# tl-084 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-2.2.2 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `bd143f481130dccaa80bd6ac8c6ceb42e1566409aa8e10ed50063d884df76f39`.

Resposta pré-gabarito: `['o1', 'o4']`; registada em `2026-11-07T23:59:13.612875+00:00`. Chave consultada depois: `['o1', 'o4']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 5 alternativas; selecionar 2.

## Resolução independente e fundamento

O conjunto o1/o4 é único: quantidade em stock verifica correção funcional; latência sob carga visa eficiência de desempenho não funcional. As duas verificações podem usar a mesma consulta. A base são os requisitos, sem estrutura interna, pelo que chamar uma API não transforma testes em caixa-branca. Concorrência de 200 utilizadores é condição de carga, não definição do nível integração de sistemas.

Raciocínio guardado antes da revelação:

A quantidade devolvida compara o resultado funcional com o requisito. O percentil 95 da latência, sob 200 utilizadores concorrentes, mede eficiência de desempenho. No máximo é inclusivo: p95=300 ms cumpre esse limite; não exige que todas as respostas tenham latência até 300 ms. O requisito não especifica método estatístico, amostragem ou duração, pelo que não se inventam. A origem em requisitos sem estrutura indica caixa-preta; API e concorrência não fixam técnica nem nível.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 2.2.2: EN páginas [29, 30]; PT páginas [32, 33].
- Secção 2.2.1: EN páginas [29]; PT páginas [31, 32].

- LO FL-2.2.2/K2: EN página 24; PT página 26.

EN secção 2.2.2 começa na página 29 e continua na 30; PT está nas páginas 32–33. Ambas permitem derivar não funcionais de operações funcionais e distinguem bases de especificação/estrutura. A lista EN atualiza nomes e inclui safety, ao contrário da lista PT mais antiga; eficiência de desempenho está em ambas e esta diferença não altera o item. Níveis de sistema e integração são apoiados por EN página 29 e PT página 31.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web nesta execução; referências e páginas verificadas nas cópias oficiais locais, com origem e hashes declarados. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

At most/no máximo traduz o limite inclusivo p95 ≤ 300 ms; p95 igual a 300 ms satisfaz o limite, sem inventar tolerância de arredondamento. 95th-percentile/percentil 95 mantém estatística de distribuição, não máximo de cada resposta. With 200 concurrent users/com 200 utilizadores concorrentes preserva carga e simultaneidade. Select TWO/Selecione DUAS preserva duas respostas entre cinco. Estes factos matemáticos são interpretação do requisito, não uma definição de percentil inventada no syllabus.

| EN literal           | PT literal                    |
| -------------------- | ----------------------------- |
| at most 300 ms       | no máximo, 300 ms             |
| 95th-percentile      | percentil 95                  |
| 200 concurrent users | 200 utilizadores concorrentes |
| Select TWO           | Selecione DUAS                |

## Contraevidência e outras respostas defensáveis

Uma API pode ser usada num teste estrutural ou de integração, mas isso exigiria base estrutural ou âmbito de sistemas que o cenário não fornece; o5 e o3 impõem conclusões por si só. A falta de duração e método de quantil seria relevante para um ensaio de desempenho executável, mas não torna ambígua a classificação conceptual pedida. O percentil 95 não exige todas as respostas até 300 ms.

## LO, nível K, explicações e dificuldade

K2: distinguir tipos funcionais/não funcionais e separá-los da base de derivação e do nível, explicando dois objetivos sobre a mesma operação. Não é necessário calcular um percentil, instrumentar uma API ou executar 200 utilizadores, o que seria outra tarefa. A explicação geral e as cinco justificações são corretas; não explicitam toda definição estatística, mas não a contradizem e são suficientes para o objetivo.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Para um serviço de armazém, os requisitos especificam a quantidade em stock devolvida para um código de barras válido e uma latência de resposta no percentil 95 de, no máximo, 300 ms com 200 utilizadores concorrentes. Os testes usam chamadas à API derivadas destes requisitos, não da estrutura do código. Selecione DUAS classificações corretas.
```

Proposto atual — sem alteração

```text
Para um serviço de armazém, os requisitos especificam a quantidade em stock devolvida para um código de barras válido e uma latência de resposta no percentil 95 de, no máximo, 300 ms com 200 utilizadores concorrentes. Os testes usam chamadas à API derivadas destes requisitos, não da estrutura do código. Selecione DUAS classificações corretas.
```

### Enunciado EN

Original

```text
For a warehouse service, requirements specify the stock quantity returned for a valid barcode and a 95th-percentile response latency of at most 300 ms with 200 concurrent users. Tests use API calls derived from these requirements, not code structure. Select TWO correct classifications.
```

Proposto atual — sem alteração

```text
For a warehouse service, requirements specify the stock quantity returned for a valid barcode and a 95th-percentile response latency of at most 300 ms with 200 concurrent users. Tests use API calls derived from these requirements, not code structure. Select TWO correct classifications.
```

### o1 — alternativa PT

Original

```text
Verificar a quantidade em stock devolvida visa a correção funcional.
```

Proposto atual — sem alteração

```text
Verificar a quantidade em stock devolvida visa a correção funcional.
```

### o1 — explicação PT

Original

```text
A asserção verifica o que o serviço faz: devolver o valor de stock especificado para a entrada.
```

Proposto atual — sem alteração

```text
A asserção verifica o que o serviço faz: devolver o valor de stock especificado para a entrada.
```

### o1 — alternativa EN

Original

```text
Checking the returned stock quantity targets functional correctness.
```

Proposto atual — sem alteração

```text
Checking the returned stock quantity targets functional correctness.
```

### o1 — explicação EN

Original

```text
The assertion checks what the service does: returning the specified stock value for the input.
```

Proposto atual — sem alteração

```text
The assertion checks what the service does: returning the specified stock value for the input.
```

### o2 — alternativa PT

Original

```text
Verificar a latência é teste funcional porque executa a mesma consulta de stock.
```

Proposto atual — sem alteração

```text
Verificar a latência é teste funcional porque executa a mesma consulta de stock.
```

### o2 — explicação PT

Original

```text
Um teste não funcional pode reutilizar uma operação funcional enquanto avalia uma restrição de desempenho, em vez do resultado funcional.
```

Proposto atual — sem alteração

```text
Um teste não funcional pode reutilizar uma operação funcional enquanto avalia uma restrição de desempenho, em vez do resultado funcional.
```

### o2 — alternativa EN

Original

```text
Checking latency is functional testing because it executes the same stock query.
```

Proposto atual — sem alteração

```text
Checking latency is functional testing because it executes the same stock query.
```

### o2 — explicação EN

Original

```text
A non-functional test can reuse a functional operation while assessing a performance constraint rather than its functional output.
```

Proposto atual — sem alteração

```text
A non-functional test can reuse a functional operation while assessing a performance constraint rather than its functional output.
```

### o3 — alternativa PT

Original

```text
Os utilizadores concorrentes tornam o nível de teste integração de sistemas, independentemente dos sistemas envolvidos.
```

Proposto atual — sem alteração

```text
Os utilizadores concorrentes tornam o nível de teste integração de sistemas, independentemente dos sistemas envolvidos.
```

### o3 — explicação PT

Original

```text
A concorrência é uma característica de carga, não evidência de interfaces com sistemas externos. O nível de teste depende do objeto e do âmbito.
```

Proposto atual — sem alteração

```text
A concorrência é uma característica de carga, não evidência de interfaces com sistemas externos. O nível de teste depende do objeto e do âmbito.
```

### o3 — alternativa EN

Original

```text
The concurrent users make the test level system integration, irrespective of the systems involved.
```

Proposto atual — sem alteração

```text
The concurrent users make the test level system integration, irrespective of the systems involved.
```

### o3 — explicação EN

Original

```text
Concurrency is a load characteristic, not evidence of interfaces with external systems. Test level depends on the object and scope.
```

Proposto atual — sem alteração

```text
Concurrency is a load characteristic, not evidence of interfaces with external systems. Test level depends on the object and scope.
```

### o4 — alternativa PT

Original

```text
Verificar o limite de latência visa a característica não funcional eficiência de desempenho.
```

Proposto atual — sem alteração

```text
Verificar o limite de latência visa a característica não funcional eficiência de desempenho.
```

### o4 — explicação PT

Original

```text
A restrição temporal descreve quão bem o serviço realiza a função. É uma restrição de qualidade não funcional.
```

Proposto atual — sem alteração

```text
A restrição temporal descreve quão bem o serviço realiza a função. É uma restrição de qualidade não funcional.
```

### o4 — alternativa EN

Original

```text
Checking the latency limit targets the non-functional characteristic performance efficiency.
```

Proposto atual — sem alteração

```text
Checking the latency limit targets the non-functional characteristic performance efficiency.
```

### o4 — explicação EN

Original

```text
The time constraint describes how well the service performs its function. It is a non-functional quality constraint.
```

Proposto atual — sem alteração

```text
The time constraint describes how well the service performs its function. It is a non-functional quality constraint.
```

### o5 — alternativa PT

Original

```text
Usar uma API torna ambos os testes de caixa-branca, mesmo quando a sua base são os requisitos.
```

Proposto atual — sem alteração

```text
Usar uma API torna ambos os testes de caixa-branca, mesmo quando a sua base são os requisitos.
```

### o5 — explicação PT

Original

```text
A base de derivação, e não a interface usada para executar um teste, distingue testes baseados na especificação de testes baseados na estrutura.
```

Proposto atual — sem alteração

```text
A base de derivação, e não a interface usada para executar um teste, distingue testes baseados na especificação de testes baseados na estrutura.
```

### o5 — alternativa EN

Original

```text
Using an API makes both tests white-box, even when their basis is the requirements.
```

Proposto atual — sem alteração

```text
Using an API makes both tests white-box, even when their basis is the requirements.
```

### o5 — explicação EN

Original

```text
The derivation basis, not the interface used to execute a test, distinguishes specification-based from structure-based testing.
```

Proposto atual — sem alteração

```text
The derivation basis, not the interface used to execute a test, distinguishes specification-based from structure-based testing.
```

### Explicação geral PT

Original

```text
A asserção sobre o resultado é funcional; a asserção sobre a latência é não funcional. Ambas podem exercitar a mesma operação. O acesso pela API e a concorrência, por si só, não determinam uma base de caixa-branca nem o nível de integração de sistemas.
```

Proposto atual — sem alteração

```text
A asserção sobre o resultado é funcional; a asserção sobre a latência é não funcional. Ambas podem exercitar a mesma operação. O acesso pela API e a concorrência, por si só, não determinam uma base de caixa-branca nem o nível de integração de sistemas.
```

### Explicação geral EN

Original

```text
The output assertion is functional; the latency assertion is non-functional. They can exercise the same operation. API access and concurrency do not by themselves determine a white-box basis or a system-integration test level.
```

Proposto atual — sem alteração

```text
The output assertion is functional; the latency assertion is non-functional. They can exercise the same operation. API access and concurrency do not by themselves determine a white-box basis or a system-integration test level.
```

## Avaliação de todas as alternativas

### o1 — correta

Correta: a quantidade devolvida para um código de barras válido compara o resultado com a especificação, visando correção funcional e não rapidez.

Returned stock quantity checks the required functional result for a valid barcode, so it targets functional correctness. Correctness of the quantity is distinct from how quickly that quantity is returned.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — distrator

Incorreta: usar a mesma consulta não torna funcional o objetivo temporal; a fonte permite verificar exigências não funcionais durante uma função.

Executing the same query does not make its latency objective functional. The objective is how well the function performs, so a timing constraint remains non-functional even when it shares inputs and execution with a functional test.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

Incorreta: concorrência é condição de carga; não prova interfaces entre sistemas externos nem determina nível sem conhecer objeto e âmbito.

Concurrent users specify a workload condition, not a test level. System integration concerns the relevant system boundaries and interfaces; concurrency alone cannot establish which systems are involved.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — correta

Correta: o limite do percentil de latência sob 200 utilizadores visa eficiência de desempenho; no máximo inclui igualdade, sem exigir todas as respostas abaixo do limiar.

The response-latency requirement targets performance efficiency. At most300 ms is inclusive, and a95th-percentile limit is not a maximum over every individual response. The200-concurrent-user condition must be retained when interpreting this measurement.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o5 — distrator

Incorreta: executar através da API não é base estrutural; o enunciado exclui derivação da estrutura e explicita requisitos como fundamento.

The interface used does not determine white-box derivation. The statement explicitly derives API tests from requirements and not internal structure, so the tests remain specification-based black-box tests.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave        | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —            | —                                                                |
| 2026-10-27.2 | False    | —      | —            | —                                                                |
| 2026-10-27.3 | False    | —      | —            | —                                                                |
| 2026-10-27.4 | False    | —      | —            | —                                                                |
| 2026-10-27.5 | False    | —      | —            | —                                                                |
| 2026-10-27.6 | False    | —      | —            | —                                                                |
| 2026-10-27.7 | False    | —      | —            | —                                                                |
| 2026-10-27.8 | False    | —      | —            | —                                                                |
| 2026-10-27.9 | True     | 1      | ['o1', 'o4'] | bd143f481130dccaa80bd6ac8c6ceb42e1566409aa8e10ed50063d884df76f39 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 16; reconciliação global e revisão humana são etapas separadas, não iniciadas automaticamente.

## Comparação literal lado a lado

| Campo               | Original                                                                                                                                                                                                                                                                                                                                                 | Proposto não aplicado — idêntico                                                                                                                                                                                                                                                                                                                         |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| PT Enunciado        | Para um serviço de armazém, os requisitos especificam a quantidade em stock devolvida para um código de barras válido e uma latência de resposta no percentil 95 de, no máximo, 300 ms com 200 utilizadores concorrentes. Os testes usam chamadas à API derivadas destes requisitos, não da estrutura do código. Selecione DUAS classificações corretas. | Para um serviço de armazém, os requisitos especificam a quantidade em stock devolvida para um código de barras válido e uma latência de resposta no percentil 95 de, no máximo, 300 ms com 200 utilizadores concorrentes. Os testes usam chamadas à API derivadas destes requisitos, não da estrutura do código. Selecione DUAS classificações corretas. |
| PT o1 text          | Verificar a quantidade em stock devolvida visa a correção funcional.                                                                                                                                                                                                                                                                                     | Verificar a quantidade em stock devolvida visa a correção funcional.                                                                                                                                                                                                                                                                                     |
| PT o1 explanation   | A asserção verifica o que o serviço faz: devolver o valor de stock especificado para a entrada.                                                                                                                                                                                                                                                          | A asserção verifica o que o serviço faz: devolver o valor de stock especificado para a entrada.                                                                                                                                                                                                                                                          |
| PT o2 text          | Verificar a latência é teste funcional porque executa a mesma consulta de stock.                                                                                                                                                                                                                                                                         | Verificar a latência é teste funcional porque executa a mesma consulta de stock.                                                                                                                                                                                                                                                                         |
| PT o2 explanation   | Um teste não funcional pode reutilizar uma operação funcional enquanto avalia uma restrição de desempenho, em vez do resultado funcional.                                                                                                                                                                                                                | Um teste não funcional pode reutilizar uma operação funcional enquanto avalia uma restrição de desempenho, em vez do resultado funcional.                                                                                                                                                                                                                |
| PT o3 text          | Os utilizadores concorrentes tornam o nível de teste integração de sistemas, independentemente dos sistemas envolvidos.                                                                                                                                                                                                                                  | Os utilizadores concorrentes tornam o nível de teste integração de sistemas, independentemente dos sistemas envolvidos.                                                                                                                                                                                                                                  |
| PT o3 explanation   | A concorrência é uma característica de carga, não evidência de interfaces com sistemas externos. O nível de teste depende do objeto e do âmbito.                                                                                                                                                                                                         | A concorrência é uma característica de carga, não evidência de interfaces com sistemas externos. O nível de teste depende do objeto e do âmbito.                                                                                                                                                                                                         |
| PT o4 text          | Verificar o limite de latência visa a característica não funcional eficiência de desempenho.                                                                                                                                                                                                                                                             | Verificar o limite de latência visa a característica não funcional eficiência de desempenho.                                                                                                                                                                                                                                                             |
| PT o4 explanation   | A restrição temporal descreve quão bem o serviço realiza a função. É uma restrição de qualidade não funcional.                                                                                                                                                                                                                                           | A restrição temporal descreve quão bem o serviço realiza a função. É uma restrição de qualidade não funcional.                                                                                                                                                                                                                                           |
| PT o5 text          | Usar uma API torna ambos os testes de caixa-branca, mesmo quando a sua base são os requisitos.                                                                                                                                                                                                                                                           | Usar uma API torna ambos os testes de caixa-branca, mesmo quando a sua base são os requisitos.                                                                                                                                                                                                                                                           |
| PT o5 explanation   | A base de derivação, e não a interface usada para executar um teste, distingue testes baseados na especificação de testes baseados na estrutura.                                                                                                                                                                                                         | A base de derivação, e não a interface usada para executar um teste, distingue testes baseados na especificação de testes baseados na estrutura.                                                                                                                                                                                                         |
| PT Explicação geral | A asserção sobre o resultado é funcional; a asserção sobre a latência é não funcional. Ambas podem exercitar a mesma operação. O acesso pela API e a concorrência, por si só, não determinam uma base de caixa-branca nem o nível de integração de sistemas.                                                                                             | A asserção sobre o resultado é funcional; a asserção sobre a latência é não funcional. Ambas podem exercitar a mesma operação. O acesso pela API e a concorrência, por si só, não determinam uma base de caixa-branca nem o nível de integração de sistemas.                                                                                             |
| EN Enunciado        | For a warehouse service, requirements specify the stock quantity returned for a valid barcode and a 95th-percentile response latency of at most 300 ms with 200 concurrent users. Tests use API calls derived from these requirements, not code structure. Select TWO correct classifications.                                                           | For a warehouse service, requirements specify the stock quantity returned for a valid barcode and a 95th-percentile response latency of at most 300 ms with 200 concurrent users. Tests use API calls derived from these requirements, not code structure. Select TWO correct classifications.                                                           |
| EN o1 text          | Checking the returned stock quantity targets functional correctness.                                                                                                                                                                                                                                                                                     | Checking the returned stock quantity targets functional correctness.                                                                                                                                                                                                                                                                                     |
| EN o1 explanation   | The assertion checks what the service does: returning the specified stock value for the input.                                                                                                                                                                                                                                                           | The assertion checks what the service does: returning the specified stock value for the input.                                                                                                                                                                                                                                                           |
| EN o2 text          | Checking latency is functional testing because it executes the same stock query.                                                                                                                                                                                                                                                                         | Checking latency is functional testing because it executes the same stock query.                                                                                                                                                                                                                                                                         |
| EN o2 explanation   | A non-functional test can reuse a functional operation while assessing a performance constraint rather than its functional output.                                                                                                                                                                                                                       | A non-functional test can reuse a functional operation while assessing a performance constraint rather than its functional output.                                                                                                                                                                                                                       |
| EN o3 text          | The concurrent users make the test level system integration, irrespective of the systems involved.                                                                                                                                                                                                                                                       | The concurrent users make the test level system integration, irrespective of the systems involved.                                                                                                                                                                                                                                                       |
| EN o3 explanation   | Concurrency is a load characteristic, not evidence of interfaces with external systems. Test level depends on the object and scope.                                                                                                                                                                                                                      | Concurrency is a load characteristic, not evidence of interfaces with external systems. Test level depends on the object and scope.                                                                                                                                                                                                                      |
| EN o4 text          | Checking the latency limit targets the non-functional characteristic performance efficiency.                                                                                                                                                                                                                                                             | Checking the latency limit targets the non-functional characteristic performance efficiency.                                                                                                                                                                                                                                                             |
| EN o4 explanation   | The time constraint describes how well the service performs its function. It is a non-functional quality constraint.                                                                                                                                                                                                                                     | The time constraint describes how well the service performs its function. It is a non-functional quality constraint.                                                                                                                                                                                                                                     |
| EN o5 text          | Using an API makes both tests white-box, even when their basis is the requirements.                                                                                                                                                                                                                                                                      | Using an API makes both tests white-box, even when their basis is the requirements.                                                                                                                                                                                                                                                                      |
| EN o5 explanation   | The derivation basis, not the interface used to execute a test, distinguishes specification-based from structure-based testing.                                                                                                                                                                                                                          | The derivation basis, not the interface used to execute a test, distinguishes specification-based from structure-based testing.                                                                                                                                                                                                                          |
| EN Explicação geral | The output assertion is functional; the latency assertion is non-functional. They can exercise the same operation. API access and concurrency do not by themselves determine a white-box basis or a system-integration test level.                                                                                                                       | The output assertion is functional; the latency assertion is non-functional. They can exercise the same operation. API access and concurrency do not by themselves determine a white-box basis or a system-integration test level.                                                                                                                       |


# tl-085 — revisão académica bilingue

**Parecer: ACCEPT_AS_IS. Revisão por IA; não aprovação humana.**

FL-5.2.4 / K2; versão 1; revisão 2026-10-27.10; SHA-256 canónico `7e58e2424021b96398caee8e0b489767e952131b97e642a63edbd1d8d8f2c161`.

Resposta pré-gabarito: `['o2', 'o5']`; registada em `2026-11-07T23:59:13.612875+00:00`. Chave consultada depois: `['o2', 'o5']`. A coincidência é apenas uma comparação; o fundamento, contraevidência, traduções e explicações são avaliados abaixo.

Formato publicado: 5 alternativas; selecionar 2.

## Resolução independente e fundamento

O conjunto o2/o5 distingue ações de controlo de repetição da análise inicial já concluída. Executar testes de mudança da hora escolhidos para reduzir um risco de faturação avaliado implementa mitigação. Verificar eficácia e adaptar respostas a riscos emergentes implementa monitorização/controlo. Listar eventos, classificar probabilidade/impacto e categorizar antes do tratamento são análise no contexto dado.

Raciocínio guardado antes da revelação:

A identificação e avaliação iniciais já produziram probabilidade e impacto. Executar testes orientados ao risco avaliado é mitigação; acompanhar eficácia e adaptar respostas a riscos emergentes é monitorização e controlo. Listar eventos, estimar classificações e agrupar riscos são tarefas de análise neste contexto. A distinção não proíbe análise futura quando surgirem riscos novos; impede apresentar repetição da análise inicial como a ação de controlo pedida.

## Referências oficiais e LO/K

EN ISTQB CTFL v4.0.1 (2024-09-15); PT oficial v4.0, tradução 1.0 (syllabus 21-04-2023). Páginas físicas, capa=1; edição, URLs, origem e hashes em sources.json.

- Secção 5.2.4: EN páginas [53]; PT páginas [59].
- Secção 5.2.3: EN páginas [52, 53]; PT páginas [58, 59].

- LO FL-5.2.4/K2: EN página 47; PT página 52.

EN secção 5.2.3 nas páginas 52–53 e PT nas páginas 58–59 descrevem identificação, avaliação e categorização. EN 5.2.4 na página 53 e PT na 59 definem mitigação e monitorização, incluindo eficácia e riscos emergentes. O exemplo de mudança da hora é aplicação do revisor à premissa publicada, não uma recomendação tarifária específica atribuída ao ISTQB.

Fontes efetivamente consultadas nesta execução. A aplicação ao cenário e os contraexemplos são interpretação do revisor, não novas regras oficiais. Não se declara igualdade textual entre edições. EN e PT acessíveis via web nesta execução; referências e páginas verificadas nas cópias oficiais locais, com origem e hashes declarados. Não se atribui qualificação humana à IA.

## Equivalência PT/EN

Initial identification and assessment/identificação e avaliação iniciais e already contains/já contém mantêm a premissa temporal. Rather than repeat that initial analysis/em vez de repetir essa análise inicial não quer dizer nunca mais analisar. Assessed billing risk/risco de faturação avaliado mantém ligação entre testes e risco. When emerging risks require it/quando os riscos emergentes o exigirem condiciona a adaptação, sem garantir eliminação de risco.

| EN literal                               | PT literal                             |
| ---------------------------------------- | -------------------------------------- |
| rather than repeat that initial analysis | em vez de repetir essa análise inicial |
| likelihood and impact                    | probabilidade e impacto                |
| clock-change tests                       | testes de mudança da hora              |
| emerging risks                           | riscos emergentes                      |

## Contraevidência e outras respostas defensáveis

Identificação e avaliação podem voltar a ocorrer quando novos riscos ou informação surgem; a fonte diz que monitorização melhora a avaliação e identifica riscos emergentes. Rather than repeat initial analysis delimita a pergunta à análise inicial já feita, não proíbe análise futura. Agrupar riscos pode ajudar a selecionar mitigação, mas o4 não implementa nem acompanha tratamento. Nenhuma regra tarifária específica ou mecanismo de mudança de hora é inferido.

## LO, nível K, explicações e dificuldade

K2: explicar medidas de resposta a riscos analisados e distingui-las de identificação, avaliação e categorização. Não se calculam probabilidades, impacto ou nível de risco K3. As cinco explicações e a síntese publicada sustentam a distinção sem impor um fluxo de gestão irreversível; monitorização pode alimentar nova análise. O contexto de contadores só exemplifica mitigação, não exige experiência de faturação.

## Textos integrais originais / proposto atual

Banco preservado. O proposto atual permanece idêntico ao original em todos os blocos; avaliação e sugestões não se confundem com texto publicado.

### Enunciado PT

Original

```text
Um projeto de contadores inteligentes concluiu a identificação e avaliação iniciais dos riscos de faturação; o registo já contém classificações de probabilidade e impacto. Selecione DUAS ações propostas que realizam controlo do risco de produto, em vez de repetir essa análise inicial.
```

Proposto atual — sem alteração

```text
Um projeto de contadores inteligentes concluiu a identificação e avaliação iniciais dos riscos de faturação; o registo já contém classificações de probabilidade e impacto. Selecione DUAS ações propostas que realizam controlo do risco de produto, em vez de repetir essa análise inicial.
```

### Enunciado EN

Original

```text
A smart-meter project has completed initial identification and assessment of billing risks; the register already contains likelihood and impact ratings. Select TWO proposed actions that perform product risk control rather than repeat that initial analysis.
```

Proposto atual — sem alteração

```text
A smart-meter project has completed initial identification and assessment of billing risks; the register already contains likelihood and impact ratings. Select TWO proposed actions that perform product risk control rather than repeat that initial analysis.
```

### o1 — alternativa PT

Original

```text
Listar potenciais eventos de risco de faturação antes de avaliar a sua importância.
```

Proposto atual — sem alteração

```text
Listar potenciais eventos de risco de faturação antes de avaliar a sua importância.
```

### o1 — explicação PT

Original

```text
Criar a lista inicial de riscos é identificação do risco, parte da análise, não execução nem monitorização de uma resposta.
```

Proposto atual — sem alteração

```text
Criar a lista inicial de riscos é identificação do risco, parte da análise, não execução nem monitorização de uma resposta.
```

### o1 — alternativa EN

Original

```text
List potential billing-risk events before evaluating their significance.
```

Proposto atual — sem alteração

```text
List potential billing-risk events before evaluating their significance.
```

### o1 — explicação EN

Original

```text
Creating the initial risk list is risk identification, part of risk analysis, not execution or monitoring of a response.
```

Proposto atual — sem alteração

```text
Creating the initial risk list is risk identification, part of risk analysis, not execution or monitoring of a response.
```

### o2 — alternativa PT

Original

```text
Executar testes de mudança da hora selecionados para mitigar o risco de faturação avaliado.
```

Proposto atual — sem alteração

```text
Executar testes de mudança da hora selecionados para mitigar o risco de faturação avaliado.
```

### o2 — explicação PT

Original

```text
Executar uma resposta de teste planeada para reduzir um risco avaliado é mitigação do risco, que faz parte do controlo do risco de produto.
```

Proposto atual — sem alteração

```text
Executar uma resposta de teste planeada para reduzir um risco avaliado é mitigação do risco, que faz parte do controlo do risco de produto.
```

### o2 — alternativa EN

Original

```text
Execute clock-change tests selected to mitigate the assessed billing risk.
```

Proposto atual — sem alteração

```text
Execute clock-change tests selected to mitigate the assessed billing risk.
```

### o2 — explicação EN

Original

```text
Executing a planned testing response to reduce an assessed risk is risk mitigation, which is part of product risk control.
```

Proposto atual — sem alteração

```text
Executing a planned testing response to reduce an assessed risk is risk mitigation, which is part of product risk control.
```

### o3 — alternativa PT

Original

```text
Estimar a probabilidade e o impacto para ordenar os riscos de faturação.
```

Proposto atual — sem alteração

```text
Estimar a probabilidade e o impacto para ordenar os riscos de faturação.
```

### o3 — explicação PT

Original

```text
A avaliação inicial de probabilidade e impacto pertence à análise do risco. Precede a escolha e implementação de uma resposta de controlo.
```

Proposto atual — sem alteração

```text
A avaliação inicial de probabilidade e impacto pertence à análise do risco. Precede a escolha e implementação de uma resposta de controlo.
```

### o3 — alternativa EN

Original

```text
Estimate likelihood and impact to rank the billing risks.
```

Proposto atual — sem alteração

```text
Estimate likelihood and impact to rank the billing risks.
```

### o3 — explicação EN

Original

```text
Initial likelihood and impact assessment belongs to risk analysis. It precedes choosing and implementing a control response.
```

Proposto atual — sem alteração

```text
Initial likelihood and impact assessment belongs to risk analysis. It precedes choosing and implementing a control response.
```

### o4 — alternativa PT

Original

```text
Agrupar os riscos de faturação avaliados por característica de qualidade antes de selecionar tratamentos.
```

Proposto atual — sem alteração

```text
Agrupar os riscos de faturação avaliados por característica de qualidade antes de selecionar tratamentos.
```

### o4 — explicação PT

Original

```text
A categorização na avaliação inicial apoia a análise do risco; por si só, não implementa nem monitoriza um tratamento.
```

Proposto atual — sem alteração

```text
A categorização na avaliação inicial apoia a análise do risco; por si só, não implementa nem monitoriza um tratamento.
```

### o4 — alternativa EN

Original

```text
Group the assessed billing risks by quality characteristic before selecting treatments.
```

Proposto atual — sem alteração

```text
Group the assessed billing risks by quality characteristic before selecting treatments.
```

### o4 — explicação EN

Original

```text
Categorization in the initial assessment supports risk analysis; it does not itself implement or monitor a treatment.
```

Proposto atual — sem alteração

```text
Categorization in the initial assessment supports risk analysis; it does not itself implement or monitor a treatment.
```

### o5 — alternativa PT

Original

```text
Verificar se a mitigação é eficaz e rever a resposta quando os riscos emergentes o exigirem.
```

Proposto atual — sem alteração

```text
Verificar se a mitigação é eficaz e rever a resposta quando os riscos emergentes o exigirem.
```

### o5 — explicação PT

Original

```text
A monitorização do risco verifica a eficácia, melhora a informação sobre o risco e identifica riscos emergentes para permitir adaptar a resposta.
```

Proposto atual — sem alteração

```text
A monitorização do risco verifica a eficácia, melhora a informação sobre o risco e identifica riscos emergentes para permitir adaptar a resposta.
```

### o5 — alternativa EN

Original

```text
Check whether mitigation is effective and revise the response when emerging risks require it.
```

Proposto atual — sem alteração

```text
Check whether mitigation is effective and revise the response when emerging risks require it.
```

### o5 — explicação EN

Original

```text
Risk monitoring checks effectiveness, improves information about risk and identifies emerging risks so the response can be adapted.
```

Proposto atual — sem alteração

```text
Risk monitoring checks effectiveness, improves information about risk and identifies emerging risks so the response can be adapted.
```

### Explicação geral PT

Original

```text
O controlo do risco de produto combina mitigação e monitorização. Executar os testes de mudança da hora selecionados implementa a mitigação; verificar a eficácia e adaptar a resposta realiza monitorização/controlo. As outras atividades descrevem identificação ou avaliação iniciais.
```

Proposto atual — sem alteração

```text
O controlo do risco de produto combina mitigação e monitorização. Executar os testes de mudança da hora selecionados implementa a mitigação; verificar a eficácia e adaptar a resposta realiza monitorização/controlo. As outras atividades descrevem identificação ou avaliação iniciais.
```

### Explicação geral EN

Original

```text
Product risk control combines mitigation and monitoring. Running the selected clock-change tests implements mitigation; checking effectiveness and adapting the response performs monitoring/control. The other activities describe initial identification or assessment.
```

Proposto atual — sem alteração

```text
Product risk control combines mitigation and monitoring. Running the selected clock-change tests implements mitigation; checking effectiveness and adapting the response performs monitoring/control. The other activities describe initial identification or assessment.
```

## Avaliação de todas as alternativas

### o1 — distrator

Incorreta neste pedido: listar eventos antes de avaliar importância é identificação, parte da análise inicial, e não implementação ou monitorização de resposta.

Listing potential events before judging significance is risk identification, a component of analysis already completed in the scenario. It is not the proposed implementation or monitoring of risk responses requested here.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o2 — correta

Correta: executar os testes de mudança da hora selecionados para o risco avaliado põe em prática mitigação; não garante eliminar todo risco de faturação.

Executing clock-change tests selected against an assessed billing risk implements a mitigation measure. It does not guarantee elimination of every billing risk or require inventing a particular tariff or daylight-saving rule.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o3 — distrator

Incorreta neste pedido: estimar probabilidade/impacto para ordenar riscos é avaliação; pode ser útil reavaliar mais tarde, mas aqui apenas repete a etapa inicial.

Estimating likelihood and impact and ranking risks is risk assessment, part of the initial analysis. Reassessment can be useful later, but this option simply repeats the analysis explicitly completed in the stem.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o4 — distrator

Incorreta neste pedido: agrupar por característica de qualidade categoriza a avaliação antes de tratamentos; por si só não executa nem acompanha a resposta.

Grouping assessed risks by quality characteristic helps organise analysis before treatment selection. As stated it does not implement mitigation or monitor effectiveness, unlike the two control actions among the options.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

### o5 — correta

Correta: verificar eficácia e adaptar resposta por riscos emergentes é monitorização/controlo, compatível com recolher informação para melhorar avaliações futuras.

Checking whether mitigation works and revising responses when emerging risks require it monitors and adapts product risk control. It allows future analysis of new information rather than asserting that initial analysis must never be revisited.

A explicação publicada foi confrontada com a análise individual acima e com as fontes; contraexemplos e limites do cenário estão explicitados no relatório. Não se transforma possibilidade em garantia nem se omite uma alternativa publicada.

## Histórico de versões

| Revisão      | Presente | Versão | Chave        | SHA-256 canónico                                                 |
| ------------ | -------- | ------ | ------------ | ---------------------------------------------------------------- |
| 2026-10-27.1 | False    | —      | —            | —                                                                |
| 2026-10-27.2 | False    | —      | —            | —                                                                |
| 2026-10-27.3 | False    | —      | —            | —                                                                |
| 2026-10-27.4 | False    | —      | —            | —                                                                |
| 2026-10-27.5 | False    | —      | —            | —                                                                |
| 2026-10-27.6 | False    | —      | —            | —                                                                |
| 2026-10-27.7 | False    | —      | —            | —                                                                |
| 2026-10-27.8 | False    | —      | —            | —                                                                |
| 2026-10-27.9 | True     | 1      | ['o2', 'o5'] | 7e58e2424021b96398caee8e0b489767e952131b97e642a63edbd1d8d8f2c161 |

A versão mais recente não foi assumida correta. Mudanças históricas são registadas, não substituídas. Não se inventam versões ausentes.

## Problemas, propostas e aprovação

Nenhum defeito académico obrigatório confirmado nem ambiguidade decisiva por resolver. Preferências de estilo sem impacto comprovado não justificam criar alterações. Não há proposta editorial ou de conteúdo para este item; optional-candidates.json permanece vazio.

OWNER_ACCEPTED não atribuído. HUMAN_APPROVED não atribuído; revisão humana independente PENDING. A antiga triagem NONE não foi fundamento. Dificuldade não calibrada empiricamente; testes automáticos não provam verdade académica. Fase 10H aberta. Concluir só Lote 16; reconciliação global e revisão humana são etapas separadas, não iniciadas automaticamente.

## Comparação literal lado a lado

| Campo               | Original                                                                                                                                                                                                                                                                                      | Proposto não aplicado — idêntico                                                                                                                                                                                                                                                              |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| PT Enunciado        | Um projeto de contadores inteligentes concluiu a identificação e avaliação iniciais dos riscos de faturação; o registo já contém classificações de probabilidade e impacto. Selecione DUAS ações propostas que realizam controlo do risco de produto, em vez de repetir essa análise inicial. | Um projeto de contadores inteligentes concluiu a identificação e avaliação iniciais dos riscos de faturação; o registo já contém classificações de probabilidade e impacto. Selecione DUAS ações propostas que realizam controlo do risco de produto, em vez de repetir essa análise inicial. |
| PT o1 text          | Listar potenciais eventos de risco de faturação antes de avaliar a sua importância.                                                                                                                                                                                                           | Listar potenciais eventos de risco de faturação antes de avaliar a sua importância.                                                                                                                                                                                                           |
| PT o1 explanation   | Criar a lista inicial de riscos é identificação do risco, parte da análise, não execução nem monitorização de uma resposta.                                                                                                                                                                   | Criar a lista inicial de riscos é identificação do risco, parte da análise, não execução nem monitorização de uma resposta.                                                                                                                                                                   |
| PT o2 text          | Executar testes de mudança da hora selecionados para mitigar o risco de faturação avaliado.                                                                                                                                                                                                   | Executar testes de mudança da hora selecionados para mitigar o risco de faturação avaliado.                                                                                                                                                                                                   |
| PT o2 explanation   | Executar uma resposta de teste planeada para reduzir um risco avaliado é mitigação do risco, que faz parte do controlo do risco de produto.                                                                                                                                                   | Executar uma resposta de teste planeada para reduzir um risco avaliado é mitigação do risco, que faz parte do controlo do risco de produto.                                                                                                                                                   |
| PT o3 text          | Estimar a probabilidade e o impacto para ordenar os riscos de faturação.                                                                                                                                                                                                                      | Estimar a probabilidade e o impacto para ordenar os riscos de faturação.                                                                                                                                                                                                                      |
| PT o3 explanation   | A avaliação inicial de probabilidade e impacto pertence à análise do risco. Precede a escolha e implementação de uma resposta de controlo.                                                                                                                                                    | A avaliação inicial de probabilidade e impacto pertence à análise do risco. Precede a escolha e implementação de uma resposta de controlo.                                                                                                                                                    |
| PT o4 text          | Agrupar os riscos de faturação avaliados por característica de qualidade antes de selecionar tratamentos.                                                                                                                                                                                     | Agrupar os riscos de faturação avaliados por característica de qualidade antes de selecionar tratamentos.                                                                                                                                                                                     |
| PT o4 explanation   | A categorização na avaliação inicial apoia a análise do risco; por si só, não implementa nem monitoriza um tratamento.                                                                                                                                                                        | A categorização na avaliação inicial apoia a análise do risco; por si só, não implementa nem monitoriza um tratamento.                                                                                                                                                                        |
| PT o5 text          | Verificar se a mitigação é eficaz e rever a resposta quando os riscos emergentes o exigirem.                                                                                                                                                                                                  | Verificar se a mitigação é eficaz e rever a resposta quando os riscos emergentes o exigirem.                                                                                                                                                                                                  |
| PT o5 explanation   | A monitorização do risco verifica a eficácia, melhora a informação sobre o risco e identifica riscos emergentes para permitir adaptar a resposta.                                                                                                                                             | A monitorização do risco verifica a eficácia, melhora a informação sobre o risco e identifica riscos emergentes para permitir adaptar a resposta.                                                                                                                                             |
| PT Explicação geral | O controlo do risco de produto combina mitigação e monitorização. Executar os testes de mudança da hora selecionados implementa a mitigação; verificar a eficácia e adaptar a resposta realiza monitorização/controlo. As outras atividades descrevem identificação ou avaliação iniciais.    | O controlo do risco de produto combina mitigação e monitorização. Executar os testes de mudança da hora selecionados implementa a mitigação; verificar a eficácia e adaptar a resposta realiza monitorização/controlo. As outras atividades descrevem identificação ou avaliação iniciais.    |
| EN Enunciado        | A smart-meter project has completed initial identification and assessment of billing risks; the register already contains likelihood and impact ratings. Select TWO proposed actions that perform product risk control rather than repeat that initial analysis.                              | A smart-meter project has completed initial identification and assessment of billing risks; the register already contains likelihood and impact ratings. Select TWO proposed actions that perform product risk control rather than repeat that initial analysis.                              |
| EN o1 text          | List potential billing-risk events before evaluating their significance.                                                                                                                                                                                                                      | List potential billing-risk events before evaluating their significance.                                                                                                                                                                                                                      |
| EN o1 explanation   | Creating the initial risk list is risk identification, part of risk analysis, not execution or monitoring of a response.                                                                                                                                                                      | Creating the initial risk list is risk identification, part of risk analysis, not execution or monitoring of a response.                                                                                                                                                                      |
| EN o2 text          | Execute clock-change tests selected to mitigate the assessed billing risk.                                                                                                                                                                                                                    | Execute clock-change tests selected to mitigate the assessed billing risk.                                                                                                                                                                                                                    |
| EN o2 explanation   | Executing a planned testing response to reduce an assessed risk is risk mitigation, which is part of product risk control.                                                                                                                                                                    | Executing a planned testing response to reduce an assessed risk is risk mitigation, which is part of product risk control.                                                                                                                                                                    |
| EN o3 text          | Estimate likelihood and impact to rank the billing risks.                                                                                                                                                                                                                                     | Estimate likelihood and impact to rank the billing risks.                                                                                                                                                                                                                                     |
| EN o3 explanation   | Initial likelihood and impact assessment belongs to risk analysis. It precedes choosing and implementing a control response.                                                                                                                                                                  | Initial likelihood and impact assessment belongs to risk analysis. It precedes choosing and implementing a control response.                                                                                                                                                                  |
| EN o4 text          | Group the assessed billing risks by quality characteristic before selecting treatments.                                                                                                                                                                                                       | Group the assessed billing risks by quality characteristic before selecting treatments.                                                                                                                                                                                                       |
| EN o4 explanation   | Categorization in the initial assessment supports risk analysis; it does not itself implement or monitor a treatment.                                                                                                                                                                         | Categorization in the initial assessment supports risk analysis; it does not itself implement or monitor a treatment.                                                                                                                                                                         |
| EN o5 text          | Check whether mitigation is effective and revise the response when emerging risks require it.                                                                                                                                                                                                 | Check whether mitigation is effective and revise the response when emerging risks require it.                                                                                                                                                                                                 |
| EN o5 explanation   | Risk monitoring checks effectiveness, improves information about risk and identifies emerging risks so the response can be adapted.                                                                                                                                                           | Risk monitoring checks effectiveness, improves information about risk and identifies emerging risks so the response can be adapted.                                                                                                                                                           |
| EN Explicação geral | Product risk control combines mitigation and monitoring. Running the selected clock-change tests implements mitigation; checking effectiveness and adapting the response performs monitoring/control. The other activities describe initial identification or assessment.                     | Product risk control combines mitigation and monitoring. Running the selected clock-change tests implements mitigation; checking effectiveness and adapting the response performs monitoring/control. The other activities describe initial identification or assessment.                     |


